#ifndef DEM_TYPES_H_
#define DEM_TYPES_H_
#include "Std_Types.h"

typedef uint16 Dem_EventIdType;
typedef uint32 Dem_DTCType;
typedef uint8  Dem_UdsStatusByteType;
typedef uint8  Dem_DTCSeverityType;
typedef uint8  Dem_OperationCycleIdType;

typedef enum
{
    DEM_UNINIT = 0,
    DEM_INIT_RESTORE_PENDING,
    DEM_INITIALIZED
} Dem_InitStateType;

typedef enum
{
    DEM_EVENT_STATUS_PASSED = 0,
    DEM_EVENT_STATUS_FAILED,
    DEM_EVENT_STATUS_PREPASSED,
    DEM_EVENT_STATUS_PREFAILED
} Dem_EventStatusType;

typedef enum
{
    DEM_CYCLE_STATE_END = 0,
    DEM_CYCLE_STATE_START
} Dem_OperationCycleStateType;

typedef enum
{
    DEM_DTC_FORMAT_UDS = 0
} Dem_DTCFormatType;

typedef enum
{
    DEM_DTC_ORIGIN_PRIMARY_MEMORY = 0
} Dem_DTCOriginType;

typedef enum
{
    DEM_CLEAR_IDLE = 0,
    DEM_CLEAR_PENDING,
    DEM_CLEAR_OK,
    DEM_CLEAR_FAILED
} Dem_ClearDTCStatusType;

#define DEM_UDS_STATUS_TF       0x01u
#define DEM_UDS_STATUS_TFTOC    0x02u
#define DEM_UDS_STATUS_PDTC     0x04u
#define DEM_UDS_STATUS_CDTC     0x08u
#define DEM_UDS_STATUS_TNCSLC   0x10u
#define DEM_UDS_STATUS_TFSLC    0x20u
#define DEM_UDS_STATUS_TNCTOC   0x40u
#define DEM_UDS_STATUS_WIR      0x80u

#define DEM_UDS_STATUS_AVAILABILITY_MASK \
    ((uint8)(DEM_UDS_STATUS_TF     | DEM_UDS_STATUS_TFTOC  | DEM_UDS_STATUS_PDTC | \
             DEM_UDS_STATUS_CDTC   | DEM_UDS_STATUS_TNCSLC | DEM_UDS_STATUS_TFSLC | \
             DEM_UDS_STATUS_TNCTOC | DEM_UDS_STATUS_WIR))

#define DEM_DTC_GROUP_ALL_DTCS 0x00FFFFFFu

typedef Std_ReturnType (*Dem_CaptureDataFctType)(
    Dem_EventIdType eventId,
    uint8 *buffer,
    uint16 *length
);

typedef void (*Dem_EventStatusChangedFctType)(
    Dem_EventIdType eventId,
    Dem_UdsStatusByteType oldStatus,
    Dem_UdsStatusByteType newStatus
);

typedef struct
{
    Dem_EventIdType EventId;
    Dem_DTCType DTC;

    Dem_DTCSeverityType Severity;
    uint8 Priority;

    sint16 FailedThreshold;
    sint16 PassedThreshold;
    sint16 IncrementStep;
    sint16 DecrementStep;

    uint8 ConfirmationThreshold;

    boolean AgingAllowed;
    uint8 AgingThreshold;

    boolean StorageEnabled;

    Dem_CaptureDataFctType SnapshotDataCapture;
    Dem_EventStatusChangedFctType StatusChangedCallback;
} Dem_EventConfigType;

typedef struct
{
    const Dem_EventConfigType *Events;
    uint16 EventCount;

    Dem_OperationCycleIdType DefaultOperationCycleId;

    uint16 NvMBlockId;

    Dem_EventStatusChangedFctType GlobalStatusChangedCallback;
} Dem_ConfigType;

#endif
