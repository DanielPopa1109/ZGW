/*
 * FreeRTOS_core1 Kernel V10.5.1
 * Copyright (C) 2021 Amazon.com, Inc. or its affiliates.  All Rights Reserved.
 *
 * SPDX-License-Identifier: MIT
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of
 * this software and associated documentation files (the "Software"), to deal in
 * the Software without restriction, including without limitation the rights to
 * use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
 * the Software, and to permit persons to whom the Software is furnished to do so,
 * subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
 * FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * https://www.FreeRTOS_core1.org
 * https://github.com/FreeRTOS_core1
 *
 */

#ifndef MPU_WRAPPERS_CORE1_H
#define MPU_WRAPPERS_CORE1_H

/* This file redefines API functions to be called through a wrapper macro, but
 * only for ports that are using the MPU. */
#if ( portUSING_MPU_WRAPPERS_core1 == 1 )

/* MPU_WRAPPERS_INCLUDED_FROM_API_FILE_core1 will be defined when this file is
 * included from queue.c or task_core1.c to prevent it from having an effect within
 * those files. */
    #ifndef MPU_WRAPPERS_INCLUDED_FROM_API_FILE_core1

/*
 * Map standard (non MPU) API functions to equivalents that start
 * "MPU_".  This will cause the application code to call the MPU_
 * version, which wraps the non-MPU version with privilege promoting
 * then demoting code, so the kernel code always runs will full
 * privileges.
 */
//
///* Map standard task_core1.h API functions to the MPU equivalents. */
//        #define xTaskCreate_core1                            MPU_xTaskCreate_core1
//        #define xTaskCreateStatic_core1                      MPU_xTaskCreateStatic_core1
//        #define vTaskDelete_core1                            MPU_vTaskDelete_core1
//        #define vTaskDelay_core1                             MPU_vTaskDelay_core1
//        #define xTaskDelayUntil                        MPU_xTaskDelayUntil_core1
//        #define xTaskAbortDelay                        MPU_xTaskAbortDelay_core1
//        #define uxTaskPriorityGet_core1                      MPU_uxTaskPriorityGet_core1
//        #define eTaskGetState_core1                          MPU_eTaskGetState_core1
//        #define vTaskGetInfo                           MPU_vTaskGetInfo_core1
//        #define vTaskPrioritySet_core1                       MPU_vTaskPrioritySet_core1
//        #define vTaskSuspend_core1                           MPU_vTaskSuspend_core1
//        #define vTaskResume_core1                            MPU_vTaskResume_core1
//        #define vTaskSuspendAll_core1                        MPU_vTaskSuspendAll_core1
//        #define xTaskResumeAll_core1                         MPU_xTaskResumeAll_core1
//        #define xTaskGetTickCount_core1                      MPU_xTaskGetTickCount_core1
//        #define uxTaskGetNumberOfTasks_core1                 MPU_uxTaskGetNumberOfTasks_core1
//        #define pcTaskGetName_core1                          MPU_pcTaskGetName_core1
//        #define xTaskGetHandle_core1                         MPU_xTaskGetHandle_core1
//        #define uxTaskGetStackHighWaterMark            MPU_uxTaskGetStackHighWaterMark_core1
//        #define uxTaskGetStackHighWaterMark2           MPU_uxTaskGetStackHighWaterMark2_core1
//        #define vTaskSetApplicationTaskTag             MPU_vTaskSetApplicationTaskTag_core1
//        #define xTaskGetApplicationTaskTag             MPU_xTaskGetApplicationTaskTag_core1
//        #define vTaskSetThreadLocalStoragePointer      MPU_vTaskSetThreadLocalStoragePointer_core1
//        #define pvTaskGetThreadLocalStoragePointer     MPU_pvTaskGetThreadLocalStoragePointer_core1
//        #define xTaskCallApplicationTaskHook           MPU_xTaskCallApplicationTaskHook_core1
//        #define xTaskGetIdleTaskHandle                 MPU_xTaskGetIdleTaskHandle_core1
//        #define uxTaskGetSystemState_core1                   MPU_uxTaskGetSystemState_core1
//        #define vTaskList                              MPU_vTaskList_core1
//        #define vTaskGetRunTimeStats                   MPU_vTaskGetRunTimeStats_core1
//        #define ulTaskGetIdleRunTimeCounter            MPU_ulTaskGetIdleRunTimeCounter_core1
//        #define ulTaskGetIdleRunTimePercent            MPU_ulTaskGetIdleRunTimePercent_core1
//        #define xTaskGenericNotify                     MPU_xTaskGenericNotify_core1
//        #define xTaskGenericNotifyWait                 MPU_xTaskGenericNotifyWait_core1
//        #define ulTaskGenericNotifyTake                MPU_ulTaskGenericNotifyTake_core1
//        #define xTaskGenericNotifyStateClear           MPU_xTaskGenericNotifyStateClear_core1
//        #define ulTaskGenericNotifyValueClear          MPU_ulTaskGenericNotifyValueClear_core1
//        #define xTaskCatchUpTicks_core1                      MPU_xTaskCatchUpTicks_core1
//
//        #define xTaskGetCurrentTaskHandle              MPU_xTaskGetCurrentTaskHandle_core1
//        #define vTaskSetTimeOutState                   MPU_vTaskSetTimeOutState_core1
//        #define xTaskCheckForTimeOut                   MPU_xTaskCheckForTimeOut_core1
//        #define xTaskGetSchedulerState_core1                 MPU_xTaskGetSchedulerState_core1
//
///* Map standard queue.h API functions to the MPU equivalents. */
//        #define xQueueGenericSend                      MPU_xQueueGenericSend_core1
//        #define xQueueReceive_core1                          MPU_xQueueReceive_core1
//        #define xQueuePeek                             MPU_xQueuePeek_core1
//        #define xQueueSemaphoreTake                    MPU_xQueueSemaphoreTake_core1
//        #define uxQueueMessagesWaiting                 MPU_uxQueueMessagesWaiting_core1
//        #define uxQueueSpacesAvailable                 MPU_uxQueueSpacesAvailable_core1
//        #define vQueueDelete                           MPU_vQueueDelete_core1
//        #define xQueueCreateMutex                      MPU_xQueueCreateMutex_core1
//        #define xQueueCreateMutexStatic                MPU_xQueueCreateMutexStatic_core1
//        #define xQueueCreateCountingSemaphore          MPU_xQueueCreateCountingSemaphore_core1
//        #define xQueueCreateCountingSemaphoreStatic    MPU_xQueueCreateCountingSemaphoreStatic_core1
//        #define xQueueGetMutexHolder                   MPU_xQueueGetMutexHolder_core1
//        #define xQueueTakeMutexRecursive               MPU_xQueueTakeMutexRecursive_core1
//        #define xQueueGiveMutexRecursive               MPU_xQueueGiveMutexRecursive_core1
//        #define xQueueGenericCreate                    MPU_xQueueGenericCreate_core1
//        #define xQueueGenericCreateStatic              MPU_xQueueGenericCreateStatic_core1
//        #define xQueueCreateSet                        MPU_xQueueCreateSet_core1
//        #define xQueueAddToSet                         MPU_xQueueAddToSet_core1
//        #define xQueueRemoveFromSet                    MPU_xQueueRemoveFromSet_core1
//        #define xQueueSelectFromSet                    MPU_xQueueSelectFromSet_core1
//        #define xQueueGenericReset                     MPU_xQueueGenericReset_core1
//
//        #if ( configQUEUE_REGISTRY_SIZE_core1 > 0 )
//            #define vQueueAddToRegistry_core1                MPU_vQueueAddToRegistry_core1
//            #define vQueueUnregisterQueue              MPU_vQueueUnregisterQueue_core1
//            #define pcQueueGetName                     MPU_pcQueueGetName_core1
//        #endif
//
///* Map standard timer.h API functions to the MPU equivalents. */
//        #define pvTimerGetTimerID_core1                      MPU_pvTimerGetTimerID_core1
//        #define vTimerSetTimerID                       MPU_vTimerSetTimerID_core1
//        #define xTimerIsTimerActive_core1                    MPU_xTimerIsTimerActive_core1
//        #define xTimerGetTimerDaemonTaskHandle_core1         MPU_xTimerGetTimerDaemonTaskHandle_core1
//        #define pcTimerGetName_core1                         MPU_pcTimerGetName_core1
//        #define vTimerSetReloadMode_core1                    MPU_vTimerSetReloadMode_core1
//        #define uxTimerGetReloadMode_core1                   MPU_uxTimerGetReloadMode_core1
//        #define xTimerGetPeriod_core1                        MPU_xTimerGetPeriod_core1
//        #define xTimerGetExpiryTime_core1                    MPU_xTimerGetExpiryTime_core1
//        #define xTimerGenericCommand_core1                   MPU_xTimerGenericCommand_core1

/* Map standard event_group.h API functions to the MPU equivalents. */
//        #define xEventGroupCreate_core1                      MPU_xEventGroupCreate_core1
//        #define xEventGroupCreateStatic_core1                MPU_xEventGroupCreateStatic_core1
//        #define xEventGroupWaitBits_core1                    MPU_xEventGroupWaitBits_core1
//        #define xEventGroupClearBits_core1                   MPU_xEventGroupClearBits_core1
//        #define xEventGroupSetBits_core1                     MPU_xEventGroupSetBits_core1
//        #define xEventGroupSync_core1                        MPU_xEventGroupSync_core1
//        #define vEventGroupDelete_core1                      MPU_vEventGroupDelete_core1

/* Map standard message/stream_buffer_core1.h API functions to the MPU
 * equivalents. */
//        #define xStreamBufferSend_core1                      MPU_xStreamBufferSend_core1
//        #define xStreamBufferReceive_core1                   MPU_xStreamBufferReceive_core1
//        #define xStreamBufferNextMessageLengthBytes_core1    MPU_xStreamBufferNextMessageLengthBytes_core1
//        #define vStreamBufferDelete_core1                    MPU_vStreamBufferDelete_core1
//        #define xStreamBufferIsFull_core1                    MPU_xStreamBufferIsFull_core1
//        #define xStreamBufferIsEmpty_core1                   MPU_xStreamBufferIsEmpty_core1
//        #define xStreamBufferReset_core1                     MPU_xStreamBufferReset_core1
//        #define xStreamBufferSpacesAvailable_core1           MPU_xStreamBufferSpacesAvailable_core1
//        #define xStreamBufferBytesAvailable            MPU_xStreamBufferBytesAvailable_core1
//        #define xStreamBufferSetTriggerLevel           MPU_xStreamBufferSetTriggerLevel_core1
//        #define xStreamBufferGenericCreate_core1             MPU_xStreamBufferGenericCreate_core1
//        #define xStreamBufferGenericCreateStatic_core1       MPU_xStreamBufferGenericCreateStatic_core1


/* Remove the privileged function macro, but keep the PRIVILEGED_DATA_core1
 * macro so applications can place data in privileged access sections
 * (useful when using statically allocated objects). */
        #define PRIVILEGED_FUNCTION_core1
        #define PRIVILEGED_DATA_core1    __attribute__( ( section( "privileged_data" ) ) )
        #define FREERTOS_SYSTEM_CALL_core1

    #else /* MPU_WRAPPERS_INCLUDED_FROM_API_FILE_core1 */

/* Ensure API functions go in the privileged execution section. */
        #define PRIVILEGED_FUNCTION_core1     __attribute__( ( section( "privileged_functions" ) ) )
        #define PRIVILEGED_DATA_core1         __attribute__( ( section( "privileged_data" ) ) )
        #define FREERTOS_SYSTEM_CALL_core1    __attribute__( ( section( "freertos_system_calls" ) ) )

    #endif /* MPU_WRAPPERS_INCLUDED_FROM_API_FILE_core1 */

#else /* portUSING_MPU_WRAPPERS_core1 */

    #define PRIVILEGED_FUNCTION_core1
    #define PRIVILEGED_DATA_core1
    #define FREERTOS_SYSTEM_CALL_core1

#endif /* portUSING_MPU_WRAPPERS_core1 */


#endif /* MPU_WRAPPERS_H */
