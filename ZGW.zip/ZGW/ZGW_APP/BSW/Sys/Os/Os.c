#include "Os.h"
#include "FreeRTOS_core0.h"
#include "FreeRTOS_core1.h"
#include "FreeRTOS_core2.h"
#include "FreeRTOSConfig_core0.h"
#include "FreeRTOSConfig_core1.h"
#include "FreeRTOSConfig_core2.h"
#include "McuSm.h"
#include "Can.h"
#include "SysMgr.h"
#include "Dcm.h"
#include "timers_core0.h"
#include "timers_core1.h"
#include "timers_core2.h"
#include "task_core0.h"
#include "task_core1.h"
#include "task_core2.h"
#include "CanIf.h"
#include "CanTp.h"
#include "Dcm_Cfg.h"
#include "LinIf.h"
#include "LinSM.h"
#include "PduR.h"
#include "Com.h"
#include "CanSM.h"
#include "CanDiag.h"
#include "LinDiag.h"
#include "LinTp.h"
#include "DoIP.h"
#include "SoAd.h"
#include "SomeIp.h"
#include "SomeIpSd.h"
#include "TcpIpH.h"
#include "EthStack.h"
#include "Fee.h"
#include "Nvm.h"
#include "Fls.h"
#include "Dem.h"
#include "GatewaySwc.h"
#include "APP/CodingApp/CodingApp.h"
#include "APP/ParallelFlashSwc/ParallelFlashSwc.h"
#include "SafetyKit_InternalWatchdogs.h"
#include "lwip_geth_conf.h"
#include "lwip_geth_lwip.h"
#include "Nm.h"
#include "CanNm.h"
#include "ComM.h"
#include "UdpNm.h"
#include "EthSM.h"
#include "EthernetDiag.h"
#include "APP/TimeSync/TimeBase.h"
#include "BSW/Com/Ethernet/EthTimeSync.h"
#include "APP/TimeSync/Gptp_Lab.h"
#include "APP/AiModel/AiModel.h"
#include "BSW/Com/Ethernet/EthStartupTiming.h"
#include "BSW/Io/GtmTom/GtmTom.h"
#include "BSW/Sys/CpuPerf/CpuPerf.h"

void Os_Init_C0(void);
void Os_Init_C1(void);
void Os_Init_C2(void);
void ASIL_BSW_Task_C0(void *pvParameters);
void ASIL_NVM_Task_C0(void *pvParameters);
void QM_DIAG_Task_C0(void *pvParameters);
void QM_CAN_Task_C0(void *pvParameters);
void QM_LIN_Task_C0(void *pvParameters);
void QM_BSW_Task_C0(void *pvParameters);
void QM_APPL_Task_C0(void *pvParameters);
void ASIL_BSW_Task_C1(void *pvParameters);
void QM_APPL_Task_C1(void *pvParameters);
void ASIL_BSW_Task_C2(void *pvParameters);
void QM_BSW_Task_C2(void *pvParameters);

void Alarm5ms_Callback_QM_DIAG_Task_C0( TimerHandle_t_core0 xTimer_core0 );
void Alarm5ms_Callback_QM_CAN_Task_C0( TimerHandle_t_core0 xTimer_core0 );
void Alarm5ms_Callback_QM_LIN_Task_C0( TimerHandle_t_core0 xTimer_core0 );
void Alarm5ms_Callback_ASIL_NVM_Task_C0( TimerHandle_t_core0 xTimer_core0 );
void Alarm5ms_Callback_ASIL_BSW_Task_C0( TimerHandle_t_core0 xTimer_core0 );
void Alarm5ms_Callback_QM_BSW_Task_C0( TimerHandle_t_core0 xTimer_core0 );
void Alarm5ms_Callback_QM_APPL_Task_C0( TimerHandle_t_core0 xTimer_core0 );
void Alarm5ms_Callback_ASIL_BSW_Task_C1( TimerHandle_t_core1 xTimer_core1);
void Alarm5ms_Callback_QM_APPL_Task_C1( TimerHandle_t_core1 xTimer_core1);
void Alarm5ms_Callback_ASIL_BSW_Task_C2( TimerHandle_t_core2 xTimer_core2);
void Alarm5ms_Callback_QM_BSW_Task_C2( TimerHandle_t_core2 xTimer_core2);

#define OS_CPU_CORE_0                  0u
#define OS_CPU_CORE_1                  1u
#define OS_CPU_CORE_2                  2u
#define OS_TASK_STACK_CORE0_ASIL_BSW   ( configMINIMAL_STACK_SIZE_core0 * 2u )
#define OS_TASK_STACK_CORE0_ASIL_NVM   ( configMINIMAL_STACK_SIZE_core0 * 2u )
#define OS_TASK_STACK_CORE0_QM_BSW     ( configMINIMAL_STACK_SIZE_core0 * 2u )
#define OS_TASK_STACK_CORE0_QM_DIAG    ( configMINIMAL_STACK_SIZE_core0 * 3u )
#define OS_TASK_STACK_CORE0_QM_CAN     ( configMINIMAL_STACK_SIZE_core0 * 2u )
#define OS_TASK_STACK_CORE0_QM_LIN     ( configMINIMAL_STACK_SIZE_core0 * 2u )
#define OS_TASK_STACK_CORE0_QM_APPL    ( configMINIMAL_STACK_SIZE_core0 * 2u )
#define OS_TASK_STACK_CORE1_ASIL_BSW   ( configMINIMAL_STACK_SIZE_core1 * 8u )
#define OS_TASK_STACK_CORE1_QM_APPL    ( configMINIMAL_STACK_SIZE_core1 * 8u )
#define OS_TASK_STACK_CORE2_ASIL_BSW   ( configMINIMAL_STACK_SIZE_core2 * 8u )
#define OS_TASK_STACK_CORE2_QM_BSW     ( configMINIMAL_STACK_SIZE_core2 * 8u )
#define OS_TASK_PRIO_CORE0_ASIL_BSW    28u
#define OS_TASK_PRIO_CORE0_QM_BSW      26u
#define OS_TASK_PRIO_CORE0_QM_CAN      25u
#define OS_TASK_PRIO_CORE0_QM_LIN      24u
#define OS_TASK_PRIO_CORE0_QM_DIAG     23u
#define OS_TASK_PRIO_CORE0_QM_APPL     21u
#define OS_TASK_PRIO_CORE1_ASIL_BSW    29u
#define OS_TASK_PRIO_CORE1_QM_APPL     28u
#define OS_TASK_PRIO_CORE0_ASIL_NVM    20u
#define OS_TASK_PRIO_CORE2_QM_BSW      28u
#define OS_TASK_PRIO_CORE2_ASIL_BSW    29u
#define OS_ETH_STARTUP_INIT_YIELD_RETRIES 16u
/*
 * Max Fls/Fee/NvM stack cycles ASIL_NVM runs per 5ms activation. Keep the batch
 * bounded to avoid monopolizing core0 while allowing QM tasks to run first.
 */
#define OS_NVM_MAIN_CYCLES_PER_ACTIVATION 256u
#define OS_CPU_LOAD_MAX_PERCENT        100u
#define OS_CPU_LOAD_MAX_PERMILLE       1000u
#define OS_CPU_LOAD_SAMPLE_TICKS       ((uint32)configTICK_RATE_HZ_core0)
#define OS_INIT_FAIL_C0_ASIL_TASK      1u
#define OS_INIT_FAIL_C0_QM_TASK        2u
#define OS_INIT_FAIL_C0_ASIL_TIMER     3u
#define OS_INIT_FAIL_C0_QM_TIMER       4u
#define OS_INIT_FAIL_C0_ASIL_START     5u
#define OS_INIT_FAIL_C0_QM_START       6u
#define OS_INIT_FAIL_C1_ASIL_TASK      7u
#define OS_INIT_FAIL_C1_APPL_TASK      8u
#define OS_INIT_FAIL_C1_ASIL_TIMER     9u
#define OS_INIT_FAIL_C1_APPL_TIMER     10u
#define OS_INIT_FAIL_C1_ASIL_START     11u
#define OS_INIT_FAIL_C1_APPL_START     12u
#define OS_INIT_FAIL_C2_ASIL_BSW_TASK  13u
#define OS_INIT_FAIL_C2_QM_TASK        14u
#define OS_INIT_FAIL_C0_QM_APPL_TASK   15u
#define OS_INIT_FAIL_C0_QM_APPL_TIMER  16u
#define OS_INIT_FAIL_C0_QM_APPL_START  17u
#define OS_INIT_FAIL_C0_QM_DIAG_TASK   19u
#define OS_INIT_FAIL_C0_QM_CAN_TASK    20u
#define OS_INIT_FAIL_C0_QM_LIN_TASK    21u
#define OS_INIT_FAIL_C0_ASIL_NVM_TASK  22u
#define OS_INIT_FAIL_C0_QM_DIAG_TIMER  23u
#define OS_INIT_FAIL_C0_QM_CAN_TIMER   24u
#define OS_INIT_FAIL_C0_QM_LIN_TIMER   25u
#define OS_INIT_FAIL_C0_ASIL_NVM_TIMER 26u
#define OS_INIT_FAIL_C0_QM_DIAG_START  27u
#define OS_INIT_FAIL_C0_QM_CAN_START   28u
#define OS_INIT_FAIL_C0_QM_LIN_START   29u
#define OS_INIT_FAIL_C0_ASIL_NVM_START 30u
#define OS_INIT_FAIL_C2_ASIL_BSW_TIMER 31u
#define OS_INIT_FAIL_C2_QM_TIMER       32u
#define OS_INIT_FAIL_C2_ASIL_BSW_START 33u
#define OS_INIT_FAIL_C2_QM_START       34u

enum
{
    OS_NVM_STARTUP_INIT_WAIT = 0,
    OS_NVM_STARTUP_READALL_START,
    OS_NVM_STARTUP_READALL_WAIT,
    OS_NVM_STARTUP_APPLY_READALL,
    OS_NVM_STARTUP_TIME_LOAD_WAIT,
    OS_NVM_STARTUP_TIME_STANDBY_PREPARE,
    OS_NVM_STARTUP_TIME_STANDBY_WAIT,
    OS_NVM_STARTUP_DEM_INIT,
    OS_NVM_STARTUP_DEM_WAIT,
    OS_NVM_STARTUP_OPERATION_CYCLE_START,
    OS_NVM_STARTUP_OPERATION_CYCLE_WAIT,
    OS_NVM_STARTUP_DEFERRED_FORMAT_START,
    OS_NVM_STARTUP_DEFERRED_FORMAT_WAIT,
    OS_NVM_STARTUP_DONE
};

typedef struct
{
        uint8 initialized;
        uint32 sampleTicks;
        uint32 lastRuntime;
        uint32 lastIdleRuntime;
        uint32 idleRuntime;
        uint32 idleTaskStartRuntime;
        uint8 currentTaskIsIdle;
} Os_CpuLoadRuntimeType;

static void Os_CpuLoad_RecordTick(uint8 CoreId);
static uint32 Os_CpuLoad_ReadRuntimeCounter(uint8 CoreId);
static void Os_CpuLoad_UpdateIdleRuntime(uint8 CoreId, uint32 RuntimeNow);
static uint8 Os_CpuLoad_PermilleToPercent(uint16 LoadPermille);
static void Os_CpuLoad_StorePublic(uint8 CoreId, uint16 LoadPermille, uint8 Valid);
static void Os_InitFailure(uint8 CoreId, uint32 Step);
static uint8 Os_TryInitEthStackCore2(void);
static boolean Os_NvMStackHasPendingJobs(void);
static void Os_NvMStartup_MainFunction(void);
void Os_CpuLoad_TaskSwitchedIn(uint8 CoreId, uint8 IsIdleTask);
void Os_CpuLoad_TaskSwitchedOut(uint8 CoreId);

volatile long long OS_Counter_core0 = 0u;
volatile long long IDLE_Counter_core0 = 0u;
volatile long long OS_Counter_core1 = 0u;
volatile long long IDLE_Counter_core1 = 0u;
volatile long long OS_Counter_core2 = 0u;
volatile long long IDLE_Counter_core2 = 0u;
volatile uint8 Os_CpuLoadPercent_core0 = OS_CPU_LOAD_INVALID_PERCENT;
volatile uint8 Os_CpuLoadPercent_core1 = OS_CPU_LOAD_INVALID_PERCENT;
volatile uint8 Os_CpuLoadPercent_core2 = OS_CPU_LOAD_INVALID_PERCENT;
volatile uint16 Os_CpuLoadPermille_core0 = OS_CPU_LOAD_INVALID_PERMILLE;
volatile uint16 Os_CpuLoadPermille_core1 = OS_CPU_LOAD_INVALID_PERMILLE;
volatile uint16 Os_CpuLoadPermille_core2 = OS_CPU_LOAD_INVALID_PERMILLE;
volatile uint8 Os_EthStackInitialized = 0u;
volatile uint8 Os_EthNetifReadyBeforeStackInit = 0u;
volatile uint32 Os_EthNetifWaitLoops = 0u;
volatile uint32 Os_EthStartupYieldRetries = 0u;
volatile uint32 Os_Core2AsilBswStackHighWater = 0u;
volatile uint32 Os_Core2QmBswStackHighWater = 0u;

uint8 Alarm5ms_Flag_QM_DIAG_Task_C0 = 0u;
uint8 Alarm5ms_Flag_QM_CAN_Task_C0 = 0u;
uint8 Alarm5ms_Flag_QM_LIN_Task_C0 = 0u;
uint8 Alarm5ms_Flag_ASIL_NVM_Task_C0 = 0u;
uint8 Alarm5ms_Flag_ASIL_BSW_Task_C0 = 0u;
uint8 Alarm5ms_Flag_QM_BSW_Task_C0 = 0u;
uint8 Alarm5ms_Flag_QM_APPL_Task_C0 = 0u;
uint8 Alarm5ms_Flag_ASIL_BSW_Task_C1 = 0u;
uint8 Alarm5ms_Flag_QM_APPL_Task_C1 = 0u;
uint8 Alarm5ms_Flag_ASIL_BSW_Task_C2 = 0u;
uint8 Alarm5ms_Flag_QM_BSW_Task_C2 = 0u;

TimerHandle_t_core0 Handler_Alarm5ms_Callback_QM_DIAG_Task_C0;
TimerHandle_t_core0 Handler_Alarm5ms_Callback_QM_CAN_Task_C0;
TimerHandle_t_core0 Handler_Alarm5ms_Callback_QM_LIN_Task_C0;
TimerHandle_t_core0 Handler_Alarm5ms_Callback_ASIL_NVM_Task_C0;
TimerHandle_t_core0 Handler_Alarm5ms_Callback_ASIL_BSW_Task_C0;
TimerHandle_t_core0 Handler_Alarm5ms_Callback_QM_BSW_Task_C0;
TimerHandle_t_core0 Handler_Alarm5ms_Callback_QM_APPL_Task_C0;
TimerHandle_t_core1 Handler_Alarm5ms_Callback_ASIL_BSW_Task_C1;
TimerHandle_t_core1 Handler_Alarm5ms_Callback_QM_APPL_Task_C1;
TimerHandle_t_core2 Handler_Alarm5ms_Callback_ASIL_BSW_Task_C2;
TimerHandle_t_core2 Handler_Alarm5ms_Callback_QM_BSW_Task_C2;

TaskHandle_t_core0 QM_DIAG_Task_C0_THandle ;
TaskHandle_t_core0 QM_CAN_Task_C0_THandle ;
TaskHandle_t_core0 QM_LIN_Task_C0_THandle ;
TaskHandle_t_core0 ASIL_NVM_Task_C0_THandle ;
TaskHandle_t_core0 ASIL_BSW_Task_C0_THandle ;
TaskHandle_t_core0 QM_BSW_Task_C0_THandle;
TaskHandle_t_core0 QM_APPL_Task_C0_THandle;
TaskHandle_t_core1 ASIL_BSW_Task_C1_THandle;
TaskHandle_t_core1 QM_APPL_Task_C1_THandle;
TaskHandle_t_core2 ASIL_BSW_Task_C2_THandle;
TaskHandle_t_core2 QM_BSW_Task_C2_THandle;

volatile uint8 Os_FreeRtosInitFailureCore = 0xFFu;
volatile uint32 Os_FreeRtosInitFailureStep = 0u;
static Os_CpuLoadRuntimeType Os_CpuLoadRuntime[OS_CPU_LOAD_CORE_COUNT];

long long ASIL_BSW_Task_C0_Counter = 0;
long long ASIL_NVM_Task_C0_Counter = 0;
long long QM_DIAG_Task_C0_Counter = 0;
long long QM_CAN_Task_C0_Counter = 0;
long long QM_LIN_Task_C0_Counter = 0;
long long QM_BSW_Task_C0_Counter = 0;
long long QM_APPL_Task_C0_Counter = 0;
long long ASIL_BSW_Task_C1_Counter = 0;
long long QM_APPL_Task_C1_Counter = 0;
long long AiModel_MainFunction_Counter = 0;
long long ASIL_BSW_Task_C2_Counter = 0;
long long QM_BSW_Task_C2_Counter = 0;
volatile uint32 Os_NvMBudgetHitCounter = 0u;
volatile uint8 Os_NvMStartupState = OS_NVM_STARTUP_INIT_WAIT;
volatile uint32 Os_NvMStartupMainCounter = 0u;
volatile uint32 Os_NvMStartupReadAllStartCounter = 0u;
volatile uint32 Os_NvMStartupDeferredFormatStartCounter = 0u;
volatile uint32 Os_NvMStartupErrorCounter = 0u;
volatile uint32 Os_NvMStartupLastErrorState = 0u;

void Os_Init_C0(void)
{
    if(xTaskCreate_core0(ASIL_BSW_Task_C0, "ASIL_BSW_Task_C0", OS_TASK_STACK_CORE0_ASIL_BSW, NULL, OS_TASK_PRIO_CORE0_ASIL_BSW, &ASIL_BSW_Task_C0_THandle) != pdPASS_core0)
    {
        Os_InitFailure(OS_CPU_CORE_0, OS_INIT_FAIL_C0_ASIL_TASK);
    }

    if(xTaskCreate_core0(QM_BSW_Task_C0, "QM_BSW_Task_C0", OS_TASK_STACK_CORE0_QM_BSW, NULL, OS_TASK_PRIO_CORE0_QM_BSW, &QM_BSW_Task_C0_THandle) != pdPASS_core0)
    {
        Os_InitFailure(OS_CPU_CORE_0, OS_INIT_FAIL_C0_QM_TASK);
    }

    if(xTaskCreate_core0(QM_DIAG_Task_C0, "QM_DIAG_Task_C0", OS_TASK_STACK_CORE0_QM_DIAG, NULL, OS_TASK_PRIO_CORE0_QM_DIAG, &QM_DIAG_Task_C0_THandle) != pdPASS_core0)
    {
        Os_InitFailure(OS_CPU_CORE_0, OS_INIT_FAIL_C0_QM_DIAG_TASK);
    }

    if(xTaskCreate_core0(QM_CAN_Task_C0, "QM_CAN_Task_C0", OS_TASK_STACK_CORE0_QM_CAN, NULL, OS_TASK_PRIO_CORE0_QM_CAN, &QM_CAN_Task_C0_THandle) != pdPASS_core0)
    {
        Os_InitFailure(OS_CPU_CORE_0, OS_INIT_FAIL_C0_QM_CAN_TASK);
    }

    if(xTaskCreate_core0(QM_LIN_Task_C0, "QM_LIN_Task_C0", OS_TASK_STACK_CORE0_QM_LIN, NULL, OS_TASK_PRIO_CORE0_QM_LIN, &QM_LIN_Task_C0_THandle) != pdPASS_core0)
    {
        Os_InitFailure(OS_CPU_CORE_0, OS_INIT_FAIL_C0_QM_LIN_TASK);
    }

    if(xTaskCreate_core0(ASIL_NVM_Task_C0, "ASIL_NVM_Task_C0", OS_TASK_STACK_CORE0_ASIL_NVM, NULL, OS_TASK_PRIO_CORE0_ASIL_NVM, &ASIL_NVM_Task_C0_THandle) != pdPASS_core0)
    {
        Os_InitFailure(OS_CPU_CORE_0, OS_INIT_FAIL_C0_ASIL_NVM_TASK);
    }

    if(xTaskCreate_core0(QM_APPL_Task_C0, "QM_APPL_Task_C0", OS_TASK_STACK_CORE0_QM_APPL, NULL, OS_TASK_PRIO_CORE0_QM_APPL, &QM_APPL_Task_C0_THandle) != pdPASS_core0)
    {
        Os_InitFailure(OS_CPU_CORE_0, OS_INIT_FAIL_C0_QM_APPL_TASK);
    }

    Handler_Alarm5ms_Callback_QM_DIAG_Task_C0 = xTimerCreate_core0("Alarm5ms_Callback_QM_DIAG_Task_C0",
            pdMS_TO_TICKS_core0(5u),
            1u,
            NULL,
            Alarm5ms_Callback_QM_DIAG_Task_C0);

    if(Handler_Alarm5ms_Callback_QM_DIAG_Task_C0 == NULL)
    {
        Os_InitFailure(OS_CPU_CORE_0, OS_INIT_FAIL_C0_QM_DIAG_TIMER);
    }

    Handler_Alarm5ms_Callback_QM_CAN_Task_C0 = xTimerCreate_core0("Alarm5ms_Callback_QM_CAN_Task_C0",
            pdMS_TO_TICKS_core0(5u),
            1u,
            NULL,
            Alarm5ms_Callback_QM_CAN_Task_C0);

    if(Handler_Alarm5ms_Callback_QM_CAN_Task_C0 == NULL)
    {
        Os_InitFailure(OS_CPU_CORE_0, OS_INIT_FAIL_C0_QM_CAN_TIMER);
    }

    Handler_Alarm5ms_Callback_QM_LIN_Task_C0 = xTimerCreate_core0("Alarm5ms_Callback_QM_LIN_Task_C0",
            pdMS_TO_TICKS_core0(5u),
            1u,
            NULL,
            Alarm5ms_Callback_QM_LIN_Task_C0);

    if(Handler_Alarm5ms_Callback_QM_LIN_Task_C0 == NULL)
    {
        Os_InitFailure(OS_CPU_CORE_0, OS_INIT_FAIL_C0_QM_LIN_TIMER);
    }

    Handler_Alarm5ms_Callback_ASIL_NVM_Task_C0 = xTimerCreate_core0("Alarm5ms_Callback_ASIL_NVM_Task_C0",
            pdMS_TO_TICKS_core0(5u),
            1u,
            NULL,
            Alarm5ms_Callback_ASIL_NVM_Task_C0);

    if(Handler_Alarm5ms_Callback_ASIL_NVM_Task_C0 == NULL)
    {
        Os_InitFailure(OS_CPU_CORE_0, OS_INIT_FAIL_C0_ASIL_NVM_TIMER);
    }

    Handler_Alarm5ms_Callback_ASIL_BSW_Task_C0 = xTimerCreate_core0("Alarm5ms_Callback_ASIL_BSW_Task_C0",
            pdMS_TO_TICKS_core0(5u),
            1u,
            NULL,
            Alarm5ms_Callback_ASIL_BSW_Task_C0);

    if(Handler_Alarm5ms_Callback_ASIL_BSW_Task_C0 == NULL)
    {
        Os_InitFailure(OS_CPU_CORE_0, OS_INIT_FAIL_C0_ASIL_TIMER);
    }

    Handler_Alarm5ms_Callback_QM_BSW_Task_C0 = xTimerCreate_core0("Alarm5ms_Callback_QM_BSW_Task_C0",
            pdMS_TO_TICKS_core0(5u),
            1u,
            NULL,
            Alarm5ms_Callback_QM_BSW_Task_C0);

    if(Handler_Alarm5ms_Callback_QM_BSW_Task_C0 == NULL)
    {
        Os_InitFailure(OS_CPU_CORE_0, OS_INIT_FAIL_C0_QM_TIMER);
    }

    Handler_Alarm5ms_Callback_QM_APPL_Task_C0 = xTimerCreate_core0("Alarm5ms_Callback_QM_APPL_Task_C0",
            pdMS_TO_TICKS_core0(5u),
            1u,
            NULL,
            Alarm5ms_Callback_QM_APPL_Task_C0);

    if(Handler_Alarm5ms_Callback_QM_APPL_Task_C0 == NULL)
    {
        Os_InitFailure(OS_CPU_CORE_0, OS_INIT_FAIL_C0_QM_APPL_TIMER);
    }

    if(xTimerStart_core0(Handler_Alarm5ms_Callback_QM_DIAG_Task_C0, pdMS_TO_TICKS_core0(5u)) != pdPASS_core0)
    {
        Os_InitFailure(OS_CPU_CORE_0, OS_INIT_FAIL_C0_QM_DIAG_START);
    }

    if(xTimerStart_core0(Handler_Alarm5ms_Callback_QM_CAN_Task_C0, pdMS_TO_TICKS_core0(5u)) != pdPASS_core0)
    {
        Os_InitFailure(OS_CPU_CORE_0, OS_INIT_FAIL_C0_QM_CAN_START);
    }

    if(xTimerStart_core0(Handler_Alarm5ms_Callback_QM_LIN_Task_C0, pdMS_TO_TICKS_core0(5u)) != pdPASS_core0)
    {
        Os_InitFailure(OS_CPU_CORE_0, OS_INIT_FAIL_C0_QM_LIN_START);
    }

    if(xTimerStart_core0(Handler_Alarm5ms_Callback_ASIL_NVM_Task_C0, pdMS_TO_TICKS_core0(5u)) != pdPASS_core0)
    {
        Os_InitFailure(OS_CPU_CORE_0, OS_INIT_FAIL_C0_ASIL_NVM_START);
    }

    if(xTimerStart_core0(Handler_Alarm5ms_Callback_ASIL_BSW_Task_C0, pdMS_TO_TICKS_core0(5u)) != pdPASS_core0)
    {
        Os_InitFailure(OS_CPU_CORE_0, OS_INIT_FAIL_C0_ASIL_START);
    }

    if(xTimerStart_core0(Handler_Alarm5ms_Callback_QM_BSW_Task_C0, pdMS_TO_TICKS_core0(5u)) != pdPASS_core0)
    {
        Os_InitFailure(OS_CPU_CORE_0, OS_INIT_FAIL_C0_QM_START);
    }

    if(xTimerStart_core0(Handler_Alarm5ms_Callback_QM_APPL_Task_C0, pdMS_TO_TICKS_core0(5u)) != pdPASS_core0)
    {
        Os_InitFailure(OS_CPU_CORE_0, OS_INIT_FAIL_C0_QM_APPL_START);
    }
}

void Os_Init_C1(void)
{
    if(xTaskCreate_core1(ASIL_BSW_Task_C1, "ASIL_BSW_Task_C1", OS_TASK_STACK_CORE1_ASIL_BSW, NULL, OS_TASK_PRIO_CORE1_ASIL_BSW, &ASIL_BSW_Task_C1_THandle) != pdPASS_core1)
    {
        Os_InitFailure(OS_CPU_CORE_1, OS_INIT_FAIL_C1_ASIL_TASK);
    }

    if(xTaskCreate_core1(QM_APPL_Task_C1, "QM_APPL_Task_C1", OS_TASK_STACK_CORE1_QM_APPL, NULL, OS_TASK_PRIO_CORE1_QM_APPL, &QM_APPL_Task_C1_THandle) != pdPASS_core1)
    {
        Os_InitFailure(OS_CPU_CORE_1, OS_INIT_FAIL_C1_APPL_TASK);
    }

    Handler_Alarm5ms_Callback_ASIL_BSW_Task_C1 = xTimerCreate_core1("Alarm5ms_Callback_ASIL_BSW_Task_C1",
            pdMS_TO_TICKS_core1(5u),
            1u,
            NULL,
            Alarm5ms_Callback_ASIL_BSW_Task_C1);
    if(Handler_Alarm5ms_Callback_ASIL_BSW_Task_C1 == NULL)
    {
        Os_InitFailure(OS_CPU_CORE_1, OS_INIT_FAIL_C1_ASIL_TIMER);
    }


    Handler_Alarm5ms_Callback_QM_APPL_Task_C1 = xTimerCreate_core1("Alarm5ms_Callback_QM_APPL_Task_C1",
            pdMS_TO_TICKS_core1(5u),
            1u,
            NULL,
            Alarm5ms_Callback_QM_APPL_Task_C1);
    if(Handler_Alarm5ms_Callback_QM_APPL_Task_C1 == NULL)
    {
        Os_InitFailure(OS_CPU_CORE_1, OS_INIT_FAIL_C1_APPL_TIMER);
    }

    if(xTimerStart_core1(Handler_Alarm5ms_Callback_ASIL_BSW_Task_C1, pdMS_TO_TICKS_core1(5u)) != pdPASS_core1)
    {
        Os_InitFailure(OS_CPU_CORE_1, OS_INIT_FAIL_C1_ASIL_START);
    }

    if(xTimerStart_core1(Handler_Alarm5ms_Callback_QM_APPL_Task_C1, pdMS_TO_TICKS_core1(5u)) != pdPASS_core1)
    {
        Os_InitFailure(OS_CPU_CORE_1, OS_INIT_FAIL_C1_APPL_START);
    }
}

void Os_Init_C2(void)
{
    if(xTaskCreate_core2(ASIL_BSW_Task_C2, "ASIL_BSW_Task_C2", OS_TASK_STACK_CORE2_ASIL_BSW, NULL, OS_TASK_PRIO_CORE2_ASIL_BSW, &ASIL_BSW_Task_C2_THandle) != pdPASS_core2)
    {
        Os_InitFailure(OS_CPU_CORE_2, OS_INIT_FAIL_C2_ASIL_BSW_TASK);
    }

    if(xTaskCreate_core2(QM_BSW_Task_C2, "QM_BSW_Task_C2", OS_TASK_STACK_CORE2_QM_BSW, NULL, OS_TASK_PRIO_CORE2_QM_BSW, &QM_BSW_Task_C2_THandle) != pdPASS_core2)
    {
        Os_InitFailure(OS_CPU_CORE_2, OS_INIT_FAIL_C2_QM_TASK);
    }

    Handler_Alarm5ms_Callback_ASIL_BSW_Task_C2 = xTimerCreate_core2("Alarm5ms_Callback_ASIL_BSW_Task_C2",
            pdMS_TO_TICKS_core2(5u),
            1u,
            NULL,
            Alarm5ms_Callback_ASIL_BSW_Task_C2);
    if(Handler_Alarm5ms_Callback_ASIL_BSW_Task_C2 == NULL)
    {
        Os_InitFailure(OS_CPU_CORE_2, OS_INIT_FAIL_C2_ASIL_BSW_TIMER);
    }

    Handler_Alarm5ms_Callback_QM_BSW_Task_C2 = xTimerCreate_core2("Alarm5ms_Callback_QM_BSW_Task_C2",
            pdMS_TO_TICKS_core2(5u),
            1u,
            NULL,
            Alarm5ms_Callback_QM_BSW_Task_C2);
    if(Handler_Alarm5ms_Callback_QM_BSW_Task_C2 == NULL)
    {
        Os_InitFailure(OS_CPU_CORE_2, OS_INIT_FAIL_C2_QM_TIMER);
    }

    if(xTimerStart_core2(Handler_Alarm5ms_Callback_ASIL_BSW_Task_C2, pdMS_TO_TICKS_core2(5u)) != pdPASS_core2)
    {
        Os_InitFailure(OS_CPU_CORE_2, OS_INIT_FAIL_C2_ASIL_BSW_START);
    }

    if(xTimerStart_core2(Handler_Alarm5ms_Callback_QM_BSW_Task_C2, pdMS_TO_TICKS_core2(5u)) != pdPASS_core2)
    {
        Os_InitFailure(OS_CPU_CORE_2, OS_INIT_FAIL_C2_QM_START);
    }

    CpuPerf_RegisterMonitoredTask(OS_CPU_CORE_2, (const void *)QM_BSW_Task_C2_THandle);
}

static void Os_InitFailure(uint8 CoreId, uint32 Step)
{
    Os_FreeRtosInitFailureCore = CoreId;
    Os_FreeRtosInitFailureStep = Step;

    McuSm_PerformResetHook(381u, (((uint32)CoreId) << 16u) | Step);

    for(;;)
    {
        /* Wait for reset. */
    }
}

void vApplicationMallocFailedHook_core0(void)
{
    McuSm_PerformResetHook(380u, 1u);
}

void vApplicationStackOverflowHook_core0(TaskHandle_t_core0 xTask, char * pcTaskName )
{
    McuSm_PerformResetHook(379u, 1u);
}

void vApplicationTickHook_core0(void)
{
    OS_Counter_core0++;
    Os_CpuLoad_RecordTick(OS_CPU_CORE_0);
}

void vApplicationIdleHook_core0(void)
{
    IDLE_Counter_core0++;
}

void vApplicationMallocFailedHook_core1(void)
{
    McuSm_PerformResetHook(380u, 2u);
}

void vApplicationStackOverflowHook_core1(TaskHandle_t_core1 xTask, char * pcTaskName )
{
    McuSm_PerformResetHook(379u, 2u);
}

void vApplicationTickHook_core1(void)
{
    OS_Counter_core1++;
    Os_CpuLoad_RecordTick(OS_CPU_CORE_1);
}

void vApplicationIdleHook_core1(void)
{
    IDLE_Counter_core1++;
}

void vApplicationMallocFailedHook_core2(void)
{
    McuSm_PerformResetHook(380u, 3u);
}

void vApplicationStackOverflowHook_core2(TaskHandle_t_core2 xTask, char * pcTaskName )
{
    McuSm_PerformResetHook(379u, 3u);
}

void vApplicationTickHook_core2(void)
{
    OS_Counter_core2++;
    Os_CpuLoad_RecordTick(OS_CPU_CORE_2);
}

void vApplicationIdleHook_core2(void)
{
    IDLE_Counter_core2++;
}

static uint32 Os_CpuLoad_ReadRuntimeCounter(uint8 CoreId)
{
    switch(CoreId)
    {
        case OS_CPU_CORE_0:
            return (uint32)portGET_RUN_TIME_COUNTER_VALUE_core0();

        case OS_CPU_CORE_1:
            return (uint32)portGET_RUN_TIME_COUNTER_VALUE_core1();

        case OS_CPU_CORE_2:
            return (uint32)portGET_RUN_TIME_COUNTER_VALUE_core2();

        default:
            return 0u;
    }
}

static void Os_CpuLoad_UpdateIdleRuntime(uint8 CoreId, uint32 RuntimeNow)
{
    Os_CpuLoadRuntimeType *runtime;

    if (CoreId >= OS_CPU_LOAD_CORE_COUNT)
    {
        return;
    }

    runtime = &Os_CpuLoadRuntime[CoreId];
    if (runtime->currentTaskIsIdle != 0u)
    {
        runtime->idleRuntime += RuntimeNow - runtime->idleTaskStartRuntime;
        runtime->idleTaskStartRuntime = RuntimeNow;
    }
}

void Os_CpuLoad_TaskSwitchedIn(uint8 CoreId, uint8 IsIdleTask)
{
    Os_CpuLoadRuntimeType *runtime;
    uint32 runtimeNow;

    if (CoreId >= OS_CPU_LOAD_CORE_COUNT)
    {
        return;
    }

    runtime = &Os_CpuLoadRuntime[CoreId];
    runtimeNow = Os_CpuLoad_ReadRuntimeCounter(CoreId);
    Os_CpuLoad_UpdateIdleRuntime(CoreId, runtimeNow);

    if (IsIdleTask != 0u)
    {
        runtime->currentTaskIsIdle = 1u;
        runtime->idleTaskStartRuntime = runtimeNow;
    }
    else
    {
        runtime->currentTaskIsIdle = 0u;
    }
}

void Os_CpuLoad_TaskSwitchedOut(uint8 CoreId)
{
    uint32 runtimeNow;

    if (CoreId >= OS_CPU_LOAD_CORE_COUNT)
    {
        return;
    }

    runtimeNow = Os_CpuLoad_ReadRuntimeCounter(CoreId);
    Os_CpuLoad_UpdateIdleRuntime(CoreId, runtimeNow);
    Os_CpuLoadRuntime[CoreId].currentTaskIsIdle = 0u;
}

static uint8 Os_CpuLoad_PermilleToPercent(uint16 LoadPermille)
{
    uint16 percent;

    if (LoadPermille == OS_CPU_LOAD_INVALID_PERMILLE)
    {
        return OS_CPU_LOAD_INVALID_PERCENT;
    }

    percent = (uint16)((LoadPermille + 5u) / 10u);

    if (percent > OS_CPU_LOAD_MAX_PERCENT)
    {
        percent = OS_CPU_LOAD_MAX_PERCENT;
    }

    return (uint8)percent;
}

static void Os_CpuLoad_StorePublic(uint8 CoreId, uint16 LoadPermille, uint8 Valid)
{
    uint16 permille;
    uint8 percent;

    permille = (Valid != 0u) ? LoadPermille : OS_CPU_LOAD_INVALID_PERMILLE;
    percent = Os_CpuLoad_PermilleToPercent(permille);

    switch(CoreId)
    {
        case OS_CPU_CORE_0:
            Os_CpuLoadPermille_core0 = permille;
            Os_CpuLoadPercent_core0 = percent;
            break;

        case OS_CPU_CORE_1:
            Os_CpuLoadPermille_core1 = permille;
            Os_CpuLoadPercent_core1 = percent;
            break;

        case OS_CPU_CORE_2:
            Os_CpuLoadPermille_core2 = permille;
            Os_CpuLoadPercent_core2 = percent;
            break;

        default:
            break;
    }
}

static void Os_CpuLoad_RecordTick(uint8 CoreId)
{
    Os_CpuLoadRuntimeType *runtime;
    uint32 runtimeNow;
    uint32 idleRuntimeNow;
    uint32 runtimeDelta;
    uint32 idleRuntimeDelta;
    uint32 busyRuntimeDelta;
    uint32 loadPermille;
    uint64 loadNumerator;

    if (CoreId >= OS_CPU_LOAD_CORE_COUNT)
    {
        return;
    }

    runtime = &Os_CpuLoadRuntime[CoreId];
    runtimeNow = Os_CpuLoad_ReadRuntimeCounter(CoreId);
    Os_CpuLoad_UpdateIdleRuntime(CoreId, runtimeNow);
    idleRuntimeNow = runtime->idleRuntime;

    if (runtime->initialized == 0u)
    {
        runtime->lastRuntime = runtimeNow;
        runtime->lastIdleRuntime = idleRuntimeNow;
        runtime->initialized = 1u;
        Os_CpuLoad_StorePublic(CoreId, OS_CPU_LOAD_INVALID_PERMILLE, 0u);
        return;
    }

    runtime->sampleTicks++;
    if (runtime->sampleTicks < OS_CPU_LOAD_SAMPLE_TICKS)
    {
        return;
    }

    runtime->sampleTicks = 0u;
    runtimeDelta = runtimeNow - runtime->lastRuntime;
    idleRuntimeDelta = idleRuntimeNow - runtime->lastIdleRuntime;
    runtime->lastRuntime = runtimeNow;
    runtime->lastIdleRuntime = idleRuntimeNow;

    if (runtimeDelta == 0u)
    {
        Os_CpuLoad_StorePublic(CoreId, OS_CPU_LOAD_INVALID_PERMILLE, 0u);
        return;
    }

    if (idleRuntimeDelta > runtimeDelta)
    {
        idleRuntimeDelta = runtimeDelta;
    }

    busyRuntimeDelta = runtimeDelta - idleRuntimeDelta;
    loadNumerator = ((uint64)busyRuntimeDelta * OS_CPU_LOAD_MAX_PERMILLE) + (runtimeDelta / 2u);
    loadPermille = (uint32)(loadNumerator / runtimeDelta);

    if (loadPermille > OS_CPU_LOAD_MAX_PERMILLE)
    {
        loadPermille = OS_CPU_LOAD_MAX_PERMILLE;
    }

    Os_CpuLoad_StorePublic(CoreId, (uint16)loadPermille, 1u);
}

uint16 Os_GetCpuLoadPermille(uint8 CoreId)
{
    switch(CoreId)
    {
        case OS_CPU_CORE_0:
            return Os_CpuLoadPermille_core0;

        case OS_CPU_CORE_1:
            return Os_CpuLoadPermille_core1;

        case OS_CPU_CORE_2:
            return Os_CpuLoadPermille_core2;

        default:
            return OS_CPU_LOAD_INVALID_PERMILLE;
    }
}

static boolean Os_NvMStackHasPendingJobs(void)
{
    NvM_StatusType nvmStatus;
    MemIf_StatusType feeStatus;
    MemIf_StatusType flsStatus;

    nvmStatus = NvM_GetStatus();
    feeStatus = Fee_GetStatus();
    flsStatus = Fls_GetStatus();

    if ((nvmStatus == NVM_BUSY) || (nvmStatus == NVM_BUSY_INTERNAL))
    {
        return TRUE;
    }

    if ((feeStatus == MEMIF_BUSY) || (feeStatus == MEMIF_BUSY_INTERNAL))
    {
        return TRUE;
    }

    if (flsStatus == MEMIF_BUSY)
    {
        return TRUE;
    }

    return FALSE;
}

static void Os_NvMStartup_RecordError(void)
{
    Os_NvMStartupErrorCounter++;
    Os_NvMStartupLastErrorState = (uint32)Os_NvMStartupState;
}

static void Os_NvMStartup_MainFunction(void)
{
    Os_NvMStartupMainCounter++;

    switch (Os_NvMStartupState)
    {
        case OS_NVM_STARTUP_INIT_WAIT:
            if (NvM_GetStatus() == NVM_IDLE)
            {
                Os_NvMStartupState = OS_NVM_STARTUP_READALL_START;
            }
            break;

        case OS_NVM_STARTUP_READALL_START:
            if (NvM_GetStatus() != NVM_IDLE)
            {
                break;
            }

            if (NvM_ReadAll() == E_OK)
            {
                Os_NvMStartupReadAllStartCounter++;
                Os_NvMStartupState = OS_NVM_STARTUP_READALL_WAIT;
            }
            else
            {
                Os_NvMStartup_RecordError();
            }
            break;

        case OS_NVM_STARTUP_READALL_WAIT:
            if (NvM_GetStatus() == NVM_IDLE)
            {
                Os_NvMStartupState = OS_NVM_STARTUP_APPLY_READALL;
            }
            break;

        case OS_NVM_STARTUP_APPLY_READALL:
            /* Release the finalized Ethernet timing snapshot only now. Before
             * this point NvM owns its RAM mirror and may still replace it. */
            EthStartupTiming_OnNvMReadAllComplete();
            CodingApp_OnNvMReadAllComplete();
            (void)TimeBase_LoadUtcFromNvM();
            Os_NvMStartupState = OS_NVM_STARTUP_TIME_LOAD_WAIT;
            break;

        case OS_NVM_STARTUP_TIME_LOAD_WAIT:
            if (NvM_GetStatus() == NVM_IDLE)
            {
                Os_NvMStartupState = OS_NVM_STARTUP_TIME_STANDBY_PREPARE;
            }
            break;

        case OS_NVM_STARTUP_TIME_STANDBY_PREPARE:
            if (NvM_GetStatus() != NVM_IDLE)
            {
                break;
            }

            (void)TimeBase_PrepareStandbyRtc();
            Os_NvMStartupState = OS_NVM_STARTUP_TIME_STANDBY_WAIT;
            break;

        case OS_NVM_STARTUP_TIME_STANDBY_WAIT:
            if (NvM_GetStatus() == NVM_IDLE)
            {
                Os_NvMStartupState = OS_NVM_STARTUP_DEM_INIT;
            }
            break;

        case OS_NVM_STARTUP_DEM_INIT:
            if (NvM_GetStatus() != NVM_IDLE)
            {
                break;
            }

            Dem_Init(&Dem_Config);
            Os_NvMStartupState = OS_NVM_STARTUP_DEM_WAIT;
            break;

        case OS_NVM_STARTUP_DEM_WAIT:
            Dem_MainFunction();
            if ((Dem_IsReady() != FALSE) && (NvM_GetStatus() == NVM_IDLE))
            {
                Os_NvMStartupState = OS_NVM_STARTUP_OPERATION_CYCLE_START;
            }
            break;

        case OS_NVM_STARTUP_OPERATION_CYCLE_START:
            if (NvM_GetStatus() != NVM_IDLE)
            {
                break;
            }

            (void)Dem_SetOperationCycleState(DEM_DEFAULT_OPERATION_CYCLE, DEM_CYCLE_STATE_START);

            Os_NvMStartupState = OS_NVM_STARTUP_OPERATION_CYCLE_WAIT;

            break;

        case OS_NVM_STARTUP_OPERATION_CYCLE_WAIT:

            Dem_MainFunction();

            if (NvM_GetStatus() == NVM_IDLE)
            {
                Os_NvMStartupState = OS_NVM_STARTUP_DEFERRED_FORMAT_START;
            }

            break;

        case OS_NVM_STARTUP_DEFERRED_FORMAT_START:
            if (NvM_GetStatus() != NVM_IDLE)
            {
                break;
            }

            if (NvM_StartDeferredDefaultImage() == E_OK)
            {
                Os_NvMStartupDeferredFormatStartCounter++;
                Os_NvMStartupState = OS_NVM_STARTUP_DEFERRED_FORMAT_WAIT;
            }
            else
            {
                Os_NvMStartup_RecordError();
                Os_NvMStartupState = OS_NVM_STARTUP_DONE;
            }

            break;

        case OS_NVM_STARTUP_DEFERRED_FORMAT_WAIT:
            if (NvM_GetStatus() == NVM_IDLE)
            {
                Os_NvMStartupState = OS_NVM_STARTUP_DONE;
            }

            break;

        case OS_NVM_STARTUP_DONE:
        default:
            break;
    }
}

void ASIL_BSW_Task_C0(void *pvParameters)
{
    while(1)
    {
        if(1u == Alarm5ms_Flag_ASIL_BSW_Task_C0)
        {
            CpuPerf_ContextType cpuPerfCtx;

            Alarm5ms_Flag_ASIL_BSW_Task_C0 = 0u;

            CpuPerf_Start(CPUPERF_ID_OS_ASIL_BSW_TASK_C0, &cpuPerfCtx);

            SysMgr_MainFunction();
            serviceCpuWatchdog();
            serviceSafetyWatchdog();

            CpuPerf_Stop(CPUPERF_ID_OS_ASIL_BSW_TASK_C0, &cpuPerfCtx);

            ASIL_BSW_Task_C0_Counter ++;

        }
        else
        {
            /* Do nothing. */
        }

        vTaskSuspend_core0(NULL);
    }
}

void ASIL_NVM_Task_C0(void *pvParameters)
{
    uint32 nvmCycleBudget;

    while(1)
    {
        if(1u == Alarm5ms_Flag_ASIL_NVM_Task_C0)
        {
            CpuPerf_ContextType activationPerfCtx;
            CpuPerf_ContextType segmentPerfCtx;

            Alarm5ms_Flag_ASIL_NVM_Task_C0 = 0u;

            CpuPerf_Start(CPUPERF_ID_OS_ASIL_NVM_TASK_C0, &activationPerfCtx);
            CpuPerf_Start(CPUPERF_ID_OS_NVM_STARTUP_MAIN_C0, &segmentPerfCtx);

            Os_NvMStartup_MainFunction();

            CpuPerf_Stop(CPUPERF_ID_OS_NVM_STARTUP_MAIN_C0, &segmentPerfCtx);
            nvmCycleBudget = OS_NVM_MAIN_CYCLES_PER_ACTIVATION;

            do
            {
                CpuPerf_Start(CPUPERF_ID_OS_NVM_FLS_MAIN_C0, &segmentPerfCtx);

                Fls_MainFunction();

                CpuPerf_Stop(CPUPERF_ID_OS_NVM_FLS_MAIN_C0, &segmentPerfCtx);
                CpuPerf_Start(CPUPERF_ID_OS_NVM_FEE_MAIN_C0, &segmentPerfCtx);

                Fee_MainFunction();

                CpuPerf_Stop(CPUPERF_ID_OS_NVM_FEE_MAIN_C0, &segmentPerfCtx);
                CpuPerf_Start(CPUPERF_ID_OS_NVM_NVM_MAIN_C0, &segmentPerfCtx);

                NvM_MainFunction();

                CpuPerf_Stop(CPUPERF_ID_OS_NVM_NVM_MAIN_C0, &segmentPerfCtx);

                ASIL_NVM_Task_C0_Counter ++;

                if (nvmCycleBudget > 0u)
                {
                    nvmCycleBudget--;
                }

                taskYIELD_core0();

            } while ((nvmCycleBudget > 0u) && (Os_NvMStackHasPendingJobs() != FALSE));

            if ((nvmCycleBudget == 0u) && (Os_NvMStackHasPendingJobs() != FALSE))
            {
                Os_NvMBudgetHitCounter++;
            }

            CpuPerf_Stop(CPUPERF_ID_OS_ASIL_NVM_TASK_C0, &activationPerfCtx);
        }
        else
        {
            /* Do nothing. */
        }

        vTaskSuspend_core0(NULL);
    }
}

void QM_BSW_Task_C0(void *pvParameters)
{
    while(1)
    {
        if(1u == Alarm5ms_Flag_QM_BSW_Task_C0)
        {
            Alarm5ms_Flag_QM_BSW_Task_C0 = 0u;
            Com_MainFunctionRx();
            ComM_MainFunction();
            Nm_MainFunction();
            CanNm_MainFunction();
            GtmTom_MainFunction();
            QM_BSW_Task_C0_Counter ++;
        }
        else
        {
            /* Do nothing. */
        }

        vTaskSuspend_core0(NULL);
    }
}

void QM_APPL_Task_C0(void *pvParameters)
{
    while(1)
    {
        if(1u == Alarm5ms_Flag_QM_APPL_Task_C0)
        {
            Alarm5ms_Flag_QM_APPL_Task_C0 = 0u;

            if (SYSMGR_RUN == SysMgr_EcuState)
            {
                GatewaySwc_MainFunction();
                CodingApp_MainFunction();
                ParallelFlashSwc_MainFunction();
            }

            GatewaySwc_RequestLinIfMainFunction();
            GatewaySwc_RequestComMainFunctionTx();
            TimeBase_MainFunction();
            QM_APPL_Task_C0_Counter++;
        }
        else
        {
            /* Do nothing. */
        }

        vTaskSuspend_core0(NULL);
    }
}

void QM_LIN_Task_C0(void *pvParameters)
{
    while(1)
    {
        if(1u == Alarm5ms_Flag_QM_LIN_Task_C0)
        {
            Alarm5ms_Flag_QM_LIN_Task_C0 = 0u;
            LinSM_MainFunction();
            LinTp_MainFunction();
            LinDiag_MainFunction();
            QM_LIN_Task_C0_Counter ++;
        }
        else
        {
            /* Do nothing. */
        }

        vTaskSuspend_core0(NULL);
    }
}

void QM_CAN_Task_C0(void *pvParameters)
{
    while(1)
    {
        if(1u == Alarm5ms_Flag_QM_CAN_Task_C0)
        {
            Alarm5ms_Flag_QM_CAN_Task_C0 = 0u;
            Can_MainFunction();
            CanSM_MainFunction();
            CanDiag_MainFunction();
            CanTp_MainFunction();
            QM_CAN_Task_C0_Counter++;
        }
        else
        {
            /* Do nothing. */
        }

        vTaskSuspend_core0(NULL);
    }
}


void QM_DIAG_Task_C0(void *pvParameters)
{
    while(1)
    {
        if(1u == Alarm5ms_Flag_QM_DIAG_Task_C0)
        {
            Alarm5ms_Flag_QM_DIAG_Task_C0 = 0u;
            PduR_DoIPCore0MainFunction();
            Dcm_MainFunction();
            Dem_MainFunction();
            QM_DIAG_Task_C0_Counter ++;
        }
        else
        {
            /* Do nothing. */
        }

        vTaskSuspend_core0(NULL);
    }
}

void ASIL_BSW_Task_C1(void *pvParameters)
{
    while(1)
    {
        if(1u == Alarm5ms_Flag_ASIL_BSW_Task_C1)
        {
            Alarm5ms_Flag_ASIL_BSW_Task_C1 = 0u;
            serviceCpuWatchdog();
            ASIL_BSW_Task_C1_Counter++;
        }
        else
        {
            /* Do nothing. */
        }

        vTaskSuspend_core1(NULL);
    }
}

void QM_APPL_Task_C1(void *pvParameters)
{
    while(1)
    {
        if(1u == Alarm5ms_Flag_QM_APPL_Task_C1)
        {
            Alarm5ms_Flag_QM_APPL_Task_C1 = 0u;
            AiModel_MainFunction();
            QM_APPL_Task_C1_Counter++;
        }
        else
        {
            /* Do nothing. */
        }

        vTaskSuspend_core1(NULL);
    }
}

void ASIL_BSW_Task_C2(void *pvParameters)
{
    (void)pvParameters;

    while(1)
    {
        if(1u == Alarm5ms_Flag_ASIL_BSW_Task_C2)
        {
            Alarm5ms_Flag_ASIL_BSW_Task_C2 = 0u;
            Os_Core2AsilBswStackHighWater = (uint32)uxTaskGetStackHighWaterMark_core2(ASIL_BSW_Task_C2_THandle);
            serviceCpuWatchdog();
            ASIL_BSW_Task_C2_Counter++;
        }
        else
        {
            /* Do nothing. */
        }

        vTaskSuspend_core2(NULL);
    }
}

static uint8 Os_TryInitEthStackCore2(void)
{
    if (Os_EthStackInitialized != 0u)
    {
        return 1u;
    }

    if (g_LwipInitDone == 0u)
    {
        return 0u;
    }

    Os_EthNetifReadyBeforeStackInit = 1u;

    EthStartupTiming_Capture(ETHSTARTUPTIMING_EVENT_ETH_STARTUP_ENTER);

    EthStack_Init();

    EthTimeSync_Init();

    Gptp_Lab_Init();

    UdpNm_Init();

    EthSM_Init();

    Os_EthStackInitialized = 1u;

    return 1u;
}

void QM_BSW_Task_C2(void *pvParameters)
{
    uint32 startupRetry;

    (void)pvParameters;

    EthStartupTiming_Capture(ETHSTARTUPTIMING_EVENT_ETH_STARTUP_ENTER);

    (void)LWIP_GETH_Init(lwip_geth_handle);

    Os_EthNetifWaitLoops = 0u;

    for (startupRetry = 0u;
            (startupRetry < OS_ETH_STARTUP_INIT_YIELD_RETRIES) &&
                    (Os_TryInitEthStackCore2() == 0u);
            startupRetry++)
    {
        Os_EthStartupYieldRetries++;
        taskYIELD_core2();
    }

    if (Os_EthStackInitialized != 0u)
    {
        UdpNm_MainFunction();
        EthTimeSync_MainFunction(5u);

        Gptp_Lab_MainFunction(5u);

        SomeIpSd_MainFunction(5);

        lwip_geth_Lwip_pollTimerFlags();

        lwip_geth_Lwip_pollReceiveFlags();

        lwip_geth_Lwip_watchRxProgress();

        TcpIp_MainFunction();

        SoAd_MainFunction();

        GatewaySwc_EthernetMainFunction();

        DoIP_MainFunction(5);

        PduR_DoIPCore2MainFunction();

        SomeIp_MainFunction(5);

        EthSM_MainFunction();

        EthernetDiag_MainFunction();
    }

    while(1)
    {
        if(1u == Alarm5ms_Flag_QM_BSW_Task_C2)
        {
            CpuPerf_ContextType cpuPerfCtx;
            CpuPerf_ContextType componentPerfCtx;

            Alarm5ms_Flag_QM_BSW_Task_C2 = 0u;
            CpuPerf_Start(CPUPERF_ID_OS_QM_BSW_TASK_C2, &cpuPerfCtx);

            if (Os_EthStackInitialized == 0u)
            {
                Os_EthNetifWaitLoops++;
                (void)Os_TryInitEthStackCore2();
            }

            if (Os_EthStackInitialized != 0u)
            {
                CpuPerf_Start(CPUPERF_ID_C2_NETWORK_MGMT, &componentPerfCtx);

                UdpNm_MainFunction();

                EthTimeSync_MainFunction(5u);

                Gptp_Lab_MainFunction(5u);

                SomeIpSd_MainFunction(5);

                CpuPerf_Stop(CPUPERF_ID_C2_NETWORK_MGMT, &componentPerfCtx);

                CpuPerf_Start(CPUPERF_ID_C2_LWIP_SERVICE, &componentPerfCtx);

                lwip_geth_Lwip_pollTimerFlags();

                lwip_geth_Lwip_pollReceiveFlags();

                lwip_geth_Lwip_watchRxProgress();

                CpuPerf_Stop(CPUPERF_ID_C2_LWIP_SERVICE, &componentPerfCtx);

                TcpIp_MainFunction();

                SoAd_MainFunction();

                GatewaySwc_EthernetMainFunction();

                DoIP_MainFunction(5);

                PduR_DoIPCore2MainFunction();

                CpuPerf_Start(CPUPERF_ID_C2_SOMEIP, &componentPerfCtx);

                SomeIp_MainFunction(5);

                CpuPerf_Stop(CPUPERF_ID_C2_SOMEIP, &componentPerfCtx);

                CpuPerf_Start(CPUPERF_ID_C2_ETH_STATE_DIAG, &componentPerfCtx);

                EthSM_MainFunction();

                EthernetDiag_MainFunction();

                CpuPerf_Stop(CPUPERF_ID_C2_ETH_STATE_DIAG, &componentPerfCtx);
            }

            Os_Core2QmBswStackHighWater = (uint32)uxTaskGetStackHighWaterMark_core2(QM_BSW_Task_C2_THandle);

            CpuPerf_Stop(CPUPERF_ID_OS_QM_BSW_TASK_C2, &cpuPerfCtx);

            QM_BSW_Task_C2_Counter++;
        }
        else
        {
            /* Do nothing. */
        }

        vTaskSuspend_core2(NULL);
    }
}

void Alarm5ms_Callback_QM_DIAG_Task_C0( TimerHandle_t_core0 xTimer_core0 )
{
    Alarm5ms_Flag_QM_DIAG_Task_C0 = 1u;
    vTaskResume_core0(QM_DIAG_Task_C0_THandle);
}

void Alarm5ms_Callback_QM_CAN_Task_C0( TimerHandle_t_core0 xTimer_core0 )
{
    Alarm5ms_Flag_QM_CAN_Task_C0 = 1u;
    vTaskResume_core0(QM_CAN_Task_C0_THandle);
}

void Alarm5ms_Callback_QM_LIN_Task_C0( TimerHandle_t_core0 xTimer_core0 )
{
    Alarm5ms_Flag_QM_LIN_Task_C0 = 1u;
    vTaskResume_core0(QM_LIN_Task_C0_THandle);
}

void Alarm5ms_Callback_ASIL_NVM_Task_C0( TimerHandle_t_core0 xTimer_core0 )
{
    Alarm5ms_Flag_ASIL_NVM_Task_C0 = 1u;
    vTaskResume_core0(ASIL_NVM_Task_C0_THandle);
}

void Alarm5ms_Callback_ASIL_BSW_Task_C0( TimerHandle_t_core0 xTimer_core0 )
{
    Alarm5ms_Flag_ASIL_BSW_Task_C0 = 1u;
    vTaskResume_core0(ASIL_BSW_Task_C0_THandle);
}

void Alarm5ms_Callback_QM_BSW_Task_C0( TimerHandle_t_core0 xTimer_core0 )
{
    Alarm5ms_Flag_QM_BSW_Task_C0 = 1u;
    vTaskResume_core0(QM_BSW_Task_C0_THandle);
}

void Alarm5ms_Callback_QM_APPL_Task_C0( TimerHandle_t_core0 xTimer_core0 )
{
    Alarm5ms_Flag_QM_APPL_Task_C0 = 1u;
    vTaskResume_core0(QM_APPL_Task_C0_THandle);
}

void Alarm5ms_Callback_ASIL_BSW_Task_C1( TimerHandle_t_core1 xTimer_core1 )
{
    Alarm5ms_Flag_ASIL_BSW_Task_C1 = 1u;
    vTaskResume_core1(ASIL_BSW_Task_C1_THandle);
}

void Alarm5ms_Callback_QM_APPL_Task_C1( TimerHandle_t_core1 xTimer_core1 )
{
    Alarm5ms_Flag_QM_APPL_Task_C1 = 1u;
    vTaskResume_core1(QM_APPL_Task_C1_THandle);
}

void Alarm5ms_Callback_ASIL_BSW_Task_C2( TimerHandle_t_core2 xTimer_core2 )
{
    Alarm5ms_Flag_ASIL_BSW_Task_C2 = 1u;
    vTaskResume_core2(ASIL_BSW_Task_C2_THandle);
}

void Alarm5ms_Callback_QM_BSW_Task_C2( TimerHandle_t_core2 xTimer_core2 )
{
    Alarm5ms_Flag_QM_BSW_Task_C2 = 1u;
    vTaskResume_core2(QM_BSW_Task_C2_THandle);
}
