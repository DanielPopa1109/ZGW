/* EthStack_Cfg.c */
#include "SoAd.h"
#include "DoIP.h"
#include "SomeIp.h"
#include "SomeIpSd.h"
#include "Dcm_EthTpBridge.h"
#include "PduR.h"

#define SOAD_SOCON_DOIP_UDP        0u
#define SOAD_SOCON_DOIP_TCP        1u
#define SOAD_SOCON_SOMEIP_SD_UDP   2u
#define SOAD_SOCON_SOMEIP_UDP      3u
#define SOAD_SOCON_PDUR_IF_UDP      4u

static void Demo_MethodHandler(SoAd_SoConIdType soConId,
                               const TcpIp_SockAddrType *remoteAddr,
                               const SomeIp_MessageType *request)
{
    static const uint8_t payload[] = {0x12u, 0x34u};
    (void)SomeIp_SendResponse(soConId,
                              remoteAddr,
                              request,
                              payload,
                              sizeof(payload),
                              SOMEIP_RET_OK);
}

static const SomeIp_MethodConfigType SomeIpMethods[] =
{
    {
        .serviceId = 0x1234u,
        .methodId = 0x0001u,
        .interfaceVersion = 0x01u,
        .handler = Demo_MethodHandler
    }
};

const SomeIp_ConfigType SomeIp_Config =
{
    .udpSoConId = SOAD_SOCON_SOMEIP_UDP,
    .tcpSoConId = 0xFFu,
    .methods = SomeIpMethods,
    .methodCount = sizeof(SomeIpMethods) / sizeof(SomeIpMethods[0])
};

static const SomeIpSd_OfferedServiceType OfferedServices[] =
{
    {
        .serviceId = 0x1234u,
        .instanceId = 0x0001u,
        .majorVersion = 0x01u,
        .ttl = 3u,
        .udpPort = 30500u,
        .tcpPort = 0u
    }
};

const SomeIpSd_ConfigType SomeIpSd_Config =
{
    .sdUdpSoConId = SOAD_SOCON_SOMEIP_SD_UDP,
    .multicastAddr = {0xE0F4E0F5u, 30490u},
    .services = OfferedServices,
    .serviceCount = sizeof(OfferedServices) / sizeof(OfferedServices[0]),
    .offerPeriodMs = 1000u
};

static const SoAd_SocketConnectionConfigType SoAdConnections[] =
{
    {
        .soConId = SOAD_SOCON_DOIP_UDP,
        .upperLayer = SOAD_UPPER_DOIP,
        .protocol = TCPIP_PROTOCOL_UDP,
        .isServer = 1u,
        .useConfiguredRemote = 0u,
        .localAddr = {{192u, 168u, 1u, 10u}, 13400u},
        .remoteAddr = {{255u, 255u, 255u, 255u}, 13400u},
        .rxIndication = DoIP_SoAdUdpRxIndication,
        .tcpConnected = 0,
        .tcpDisconnected = 0
    },
    {
        .soConId = SOAD_SOCON_DOIP_TCP,
        .upperLayer = SOAD_UPPER_DOIP,
        .protocol = TCPIP_PROTOCOL_TCP,
        .isServer = 1u,
        .useConfiguredRemote = 0u,
        .localAddr = {{192u, 168u, 1u, 10u}, 13400u},
        .remoteAddr = {{0u, 0u, 0u, 0u}, 0u},
        .rxIndication = DoIP_SoAdTcpRxIndication,
        .tcpConnected = DoIP_SoAdTcpConnected,
        .tcpDisconnected = DoIP_SoAdTcpDisconnected
    },
    {
        .soConId = SOAD_SOCON_SOMEIP_SD_UDP,
        .upperLayer = SOAD_UPPER_SOMEIP_SD,
        .protocol = TCPIP_PROTOCOL_UDP,
        .isServer = 1u,
        .useConfiguredRemote = 0u,
        .localAddr = {{192u, 168u, 1u, 10u}, 30490u},
        .remoteAddr = {{224u, 244u, 224u, 245u}, 30490u},
        .rxIndication = SomeIpSd_SoAdRxIndication,
        .tcpConnected = 0,
        .tcpDisconnected = 0
    },
    {
        .soConId = SOAD_SOCON_SOMEIP_UDP,
        .upperLayer = SOAD_UPPER_SOMEIP,
        .protocol = TCPIP_PROTOCOL_UDP,
        .isServer = 1u,
        .useConfiguredRemote = 0u,
        .localAddr = {{192u, 168u, 1u, 10u}, 30500u},
        .remoteAddr = {{0u, 0u, 0u, 0u}, 0u},
        .rxIndication = SomeIp_SoAdRxIndication,
        .tcpConnected = 0,
        .tcpDisconnected = 0
    },
    {
        .soConId = SOAD_SOCON_PDUR_IF_UDP,
        .upperLayer = SOAD_UPPER_NONE,
        .protocol = TCPIP_PROTOCOL_UDP,
        .isServer = 1u,
        .useConfiguredRemote = 1u,
        .localAddr = {{192u, 168u, 1u, 10u}, 30600u},
        .remoteAddr = {{192u, 168u, 1u, 255u}, 30600u},
        .rxIndication = PduR_SoAdIfRxIndication,
        .tcpConnected = 0,
        .tcpDisconnected = 0
    }
};

const SoAd_ConfigType SoAd_Config =
{
    .connections = SoAdConnections,
    .numConnections  = sizeof(SoAdConnections) / sizeof(SoAdConnections[0])
};

const DoIP_ConfigType DoIP_Config =
{
    .vin = "WBAJA9C51KG240310",
    .eid = {0x02u, 0x00u, 0x00u, 0x00u, 0x00u, 0x01u},
    .gid = {0x03u, 0x00u, 0x00u, 0x00u, 0x00u, 0x01u},
    .logicalAddress = 0x1001u,
    .testerLogicalAddress = 0x0710u,
    .udpSoConId = SOAD_SOCON_DOIP_UDP,
    .tcpSoConId = SOAD_SOCON_DOIP_TCP
};
