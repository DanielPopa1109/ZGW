#include "Lin_Protocol.h"

uint8 Lin_MakePid(uint8 id)
{
    uint8 p0;
    uint8 p1;

    id &= 0x3Fu;

    p0 = (uint8)(((id >> 0u) ^ (id >> 1u) ^ (id >> 2u) ^ (id >> 4u)) & 1u);
    p1 = (uint8)(~(((id >> 1u) ^ (id >> 3u) ^ (id >> 4u) ^ (id >> 5u)) & 1u) & 1u);

    return (uint8)(id | (p0 << 6u) | (p1 << 7u));
}

Std_ReturnType Lin_CheckPid(uint8 pid, uint8* idOut)
{
    uint8 id;

    if (idOut == NULL_PTR)
    {
        return E_NOT_OK;
    }

    id = (uint8)(pid & 0x3Fu);

    if (Lin_MakePid(id) != pid)
    {
        return E_NOT_OK;
    }

    *idOut = id;
    return E_OK;
}
