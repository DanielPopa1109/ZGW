#include "CanTp.h"
#include "Dcm_Cfg.h"
#include "GatewaySwc.h"
#include "PduR.h"
#include "BSW/Sys/CpuPerf/CpuPerf.h"
#include <string.h>

#define CANTP_TX_CF_BURST_BUDGET 16u

typedef enum
{
    CANTP_DIR_NONE = 0u,
    CANTP_DIR_RX,
    CANTP_DIR_TX
} CanTp_DirectionType;

typedef enum
{
    CANTP_TXFRAME_NONE = 0u,
    CANTP_TXFRAME_SF,
    CANTP_TXFRAME_FF,
    CANTP_TXFRAME_CF,
    CANTP_TXFRAME_FC
} CanTp_TxFrameType;

typedef struct
{
    CanTp_StateType state;
    CanTp_DirectionType direction;
    CanTp_TimerType timerType;

    PduLengthType rxLen;
    PduLengthType rxExpectedLen;
    uint8 rxNextSn;
    uint8 rxBlockCounter;

    uint8 txBufferIdx;
    PduLengthType txLen;
    PduLengthType txOffset;
    uint8 txSn;
    uint8 txBlockCounter;
    uint8 txBlockSize;
    uint8 txStMinTicks;
    uint8 txStTimer;
    uint8 txWaitFrameCounter;
    uint8 txAssumeFlowControl;
    uint8 txBusy;
    CanTp_TxFrameType pendingTxFrame;

    uint16 timer;
} CanTp_ChannelStateType;

static const CanTp_ChannelConfigType CanTp_ChannelConfig[] =
{
    { CANIF_PDU_CLASSIC_PHYS_RX, CANIF_PDU_CLASSIC_PHYS_TX,      DCM_RX_CAN_PHYS,        DCM_TX_CAN_PHYS,        CANTP_ADDR_PHYSICAL,   8u,  8u, 0u, 0x00u, CANTP_FORMAT_NORMAL,   0u,                    0u,                  CANTP_PADDING_ON, CANTP_N_AS_TICKS, CANTP_N_AR_TICKS, CANTP_N_BS_TICKS, CANTP_N_BR_TICKS, CANTP_N_CS_TICKS, CANTP_N_CR_TICKS },
    { CANIF_PDU_FD_PHYS_RX,      CANIF_PDU_FD_PHYS_TX,           DCM_RX_CANFD_PHYS,      DCM_TX_CANFD_PHYS,      CANTP_ADDR_PHYSICAL,   64u, 8u, 0u, 0x00u, CANTP_FORMAT_NORMAL,   0u,                    0u,                  CANTP_PADDING_ON, CANTP_N_AS_TICKS, CANTP_N_AR_TICKS, CANTP_N_BS_TICKS, CANTP_N_BR_TICKS, CANTP_N_CS_TICKS, CANTP_N_CR_TICKS },
    { CANIF_PDU_CLASSIC_PHYS_RX, CANIF_PDU_CLASSIC_EXT_PHYS_TX0, DCM_RX_CAN_EXT_PHYS,    DCM_TX_CAN_EXT_PHYS,    CANTP_ADDR_PHYSICAL,   8u,  8u, 0u, 0x00u, CANTP_FORMAT_EXTENDED, DCM_EXT_ADDR_ZGW,          DCM_EXT_ADDR_TESTER,   CANTP_PADDING_ON, CANTP_N_AS_TICKS, CANTP_N_AR_TICKS, CANTP_N_BS_TICKS, CANTP_N_BR_TICKS, CANTP_N_CS_TICKS, CANTP_N_CR_TICKS },
    { CANIF_PDU_CLASSIC_PHYS_RX, CANIF_PDU_CLASSIC_EXT_PHYS_TX1, DCM_RX_CAN_EXT_PHYS_2,  DCM_TX_CAN_EXT_PHYS_2,  CANTP_ADDR_PHYSICAL,   8u,  8u, 0u, 0x00u, CANTP_FORMAT_EXTENDED, DCM_EXT_ADDR_ZGW,          DCM_EXT_ADDR_TESTER,   CANTP_PADDING_ON, CANTP_N_AS_TICKS, CANTP_N_AR_TICKS, CANTP_N_BS_TICKS, CANTP_N_BR_TICKS, CANTP_N_CS_TICKS, CANTP_N_CR_TICKS },
    { CANIF_PDU_CLASSIC_PHYS_RX, CANIF_PDU_CLASSIC_EXT_PHYS_TX2, DCM_RX_CAN_EXT_PHYS_3,  DCM_TX_CAN_EXT_PHYS_3,  CANTP_ADDR_PHYSICAL,   8u,  8u, 0u, 0x00u, CANTP_FORMAT_EXTENDED, DCM_EXT_ADDR_ZGW,          DCM_EXT_ADDR_TESTER,   CANTP_PADDING_ON, CANTP_N_AS_TICKS, CANTP_N_AR_TICKS, CANTP_N_BS_TICKS, CANTP_N_BR_TICKS, CANTP_N_CS_TICKS, CANTP_N_CR_TICKS },
    { CANIF_PDU_CLASSIC_PHYS_RX, CANIF_PDU_CLASSIC_EXT_PHYS_TX3, DCM_RX_CAN_EXT_PHYS_4,  DCM_TX_CAN_EXT_PHYS_4,  CANTP_ADDR_PHYSICAL,   8u,  8u, 0u, 0x00u, CANTP_FORMAT_EXTENDED, DCM_EXT_ADDR_ZGW,          DCM_EXT_ADDR_TESTER,   CANTP_PADDING_ON, CANTP_N_AS_TICKS, CANTP_N_AR_TICKS, CANTP_N_BS_TICKS, CANTP_N_BR_TICKS, CANTP_N_CS_TICKS, CANTP_N_CR_TICKS },
    { CANIF_PDU_FD_PHYS_RX,      CANIF_PDU_FD_EXT_PHYS_TX0,      DCM_RX_CANFD_EXT_PHYS,  DCM_TX_CANFD_EXT_PHYS,  CANTP_ADDR_PHYSICAL,   64u, 8u, 0u, 0x00u, CANTP_FORMAT_EXTENDED, DCM_EXT_ADDR_ZGW,          DCM_EXT_ADDR_TESTER,   CANTP_PADDING_ON, CANTP_N_AS_TICKS, CANTP_N_AR_TICKS, CANTP_N_BS_TICKS, CANTP_N_BR_TICKS, CANTP_N_CS_TICKS, CANTP_N_CR_TICKS }
};

const CanTp_ConfigType CanTp_Config =
{
    CanTp_ChannelConfig,
    (uint8)(sizeof(CanTp_ChannelConfig) / sizeof(CanTp_ChannelConfig[0]))
};

static const CanTp_ConfigType* CanTp_ConfigPtr;
static CanTp_ChannelStateType CanTp_Channel[CANTP_MAX_CHANNELS];
static uint8 CanTp_TxPayloadBuffer[CANTP_MAX_TX_BUFFERS][CANTP_MAX_PAYLOAD_LEN];
static uint8 CanTp_TxPayloadBufferInUse[CANTP_MAX_TX_BUFFERS];
static uint8 CanTp_TxPayloadBufferOwner[CANTP_MAX_TX_BUFFERS];
static uint8 CanTp_TxAddressOverrideValid[CANTP_MAX_CHANNELS];
static uint8 CanTp_TxAddressOverride[CANTP_MAX_CHANNELS];

#if CANTP_DEBUG_INSTRUMENTATION
volatile uint32 CanTp_DebugExtendedTxRequests = 0u;
volatile uint32 CanTp_DebugExtendedTxOk = 0u;
volatile uint32 CanTp_DebugExtendedTxFail = 0u;
volatile uint16 CanTp_DebugExtendedLastUpperTxPdu = 0u;
volatile uint16 CanTp_DebugExtendedLastLen = 0u;
volatile uint8 CanTp_DebugExtendedLastTarget = 0u;
volatile uint8 CanTp_DebugExtendedLastChannel = 0xFFu;
volatile uint8 CanTp_DebugExtendedLastState = 0xFFu;
volatile uint8 CanTp_DebugExtendedLastReason = CANTP_DEBUG_EXT_TX_BAD_CONFIG;
#endif

#if CANTP_DEBUG_INSTRUMENTATION
#define CANTP_DEBUG_ASSIGN(lhs, rhs) do { (lhs) = (rhs); } while (0)
#define CANTP_DEBUG_INC(lhs) do { (lhs)++; } while (0)
#else
#define CANTP_DEBUG_ASSIGN(lhs, rhs) do { (void)0; } while (0)
#define CANTP_DEBUG_INC(lhs) do { (void)0; } while (0)
#endif

static uint8 CanTp_IsConfigValid(void);

#define CANTP_TX_BUFFER_INVALID 0xFFu

static void CanTp_ResetTxPayloadBufferPool(void)
{
    uint8 i;

    for (i = 0u; i < CANTP_MAX_TX_BUFFERS; i++)
    {
        CanTp_TxPayloadBufferInUse[i] = FALSE;
        CanTp_TxPayloadBufferOwner[i] = CANTP_TX_BUFFER_INVALID;
    }
}

static uint8* CanTp_GetTxPayloadBuffer(uint8 ch)
{
    uint8 idx;

    if (ch >= CANTP_MAX_CHANNELS)
    {
        return NULL_PTR;
    }

    idx = CanTp_Channel[ch].txBufferIdx;

    if ((idx >= CANTP_MAX_TX_BUFFERS) ||
        (CanTp_TxPayloadBufferInUse[idx] == FALSE) ||
        (CanTp_TxPayloadBufferOwner[idx] != ch))
    {
        return NULL_PTR;
    }

    return CanTp_TxPayloadBuffer[idx];
}

static Std_ReturnType CanTp_AllocTxPayloadBuffer(uint8 ch)
{
    uint8 i;

    if (CanTp_GetTxPayloadBuffer(ch) != NULL_PTR)
    {
        return E_OK;
    }

    for (i = 0u; i < CANTP_MAX_TX_BUFFERS; i++)
    {
        if (CanTp_TxPayloadBufferInUse[i] == FALSE)
        {
            CanTp_TxPayloadBufferInUse[i] = TRUE;
            CanTp_TxPayloadBufferOwner[i] = ch;
            CanTp_Channel[ch].txBufferIdx = i;
            return E_OK;
        }
    }

    return E_NOT_OK;
}

static void CanTp_ReleaseTxPayloadBuffer(uint8 ch)
{
    uint8 idx;

    if (ch >= CANTP_MAX_CHANNELS)
    {
        return;
    }

    idx = CanTp_Channel[ch].txBufferIdx;

    if ((idx < CANTP_MAX_TX_BUFFERS) &&
        (CanTp_TxPayloadBufferOwner[idx] == ch))
    {
        CanTp_TxPayloadBufferInUse[idx] = FALSE;
        CanTp_TxPayloadBufferOwner[idx] = CANTP_TX_BUFFER_INVALID;
    }

    CanTp_Channel[ch].txBufferIdx = CANTP_TX_BUFFER_INVALID;
}

static uint8 CanTp_UsesAddressByte(const CanTp_ChannelConfigType* cfg)
{
    if (cfg == NULL_PTR)
    {
        return 0u;
    }

    if ((cfg->addressFormat == CANTP_FORMAT_EXTENDED) ||
        (cfg->addressFormat == CANTP_FORMAT_MIXED))
    {
        return TRUE;
    }

    return FALSE;
}

static uint8 CanTp_GetAddrOffset(const CanTp_ChannelConfigType* cfg)
{
    if (CanTp_UsesAddressByte(cfg) != FALSE)
    {
        return 1u;
    }

    return 0u;
}

static uint8 CanTp_GetSfMaxPayload(const CanTp_ChannelConfigType* cfg)
{
    uint8 off;

    if (cfg == NULL_PTR)
    {
        return 0u;
    }

    off = CanTp_GetAddrOffset(cfg);

    if (cfg->canDl <= (uint8)(off + 1u))
    {
        return 0u;
    }

    if (cfg->canDl <= 8u)
    {
        return (uint8)(cfg->canDl - off - 1u);
    }

    if (cfg->canDl <= (uint8)(off + 2u))
    {
        return 0u;
    }

    return (uint8)(cfg->canDl - off - 2u);
}

static uint8 CanTp_CanUseExtendedFfLength(const CanTp_ChannelConfigType* cfg)
{
    /* Lab deviation: the 32-bit FF_DL escape format is valid on classic 8-byte
     * frames per ISO 15765-2, so it is no longer restricted to CAN-FD (canDl>8).
     * This lets large diagnostic responses (e.g. 19 0A reportSupportedDTC) span
     * more than CANTP_LEGACY_MAX_PAYLOAD_LEN over standard CAN. */
    return (cfg != NULL_PTR) ? TRUE : FALSE;
}

static uint8 CanTp_GetFfPayload(const CanTp_ChannelConfigType* cfg, uint8 pciLen)
{
    uint8 off;

    if (cfg == NULL_PTR)
    {
        return 0u;
    }

    off = CanTp_GetAddrOffset(cfg);

    if (cfg->canDl <= (uint8)(off + pciLen))
    {
        return 0u;
    }

    return (uint8)(cfg->canDl - off - pciLen);
}

static uint8 CanTp_GetCfPayload(const CanTp_ChannelConfigType* cfg)
{
    return (uint8)(cfg->canDl - 1u - CanTp_GetAddrOffset(cfg));
}

static void CanTp_ClearFrame(uint8* frame, uint8 len, uint8 padding)
{
    memset(frame, padding, len);
}

static uint8 CanTp_GetCanFdFrameLen(uint8 bytesNeeded)
{
    if (bytesNeeded <= 8u)
    {
        return 8u;
    }
    if (bytesNeeded <= 12u)
    {
        return 12u;
    }
    if (bytesNeeded <= 16u)
    {
        return 16u;
    }
    if (bytesNeeded <= 20u)
    {
        return 20u;
    }
    if (bytesNeeded <= 24u)
    {
        return 24u;
    }
    if (bytesNeeded <= 32u)
    {
        return 32u;
    }
    if (bytesNeeded <= 48u)
    {
        return 48u;
    }

    return 64u;
}

static uint8 CanTp_GetTxFrameLenForBytes(const CanTp_ChannelConfigType* cfg,
                                         uint8 bytesNeeded)
{
    uint8 frameLen;

    if (cfg == NULL_PTR)
    {
        return 0u;
    }

    if (cfg->canDl <= 8u)
    {
        return cfg->canDl;
    }

    frameLen = CanTp_GetCanFdFrameLen(bytesNeeded);

    return (frameLen > cfg->canDl) ? cfg->canDl : frameLen;
}

static uint8 CanTp_CheckRxAddress(const CanTp_ChannelConfigType* cfg,
                                  const uint8* data,
                                  PduLengthType len)
{
    if ((cfg == NULL_PTR) || (data == NULL_PTR) || (len == 0u))
    {
        return FALSE;
    }

    if (CanTp_UsesAddressByte(cfg) != FALSE)
    {
        if (len < 2u)
        {
            return FALSE;
        }

        if (data[0] != cfg->nTa)
        {
            return FALSE;
        }
    }

    return TRUE;
}

static uint8 CanTp_GetRxPciIndex(const CanTp_ChannelConfigType* cfg)
{
    return CanTp_GetAddrOffset(cfg);
}

static void CanTp_SetTxAddress(uint8 ch, const CanTp_ChannelConfigType* cfg, uint8* frame)
{
    if ((frame != NULL_PTR) && (CanTp_UsesAddressByte(cfg) != FALSE))
    {
        frame[0] = (CanTp_TxAddressOverrideValid[ch] != FALSE) ? CanTp_TxAddressOverride[ch] : cfg->txNta;
    }
}

static uint16 CanTp_GetTimerTicks(uint8 ch, CanTp_TimerType timer)
{
    const CanTp_ChannelConfigType* cfg;

    if ((CanTp_IsConfigValid() != FALSE) && (ch < CanTp_ConfigPtr->numChannels))
    {
        cfg = &CanTp_ConfigPtr->channels[ch];
    }
    else
    {
        cfg = NULL_PTR;
    }

    switch (timer)
    {
        case CANTP_TIMER_N_AS: return (cfg != NULL_PTR) ? cfg->nAsTicks : (uint16)CANTP_N_AS_TICKS;
        case CANTP_TIMER_N_AR: return (cfg != NULL_PTR) ? cfg->nArTicks : (uint16)CANTP_N_AR_TICKS;
        case CANTP_TIMER_N_BS: return (cfg != NULL_PTR) ? cfg->nBsTicks : (uint16)CANTP_N_BS_TICKS;
        case CANTP_TIMER_N_BR: return (cfg != NULL_PTR) ? cfg->nBrTicks : (uint16)CANTP_N_BR_TICKS;
        case CANTP_TIMER_N_CS: return (cfg != NULL_PTR) ? cfg->nCsTicks : (uint16)CANTP_N_CS_TICKS;
        case CANTP_TIMER_N_CR: return (cfg != NULL_PTR) ? cfg->nCrTicks : (uint16)CANTP_N_CR_TICKS;
        default: return 0u;
    }
}

static void CanTp_StartTimer(uint8 ch, CanTp_TimerType timer)
{
    CanTp_Channel[ch].timerType = timer;
    CanTp_Channel[ch].timer = CanTp_GetTimerTicks(ch, timer);
}

static uint8 CanTp_IsConfigValid(void)
{
    if (CanTp_ConfigPtr == NULL_PTR)
    {
        return FALSE;
    }

    if (CanTp_ConfigPtr->channels == NULL_PTR)
    {
        return FALSE;
    }

    if ((CanTp_ConfigPtr->numChannels == 0u) ||
        (CanTp_ConfigPtr->numChannels > CANTP_MAX_CHANNELS))
    {
        return FALSE;
    }

    return TRUE;
}

static uint8 CanTp_ChannelCanConsumeRx(uint8 ch,
                                       const CanTp_ChannelConfigType* cfg,
                                       const uint8* data,
                                       PduLengthType len)
{
    uint8 pciIndex;
    uint8 pci;

    if ((cfg == NULL_PTR) || (data == NULL_PTR) || (ch >= CANTP_MAX_CHANNELS))
    {
        return FALSE;
    }

    pciIndex = CanTp_GetRxPciIndex(cfg);
    if (len <= pciIndex)
    {
        return FALSE;
    }

    pci = data[pciIndex] & 0xF0u;

    if ((pci == CANTP_NPCI_SF) || (pci == CANTP_NPCI_FF))
    {
        return (CanTp_Channel[ch].state == CANTP_IDLE) ? TRUE : FALSE;
    }

    if (pci == CANTP_NPCI_CF)
    {
        return (CanTp_Channel[ch].state == CANTP_RX_IN_PROGRESS) ? TRUE : FALSE;
    }

    if (pci == CANTP_NPCI_FC)
    {
        return (CanTp_Channel[ch].state == CANTP_TX_WAIT_FC) ? TRUE : FALSE;
    }

    return FALSE;
}

static uint8 CanTp_FindRxChannel(PduIdType rxPduId, const uint8* data, PduLengthType len)
{
    uint8 i;
    uint8 fallback = 0xFFu;
    const CanTp_ChannelConfigType* cfg;

    if (CanTp_IsConfigValid() == FALSE)
    {
        return 0xFFu;
    }

    for (i = 0u; i < CanTp_ConfigPtr->numChannels; i++)
    {
        cfg = &CanTp_ConfigPtr->channels[i];

        if ((cfg->rxPduId == rxPduId) &&
            (CanTp_UsesAddressByte(cfg) != FALSE) &&
            (CanTp_CheckRxAddress(cfg, data, len) != FALSE))
        {
            if (fallback == 0xFFu)
            {
                fallback = i;
            }

            if (CanTp_ChannelCanConsumeRx(i, cfg, data, len) != FALSE)
            {
                return i;
            }
        }
    }

    if (fallback != 0xFFu)
    {
        return fallback;
    }

    for (i = 0u; i < CanTp_ConfigPtr->numChannels; i++)
    {
        cfg = &CanTp_ConfigPtr->channels[i];

        if ((cfg->rxPduId == rxPduId) &&
            (CanTp_UsesAddressByte(cfg) == FALSE))
        {
            if (fallback == 0xFFu)
            {
                fallback = i;
            }

            if (CanTp_ChannelCanConsumeRx(i, cfg, data, len) != FALSE)
            {
                return i;
            }
        }
    }

    return fallback;
}

static uint8 CanTp_FindTxChannelByUpper(PduIdType upperTxPduId)
{
    uint8 i;

    if (CanTp_IsConfigValid() == FALSE)
    {
        return 0xFFu;
    }

    for (i = 0u; i < CanTp_ConfigPtr->numChannels; i++)
    {
        if (CanTp_ConfigPtr->channels[i].upperTxPduId == upperTxPduId)
        {
            return i;
        }
    }

    return 0xFFu;
}

static uint8 CanTp_FindIdleTxChannelByUpper(PduIdType upperTxPduId)
{
    uint8 i;
    uint8 firstMatch = 0xFFu;

    if (CanTp_IsConfigValid() == FALSE)
    {
        return 0xFFu;
    }

    for (i = 0u; i < CanTp_ConfigPtr->numChannels; i++)
    {
        if (CanTp_ConfigPtr->channels[i].upperTxPduId == upperTxPduId)
        {
            if (firstMatch == 0xFFu)
            {
                firstMatch = i;
            }

            if (CanTp_Channel[i].state == CANTP_IDLE)
            {
                return i;
            }
        }
    }

    return firstMatch;
}

static uint8 CanTp_FindChannelByCanIfTx(PduIdType txPduId)
{
    uint8 i;

    if (CanTp_IsConfigValid() == FALSE)
    {
        return 0xFFu;
    }

    for (i = 0u; i < CanTp_ConfigPtr->numChannels; i++)
    {
        if ((CanTp_ConfigPtr->channels[i].txPduId == txPduId) &&
            (CanTp_Channel[i].txBusy == TRUE))
        {
            return i;
        }
    }

    return 0xFFu;
}

static uint8 CanTp_StMinToTicks(uint8 stMin)
{
    if (stMin <= 0x7Fu)
    {
        return (uint8)((stMin + CANTP_MAIN_PERIOD_MS - 1u) / CANTP_MAIN_PERIOD_MS);
    }

    if ((stMin >= 0xF1u) && (stMin <= 0xF9u))
    {
        return 0u;
    }

    return 0xFFu;
}

static Std_ReturnType CanTp_ValidateFlowControl(const uint8* data, PduLengthType len)
{
    uint8 fs;
    uint8 stMin;

    if ((data == NULL_PTR) || (len < 3u))
    {
        return E_NOT_OK;
    }

    if ((data[0] & 0xF0u) != CANTP_NPCI_FC)
    {
        return E_NOT_OK;
    }

    fs = data[0] & 0x0Fu;
    stMin = data[2];

    if (fs > CANTP_FS_OVFLW)
    {
        return E_NOT_OK;
    }

    if ((stMin >= 0x80u) && (stMin <= 0xF0u))
    {
        return E_NOT_OK;
    }

    if (stMin > 0xF9u)
    {
        return E_NOT_OK;
    }

    return E_OK;
}

static void CanTp_ResetChannel(uint8 ch)
{
    if (ch < CANTP_MAX_CHANNELS)
    {
        CanTp_ReleaseTxPayloadBuffer(ch);
        memset(&CanTp_Channel[ch], 0, sizeof(CanTp_Channel[ch]));
        CanTp_Channel[ch].txBufferIdx = CANTP_TX_BUFFER_INVALID;
        CanTp_Channel[ch].state = CANTP_IDLE;
        CanTp_Channel[ch].direction = CANTP_DIR_NONE;
        CanTp_Channel[ch].timerType = CANTP_TIMER_NONE;
        CanTp_Channel[ch].pendingTxFrame = CANTP_TXFRAME_NONE;
        CanTp_TxAddressOverrideValid[ch] = FALSE;
        CanTp_TxAddressOverride[ch] = 0u;
    }
}

void CanTp_Init(const CanTp_ConfigType* ConfigPtr)
{
    uint8 i;

    CanTp_ConfigPtr = (ConfigPtr == NULL_PTR) ? &CanTp_Config : ConfigPtr;
    CanTp_ResetTxPayloadBufferPool();

    for (i = 0u; i < CANTP_MAX_CHANNELS; i++)
    {
        CanTp_ResetChannel(i);
    }

    if (CanTp_IsConfigValid() == FALSE)
    {
        CanTp_ConfigPtr = NULL_PTR;
    }
}

static Std_ReturnType CanTp_SendFc(uint8 ch, uint8 fs)
{
    uint8 frame[64u];
    uint8 pci;
    uint8 frameLen;
    uint8 bytesNeeded;
    const CanTp_ChannelConfigType* cfg;

    if ((CanTp_IsConfigValid() == FALSE) || (ch >= CanTp_ConfigPtr->numChannels))
    {
        return E_NOT_OK;
    }

    cfg = &CanTp_ConfigPtr->channels[ch];
    pci = CanTp_GetAddrOffset(cfg);
    bytesNeeded = (uint8)(pci + 3u);
    frameLen = CanTp_GetTxFrameLenForBytes(cfg, bytesNeeded);

    if (frameLen < bytesNeeded)
    {
        return E_NOT_OK;
    }

    CanTp_ClearFrame(frame, frameLen, cfg->padding);
    CanTp_SetTxAddress(ch, cfg, frame);

    frame[pci + 0u] = (uint8)(CANTP_NPCI_FC | fs);
    frame[pci + 1u] = cfg->blockSize;
    frame[pci + 2u] = cfg->stMinMs;

    CanTp_Channel[ch].txBusy = TRUE;
    CanTp_Channel[ch].pendingTxFrame = CANTP_TXFRAME_FC;
    CanTp_Channel[ch].state = CANTP_RX_WAIT_FC_TX_CONFIRM;
    CanTp_Channel[ch].direction = CANTP_DIR_RX;
    CanTp_StartTimer(ch, CANTP_TIMER_N_AR);

    if (GatewaySwc_RequestCanIfTransmit(cfg->txPduId, frame, frameLen) != E_OK)
    {
        CanTp_ResetChannel(ch);
        return E_NOT_OK;
    }

    return E_OK;
}

static Std_ReturnType CanTp_SendSingleFrame(uint8 ch)
{
    uint8 frame[64u];
    uint8 len;
    uint8 pci;
    uint8 frameLen;
    uint8 bytesNeeded;
    uint8 useEscapeSf;
    const uint8* txBuffer;
    const CanTp_ChannelConfigType* cfg;

    cfg = &CanTp_ConfigPtr->channels[ch];
    txBuffer = CanTp_GetTxPayloadBuffer(ch);

    if (txBuffer == NULL_PTR)
    {
        return E_NOT_OK;
    }

    len = (uint8)CanTp_Channel[ch].txLen;
    pci = CanTp_GetAddrOffset(cfg);
    useEscapeSf = ((cfg->canDl > 8u) && (len > 7u)) ? TRUE : FALSE;
    bytesNeeded = (uint8)(pci + (useEscapeSf != FALSE ? 2u : 1u) + len);
    frameLen = CanTp_GetTxFrameLenForBytes(cfg, bytesNeeded);

    CanTp_ClearFrame(frame, frameLen, cfg->padding);
    CanTp_SetTxAddress(ch, cfg, frame);

    if ((len > CanTp_GetSfMaxPayload(cfg)) || (frameLen < bytesNeeded))
    {
        return E_NOT_OK;
    }

    if (useEscapeSf == FALSE)
    {
        frame[pci] = len & 0x0Fu;
        memcpy(&frame[pci + 1u], txBuffer, len);
    }
    else
    {
        frame[pci] = 0x00u;
        frame[pci + 1u] = len;
        memcpy(&frame[pci + 2u], txBuffer, len);
    }

    CanTp_Channel[ch].state = CANTP_TX_WAIT_CONFIRM;
    CanTp_Channel[ch].direction = CANTP_DIR_TX;
    CanTp_Channel[ch].txBusy = TRUE;
    CanTp_Channel[ch].pendingTxFrame = CANTP_TXFRAME_SF;
    CanTp_StartTimer(ch, CANTP_TIMER_N_AS);

    if (GatewaySwc_RequestCanIfTransmit(cfg->txPduId, frame, frameLen) != E_OK)
    {
        CanTp_ResetChannel(ch);
        return E_NOT_OK;
    }

    return E_OK;
}

static Std_ReturnType CanTp_SendFirstFrame(uint8 ch)
{
    uint8 frame[64u];
    uint8 payloadInFf;
    uint8 pci;
    uint8 pciLen;
    uint8 useExtendedLength;
    uint32 txLen32;
    const uint8* txBuffer;
    const CanTp_ChannelConfigType* cfg;

    cfg = &CanTp_ConfigPtr->channels[ch];
    txBuffer = CanTp_GetTxPayloadBuffer(ch);

    if (txBuffer == NULL_PTR)
    {
        return E_NOT_OK;
    }

    pci = CanTp_GetAddrOffset(cfg);
    useExtendedLength =
            ((CanTp_Channel[ch].txLen > (PduLengthType)CANTP_LEGACY_MAX_PAYLOAD_LEN) ? TRUE : FALSE);
    pciLen = (useExtendedLength != FALSE) ? 6u : 2u;

    if ((CanTp_Channel[ch].txLen <= CanTp_GetSfMaxPayload(cfg)) ||
        (CanTp_Channel[ch].txLen > CANTP_MAX_PAYLOAD_LEN) ||
        ((useExtendedLength != FALSE) && (CanTp_CanUseExtendedFfLength(cfg) == FALSE)))
    {
        return E_NOT_OK;
    }

    payloadInFf = CanTp_GetFfPayload(cfg, pciLen);
    if (payloadInFf == 0u)
    {
        return E_NOT_OK;
    }

    CanTp_ClearFrame(frame, cfg->canDl, cfg->padding);
    CanTp_SetTxAddress(ch, cfg, frame);

    if (useExtendedLength == FALSE)
    {
        frame[pci + 0u] = (uint8)(CANTP_NPCI_FF | ((CanTp_Channel[ch].txLen >> 8u) & 0x0Fu));
        frame[pci + 1u] = (uint8)(CanTp_Channel[ch].txLen & 0xFFu);
    }
    else
    {
        txLen32 = (uint32)CanTp_Channel[ch].txLen;

        frame[pci + 0u] = CANTP_NPCI_FF;
        frame[pci + 1u] = 0u;
        frame[pci + 2u] = (uint8)((txLen32 >> 24u) & 0xFFu);
        frame[pci + 3u] = (uint8)((txLen32 >> 16u) & 0xFFu);
        frame[pci + 4u] = (uint8)((txLen32 >> 8u) & 0xFFu);
        frame[pci + 5u] = (uint8)(txLen32 & 0xFFu);
    }

    memcpy(&frame[pci + pciLen], txBuffer, payloadInFf);

    CanTp_Channel[ch].txOffset = payloadInFf;
    CanTp_Channel[ch].txSn = 1u;
    CanTp_Channel[ch].state = CANTP_TX_WAIT_CONFIRM;
    CanTp_Channel[ch].direction = CANTP_DIR_TX;
    CanTp_Channel[ch].txBusy = TRUE;
    CanTp_Channel[ch].pendingTxFrame = CANTP_TXFRAME_FF;
    CanTp_StartTimer(ch, CANTP_TIMER_N_AS);

    if (GatewaySwc_RequestCanIfTransmit(cfg->txPduId, frame, cfg->canDl) != E_OK)
    {
        CanTp_ResetChannel(ch);
        return E_NOT_OK;
    }

    return E_OK;
}

static Std_ReturnType CanTp_SendConsecutiveFrame(uint8 ch)
{
    uint8 frame[64u];
    PduLengthType remaining;
    PduLengthType oldOffset;
    uint8 payload;
    uint8 copy;
    uint8 pci;
    uint8 frameLen;
    uint8 bytesNeeded;
    uint8 oldSn;
    uint8 oldBlockCounter;
    const uint8* txBuffer;
    const CanTp_ChannelConfigType* cfg;

    if ((CanTp_Channel[ch].txBusy == TRUE) || (CanTp_Channel[ch].txStTimer > 0u))
    {
        return E_NOT_OK;
    }

    cfg = &CanTp_ConfigPtr->channels[ch];
    txBuffer = CanTp_GetTxPayloadBuffer(ch);

    if (txBuffer == NULL_PTR)
    {
        return E_NOT_OK;
    }

    pci = CanTp_GetAddrOffset(cfg);
    oldOffset = CanTp_Channel[ch].txOffset;
    oldSn = CanTp_Channel[ch].txSn;
    oldBlockCounter = CanTp_Channel[ch].txBlockCounter;
    remaining = (PduLengthType)(CanTp_Channel[ch].txLen - oldOffset);
    frameLen = cfg->canDl;

    if ((cfg->canDl > 8u) && (remaining < CanTp_GetCfPayload(cfg)))
    {
        bytesNeeded = (uint8)(pci + 1u + (uint8)remaining);
        frameLen = CanTp_GetTxFrameLenForBytes(cfg, bytesNeeded);
    }

    CanTp_ClearFrame(frame, frameLen, cfg->padding);
    CanTp_SetTxAddress(ch, cfg, frame);

    frame[pci] = (uint8)(CANTP_NPCI_CF | (oldSn & 0x0Fu));

    payload = (uint8)(frameLen - 1u - pci);
    copy = (remaining > payload) ? payload : (uint8)remaining;

    if (copy == 0u)
    {
        return E_NOT_OK;
    }

    memcpy(&frame[pci + 1u], &txBuffer[oldOffset], copy);

    CanTp_Channel[ch].txBusy = TRUE;
    CanTp_Channel[ch].pendingTxFrame = CANTP_TXFRAME_CF;
    CanTp_Channel[ch].state = CANTP_TX_WAIT_CONFIRM;
    CanTp_Channel[ch].direction = CANTP_DIR_TX;
    CanTp_StartTimer(ch, CANTP_TIMER_N_AS);
    CanTp_Channel[ch].txOffset = (PduLengthType)(oldOffset + copy);
    CanTp_Channel[ch].txSn = (uint8)((oldSn + 1u) & 0x0Fu);
    CanTp_Channel[ch].txBlockCounter = (uint8)(oldBlockCounter + 1u);

    if (GatewaySwc_RequestCanIfTransmit(cfg->txPduId, frame, frameLen) != E_OK)
    {
        CanTp_Channel[ch].txOffset = oldOffset;
        CanTp_Channel[ch].txSn = oldSn;
        CanTp_Channel[ch].txBlockCounter = oldBlockCounter;
        CanTp_Channel[ch].txBusy = FALSE;
        CanTp_Channel[ch].pendingTxFrame = CANTP_TXFRAME_NONE;
        CanTp_Channel[ch].state = CANTP_TX_CF;
        CanTp_StartTimer(ch, CANTP_TIMER_N_CS);
        return E_NOT_OK;
    }

    return E_OK;
}

static Std_ReturnType CanTp_TransmitOnChannel(uint8 ch, const uint8* data, PduLengthType len)
{
    uint8 sfMax;
    uint8* txBuffer;
    Std_ReturnType ret;

    if ((CanTp_IsConfigValid() == FALSE) ||
        (data == NULL_PTR) ||
        (len == 0u) ||
        (len > CANTP_MAX_PAYLOAD_LEN))
    {
        return E_NOT_OK;
    }

    if ((ch >= CanTp_ConfigPtr->numChannels) || (CanTp_Channel[ch].state != CANTP_IDLE))
    {
        return E_NOT_OK;
    }

    if (CanTp_AllocTxPayloadBuffer(ch) != E_OK)
    {
        return E_NOT_OK;
    }

    txBuffer = CanTp_GetTxPayloadBuffer(ch);
    if (txBuffer == NULL_PTR)
    {
        CanTp_ResetChannel(ch);
        return E_NOT_OK;
    }

    memcpy(txBuffer, data, len);

    CanTp_Channel[ch].txLen = len;
    CanTp_Channel[ch].txOffset = 0u;
    CanTp_Channel[ch].txBlockCounter = 0u;
    CanTp_Channel[ch].txBlockSize = 0u;
    CanTp_Channel[ch].txStMinTicks = 0u;
    CanTp_Channel[ch].txStTimer = 0u;
    CanTp_Channel[ch].txWaitFrameCounter = 0u;
    CanTp_Channel[ch].txBusy = FALSE;
    CanTp_Channel[ch].pendingTxFrame = CANTP_TXFRAME_NONE;
    CanTp_Channel[ch].direction = CANTP_DIR_TX;

    sfMax = CanTp_GetSfMaxPayload(&CanTp_ConfigPtr->channels[ch]);

    if (len <= sfMax)
    {
        ret = CanTp_SendSingleFrame(ch);
    }
    else
    {
        ret = CanTp_SendFirstFrame(ch);
    }

    if (ret != E_OK)
    {
        CanTp_ResetChannel(ch);
    }

    return ret;
}

Std_ReturnType CanTp_Transmit(PduIdType CanTpTxSduId, const uint8* data, PduLengthType len)
{
    return CanTp_TransmitOnChannel(CanTp_FindTxChannelByUpper(CanTpTxSduId), data, len);
}

static Std_ReturnType CanTp_TransmitExtendedAddressInternal(PduIdType CanTpTxSduId,
                                                            uint8 targetAddress,
                                                            const uint8* data,
                                                            PduLengthType len,
                                                            uint8 assumeFlowControl)
{
    uint8 ch;
    Std_ReturnType ret;

    CANTP_DEBUG_INC(CanTp_DebugExtendedTxRequests);
    CANTP_DEBUG_ASSIGN(CanTp_DebugExtendedLastUpperTxPdu, (uint16)CanTpTxSduId);
    CANTP_DEBUG_ASSIGN(CanTp_DebugExtendedLastTarget, targetAddress);
    CANTP_DEBUG_ASSIGN(CanTp_DebugExtendedLastLen, (uint16)len);
    CANTP_DEBUG_ASSIGN(CanTp_DebugExtendedLastChannel, 0xFFu);
    CANTP_DEBUG_ASSIGN(CanTp_DebugExtendedLastState, 0xFFu);
    CANTP_DEBUG_ASSIGN(CanTp_DebugExtendedLastReason, CANTP_DEBUG_EXT_TX_BAD_CONFIG);
    if ((CanTp_IsConfigValid() == FALSE) || (data == NULL_PTR) || (len == 0u))
    {
        CANTP_DEBUG_INC(CanTp_DebugExtendedTxFail);
        return E_NOT_OK;
    }

    ch = CanTp_FindIdleTxChannelByUpper(CanTpTxSduId);
    CANTP_DEBUG_ASSIGN(CanTp_DebugExtendedLastChannel, ch);
    if (ch >= CanTp_ConfigPtr->numChannels)
    {
        CANTP_DEBUG_ASSIGN(CanTp_DebugExtendedLastReason, CANTP_DEBUG_EXT_TX_NO_CHANNEL);
        CANTP_DEBUG_INC(CanTp_DebugExtendedTxFail);
        return E_NOT_OK;
    }

    CANTP_DEBUG_ASSIGN(CanTp_DebugExtendedLastState, (uint8)CanTp_Channel[ch].state);
    if (CanTp_UsesAddressByte(&CanTp_ConfigPtr->channels[ch]) == FALSE)
    {
        CANTP_DEBUG_ASSIGN(CanTp_DebugExtendedLastReason, CANTP_DEBUG_EXT_TX_NOT_EXTENDED);
        CANTP_DEBUG_INC(CanTp_DebugExtendedTxFail);
        return E_NOT_OK;
    }

    if (CanTp_Channel[ch].state != CANTP_IDLE)
    {
        CANTP_DEBUG_ASSIGN(CanTp_DebugExtendedLastReason, CANTP_DEBUG_EXT_TX_BUSY);
        CANTP_DEBUG_INC(CanTp_DebugExtendedTxFail);
        return E_NOT_OK;
    }

    CanTp_TxAddressOverride[ch] = targetAddress;
    CanTp_TxAddressOverrideValid[ch] = TRUE;
    CanTp_Channel[ch].txAssumeFlowControl = assumeFlowControl;
    ret = CanTp_TransmitOnChannel(ch, data, len);

    if (ret == E_OK)
    {
        CANTP_DEBUG_ASSIGN(CanTp_DebugExtendedLastReason, CANTP_DEBUG_EXT_TX_OK);
        CANTP_DEBUG_INC(CanTp_DebugExtendedTxOk);
    }
    else
    {
        CANTP_DEBUG_ASSIGN(CanTp_DebugExtendedLastReason, CANTP_DEBUG_EXT_TX_TRANSMIT_FAIL);
        CANTP_DEBUG_INC(CanTp_DebugExtendedTxFail);
        CanTp_TxAddressOverrideValid[ch] = FALSE;
        CanTp_TxAddressOverride[ch] = 0u;
        CanTp_Channel[ch].txAssumeFlowControl = FALSE;
    }

    return ret;
}

Std_ReturnType CanTp_TransmitExtendedAddress(PduIdType CanTpTxSduId,
                                             uint8 targetAddress,
                                             const uint8* data,
                                             PduLengthType len)
{
    return CanTp_TransmitExtendedAddressInternal(CanTpTxSduId, targetAddress, data, len, FALSE);
}

Std_ReturnType CanTp_TransmitExtendedAddressAssumeFlowControl(PduIdType CanTpTxSduId,
                                                              uint8 targetAddress,
                                                              const uint8* data,
                                                              PduLengthType len)
{
    return CanTp_TransmitExtendedAddressInternal(CanTpTxSduId, targetAddress, data, len, TRUE);
}

uint8 CanTp_IsExtendedAddressTxActive(uint8 targetAddress)
{
    uint8 i;

    if (CanTp_IsConfigValid() == FALSE)
    {
        return FALSE;
    }

    for (i = 0u; i < CanTp_ConfigPtr->numChannels; i++)
    {
        if ((CanTp_Channel[i].state != CANTP_IDLE) &&
            (CanTp_UsesAddressByte(&CanTp_ConfigPtr->channels[i]) != FALSE) &&
            (CanTp_TxAddressOverrideValid[i] != FALSE) &&
            (CanTp_TxAddressOverride[i] == targetAddress))
        {
            return TRUE;
        }
    }

    return FALSE;
}

uint8 CanTp_IsTxSduIdle(PduIdType CanTpTxSduId)
{
    uint8 ch;

    if (CanTp_IsConfigValid() == FALSE)
    {
        return FALSE;
    }

    ch = CanTp_FindIdleTxChannelByUpper(CanTpTxSduId);
    if ((ch < CanTp_ConfigPtr->numChannels) &&
        (CanTp_ConfigPtr->channels[ch].upperTxPduId == CanTpTxSduId) &&
        (CanTp_Channel[ch].state == CANTP_IDLE))
    {
        return TRUE;
    }

    return FALSE;
}

static void CanTp_HandleSingleFrame(uint8 ch, const uint8* data, PduLengthType len)
{
    uint8 sfLen;
    uint8 offset;
    uint8 pciBase;
    const CanTp_ChannelConfigType* cfg;

    cfg = &CanTp_ConfigPtr->channels[ch];
    pciBase = CanTp_GetRxPciIndex(cfg);

    if (len <= pciBase)
    {
        return;
    }

    if (CanTp_Channel[ch].state != CANTP_IDLE)
    {
        return;
    }

    data = &data[pciBase];
    len = (PduLengthType)(len - pciBase);

    if (cfg->canDl <= 8u)
    {
        sfLen = data[0] & 0x0Fu;
        offset = 1u;

        if ((sfLen == 0u) ||
            (sfLen > CanTp_GetSfMaxPayload(cfg)) ||
            ((PduLengthType)(sfLen + offset) > len))
        {
            return;
        }
    }
    else
    {
        if ((data[0] & 0x0Fu) != 0u)
        {
            sfLen = data[0] & 0x0Fu;
            offset = 1u;

            if ((sfLen > 15u) || ((PduLengthType)(sfLen + offset) > len))
            {
                return;
            }
        }
        else
        {
            if (len < 2u)
            {
                return;
            }

            sfLen = data[1];
            offset = 2u;

            if ((sfLen == 0u) ||
                (sfLen > CanTp_GetSfMaxPayload(cfg)) ||
                ((PduLengthType)(sfLen + offset) > len))
            {
                return;
            }
        }
    }

    if (PduR_CanTpStartOfReception(cfg->upperRxPduId, sfLen) != E_OK)
    {
        return;
    }

    if (PduR_CanTpCopyRxData(cfg->upperRxPduId, &data[offset], sfLen) != E_OK)
    {
        PduR_CanTpRxIndication(cfg->upperRxPduId, E_NOT_OK);
        return;
    }

    PduR_CanTpRxIndication(cfg->upperRxPduId, E_OK);
}

static void CanTp_HandleFirstFrame(uint8 ch, const uint8* data, PduLengthType len)
{
    uint32 totalLen32;
    PduLengthType totalLen;
    uint8 payload;
    uint8 copy;
    uint8 pciBase;
    uint8 pciLen;
    uint16 ffLen12;
    const CanTp_ChannelConfigType* cfg;

    cfg = &CanTp_ConfigPtr->channels[ch];
    pciBase = CanTp_GetRxPciIndex(cfg);

    if (len <= pciBase)
    {
        return;
    }

    if (CanTp_Channel[ch].state != CANTP_IDLE)
    {
        return;
    }

    data = &data[pciBase];
    len = (PduLengthType)(len - pciBase);

    if ((len < 3u) || (cfg->addressingType == CANTP_ADDR_FUNCTIONAL))
    {
        return;
    }

    ffLen12 = (uint16)((((uint16)data[0] & 0x0Fu) << 8u) | data[1]);

    if (ffLen12 != 0u)
    {
        totalLen32 = (uint32)ffLen12;
        pciLen = 2u;
    }
    else
    {
        if ((CanTp_CanUseExtendedFfLength(cfg) == FALSE) || (len < 7u))
        {
            (void)CanTp_SendFc(ch, CANTP_FS_OVFLW);
            return;
        }

        totalLen32 = ((uint32)data[2u] << 24u) |
                ((uint32)data[3u] << 16u) |
                ((uint32)data[4u] << 8u) |
                (uint32)data[5u];
        pciLen = 6u;
    }

    if ((totalLen32 <= (uint32)CanTp_GetSfMaxPayload(cfg)) ||
        (totalLen32 > (uint32)CANTP_MAX_PAYLOAD_LEN) ||
        ((ffLen12 == 0u) && (totalLen32 <= (uint32)CANTP_LEGACY_MAX_PAYLOAD_LEN)))
    {
        (void)CanTp_SendFc(ch, CANTP_FS_OVFLW);
        return;
    }

    totalLen = (PduLengthType)totalLen32;
    payload = (uint8)(len - pciLen);
    copy = (totalLen > payload) ? payload : (uint8)totalLen;

    if (PduR_CanTpStartOfReception(cfg->upperRxPduId, totalLen) != E_OK)
    {
        (void)CanTp_SendFc(ch, CANTP_FS_OVFLW);
        return;
    }

    if (PduR_CanTpCopyRxData(cfg->upperRxPduId, &data[pciLen], copy) != E_OK)
    {
        PduR_CanTpRxIndication(cfg->upperRxPduId, E_NOT_OK);
        CanTp_ResetChannel(ch);
        return;
    }

    CanTp_Channel[ch].rxExpectedLen = totalLen;
    CanTp_Channel[ch].rxLen = copy;
    CanTp_Channel[ch].rxNextSn = 1u;
    CanTp_Channel[ch].rxBlockCounter = 0u;
    CanTp_Channel[ch].direction = CANTP_DIR_RX;
    CanTp_StartTimer(ch, CANTP_TIMER_N_BR);

    (void)CanTp_SendFc(ch, CANTP_FS_CTS);
}

static void CanTp_HandleConsecutiveFrame(uint8 ch, const uint8* data, PduLengthType len)
{
    uint8 sn;
    uint8 payload;
    uint8 copy;
    uint8 pciBase;
    PduLengthType remaining;
    const CanTp_ChannelConfigType* cfg;

    cfg = &CanTp_ConfigPtr->channels[ch];
    pciBase = CanTp_GetRxPciIndex(cfg);

    if (len <= pciBase)
    {
        return;
    }

    data = &data[pciBase];
    len = (PduLengthType)(len - pciBase);

    if ((CanTp_Channel[ch].state != CANTP_RX_IN_PROGRESS) || (len < 2u))
    {
        return;
    }

    sn = data[0] & 0x0Fu;

    if (sn != CanTp_Channel[ch].rxNextSn)
    {
        PduR_CanTpRxIndication(cfg->upperRxPduId, E_NOT_OK);
        CanTp_ResetChannel(ch);
        return;
    }

    payload = (uint8)(len - 1u);
    remaining = (PduLengthType)(CanTp_Channel[ch].rxExpectedLen - CanTp_Channel[ch].rxLen);
    copy = (remaining > payload) ? payload : (uint8)remaining;

    if (copy == 0u)
    {
        PduR_CanTpRxIndication(cfg->upperRxPduId, E_NOT_OK);
        CanTp_ResetChannel(ch);
        return;
    }

    if (PduR_CanTpCopyRxData(cfg->upperRxPduId, &data[1], copy) != E_OK)
    {
        PduR_CanTpRxIndication(cfg->upperRxPduId, E_NOT_OK);
        CanTp_ResetChannel(ch);
        return;
    }

    CanTp_Channel[ch].rxLen = (PduLengthType)(CanTp_Channel[ch].rxLen + copy);
    CanTp_Channel[ch].rxNextSn = (uint8)((CanTp_Channel[ch].rxNextSn + 1u) & 0x0Fu);
    CanTp_Channel[ch].rxBlockCounter++;

    if (CanTp_Channel[ch].rxLen >= CanTp_Channel[ch].rxExpectedLen)
    {
        PduR_CanTpRxIndication(cfg->upperRxPduId, E_OK);
        CanTp_ResetChannel(ch);
    }
    else if ((cfg->blockSize != 0u) && (CanTp_Channel[ch].rxBlockCounter >= cfg->blockSize))
    {
        CanTp_Channel[ch].rxBlockCounter = 0u;
        CanTp_StartTimer(ch, CANTP_TIMER_N_BR);
        (void)CanTp_SendFc(ch, CANTP_FS_CTS);
    }
    else
    {
        CanTp_StartTimer(ch, CANTP_TIMER_N_CR);
    }
}

static void CanTp_HandleFlowControl(uint8 ch, const uint8* data, PduLengthType len)
{
    uint8 fs;
    uint8 ticks;
    uint8 pciBase;
    const CanTp_ChannelConfigType* cfg;

    cfg = &CanTp_ConfigPtr->channels[ch];
    pciBase = CanTp_GetRxPciIndex(cfg);

    if (len <= pciBase)
    {
        return;
    }

    data = &data[pciBase];
    len = (PduLengthType)(len - pciBase);

    if (CanTp_Channel[ch].state != CANTP_TX_WAIT_FC)
    {
        return;
    }

    if (CanTp_ValidateFlowControl(data, len) != E_OK)
    {
        PduR_CanTpTxConfirmation(cfg->upperTxPduId, E_NOT_OK);
        CanTp_ResetChannel(ch);
        return;
    }

    fs = data[0] & 0x0Fu;

    if (fs == CANTP_FS_CTS)
    {
        ticks = CanTp_StMinToTicks(data[2]);

        if (ticks == 0xFFu)
        {
            PduR_CanTpTxConfirmation(cfg->upperTxPduId, E_NOT_OK);
            CanTp_ResetChannel(ch);
            return;
        }

        CanTp_Channel[ch].txBlockSize = data[1];
        CanTp_Channel[ch].txStMinTicks = ticks;
        CanTp_Channel[ch].txBlockCounter = 0u;
        CanTp_Channel[ch].txWaitFrameCounter = 0u;
        CanTp_Channel[ch].state = CANTP_TX_CF;
        CanTp_Channel[ch].direction = CANTP_DIR_TX;
        CanTp_Channel[ch].txStTimer = ticks;
        CanTp_StartTimer(ch, CANTP_TIMER_N_CS);
    }
    else if (fs == CANTP_FS_WAIT)
    {
        CanTp_Channel[ch].txWaitFrameCounter++;

        if (CanTp_Channel[ch].txWaitFrameCounter > CANTP_WFT_MAX)
        {
            PduR_CanTpTxConfirmation(cfg->upperTxPduId, E_NOT_OK);
            CanTp_ResetChannel(ch);
        }
        else
        {
            CanTp_StartTimer(ch, CANTP_TIMER_N_BS);
        }
    }
    else
    {
        PduR_CanTpTxConfirmation(cfg->upperTxPduId, E_NOT_OK);
        CanTp_ResetChannel(ch);
    }
}

void CanTp_RxIndication(PduIdType CanIfRxPduId, const uint8* data, PduLengthType len)
{
    CpuPerf_ContextType cpuPerfCtx;
    uint8 ch;
    uint8 pci;
    const CanTp_ChannelConfigType* cfg;

    if ((CanTp_IsConfigValid() == FALSE) || (data == NULL_PTR) || (len == 0u))
    {
        return;
    }

    CpuPerf_Start(CPUPERF_ID_CANTP_RX_INDICATION_C0, &cpuPerfCtx);

    ch = CanTp_FindRxChannel(CanIfRxPduId, data, len);

    if (ch >= CanTp_ConfigPtr->numChannels)
    {
        CpuPerf_Stop(CPUPERF_ID_CANTP_RX_INDICATION_C0, &cpuPerfCtx);
        return;
    }

    cfg = &CanTp_ConfigPtr->channels[ch];

    pci = data[CanTp_GetRxPciIndex(cfg)] & 0xF0u;

    if ((cfg->addressingType == CANTP_ADDR_FUNCTIONAL) && (pci != CANTP_NPCI_SF))
    {
        return;
    }

    if (pci == CANTP_NPCI_SF)
    {
        CanTp_HandleSingleFrame(ch, data, len);
    }
    else if (pci == CANTP_NPCI_FF)
    {
        CanTp_HandleFirstFrame(ch, data, len);
    }
    else if (pci == CANTP_NPCI_CF)
    {
        CanTp_HandleConsecutiveFrame(ch, data, len);
    }
    else if (pci == CANTP_NPCI_FC)
    {
        CanTp_HandleFlowControl(ch, data, len);
    }

    CpuPerf_Stop(CPUPERF_ID_CANTP_RX_INDICATION_C0, &cpuPerfCtx);
}

void CanTp_TxConfirmation(PduIdType CanIfTxPduId)
{
    uint8 ch;
    const CanTp_ChannelConfigType* cfg;
    CanTp_TxFrameType confirmedFrame;

    if (CanTp_IsConfigValid() == FALSE)
    {
        return;
    }

    ch = CanTp_FindChannelByCanIfTx(CanIfTxPduId);

    if (ch >= CanTp_ConfigPtr->numChannels)
    {
        return;
    }

    cfg = &CanTp_ConfigPtr->channels[ch];

    confirmedFrame = CanTp_Channel[ch].pendingTxFrame;
    CanTp_Channel[ch].txBusy = FALSE;
    CanTp_Channel[ch].pendingTxFrame = CANTP_TXFRAME_NONE;

    if (confirmedFrame == CANTP_TXFRAME_FC)
    {
        CanTp_Channel[ch].state = CANTP_RX_IN_PROGRESS;
        CanTp_Channel[ch].direction = CANTP_DIR_RX;
        CanTp_StartTimer(ch, CANTP_TIMER_N_CR);
    }
    else if (confirmedFrame == CANTP_TXFRAME_SF)
    {
        PduR_CanTpTxConfirmation(cfg->upperTxPduId, E_OK);
        CanTp_ResetChannel(ch);
    }
    else if (confirmedFrame == CANTP_TXFRAME_FF)
    {
        if (CanTp_Channel[ch].txAssumeFlowControl != FALSE)
        {
            CanTp_Channel[ch].txBlockSize = 0u;
            CanTp_Channel[ch].txStMinTicks = 0u;
            CanTp_Channel[ch].txBlockCounter = 0u;
            CanTp_Channel[ch].txStTimer = 0u;
            CanTp_Channel[ch].state = CANTP_TX_CF;
            CanTp_Channel[ch].direction = CANTP_DIR_TX;
            CanTp_StartTimer(ch, CANTP_TIMER_N_CS);
        }
        else
        {
            CanTp_Channel[ch].state = CANTP_TX_WAIT_FC;
            CanTp_Channel[ch].direction = CANTP_DIR_TX;
            CanTp_StartTimer(ch, CANTP_TIMER_N_BS);
        }
    }
    else if (confirmedFrame == CANTP_TXFRAME_CF)
    {
        if (CanTp_Channel[ch].txOffset >= CanTp_Channel[ch].txLen)
        {
            PduR_CanTpTxConfirmation(cfg->upperTxPduId, E_OK);
            CanTp_ResetChannel(ch);
        }
        else if ((CanTp_Channel[ch].txBlockSize != 0u) &&
                 (CanTp_Channel[ch].txBlockCounter >= CanTp_Channel[ch].txBlockSize))
        {
            CanTp_Channel[ch].state = CANTP_TX_WAIT_FC;
            CanTp_StartTimer(ch, CANTP_TIMER_N_BS);
        }
        else
        {
            CanTp_Channel[ch].state = CANTP_TX_CF;
            CanTp_Channel[ch].txStTimer = CanTp_Channel[ch].txStMinTicks;
            CanTp_StartTimer(ch, CANTP_TIMER_N_CS);
        }
    }
}

void CanTp_MainFunction(void)
{
    CpuPerf_ContextType cpuPerfCtx;
    uint8 ch;
    uint8 cfBurstCount;
    const CanTp_ChannelConfigType* cfg;

    if (CanTp_IsConfigValid() == FALSE)
    {
        return;
    }

    CpuPerf_Start(CPUPERF_ID_CANTP_MAIN_C0, &cpuPerfCtx);

    for (ch = 0u; ch < CanTp_ConfigPtr->numChannels; ch++)
    {
        cfg = &CanTp_ConfigPtr->channels[ch];

        if (CanTp_Channel[ch].state == CANTP_IDLE)
        {
            continue;
        }

        if (CanTp_Channel[ch].txStTimer > 0u)
        {
            CanTp_Channel[ch].txStTimer--;
        }

        if (CanTp_Channel[ch].timer > 0u)
        {
            CanTp_Channel[ch].timer--;
        }
        else
        {
            if (CanTp_Channel[ch].direction == CANTP_DIR_TX)
            {
                PduR_CanTpTxConfirmation(cfg->upperTxPduId, E_NOT_OK);
            }
            else if (CanTp_Channel[ch].direction == CANTP_DIR_RX)
            {
                PduR_CanTpRxIndication(cfg->upperRxPduId, E_NOT_OK);
            }

            CanTp_ResetChannel(ch);
            continue;
        }

        if (CanTp_Channel[ch].state == CANTP_TX_CF)
        {
            cfBurstCount = 0u;

            while ((CanTp_Channel[ch].state == CANTP_TX_CF) &&
                   (CanTp_Channel[ch].txBusy == FALSE) &&
                   (CanTp_Channel[ch].txStTimer == 0u) &&
                   (cfBurstCount < CANTP_TX_CF_BURST_BUDGET))
            {
                if (CanTp_SendConsecutiveFrame(ch) != E_OK)
                {
                    break;
                }

                cfBurstCount++;
            }
        }
    }

    CpuPerf_Stop(CPUPERF_ID_CANTP_MAIN_C0, &cpuPerfCtx);
}
