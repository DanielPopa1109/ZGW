#include "Com.h"
#include "PduR.h"
#include "ComM/ComM.h"
#include "APP/CodingApp/CodingApp.h"
#include "SysMgr.h"
#include <string.h>

#define COM_TRUE  1u
#define COM_FALSE 0u
#define COM_NM_PERIOD_TICKS 20u /* 100 ms at the 5 ms COM task rate. */

#define COM_RX_TIMEOUT_CYCLE_FACTOR 20u
#define COM_RX_LIN_TIMEOUT_CYCLE_FACTOR 10u


typedef struct
{
    PduIdType pduId;
    Com_IpduGroupIdType groupId;
    uint8 txMode;
    uint16 periodTicks;
    uint16 mdtTicks;
    uint8 repetitions;
    uint16 repetitionPeriodTicks;
    uint16 deadlineTicks;
    uint8 len;
    uint8 init[COM_MAX_IPDU_LEN];
} Com_TxIpduConfigType;

typedef struct
{
    PduIdType pduId;
    Com_IpduGroupIdType groupId;
    uint16 deadlineTicks;
    uint8 len;
    uint8 init[COM_MAX_IPDU_LEN];
} Com_RxIpduConfigType;

typedef struct
{
    Com_SignalIdType signalId;
    uint8 isTx;
    PduIdType pduId;
    uint16 bitPosition;
    uint8 bitSize;
    uint8 dataSize;
    uint8 hasUpdateBit;
    uint16 updateBitPosition;
    uint32 invalidValue;
    uint32 initValue;
} Com_SignalConfigType;

typedef struct
{
    uint8 buffer[COM_MAX_IPDU_LEN];
    uint8 active;
    uint8 dirty;
    uint8 txInProgress;
    uint16 periodTimer;
    uint8 periodDue;
    uint8 startupPending;
    uint16 mdtTimer;
    uint8 repetitionsLeft;
    uint16 repetitionTimer;
    uint16 deadlineTimer;
} Com_TxIpduRuntimeType;

typedef struct
{
    uint8 buffer[COM_MAX_IPDU_LEN];
    uint8 active;
    uint16 deadlineTimer;
    uint8 timeout;
    uint8 received;
} Com_RxIpduRuntimeType;

static const Com_TxIpduConfigType Com_TxIpduCfg[] =
{
    { COM_TX_PDU_VEHICLESTATE                                , COM_IPDU_GROUP_0, COM_TX_MODE_MIXED, 20u, 2u, 1u, 2u, 100u, 1u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_DISPLAYOUTTEMP                              , COM_IPDU_GROUP_0, COM_TX_MODE_PERIODIC, 200u, 2u, 1u, 2u, 100u, 4u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_STATUSBODYDATA1                             , COM_IPDU_GROUP_0, COM_TX_MODE_PERIODIC, 24u, 2u, 1u, 2u, 100u, 4u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_COMMANDDISPLAYSTATUS                        , COM_IPDU_GROUP_0, COM_TX_MODE_PERIODIC, 24u, 2u, 1u, 2u, 100u, 6u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_XCPREQUEST_7C8                              , COM_IPDU_GROUP_0, COM_TX_MODE_NONE, 0u, 2u, 1u, 2u, 100u, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_XCPREQUEST_7C6                              , COM_IPDU_GROUP_0, COM_TX_MODE_NONE, 0u, 2u, 1u, 2u, 100u, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_XCPREQUEST_7C4                              , COM_IPDU_GROUP_0, COM_TX_MODE_NONE, 0u, 2u, 1u, 2u, 100u, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_XCPREQUEST_7C2                              , COM_IPDU_GROUP_0, COM_TX_MODE_NONE, 0u, 2u, 1u, 2u, 100u, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_XCPREQUEST_7C0                              , COM_IPDU_GROUP_0, COM_TX_MODE_NONE, 0u, 2u, 1u, 2u, 100u, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_SDAT                                        , COM_IPDU_GROUP_0, COM_TX_MODE_PERIODIC, 160u, 2u, 1u, 2u, 100u, 7u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_NM3                                         , COM_IPDU_GROUP_0, COM_TX_MODE_PERIODIC, 20u, 2u, 1u, 2u, 100u, 1u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_LOADREQUEST                                 , COM_IPDU_GROUP_0, COM_TX_MODE_MIXED, 200u, 2u, 1u, 2u, 100u, 2u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_DIAGREQUEST_706                             , COM_IPDU_GROUP_0, COM_TX_MODE_NONE, 0u, 2u, 1u, 2u, 100u, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_DIAGREQUEST_704                             , COM_IPDU_GROUP_0, COM_TX_MODE_NONE, 0u, 2u, 1u, 2u, 100u, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_DIAGREQUEST_702                             , COM_IPDU_GROUP_0, COM_TX_MODE_NONE, 0u, 2u, 1u, 2u, 100u, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_DIAGREQUEST_700                             , COM_IPDU_GROUP_0, COM_TX_MODE_NONE, 0u, 2u, 1u, 2u, 100u, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_CANFD_INFOTAINMENTDATA1                                      , COM_IPDU_GROUP_0, COM_TX_MODE_PERIODIC, 199u, 2u, 1u, 2u, 100u, 12u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA2                                  , COM_IPDU_GROUP_0, COM_TX_MODE_PERIODIC, 19u, 2u, 1u, 2u, 100u, 6u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA1                                  , COM_IPDU_GROUP_0, COM_TX_MODE_PERIODIC, 19u, 2u, 1u, 2u, 100u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_CANFD_VEHICLESTATE                                           , COM_IPDU_GROUP_0, COM_TX_MODE_MIXED, 19u, 2u, 1u, 2u, 100u, 1u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_CANFD_NM3                                                    , COM_IPDU_GROUP_0, COM_TX_MODE_PERIODIC, 19u, 2u, 1u, 2u, 100u, 1u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_CANFD_SDAT                                                   , COM_IPDU_GROUP_0, COM_TX_MODE_PERIODIC, 159u, 2u, 1u, 2u, 100u, 7u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_CANFD_LIGHTDATA1                                             , COM_IPDU_GROUP_0, COM_TX_MODE_PERIODIC, 23u, 2u, 1u, 2u, 100u, 3u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_CANFD_BODYDATA1                                              , COM_IPDU_GROUP_0, COM_TX_MODE_PERIODIC, 23u, 2u, 1u, 2u, 100u, 20u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_CANFD_PDM1_DIAGREQUEST                                       , COM_IPDU_GROUP_0, COM_TX_MODE_NONE, 0, 2u, 1u, 2u, 100u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_CANFD_COMMANDLOAD_PDM1                                       , COM_IPDU_GROUP_0, COM_TX_MODE_MIXED, 199u, 2u, 1u, 2u, 100u, 12u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA3                                  , COM_IPDU_GROUP_0, COM_TX_MODE_PERIODIC, 19u, 2u, 1u, 2u, 100u, 5u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_LIN_ZGW_REQUEST_HVDCDC                 , COM_IPDU_GROUP_0, COM_TX_MODE_MIXED, 2u, 1u, 1u, 2u, 20u, 2u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_LIN_ZGW_SDAT                           , COM_IPDU_GROUP_0, COM_TX_MODE_PERIODIC, 160u, 2u, 1u, 2u, 160u, 7u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} }
};

static const Com_RxIpduConfigType Com_RxIpduCfg[] =
{
    { COM_RX_PDU_CENTRALLOCKDATA                             , COM_IPDU_GROUP_0, 205u, 2u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_LIGHTDATA1                                  , COM_IPDU_GROUP_0, 105u, 3u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_STATUSACTUATOR                              , COM_IPDU_GROUP_0, 105u, 2u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_OUTSIDETEMPERATURESTATUS                    , COM_IPDU_GROUP_0, 1005u, 4u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CENTRALCOMMAND1                             , COM_IPDU_GROUP_0, 205u, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_DMUSTATUS                                   , COM_IPDU_GROUP_0, 1005u, 1u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_BATTFULLSTAT                                , COM_IPDU_GROUP_0, 1005u, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_PDCSTAT                                     , COM_IPDU_GROUP_0, 105u, 3u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_MILEAGE                                     , COM_IPDU_GROUP_0, 1005u, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_DMU_ALIVE                                   , COM_IPDU_GROUP_0, 1005u, 1u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_XCPRESPONSE_7C7                             , COM_IPDU_GROUP_0, 0, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_XCPRESPONSE_7C5                             , COM_IPDU_GROUP_0, 0, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_XCPRESPONSE_7C3                             , COM_IPDU_GROUP_0, 0, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_XCPRESPONSE_7C1                             , COM_IPDU_GROUP_0, 0, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_VOLTAGECURRENT                              , COM_IPDU_GROUP_0, 10u, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_TEMPMEAS                                    , COM_IPDU_GROUP_0, 10u, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_LOADSTATUS                                  , COM_IPDU_GROUP_0, 1005u, 1u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_L1_I2T_COUNTER                              , COM_IPDU_GROUP_0, 10u, 4u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_ERROR_706                                   , COM_IPDU_GROUP_0, 0, 4u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_ERROR_704                                   , COM_IPDU_GROUP_0, 0, 4u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_ERROR_702                                   , COM_IPDU_GROUP_0, 0, 4u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_ERROR_700                                   , COM_IPDU_GROUP_0, 0, 4u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_DIAGREQUEST_710                             , COM_IPDU_GROUP_0, 0, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_DIAGRESPONSE_707                            , COM_IPDU_GROUP_0, 0, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_DIAGRESPONSE_705                            , COM_IPDU_GROUP_0, 0, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_DIAGRESPONSE_703                            , COM_IPDU_GROUP_0, 0, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_DIAGRESPONSE_701                            , COM_IPDU_GROUP_0, 0, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_BATTSOCSOH                                  , COM_IPDU_GROUP_0, 1005u, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_BATTSOC                                     , COM_IPDU_GROUP_0, 1005u, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_BATTDIAGNOSIS                               , COM_IPDU_GROUP_0, 1005u, 1u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_BATTCURRENT                                 , COM_IPDU_GROUP_0, 10u, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_BATTCAPDISCHARGE                            , COM_IPDU_GROUP_0, 1005u, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_BATTCAPRES                                  , COM_IPDU_GROUP_0, 1005u, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM1_LOADSTATUS                                        , COM_IPDU_GROUP_0, 1000u, 12u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_1                                 , COM_IPDU_GROUP_0, 50u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_2                                 , COM_IPDU_GROUP_0, 50u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_3                                 , COM_IPDU_GROUP_0, 50u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_4                                 , COM_IPDU_GROUP_0, 50u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_5                                 , COM_IPDU_GROUP_0, 50u, 48u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM1_INPUTT30                                          , COM_IPDU_GROUP_0, 5u, 2u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM1_DIAGRESPONSE                                      , COM_IPDU_GROUP_0, 0, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_LIN_HVDCDC_STATUS                      , COM_IPDU_GROUP_0, 90u, 5u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} }
};

static const Com_SignalConfigType Com_SignalCfg[] =
{
    { COM_SIG_TX_VEHICLESTATE_VEHICLESTATUS                                     , COM_TRUE,  COM_TX_PDU_VEHICLESTATE                                , 0u, 4u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFu        , 0u },
    { COM_SIG_TX_DISPLAYOUTTEMP_COMMANDDISPLAYOUTSIDETEMPERATURE                  , COM_TRUE,  COM_TX_PDU_DISPLAYOUTTEMP                              , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_STATUSBODYDATA1_BD1_CENTRALLOCKCOMMAND                            , COM_TRUE,  COM_TX_PDU_STATUSBODYDATA1                             , 29u, 3u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7u        , 0u },
    { COM_SIG_TX_STATUSBODYDATA1_BD1_TURNSIGNALCOMMAND                             , COM_TRUE,  COM_TX_PDU_STATUSBODYDATA1                             , 12u, 4u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFu        , 0u },
    { COM_SIG_TX_STATUSBODYDATA1_BD1_RLSCOMMAND                                    , COM_TRUE,  COM_TX_PDU_STATUSBODYDATA1                             , 24u, 5u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1Fu       , 0u },
    { COM_SIG_TX_STATUSBODYDATA1_BD1_LIGTHSENSOR                                   , COM_TRUE,  COM_TX_PDU_STATUSBODYDATA1                             , 16u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_STATUSBODYDATA1_BD1_IGNITION                                      , COM_TRUE,  COM_TX_PDU_STATUSBODYDATA1                             , 8u, 4u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFu        , 0u },
    { COM_SIG_TX_STATUSBODYDATA1_BD1_HIGHBEAMCOMMAND                               , COM_TRUE,  COM_TX_PDU_STATUSBODYDATA1                             , 6u, 2u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3u        , 0u },
    { COM_SIG_TX_STATUSBODYDATA1_BD1_GEARBOX                                       , COM_TRUE,  COM_TX_PDU_STATUSBODYDATA1                             , 3u, 3u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7u        , 0u },
    { COM_SIG_TX_STATUSBODYDATA1_BD1_FOGLIGHTSCOMMAND                              , COM_TRUE,  COM_TX_PDU_STATUSBODYDATA1                             , 0u, 3u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7u        , 0u },
    { COM_SIG_TX_COMMANDDISPLAYSTATUS_COMMANDDISPLAYRECIRCULATION                       , COM_TRUE,  COM_TX_PDU_COMMANDDISPLAYSTATUS                        , 29u, 3u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7u        , 0u },
    { COM_SIG_TX_COMMANDDISPLAYSTATUS_COMMANDDISPLAYCLIMATEAUTO                         , COM_TRUE,  COM_TX_PDU_COMMANDDISPLAYSTATUS                        , 6u, 2u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3u        , 0u },
    { COM_SIG_TX_COMMANDDISPLAYSTATUS_COMMANDDISPLAYCLIMATEMP                           , COM_TRUE,  COM_TX_PDU_COMMANDDISPLAYSTATUS                        , 41u, 6u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3Fu       , 0u },
    { COM_SIG_TX_COMMANDDISPLAYSTATUS_COMMANDDISPLAYERRORMESSAGE                        , COM_TRUE,  COM_TX_PDU_COMMANDDISPLAYSTATUS                        , 8u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_COMMANDDISPLAYSTATUS_COMMANDDISPLAYDSCSTATUS                           , COM_TRUE,  COM_TX_PDU_COMMANDDISPLAYSTATUS                        , 47u, 1u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_TX_COMMANDDISPLAYSTATUS_COMMANDDISPLAYVEHICLESPEED                        , COM_TRUE,  COM_TX_PDU_COMMANDDISPLAYSTATUS                        , 32u, 9u, COM_SIGNAL_U16, COM_FALSE, 0u, 0x1FFu      , 0u },
    { COM_SIG_TX_COMMANDDISPLAYSTATUS_COMMANDDISPLAYRPM                                 , COM_TRUE,  COM_TX_PDU_COMMANDDISPLAYSTATUS                        , 16u, 13u, COM_SIGNAL_U16, COM_FALSE, 0u, 0x1FFFu     , 0u },
    { COM_SIG_TX_COMMANDDISPLAYSTATUS_COMMANDDISPLAYMODE                                , COM_TRUE,  COM_TX_PDU_COMMANDDISPLAYSTATUS                        , 4u, 2u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3u        , 0u },
    { COM_SIG_TX_COMMANDDISPLAYSTATUS_COMMANDDISPLAYCLIMAFAN                            , COM_TRUE,  COM_TX_PDU_COMMANDDISPLAYSTATUS                        , 0u, 4u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFu        , 0u },
    { COM_SIG_TX_SDAT_CSB_SDAT_YEAR                                     , COM_TRUE,  COM_TX_PDU_SDAT                                        , 16u, 6u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3Fu       , 0u },
    { COM_SIG_TX_SDAT_CSB_SDAT_SECOND                                   , COM_TRUE,  COM_TX_PDU_SDAT                                        , 8u, 6u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3Fu       , 0u },
    { COM_SIG_TX_SDAT_CSB_SDAT_MONTH                                    , COM_TRUE,  COM_TX_PDU_SDAT                                        , 40u, 4u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFu        , 0u },
    { COM_SIG_TX_SDAT_CSB_SDAT_MINUTE                                   , COM_TRUE,  COM_TX_PDU_SDAT                                        , 0u, 6u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3Fu       , 0u },
    { COM_SIG_TX_SDAT_CSB_SDAT_MILLISECOND                              , COM_TRUE,  COM_TX_PDU_SDAT                                        , 48u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_SDAT_CSB_SDAT_HOUR                                     , COM_TRUE,  COM_TX_PDU_SDAT                                        , 32u, 5u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1Fu       , 0u },
    { COM_SIG_TX_SDAT_CSB_SDAT_DAY                                      , COM_TRUE,  COM_TX_PDU_SDAT                                        , 24u, 5u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1Fu       , 0u },
    { COM_SIG_TX_SDAT_CSB_SDAT_TIMESOURCE                               , COM_TRUE,  COM_TX_PDU_SDAT                                        , 6u, 2u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3u        , 0u },
    { COM_SIG_TX_SDAT_CSB_SDAT_UTCVALID                                 , COM_TRUE,  COM_TX_PDU_SDAT                                        , 14u, 1u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_TX_SDAT_CSB_SDAT_DEFAULTTIME                              , COM_TRUE,  COM_TX_PDU_SDAT                                        , 15u, 1u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_TX_SDAT_CSB_SDAT_NVMRESTORED                              , COM_TRUE,  COM_TX_PDU_SDAT                                        , 22u, 1u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_TX_NM3_NM3_PN1                                           , COM_TRUE,  COM_TX_PDU_NM3                                         , 0u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_LOADREQUEST_LOADREQUESTSTATUS                                 , COM_TRUE,  COM_TX_PDU_LOADREQUEST                                 , 7u, 1u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_TX_LOADREQUEST_LOADREQUESTDATAID                                 , COM_TRUE,  COM_TX_PDU_LOADREQUEST                                 , 4u, 3u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7u        , 0u },
    { COM_SIG_TX_LOADREQUEST_LOADREQUESTCRC                                    , COM_TRUE,  COM_TX_PDU_LOADREQUEST                                 , 8u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_LOADREQUEST_LOADREQUESTALIVECOUNTER                           , COM_TRUE,  COM_TX_PDU_LOADREQUEST                                 , 0u, 4u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFu        , 0u },
    { COM_SIG_RX_CENTRALLOCKDATA_VIBRATIONSENSORSTATUS                             , COM_FALSE, COM_RX_PDU_CENTRALLOCKDATA                             , 8u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_CENTRALLOCKDATA_CENTRALLOCKSTATUS                                 , COM_FALSE, COM_RX_PDU_CENTRALLOCKDATA                             , 0u, 3u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7u        , 0u },
    { COM_SIG_RX_CENTRALLOCKDATA_CENTRALLOCKBUZZER                                 , COM_FALSE, COM_RX_PDU_CENTRALLOCKDATA                             , 3u, 2u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3u        , 0u },
    { COM_SIG_RX_LIGHTDATA1_REVERSELIGTHSTATUS                                , COM_FALSE, COM_RX_PDU_LIGHTDATA1                                  , 16u, 2u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3u        , 0u },
    { COM_SIG_RX_LIGHTDATA1_POSITIONLIGHTSTATUS                               , COM_FALSE, COM_RX_PDU_LIGHTDATA1                                  , 14u, 2u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3u        , 0u },
    { COM_SIG_RX_LIGHTDATA1_LOWBEAMSTATUS                                     , COM_FALSE, COM_RX_PDU_LIGHTDATA1                                  , 12u, 2u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3u        , 0u },
    { COM_SIG_RX_LIGHTDATA1_INTERIORLIGHTSTATUS                               , COM_FALSE, COM_RX_PDU_LIGHTDATA1                                  , 10u, 2u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3u        , 0u },
    { COM_SIG_RX_LIGHTDATA1_HIGHBEAMSTATUS                                    , COM_FALSE, COM_RX_PDU_LIGHTDATA1                                  , 8u, 2u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3u        , 0u },
    { COM_SIG_RX_LIGHTDATA1_FOGLIGHTSSTATUS                                   , COM_FALSE, COM_RX_PDU_LIGHTDATA1                                  , 6u, 2u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3u        , 0u },
    { COM_SIG_RX_LIGHTDATA1_TURNSIGNALSSTATUS                                 , COM_FALSE, COM_RX_PDU_LIGHTDATA1                                  , 3u, 3u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7u        , 0u },
    { COM_SIG_RX_LIGHTDATA1_BRAKELIGHTSTATUS                                  , COM_FALSE, COM_RX_PDU_LIGHTDATA1                                  , 0u, 3u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7u        , 0u },
    { COM_SIG_RX_STATUSACTUATOR_STATUSWIPERS                                      , COM_FALSE, COM_RX_PDU_STATUSACTUATOR                              , 8u, 3u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7u        , 0u },
    { COM_SIG_RX_STATUSACTUATOR_STATUSDOORS                                       , COM_FALSE, COM_RX_PDU_STATUSACTUATOR                              , 0u, 6u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3Fu       , 0u },
    { COM_SIG_RX_OUTSIDETEMPERATURESTATUS_OUTSIDETEMPERATURE                                , COM_FALSE, COM_RX_PDU_OUTSIDETEMPERATURESTATUS                    , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CENTRALCOMMAND1_HIGHBEAMCOMMAND                                   , COM_FALSE, COM_RX_PDU_CENTRALCOMMAND1                             , 37u, 2u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3u        , 0u },
    { COM_SIG_RX_CENTRALCOMMAND1_HC05CONNECTIONSTATUS                              , COM_FALSE, COM_RX_PDU_CENTRALCOMMAND1                             , 35u, 2u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3u        , 0u },
    { COM_SIG_RX_CENTRALCOMMAND1_GEARBOX                                           , COM_FALSE, COM_RX_PDU_CENTRALCOMMAND1                             , 32u, 3u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7u        , 0u },
    { COM_SIG_RX_CENTRALCOMMAND1_RECIRCULATIONCOMMAND                              , COM_FALSE, COM_RX_PDU_CENTRALCOMMAND1                             , 28u, 3u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7u        , 0u },
    { COM_SIG_RX_CENTRALCOMMAND1_TURNSIGNALCOMMAND                                 , COM_FALSE, COM_RX_PDU_CENTRALCOMMAND1                             , 24u, 4u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFu        , 0u },
    { COM_SIG_RX_CENTRALCOMMAND1_IGNITION                                          , COM_FALSE, COM_RX_PDU_CENTRALCOMMAND1                             , 20u, 4u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFu        , 0u },
    { COM_SIG_RX_CENTRALCOMMAND1_CLIMATEFANCOMMAND                                 , COM_FALSE, COM_RX_PDU_CENTRALCOMMAND1                             , 16u, 4u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFu        , 0u },
    { COM_SIG_RX_CENTRALCOMMAND1_FOGLIGHTSCOMMAND                                  , COM_FALSE, COM_RX_PDU_CENTRALCOMMAND1                             , 13u, 3u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7u        , 0u },
    { COM_SIG_RX_CENTRALCOMMAND1_RLSCOMMAND                                        , COM_FALSE, COM_RX_PDU_CENTRALCOMMAND1                             , 8u, 5u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1Fu       , 0u },
    { COM_SIG_RX_CENTRALCOMMAND1_CLIMATEAUTOCOMMAND                                , COM_FALSE, COM_RX_PDU_CENTRALCOMMAND1                             , 6u, 2u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3u        , 0u },
    { COM_SIG_RX_CENTRALCOMMAND1_CLIMATETEMPERATURECOMMAND                         , COM_FALSE, COM_RX_PDU_CENTRALCOMMAND1                             , 0u, 6u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3Fu       , 0u },
    { COM_SIG_RX_CENTRALCOMMAND1_WIPERSTOCKCOMMAND                                 , COM_FALSE, COM_RX_PDU_CENTRALCOMMAND1                             , 56u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_CENTRALCOMMAND1_LIGTHSENSOR                                       , COM_FALSE, COM_RX_PDU_CENTRALCOMMAND1                             , 48u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_CENTRALCOMMAND1_CENTRALLOCKCOMMAND                                , COM_FALSE, COM_RX_PDU_CENTRALCOMMAND1                             , 40u, 3u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7u        , 0u },
    { COM_SIG_RX_DMUSTATUS_DISPLAYCAMERASTATUS                               , COM_FALSE, COM_RX_PDU_DMUSTATUS                                   , 0u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_BATTFULLSTAT_RUNTIMEREMAINING                                  , COM_FALSE, COM_RX_PDU_BATTFULLSTAT                                , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_BATTFULLSTAT_TIMETOFULL                                        , COM_FALSE, COM_RX_PDU_BATTFULLSTAT                                , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_PDCSTAT_PDCDISTANCEREAR                                   , COM_FALSE, COM_RX_PDU_PDCSTAT                                     , 8u, 7u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7Fu       , 0u },
    { COM_SIG_RX_PDCSTAT_PDCDISTANCEFRONT                                  , COM_FALSE, COM_RX_PDU_PDCSTAT                                     , 0u, 7u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7Fu       , 0u },
    { COM_SIG_RX_PDCSTAT_PDCBUZZERFRONTREAR                                , COM_FALSE, COM_RX_PDU_PDCSTAT                                     , 16u, 3u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7u        , 0u },
    { COM_SIG_RX_MILEAGE_MILEAGETRIP                                       , COM_FALSE, COM_RX_PDU_MILEAGE                                     , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_MILEAGE_MILEAGETOTAL                                      , COM_FALSE, COM_RX_PDU_MILEAGE                                     , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_DMU_ALIVE_ALIVEINDICATION                                   , COM_FALSE, COM_RX_PDU_DMU_ALIVE                                   , 0u, 1u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_RX_VOLTAGECURRENT_L1VOLTAGE                                         , COM_FALSE, COM_RX_PDU_VOLTAGECURRENT                              , 48u, 16u, COM_SIGNAL_U16, COM_FALSE, 0u, 0xFFFFu     , 0u },
    { COM_SIG_RX_VOLTAGECURRENT_T30VOLTAGE                                        , COM_FALSE, COM_RX_PDU_VOLTAGECURRENT                              , 32u, 16u, COM_SIGNAL_U16, COM_FALSE, 0u, 0xFFFFu     , 0u },
    { COM_SIG_RX_VOLTAGECURRENT_L1ISENSE                                          , COM_FALSE, COM_RX_PDU_VOLTAGECURRENT                              , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_TEMPMEAS_L1TEMP                                            , COM_FALSE, COM_RX_PDU_TEMPMEAS                                    , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_TEMPMEAS_MCUTEMP                                           , COM_FALSE, COM_RX_PDU_TEMPMEAS                                    , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_LOADSTATUS_LOADSTATUS                                        , COM_FALSE, COM_RX_PDU_LOADSTATUS                                  , 0u, 1u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_RX_L1_I2T_COUNTER_I2TCOUNTER                                        , COM_FALSE, COM_RX_PDU_L1_I2T_COUNTER                              , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_ERROR_706_DTCID_706                                         , COM_FALSE, COM_RX_PDU_ERROR_706                                   , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_ERROR_704_DTCID_704                                         , COM_FALSE, COM_RX_PDU_ERROR_704                                   , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_ERROR_702_DTCID_702                                         , COM_FALSE, COM_RX_PDU_ERROR_702                                   , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_ERROR_700_DTCID_700                                         , COM_FALSE, COM_RX_PDU_ERROR_700                                   , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_BATTSOCSOH_SOH                                               , COM_FALSE, COM_RX_PDU_BATTSOCSOH                                  , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_BATTSOCSOH_SOCHYBRID                                         , COM_FALSE, COM_RX_PDU_BATTSOCSOH                                  , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_BATTSOC_SOCOCV                                            , COM_FALSE, COM_RX_PDU_BATTSOC                                     , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_BATTSOC_SOCCOULOMB                                        , COM_FALSE, COM_RX_PDU_BATTSOC                                     , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_BATTDIAGNOSIS_WEAKBATTERY                                       , COM_FALSE, COM_RX_PDU_BATTDIAGNOSIS                               , 7u, 1u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_RX_BATTDIAGNOSIS_VALIDOCVCALIBRATION                               , COM_FALSE, COM_RX_PDU_BATTDIAGNOSIS                               , 6u, 1u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_RX_BATTDIAGNOSIS_DISCHARGING                                       , COM_FALSE, COM_RX_PDU_BATTDIAGNOSIS                               , 5u, 1u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_RX_BATTDIAGNOSIS_DEEPDISCHARGE                                     , COM_FALSE, COM_RX_PDU_BATTDIAGNOSIS                               , 4u, 1u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_RX_BATTDIAGNOSIS_CRANKINGEVENT                                     , COM_FALSE, COM_RX_PDU_BATTDIAGNOSIS                               , 3u, 1u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_RX_BATTDIAGNOSIS_CONFINDENCE                                       , COM_FALSE, COM_RX_PDU_BATTDIAGNOSIS                               , 2u, 1u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_RX_BATTDIAGNOSIS_CHARGING                                          , COM_FALSE, COM_RX_PDU_BATTDIAGNOSIS                               , 1u, 1u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_RX_BATTDIAGNOSIS_BATTREST                                          , COM_FALSE, COM_RX_PDU_BATTDIAGNOSIS                               , 0u, 1u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_RX_BATTCURRENT_AVGDISCHARGECURRENT                               , COM_FALSE, COM_RX_PDU_BATTCURRENT                                 , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_BATTCURRENT_AVGCHARGECURRENT                                  , COM_FALSE, COM_RX_PDU_BATTCURRENT                                 , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_BATTCAPDISCHARGE_DISCHARGEAH                                       , COM_FALSE, COM_RX_PDU_BATTCAPDISCHARGE                            , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_BATTCAPDISCHARGE_CHARGEAH                                          , COM_FALSE, COM_RX_PDU_BATTCAPDISCHARGE                            , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_BATTCAPRES_INTRESISTANCE                                     , COM_FALSE, COM_RX_PDU_BATTCAPRES                                  , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_BATTCAPRES_CAPACITYAH                                        , COM_FALSE, COM_RX_PDU_BATTCAPRES                                  , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_INFOTAINMENTDATA1_IT1_MILEAGETRIP                                                  , COM_TRUE,  COM_TX_PDU_CANFD_INFOTAINMENTDATA1                                      , 56u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_INFOTAINMENTDATA1_IT1_MILEAGETOTAL                                                 , COM_TRUE,  COM_TX_PDU_CANFD_INFOTAINMENTDATA1                                      , 24u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_INFOTAINMENTDATA1_IT1_DISPLAYCAMERASTATUS                                          , COM_TRUE,  COM_TX_PDU_CANFD_INFOTAINMENTDATA1                                      , 16u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_INFOTAINMENTDATA1_IT1_COMMANDDISPLAYERRORMESSAGE                                   , COM_TRUE,  COM_TX_PDU_CANFD_INFOTAINMENTDATA1                                      , 8u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_INFOTAINMENTDATA1_IT1_ALIVEINDICATION                                              , COM_TRUE,  COM_TX_PDU_CANFD_INFOTAINMENTDATA1                                      , 0u, 1u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA2_EM1_WEAKBATTERY                                                  , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA2                                  , 8u, 1u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA2_EM1_VALIDOCVCALIBRATION                                          , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA2                                  , 7u, 1u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA2_EM1_LOADSTATUS                                                   , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA2                                  , 6u, 1u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA2_EM1_DISCHARGING                                                  , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA2                                  , 5u, 1u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA2_EM1_DEEPDISCHARGE                                                , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA2                                  , 4u, 1u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA2_EM1_CRANKINGEVENT                                                , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA2                                  , 3u, 1u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA2_EM1_CONFINDENCE                                                  , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA2                                  , 2u, 1u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA2_EM1_CHARGING                                                     , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA2                                  , 1u, 1u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA2_EM1_CAPACITYAH                                                   , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA2                                  , 16u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA2_EM1_BATTREST                                                     , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA2                                  , 0u, 1u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA1_EM1_TIMETOFULL                                                   , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA1                                  , 480u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA1_EM1_T30VOLTAGE                                                   , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA1                                  , 80u, 16u, COM_SIGNAL_U16, COM_FALSE, 0u, 0xFFFFu     , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA1_EM1_SOH                                                          , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA1                                  , 448u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA1_EM1_SOCOCV                                                       , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA1                                  , 416u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA1_EM1_SOCHYBRID                                                    , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA1                                  , 384u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA1_EM1_SOCCOULOMB                                                   , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA1                                  , 352u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA1_EM1_RUNTIMEREMAINING                                             , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA1                                  , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA1_EM1_MCUTEMP                                                      , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA1                                  , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA1_EM1_L1VOLTAGE                                                    , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA1                                  , 64u, 16u, COM_SIGNAL_U16, COM_FALSE, 0u, 0xFFFFu     , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA1_EM1_L1TEMP                                                       , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA1                                  , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA1_EM1_L1ISENSE                                                     , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA1                                  , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA1_EM1_INTRESISTANCE                                                , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA1                                  , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA1_EM1_I2TCOUNTER                                                   , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA1                                  , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA1_EM1_DISCHARGEAH                                                  , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA1                                  , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA1_EM1_CHARGEAH                                                     , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA1                                  , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA1_EM1_AVGDISCHARGECURRENT                                          , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA1                                  , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA1_EM1_AVGCHARGECURRENT                                             , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA1                                  , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_VEHICLESTATE_VEHICLESTATUS                                                    , COM_TRUE,  COM_TX_PDU_CANFD_VEHICLESTATE                                           , 0u, 4u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFu        , 0u },
    { COM_SIG_TX_CANFD_NM3_NM3_PN1                                                          , COM_TRUE,  COM_TX_PDU_CANFD_NM3                                                    , 0u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_SDAT_CANFD_SDAT_YEAR                                                  , COM_TRUE,  COM_TX_PDU_CANFD_SDAT                                                   , 48u, 6u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3Fu       , 0u },
    { COM_SIG_TX_CANFD_SDAT_CANFD_SDAT_SECOND                                                , COM_TRUE,  COM_TX_PDU_CANFD_SDAT                                                   , 40u, 6u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3Fu       , 0u },
    { COM_SIG_TX_CANFD_SDAT_CANFD_SDAT_MONTH                                                 , COM_TRUE,  COM_TX_PDU_CANFD_SDAT                                                   , 32u, 4u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFu        , 0u },
    { COM_SIG_TX_CANFD_SDAT_CANFD_SDAT_MINUTE                                                , COM_TRUE,  COM_TX_PDU_CANFD_SDAT                                                   , 24u, 6u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3Fu       , 0u },
    { COM_SIG_TX_CANFD_SDAT_CANFD_SDAT_MILLISECOND                                           , COM_TRUE,  COM_TX_PDU_CANFD_SDAT                                                   , 16u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_SDAT_CANFD_SDAT_HOUR                                                  , COM_TRUE,  COM_TX_PDU_CANFD_SDAT                                                   , 8u, 5u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1Fu       , 0u },
    { COM_SIG_TX_CANFD_SDAT_CANFD_SDAT_DAY                                                   , COM_TRUE,  COM_TX_PDU_CANFD_SDAT                                                   , 0u, 5u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1Fu       , 0u },
    { COM_SIG_TX_CANFD_SDAT_CANFD_SDAT_TIMESOURCE                                            , COM_TRUE,  COM_TX_PDU_CANFD_SDAT                                                   , 5u, 2u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3u        , 0u },
    { COM_SIG_TX_CANFD_SDAT_CANFD_SDAT_UTCVALID                                              , COM_TRUE,  COM_TX_PDU_CANFD_SDAT                                                   , 7u, 1u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_TX_CANFD_SDAT_CANFD_SDAT_DEFAULTTIME                                           , COM_TRUE,  COM_TX_PDU_CANFD_SDAT                                                   , 13u, 1u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_TX_CANFD_SDAT_CANFD_SDAT_NVMRESTORED                                           , COM_TRUE,  COM_TX_PDU_CANFD_SDAT                                                   , 14u, 1u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_TX_CANFD_LIGHTDATA1_LD1_TURNSIGNALSSTATUS                                            , COM_TRUE,  COM_TX_PDU_CANFD_LIGHTDATA1                                             , 16u, 3u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7u        , 0u },
    { COM_SIG_TX_CANFD_LIGHTDATA1_LD1_TURNSIGNALCOMMAND                                            , COM_TRUE,  COM_TX_PDU_CANFD_LIGHTDATA1                                             , 12u, 4u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFu        , 0u },
    { COM_SIG_TX_CANFD_LIGHTDATA1_LD1_REVERSELIGTHSTATUS                                           , COM_TRUE,  COM_TX_PDU_CANFD_LIGHTDATA1                                             , 10u, 2u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3u        , 0u },
    { COM_SIG_TX_CANFD_LIGHTDATA1_LD1_POSITIONLIGHTSTATUS                                          , COM_TRUE,  COM_TX_PDU_CANFD_LIGHTDATA1                                             , 8u, 2u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3u        , 0u },
    { COM_SIG_TX_CANFD_LIGHTDATA1_LD1_LOWBEAMSTATUS                                                , COM_TRUE,  COM_TX_PDU_CANFD_LIGHTDATA1                                             , 6u, 2u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3u        , 0u },
    { COM_SIG_TX_CANFD_LIGHTDATA1_LD1_INTERIORLIGHTSTATUS                                          , COM_TRUE,  COM_TX_PDU_CANFD_LIGHTDATA1                                             , 4u, 2u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3u        , 0u },
    { COM_SIG_TX_CANFD_LIGHTDATA1_LD1_HIGHBEAMSTATUS                                               , COM_TRUE,  COM_TX_PDU_CANFD_LIGHTDATA1                                             , 2u, 2u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3u        , 0u },
    { COM_SIG_TX_CANFD_LIGHTDATA1_LD1_FOGLIGHTSSTATUS                                              , COM_TRUE,  COM_TX_PDU_CANFD_LIGHTDATA1                                             , 0u, 2u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3u        , 0u },
    { COM_SIG_TX_CANFD_BODYDATA1_BD1_WIPERSTOCKCOMMAND                                            , COM_TRUE,  COM_TX_PDU_CANFD_BODYDATA1                                              , 128u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_BODYDATA1_BD1_VIBRATIONSENSORSTATUS                                        , COM_TRUE,  COM_TX_PDU_CANFD_BODYDATA1                                              , 120u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_BODYDATA1_BD1_STATUSWIPERS                                                 , COM_TRUE,  COM_TX_PDU_CANFD_BODYDATA1                                              , 109u, 3u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7u        , 0u },
    { COM_SIG_TX_CANFD_BODYDATA1_BD1_STATUSDOORS                                                  , COM_TRUE,  COM_TX_PDU_CANFD_BODYDATA1                                              , 112u, 6u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3Fu       , 0u },
    { COM_SIG_TX_CANFD_BODYDATA1_BD1_RLSCOMMAND                                                   , COM_TRUE,  COM_TX_PDU_CANFD_BODYDATA1                                              , 104u, 5u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1Fu       , 0u },
    { COM_SIG_TX_CANFD_BODYDATA1_BD1_RECIRCULATIONCOMMAND                                         , COM_TRUE,  COM_TX_PDU_CANFD_BODYDATA1                                              , 83u, 3u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7u        , 0u },
    { COM_SIG_TX_CANFD_BODYDATA1_BD1_PDCDISTANCEREAR                                              , COM_TRUE,  COM_TX_PDU_CANFD_BODYDATA1                                              , 96u, 7u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7Fu       , 0u },
    { COM_SIG_TX_CANFD_BODYDATA1_BD1_PDCDISTANCEFRONT                                             , COM_TRUE,  COM_TX_PDU_CANFD_BODYDATA1                                              , 88u, 7u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7Fu       , 0u },
    { COM_SIG_TX_CANFD_BODYDATA1_BD1_PDCBUZZERFRONTREAR                                           , COM_TRUE,  COM_TX_PDU_CANFD_BODYDATA1                                              , 80u, 3u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7u        , 0u },
    { COM_SIG_TX_CANFD_BODYDATA1_BD1_OUTSIDETEMPERATURE                                           , COM_TRUE,  COM_TX_PDU_CANFD_BODYDATA1                                              , 48u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_BODYDATA1_BD1_LIGTHSENSOR                                                  , COM_TRUE,  COM_TX_PDU_CANFD_BODYDATA1                                              , 40u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_BODYDATA1_BD1_IGNITION                                                     , COM_TRUE,  COM_TX_PDU_CANFD_BODYDATA1                                              , 34u, 4u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFu        , 0u },
    { COM_SIG_TX_CANFD_BODYDATA1_BD1_HIGHBEAMCOMMAND                                              , COM_TRUE,  COM_TX_PDU_CANFD_BODYDATA1                                              , 32u, 2u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3u        , 0u },
    { COM_SIG_TX_CANFD_BODYDATA1_BD1_HC05CONNECTIONSTATUS                                         , COM_TRUE,  COM_TX_PDU_CANFD_BODYDATA1                                              , 30u, 2u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3u        , 0u },
    { COM_SIG_TX_CANFD_BODYDATA1_BD1_GEARBOX                                                      , COM_TRUE,  COM_TX_PDU_CANFD_BODYDATA1                                              , 20u, 3u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7u        , 0u },
    { COM_SIG_TX_CANFD_BODYDATA1_BD1_FOGLIGHTSCOMMAND                                             , COM_TRUE,  COM_TX_PDU_CANFD_BODYDATA1                                              , 13u, 3u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7u        , 0u },
    { COM_SIG_TX_CANFD_BODYDATA1_BD1_CLIMATETEMPERATURECOMMAND                                    , COM_TRUE,  COM_TX_PDU_CANFD_BODYDATA1                                              , 24u, 6u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3Fu       , 0u },
    { COM_SIG_TX_CANFD_BODYDATA1_BD1_CLIMATEFANCOMMAND                                            , COM_TRUE,  COM_TX_PDU_CANFD_BODYDATA1                                              , 16u, 4u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFu        , 0u },
    { COM_SIG_TX_CANFD_BODYDATA1_BD1_CLIMATEAUTOCOMMAND                                           , COM_TRUE,  COM_TX_PDU_CANFD_BODYDATA1                                              , 11u, 2u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3u        , 0u },
    { COM_SIG_TX_CANFD_BODYDATA1_BD1_CENTRALLOCKSTATUS                                            , COM_TRUE,  COM_TX_PDU_CANFD_BODYDATA1                                              , 8u, 3u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7u        , 0u },
    { COM_SIG_TX_CANFD_BODYDATA1_BD1_CENTRALLOCKCOMMAND                                           , COM_TRUE,  COM_TX_PDU_CANFD_BODYDATA1                                              , 5u, 3u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7u        , 0u },
    { COM_SIG_TX_CANFD_BODYDATA1_BD1_CENTRALLOCKBUZZER                                            , COM_TRUE,  COM_TX_PDU_CANFD_BODYDATA1                                              , 3u, 2u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3u        , 0u },
    { COM_SIG_TX_CANFD_BODYDATA1_BD1_BRAKELIGHTSTATUS                                             , COM_TRUE,  COM_TX_PDU_CANFD_BODYDATA1                                              , 0u, 3u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7u        , 0u },
    { COM_SIG_TX_CANFD_PDM1_DIAGREQUEST_PDM1_DIAGREQ_BYTE00                                              , COM_TRUE,  COM_TX_PDU_CANFD_PDM1_DIAGREQUEST                                       , 0u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_PDM1_DIAGREQUEST_PDM1_DIAGREQ_BYTE01                                              , COM_TRUE,  COM_TX_PDU_CANFD_PDM1_DIAGREQUEST                                       , 8u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_PDM1_DIAGREQUEST_PDM1_DIAGREQ_BYTE02                                              , COM_TRUE,  COM_TX_PDU_CANFD_PDM1_DIAGREQUEST                                       , 16u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_PDM1_DIAGREQUEST_PDM1_DIAGREQ_BYTE03                                              , COM_TRUE,  COM_TX_PDU_CANFD_PDM1_DIAGREQUEST                                       , 24u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_PDM1_DIAGREQUEST_PDM1_DIAGREQ_BYTE04                                              , COM_TRUE,  COM_TX_PDU_CANFD_PDM1_DIAGREQUEST                                       , 32u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_PDM1_DIAGREQUEST_PDM1_DIAGREQ_BYTE05                                              , COM_TRUE,  COM_TX_PDU_CANFD_PDM1_DIAGREQUEST                                       , 40u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_PDM1_DIAGREQUEST_PDM1_DIAGREQ_BYTE06                                              , COM_TRUE,  COM_TX_PDU_CANFD_PDM1_DIAGREQUEST                                       , 48u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_PDM1_DIAGREQUEST_PDM1_DIAGREQ_BYTE07                                              , COM_TRUE,  COM_TX_PDU_CANFD_PDM1_DIAGREQUEST                                       , 56u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_COMMANDLOAD_PDM1_PDM1_COMMANDLOAD_01                                              , COM_TRUE,  COM_TX_PDU_CANFD_COMMANDLOAD_PDM1                                       , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_COMMANDLOAD_PDM1_PDM1_COMMANDLOAD_02                                              , COM_TRUE,  COM_TX_PDU_CANFD_COMMANDLOAD_PDM1                                       , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_COMMANDLOAD_PDM1_PDM1_COMMANDLOAD_03                                              , COM_TRUE,  COM_TX_PDU_CANFD_COMMANDLOAD_PDM1                                       , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA3_HVDCDC_RESPONSEERROR                                             , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA3                                  , 0u, 1u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA3_HVDCDC_LV_VOLTAGE                                                , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA3                                  , 8u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA3_HVDCDC_LV_CURRENT                                                , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA3                                  , 16u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA3_HVDCDC_HV_VOLTAGE                                                , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA3                                  , 24u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA3_HVDCDC_HV_CURRENT                                                , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA3                                  , 32u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_CANFD_PDM1_LOADSTATUS_PDM1_LOADSTATUS_01                                               , COM_FALSE, COM_RX_PDU_CANFD_PDM1_LOADSTATUS                                        , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_LOADSTATUS_PDM1_LOADSTATUS_02                                               , COM_FALSE, COM_RX_PDU_CANFD_PDM1_LOADSTATUS                                        , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_LOADSTATUS_PDM1_LOADSTATUS_03                                               , COM_FALSE, COM_RX_PDU_CANFD_PDM1_LOADSTATUS                                        , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_INPUTT30_INPUTT30                                                           , COM_FALSE, COM_RX_PDU_CANFD_PDM1_INPUTT30                                          , 0u, 16u, COM_SIGNAL_U16, COM_FALSE, 0u, 0xFFFFu     , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_1_PDM1_CURRFB_001                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_1                                 , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_1_PDM1_CURRFB_002                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_1                                 , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_1_PDM1_CURRFB_003                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_1                                 , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_1_PDM1_CURRFB_004                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_1                                 , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_1_PDM1_CURRFB_005                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_1                                 , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_1_PDM1_CURRFB_006                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_1                                 , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_1_PDM1_CURRFB_007                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_1                                 , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_1_PDM1_CURRFB_008                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_1                                 , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_1_PDM1_CURRFB_009                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_1                                 , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_1_PDM1_CURRFB_010                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_1                                 , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_1_PDM1_CURRFB_011                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_1                                 , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_1_PDM1_CURRFB_012                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_1                                 , 352u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_1_PDM1_CURRFB_013                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_1                                 , 384u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_1_PDM1_CURRFB_014                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_1                                 , 416u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_1_PDM1_CURRFB_015                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_1                                 , 448u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_1_PDM1_CURRFB_016                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_1                                 , 480u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_2_PDM1_CURRFB_017                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_2                                 , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_2_PDM1_CURRFB_018                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_2                                 , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_2_PDM1_CURRFB_019                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_2                                 , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_2_PDM1_CURRFB_020                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_2                                 , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_2_PDM1_CURRFB_021                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_2                                 , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_2_PDM1_CURRFB_022                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_2                                 , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_2_PDM1_CURRFB_023                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_2                                 , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_2_PDM1_CURRFB_024                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_2                                 , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_2_PDM1_CURRFB_025                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_2                                 , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_2_PDM1_CURRFB_026                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_2                                 , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_2_PDM1_CURRFB_027                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_2                                 , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_2_PDM1_CURRFB_028                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_2                                 , 352u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_2_PDM1_CURRFB_029                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_2                                 , 384u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_2_PDM1_CURRFB_030                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_2                                 , 416u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_2_PDM1_CURRFB_031                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_2                                 , 448u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_2_PDM1_CURRFB_032                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_2                                 , 480u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_3_PDM1_CURRFB_033                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_3                                 , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_3_PDM1_CURRFB_034                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_3                                 , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_3_PDM1_CURRFB_035                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_3                                 , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_3_PDM1_CURRFB_036                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_3                                 , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_3_PDM1_CURRFB_037                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_3                                 , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_3_PDM1_CURRFB_038                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_3                                 , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_3_PDM1_CURRFB_039                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_3                                 , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_3_PDM1_CURRFB_040                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_3                                 , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_3_PDM1_CURRFB_041                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_3                                 , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_3_PDM1_CURRFB_042                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_3                                 , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_3_PDM1_CURRFB_043                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_3                                 , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_3_PDM1_CURRFB_044                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_3                                 , 352u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_3_PDM1_CURRFB_045                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_3                                 , 384u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_3_PDM1_CURRFB_046                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_3                                 , 416u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_3_PDM1_CURRFB_047                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_3                                 , 448u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_3_PDM1_CURRFB_048                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_3                                 , 480u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_4_PDM1_CURRFB_049                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_4                                 , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_4_PDM1_CURRFB_050                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_4                                 , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_4_PDM1_CURRFB_051                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_4                                 , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_4_PDM1_CURRFB_052                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_4                                 , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_4_PDM1_CURRFB_053                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_4                                 , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_4_PDM1_CURRFB_054                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_4                                 , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_4_PDM1_CURRFB_055                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_4                                 , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_4_PDM1_CURRFB_056                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_4                                 , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_4_PDM1_CURRFB_057                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_4                                 , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_4_PDM1_CURRFB_058                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_4                                 , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_4_PDM1_CURRFB_059                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_4                                 , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_4_PDM1_CURRFB_060                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_4                                 , 352u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_4_PDM1_CURRFB_061                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_4                                 , 384u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_4_PDM1_CURRFB_062                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_4                                 , 416u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_4_PDM1_CURRFB_063                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_4                                 , 448u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_4_PDM1_CURRFB_064                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_4                                 , 480u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_5_PDM1_CURRFB_065                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_5                                 , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_5_PDM1_CURRFB_066                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_5                                 , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_5_PDM1_CURRFB_067                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_5                                 , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_5_PDM1_CURRFB_068                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_5                                 , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_5_PDM1_CURRFB_069                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_5                                 , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_5_PDM1_CURRFB_070                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_5                                 , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_5_PDM1_CURRFB_071                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_5                                 , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_5_PDM1_CURRFB_072                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_5                                 , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_5_PDM1_CURRFB_073                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_5                                 , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_5_PDM1_CURRFB_074                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_5                                 , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_5_PDM1_CURRFB_075                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_5                                 , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_DIAGRESPONSE_PDM1_DIAGRESP_BYTE00                                             , COM_FALSE, COM_RX_PDU_CANFD_PDM1_DIAGRESPONSE                                      , 0u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_CANFD_PDM1_DIAGRESPONSE_PDM1_DIAGRESP_BYTE01                                             , COM_FALSE, COM_RX_PDU_CANFD_PDM1_DIAGRESPONSE                                      , 8u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_CANFD_PDM1_DIAGRESPONSE_PDM1_DIAGRESP_BYTE02                                             , COM_FALSE, COM_RX_PDU_CANFD_PDM1_DIAGRESPONSE                                      , 16u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_CANFD_PDM1_DIAGRESPONSE_PDM1_DIAGRESP_BYTE03                                             , COM_FALSE, COM_RX_PDU_CANFD_PDM1_DIAGRESPONSE                                      , 24u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_CANFD_PDM1_DIAGRESPONSE_PDM1_DIAGRESP_BYTE04                                             , COM_FALSE, COM_RX_PDU_CANFD_PDM1_DIAGRESPONSE                                      , 32u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_CANFD_PDM1_DIAGRESPONSE_PDM1_DIAGRESP_BYTE05                                             , COM_FALSE, COM_RX_PDU_CANFD_PDM1_DIAGRESPONSE                                      , 40u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_CANFD_PDM1_DIAGRESPONSE_PDM1_DIAGRESP_BYTE06                                             , COM_FALSE, COM_RX_PDU_CANFD_PDM1_DIAGRESPONSE                                      , 48u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_CANFD_PDM1_DIAGRESPONSE_PDM1_DIAGRESP_BYTE07                                             , COM_FALSE, COM_RX_PDU_CANFD_PDM1_DIAGRESPONSE                                      , 56u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_LIN_ZGW_REQUEST_HVDCDC_ZGW_ENABLE_HVDCDC                                 , COM_TRUE,  COM_TX_PDU_LIN_ZGW_REQUEST_HVDCDC                 , 0u, 1u, COM_SIGNAL_U8, COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_TX_LIN_ZGW_REQUEST_HVDCDC_ZGW_TARGETVOLTAGE_HVDCDC                          , COM_TRUE,  COM_TX_PDU_LIN_ZGW_REQUEST_HVDCDC                 , 8u, 8u, COM_SIGNAL_U8, COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_LIN_ZGW_SDAT_MINUTE                                                       , COM_TRUE,  COM_TX_PDU_LIN_ZGW_SDAT                           , 0u, 6u, COM_SIGNAL_U8, COM_FALSE, 0u, 0x3Fu       , 0u },
    { COM_SIG_TX_LIN_ZGW_SDAT_TIMESOURCE                                                   , COM_TRUE,  COM_TX_PDU_LIN_ZGW_SDAT                           , 6u, 2u, COM_SIGNAL_U8, COM_FALSE, 0u, 0x3u        , 3u },
    { COM_SIG_TX_LIN_ZGW_SDAT_SECOND                                                       , COM_TRUE,  COM_TX_PDU_LIN_ZGW_SDAT                           , 8u, 6u, COM_SIGNAL_U8, COM_FALSE, 0u, 0x3Fu       , 0u },
    { COM_SIG_TX_LIN_ZGW_SDAT_UTCVALID                                                     , COM_TRUE,  COM_TX_PDU_LIN_ZGW_SDAT                           , 14u, 1u, COM_SIGNAL_U8, COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_TX_LIN_ZGW_SDAT_DEFAULTTIME                                                  , COM_TRUE,  COM_TX_PDU_LIN_ZGW_SDAT                           , 15u, 1u, COM_SIGNAL_U8, COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_TX_LIN_ZGW_SDAT_YEAR                                                         , COM_TRUE,  COM_TX_PDU_LIN_ZGW_SDAT                           , 16u, 6u, COM_SIGNAL_U8, COM_FALSE, 0u, 0x3Fu       , 0u },
    { COM_SIG_TX_LIN_ZGW_SDAT_NVMRESTORED                                                  , COM_TRUE,  COM_TX_PDU_LIN_ZGW_SDAT                           , 22u, 1u, COM_SIGNAL_U8, COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_TX_LIN_ZGW_SDAT_DAY                                                          , COM_TRUE,  COM_TX_PDU_LIN_ZGW_SDAT                           , 24u, 5u, COM_SIGNAL_U8, COM_FALSE, 0u, 0x1Fu       , 0u },
    { COM_SIG_TX_LIN_ZGW_SDAT_HOUR                                                         , COM_TRUE,  COM_TX_PDU_LIN_ZGW_SDAT                           , 32u, 5u, COM_SIGNAL_U8, COM_FALSE, 0u, 0x1Fu       , 0u },
    { COM_SIG_TX_LIN_ZGW_SDAT_MONTH                                                        , COM_TRUE,  COM_TX_PDU_LIN_ZGW_SDAT                           , 40u, 4u, COM_SIGNAL_U8, COM_FALSE, 0u, 0xFu        , 0u },
    { COM_SIG_TX_LIN_ZGW_SDAT_MILLISECOND                                                  , COM_TRUE,  COM_TX_PDU_LIN_ZGW_SDAT                           , 48u, 8u, COM_SIGNAL_U8, COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_LIN_HVDCDC_STATUS_HVDCDC_RESPONSEERROR                              , COM_FALSE, COM_RX_PDU_LIN_HVDCDC_STATUS                      , 0u, 1u, COM_SIGNAL_U8, COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_RX_LIN_HVDCDC_STATUS_HVDCDC_LV_VOLTAGE                                 , COM_FALSE, COM_RX_PDU_LIN_HVDCDC_STATUS                      , 8u, 8u, COM_SIGNAL_U8, COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_LIN_HVDCDC_STATUS_HVDCDC_LV_CURRENT                                 , COM_FALSE, COM_RX_PDU_LIN_HVDCDC_STATUS                      , 16u, 8u, COM_SIGNAL_U8, COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_LIN_HVDCDC_STATUS_HVDCDC_HV_VOLTAGE                                 , COM_FALSE, COM_RX_PDU_LIN_HVDCDC_STATUS                      , 24u, 8u, COM_SIGNAL_U8, COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_LIN_HVDCDC_STATUS_HVDCDC_HV_CURRENT                                 , COM_FALSE, COM_RX_PDU_LIN_HVDCDC_STATUS                      , 32u, 8u, COM_SIGNAL_U8, COM_FALSE, 0u, 0xFFu       , 0u }
};

#define COM_TX_IPDU_COUNT (sizeof(Com_TxIpduCfg) / sizeof(Com_TxIpduCfg[0]))
#define COM_RX_IPDU_COUNT (sizeof(Com_RxIpduCfg) / sizeof(Com_RxIpduCfg[0]))
#define COM_SIGNAL_COUNT  (sizeof(Com_SignalCfg) / sizeof(Com_SignalCfg[0]))

static Com_TxIpduRuntimeType Com_TxRt[COM_TX_IPDU_COUNT];
static Com_RxIpduRuntimeType Com_RxRt[COM_RX_IPDU_COUNT];
static uint32 Com_MainFunctionTxSequence = 0u;
static uint8 Com_MainFunctionTxActive = COM_FALSE;
static uint32 Com_TxLastTriggerSequence[COM_TX_IPDU_COUNT];
volatile uint32 Com_TxTriggerCounter[COM_TX_IPDU_COUNT];
volatile uint32 Com_TxDuplicateSuppressedCounter[COM_TX_IPDU_COUNT];
volatile uint32 Com_TxBusyRejectedCounter[COM_TX_IPDU_COUNT];
long long Com_MainFunctionTx_Counter = 0;
long long Com_MainFunctionRx_Counter = 0;
#if COM_DEBUG_INSTRUMENTATION
volatile uint16 Com_DebugFindSignalLastId = 0u;
volatile uint16 Com_DebugFindSignalIndex = 0u;
volatile uint16 Com_DebugFindSignalCount = (uint16)COM_SIGNAL_COUNT;
volatile uint16 Com_DebugFindSignalEntryId = 0u;
volatile uint8 Com_DebugFindSignalHit = 0u;
volatile uint32 Com_DebugFindSignalTableBase = 0u;
volatile uint32 Com_DebugFindSignalTableEnd = 0u;
volatile uint32 Com_DebugFindSignalEntryAddress = 0u;
volatile uint32 Com_DebugFindSignalMatchAddress = 0u;
volatile uint16 Com_DebugFindSignalEntryPduId = 0u;
volatile uint8 Com_DebugFindSignalEntryIsTx = 0u;
volatile uint16 Com_DebugSendSignalLastId = 0u;
volatile uint16 Com_DebugSendSignalLastPduId = 0u;
volatile uint8 Com_DebugSendSignalLastTxIdx = 0xFFu;
volatile uint8 Com_DebugSendSignalLastRet = E_NOT_OK;
volatile uint32 Com_DebugSendSignalLastValue = 0u;
volatile uint32 Com_DebugSendSignalLastSigAddress = 0u;
volatile uint16 Com_DebugReceiveSignalLastId = 0u;
volatile uint16 Com_DebugReceiveSignalLastPduId = 0u;
volatile uint8 Com_DebugReceiveSignalLastRxIdx = 0xFFu;
volatile uint8 Com_DebugReceiveSignalLastRet = E_NOT_OK;
volatile uint32 Com_DebugReceiveSignalLastValue = 0u;
volatile uint16 Com_DebugInvalidSignalId = 0u;
volatile uint16 Com_DebugInvalidPduId = 0u;
volatile uint16 Com_DebugInvalidBitPosition = 0u;
volatile uint8 Com_DebugInvalidBitSize = 0u;
volatile uint8 Com_DebugInvalidPduLength = 0u;
volatile uint8 Com_DebugInvalidReason = 0u;
#endif

#define COM_DEBUG_INVALID_NONE          0u
#define COM_DEBUG_INVALID_NULL_BUFFER   1u
#define COM_DEBUG_INVALID_BIT_SIZE      2u
#define COM_DEBUG_INVALID_RANGE         3u
#define COM_DEBUG_INVALID_DATA_SIZE     4u

#if COM_DEBUG_INSTRUMENTATION
#define COM_DEBUG_ASSIGN(lhs, rhs) do { (lhs) = (rhs); } while (0)
#else
#define COM_DEBUG_ASSIGN(lhs, rhs) do { (void)0; } while (0)
#endif


static uint8 Com_FindTxIpdu(PduIdType pduId)
{
    uint8 i;

    for (i = 0u; i < COM_TX_IPDU_COUNT; i++)
    {
        if (Com_TxIpduCfg[i].pduId == pduId)
        {
            return i;
        }
    }

    return 0xFFu;
}

static uint8 Com_FindRxIpdu(PduIdType pduId)
{
    uint8 i;

    for (i = 0u; i < COM_RX_IPDU_COUNT; i++)
    {
        if (Com_RxIpduCfg[i].pduId == pduId)
        {
            return i;
        }
    }

    return 0xFFu;
}

static const Com_SignalConfigType* Com_FindSignal(Com_SignalIdType signalId)
{
    const Com_SignalConfigType* entry;
    uint16 entrySignalId;
    uint16 i;

    COM_DEBUG_ASSIGN(Com_DebugFindSignalLastId, signalId);
    COM_DEBUG_ASSIGN(Com_DebugFindSignalCount, (uint16)COM_SIGNAL_COUNT);
    COM_DEBUG_ASSIGN(Com_DebugFindSignalHit, 0u);
    COM_DEBUG_ASSIGN(Com_DebugFindSignalTableBase, (uint32)(const void *)&Com_SignalCfg[0u]);
    COM_DEBUG_ASSIGN(Com_DebugFindSignalTableEnd, (uint32)(const void *)&Com_SignalCfg[COM_SIGNAL_COUNT]);
    COM_DEBUG_ASSIGN(Com_DebugFindSignalEntryAddress, Com_DebugFindSignalTableBase);
    COM_DEBUG_ASSIGN(Com_DebugFindSignalMatchAddress, 0u);
    for (i = 0u; i < (uint16)COM_SIGNAL_COUNT; i++)
    {
        entry = &Com_SignalCfg[i];
        COM_DEBUG_ASSIGN(Com_DebugFindSignalIndex, i);
        COM_DEBUG_ASSIGN(Com_DebugFindSignalEntryAddress, (uint32)(const void *)entry);
        entrySignalId = entry->signalId;
        COM_DEBUG_ASSIGN(Com_DebugFindSignalEntryId, entrySignalId);
        COM_DEBUG_ASSIGN(Com_DebugFindSignalEntryPduId, entry->pduId);
        COM_DEBUG_ASSIGN(Com_DebugFindSignalEntryIsTx, entry->isTx);
        if (entrySignalId == signalId)
        {
            COM_DEBUG_ASSIGN(Com_DebugFindSignalHit, 1u);
            COM_DEBUG_ASSIGN(Com_DebugFindSignalMatchAddress, (uint32)(const void *)entry);
            return entry;
        }
    }

    return NULL_PTR;
}


static uint8 Com_IsValidSignalAccess(const Com_SignalConfigType* sig, uint8 pduLen)
{
    uint16 signalEndBit;
    uint16 updateEndBit;

    if (sig == NULL_PTR)
    {
        return COM_FALSE;
    }

    if ((sig->bitSize == 0u) || (sig->bitSize > 32u))
    {
        COM_DEBUG_ASSIGN(Com_DebugInvalidSignalId, sig->signalId);
        COM_DEBUG_ASSIGN(Com_DebugInvalidPduId, sig->pduId);
        COM_DEBUG_ASSIGN(Com_DebugInvalidBitPosition, sig->bitPosition);
        COM_DEBUG_ASSIGN(Com_DebugInvalidBitSize, sig->bitSize);
        COM_DEBUG_ASSIGN(Com_DebugInvalidPduLength, pduLen);
        COM_DEBUG_ASSIGN(Com_DebugInvalidReason, COM_DEBUG_INVALID_BIT_SIZE);
        return COM_FALSE;
    }

    if ((sig->dataSize != COM_SIGNAL_U8) &&
        (sig->dataSize != COM_SIGNAL_U16) &&
        (sig->dataSize != COM_SIGNAL_U32))
    {
        COM_DEBUG_ASSIGN(Com_DebugInvalidSignalId, sig->signalId);
        COM_DEBUG_ASSIGN(Com_DebugInvalidPduId, sig->pduId);
        COM_DEBUG_ASSIGN(Com_DebugInvalidBitPosition, sig->bitPosition);
        COM_DEBUG_ASSIGN(Com_DebugInvalidBitSize, sig->bitSize);
        COM_DEBUG_ASSIGN(Com_DebugInvalidPduLength, pduLen);
        COM_DEBUG_ASSIGN(Com_DebugInvalidReason, COM_DEBUG_INVALID_DATA_SIZE);
        return COM_FALSE;
    }

    signalEndBit = (uint16)(sig->bitPosition + (uint16)sig->bitSize);

    if ((signalEndBit > ((uint16)pduLen * 8u)) || (signalEndBit < sig->bitPosition))
    {
        COM_DEBUG_ASSIGN(Com_DebugInvalidSignalId, sig->signalId);
        COM_DEBUG_ASSIGN(Com_DebugInvalidPduId, sig->pduId);
        COM_DEBUG_ASSIGN(Com_DebugInvalidBitPosition, sig->bitPosition);
        COM_DEBUG_ASSIGN(Com_DebugInvalidBitSize, sig->bitSize);
        COM_DEBUG_ASSIGN(Com_DebugInvalidPduLength, pduLen);
        COM_DEBUG_ASSIGN(Com_DebugInvalidReason, COM_DEBUG_INVALID_RANGE);
        return COM_FALSE;
    }

    if (sig->hasUpdateBit != COM_FALSE)
    {
        updateEndBit = (uint16)(sig->updateBitPosition + 1u);

        if ((updateEndBit > ((uint16)pduLen * 8u)) || (updateEndBit < sig->updateBitPosition))
        {
            COM_DEBUG_ASSIGN(Com_DebugInvalidSignalId, sig->signalId);
            COM_DEBUG_ASSIGN(Com_DebugInvalidPduId, sig->pduId);
            COM_DEBUG_ASSIGN(Com_DebugInvalidBitPosition, sig->updateBitPosition);
            COM_DEBUG_ASSIGN(Com_DebugInvalidBitSize, 1u);
            COM_DEBUG_ASSIGN(Com_DebugInvalidPduLength, pduLen);
            COM_DEBUG_ASSIGN(Com_DebugInvalidReason, COM_DEBUG_INVALID_RANGE);
            return COM_FALSE;
        }
    }

    return COM_TRUE;
}

static void Com_WriteBits(uint8* buffer, uint16 bitPos, uint8 bitSize, uint32 value)
{
    uint8 i;
    uint16 bitIndex;
    uint8 byteIndex;
    uint8 bitInByte;

    if (buffer == NULL_PTR)
    {
        COM_DEBUG_ASSIGN(Com_DebugInvalidReason, COM_DEBUG_INVALID_NULL_BUFFER);
        return;
    }

    if ((bitSize == 0u) || (bitSize > 32u))
    {
        COM_DEBUG_ASSIGN(Com_DebugInvalidBitPosition, bitPos);
        COM_DEBUG_ASSIGN(Com_DebugInvalidBitSize, bitSize);
        COM_DEBUG_ASSIGN(Com_DebugInvalidReason, COM_DEBUG_INVALID_BIT_SIZE);
        return;
    }

    for (i = 0u; i < bitSize; i++)
    {
        bitIndex = (uint16)(bitPos + i);
        byteIndex = (uint8)(bitIndex / 8u);
        bitInByte = (uint8)(bitIndex % 8u);

        if (((value >> i) & 1u) != 0u)
        {
            buffer[byteIndex] |= (uint8)(1u << bitInByte);
        }
        else
        {
            buffer[byteIndex] &= (uint8)~(uint8)(1u << bitInByte);
        }
    }
}

static uint32 Com_ReadBits(const uint8* buffer, uint16 bitPos, uint8 bitSize)
{
    uint8 i;
    uint32 value = 0u;
    uint16 bitIndex;
    uint8 byteIndex;
    uint8 bitInByte;

    if (buffer == NULL_PTR)
    {
        COM_DEBUG_ASSIGN(Com_DebugInvalidReason, COM_DEBUG_INVALID_NULL_BUFFER);
        return 0u;
    }

    if ((bitSize == 0u) || (bitSize > 32u))
    {
        COM_DEBUG_ASSIGN(Com_DebugInvalidBitPosition, bitPos);
        COM_DEBUG_ASSIGN(Com_DebugInvalidBitSize, bitSize);
        COM_DEBUG_ASSIGN(Com_DebugInvalidReason, COM_DEBUG_INVALID_BIT_SIZE);
        return 0u;
    }

    for (i = 0u; i < bitSize; i++)
    {
        bitIndex = (uint16)(bitPos + i);
        byteIndex = (uint8)(bitIndex / 8u);
        bitInByte = (uint8)(bitIndex % 8u);

        if ((buffer[byteIndex] & (uint8)(1u << bitInByte)) != 0u)
        {
            value |= (uint32)(1UL << i);
        }
    }

    return value;
}

static uint32 Com_LoadValue(const void* ptr, uint8 size)
{
    uint32 value = 0u;
    uint16 value16;
    uint32 value32;

    if (size == COM_SIGNAL_U8)
    {
        memcpy(&value, ptr, sizeof(uint8));
    }
    else if (size == COM_SIGNAL_U16)
    {
        memcpy(&value16, ptr, sizeof(value16));
        value = value16;
    }
    else if (size == COM_SIGNAL_U32)
    {
        memcpy(&value32, ptr, sizeof(value32));
        value = value32;
    }

    return value;
}

static void Com_StoreValue(void* ptr, uint8 size, uint32 value)
{
    uint8 value8;
    uint16 value16;

    if (size == COM_SIGNAL_U8)
    {
        value8 = (uint8)value;
        memcpy(ptr, &value8, sizeof(value8));
    }
    else if (size == COM_SIGNAL_U16)
    {
        value16 = (uint16)value;
        memcpy(ptr, &value16, sizeof(value16));
    }
    else if (size == COM_SIGNAL_U32)
    {
        memcpy(ptr, &value, sizeof(value));
    }
}

static uint8 Com_IsTxModeSendOnChange(uint8 txMode)
{
    if ((txMode == COM_TX_MODE_DIRECT) ||
        (txMode == COM_TX_MODE_MIXED))
    {
        return COM_TRUE;
    }

    return COM_FALSE;
}

static uint8 Com_IsDiagnosticOrXcpTxPdu(PduIdType pduId)
{
    if (((pduId >= COM_TX_PDU_XCPREQUEST_7C8) &&
            (pduId <= COM_TX_PDU_XCPREQUEST_7C0)) ||
            ((pduId >= COM_TX_PDU_DIAGREQUEST_706) &&
            (pduId <= COM_TX_PDU_DIAGREQUEST_700)) ||
            (pduId == COM_TX_PDU_CANFD_PDM1_DIAGREQUEST))
    {
        return COM_TRUE;
    }

    return COM_FALSE;
}

static uint8 Com_IsNormalTxIpdu(const Com_TxIpduConfigType* cfg)
{
    if ((cfg != NULL_PTR) &&
            (cfg->txMode != COM_TX_MODE_NONE) &&
            (Com_IsDiagnosticOrXcpTxPdu(cfg->pduId) == COM_FALSE))
    {
        return COM_TRUE;
    }

    return COM_FALSE;
}

static uint8 Com_GetStartupTxCount(const Com_TxIpduConfigType* cfg)
{
    if ((Com_IsNormalTxIpdu(cfg) != COM_FALSE) &&
            (cfg->periodTicks > 0u))
    {
        /* Ten NM frames at the 5 ms COM task rate; other cyclic PDUs once. */
        return ((cfg->pduId == COM_TX_PDU_NM3) ||
                (cfg->pduId == COM_TX_PDU_CANFD_NM3)) ? 10u : 1u;
    }

    return COM_FALSE;
}

static uint8 Com_IsTxSignalChangeTriggerExcluded(Com_SignalIdType signalId)
{
    switch (signalId)
    {
        case COM_SIG_TX_LOADREQUEST_LOADREQUESTCRC:
        case COM_SIG_TX_LOADREQUEST_LOADREQUESTALIVECOUNTER:
        case COM_SIG_TX_CANFD_INFOTAINMENTDATA1_IT1_ALIVEINDICATION:
        case COM_SIG_TX_SDAT_CSB_SDAT_YEAR:
        case COM_SIG_TX_SDAT_CSB_SDAT_SECOND:
        case COM_SIG_TX_SDAT_CSB_SDAT_MONTH:
        case COM_SIG_TX_SDAT_CSB_SDAT_MINUTE:
        case COM_SIG_TX_SDAT_CSB_SDAT_MILLISECOND:
        case COM_SIG_TX_SDAT_CSB_SDAT_HOUR:
        case COM_SIG_TX_SDAT_CSB_SDAT_DAY:
        case COM_SIG_TX_SDAT_CSB_SDAT_TIMESOURCE:
        case COM_SIG_TX_SDAT_CSB_SDAT_UTCVALID:
        case COM_SIG_TX_SDAT_CSB_SDAT_DEFAULTTIME:
        case COM_SIG_TX_SDAT_CSB_SDAT_NVMRESTORED:
        case COM_SIG_TX_CANFD_SDAT_CANFD_SDAT_YEAR:
        case COM_SIG_TX_CANFD_SDAT_CANFD_SDAT_SECOND:
        case COM_SIG_TX_CANFD_SDAT_CANFD_SDAT_MONTH:
        case COM_SIG_TX_CANFD_SDAT_CANFD_SDAT_MINUTE:
        case COM_SIG_TX_CANFD_SDAT_CANFD_SDAT_MILLISECOND:
        case COM_SIG_TX_CANFD_SDAT_CANFD_SDAT_HOUR:
        case COM_SIG_TX_CANFD_SDAT_CANFD_SDAT_DAY:
        case COM_SIG_TX_CANFD_SDAT_CANFD_SDAT_TIMESOURCE:
        case COM_SIG_TX_CANFD_SDAT_CANFD_SDAT_UTCVALID:
        case COM_SIG_TX_CANFD_SDAT_CANFD_SDAT_DEFAULTTIME:
        case COM_SIG_TX_CANFD_SDAT_CANFD_SDAT_NVMRESTORED:
            return COM_TRUE;

        default:
            return COM_FALSE;
    }
}

static uint16 Com_GetTxRetryTimeoutTicks(const Com_TxIpduConfigType* cfg)
{
    uint16 timeoutTicks;

    if (cfg == NULL_PTR)
    {
        return 1u;
    }

    timeoutTicks = cfg->deadlineTicks;

    if (((cfg->txMode == COM_TX_MODE_PERIODIC) ||
            (cfg->txMode == COM_TX_MODE_MIXED)) &&
            (cfg->periodTicks > 0u))
    {
        timeoutTicks = cfg->periodTicks;
    }

    if (timeoutTicks == 0u)
    {
        timeoutTicks = 1u;
    }

    return timeoutTicks;
}

static uint16 Com_MsToMainTicks(uint16 timeMs)
{
    uint32 ticks;

    if (timeMs == 0u)
    {
        return 0u;
    }

    ticks = ((uint32)timeMs + ((uint32)COM_MAIN_PERIOD_MS - 1u)) /
            (uint32)COM_MAIN_PERIOD_MS;

    return (ticks > 0xFFFFu) ? 0xFFFFu : (uint16)ticks;
}

static uint16 Com_MultiplyMainTicks(uint16 ticks, uint16 factor)
{
    uint32 scaledTicks;

    if ((ticks == 0u) || (factor == 0u))
    {
        return 0u;
    }

    scaledTicks = (uint32)ticks * (uint32)factor;

    return (scaledTicks > 0xFFFFu) ? 0xFFFFu : (uint16)scaledTicks;
}

static uint16 Com_GetRxCycleMainTicks(const Com_RxIpduConfigType* cfg)
{
    if (cfg == NULL_PTR)
    {
        return 0u;
    }

    /* RX config stores the generated message cycle time in milliseconds. */
    return Com_MsToMainTicks(cfg->deadlineTicks);
}

static uint16 Com_GetRxDeadlineMainTicks(const Com_RxIpduConfigType* cfg)
{
    uint16 factor = COM_RX_TIMEOUT_CYCLE_FACTOR;

    if (cfg == NULL_PTR)
    {
        return 0u;
    }

    if (cfg->pduId == COM_RX_PDU_LIN_HVDCDC_STATUS)
    {
        factor = COM_RX_LIN_TIMEOUT_CYCLE_FACTOR;
    }

    return Com_MultiplyMainTicks(Com_GetRxCycleMainTicks(cfg), factor);
}

static uint8 Com_TxIpduBelongsToChannel(PduIdType pduId, uint8 channel)
{
    switch (channel)
    {
        case COMM_CH_CAN:
            return ((pduId >= COM_TX_PDU_VEHICLESTATE) &&
                    (pduId <= COM_TX_PDU_DIAGREQUEST_700)) ?
                   COM_TRUE :
                   COM_FALSE;

        case COMM_CH_CANFD:
            return ((pduId >= COM_TX_PDU_CANFD_INFOTAINMENTDATA1) &&
                    (pduId <= COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA3)) ?
                   COM_TRUE :
                   COM_FALSE;

        case COMM_CH_LIN:
            return ((pduId == COM_TX_PDU_LIN_ZGW_REQUEST_HVDCDC) ||
                    (pduId == COM_TX_PDU_LIN_ZGW_SDAT)) ?
                   COM_TRUE :
                   COM_FALSE;

        default:
            return COM_FALSE;
    }
}

static Std_ReturnType Com_TriggerTransmit(uint8 txIdx)
{
    const Com_TxIpduConfigType* cfg;

    if (txIdx >= COM_TX_IPDU_COUNT)
    {
        return E_NOT_OK;
    }

    cfg = &Com_TxIpduCfg[txIdx];

    if (Com_TxRt[txIdx].active == COM_FALSE)
    {
        return E_NOT_OK;
    }

    if (CodingApp_IsTxPduEnabled(cfg->pduId) == FALSE)
    {
        Com_TxRt[txIdx].dirty = COM_FALSE;
        Com_TxRt[txIdx].periodDue = COM_FALSE;
        Com_TxRt[txIdx].startupPending = COM_FALSE;
        Com_TxRt[txIdx].repetitionsLeft = 0u;
        return E_NOT_OK;
    }

    if ((Com_MainFunctionTxActive != COM_FALSE) &&
            (Com_TxLastTriggerSequence[txIdx] == Com_MainFunctionTxSequence))
    {
        Com_TxDuplicateSuppressedCounter[txIdx]++;
        Com_TxRt[txIdx].dirty = COM_FALSE;
        return E_OK;
    }

    if (Com_TxRt[txIdx].txInProgress != COM_FALSE)
    {
        Com_TxBusyRejectedCounter[txIdx]++;
        return E_NOT_OK;
    }

    if (Com_TxRt[txIdx].mdtTimer > 0u)
    {
        return E_NOT_OK;
    }

    if (PduR_ComTransmit(cfg->pduId, Com_TxRt[txIdx].buffer, cfg->len) == E_OK)
    {
        Com_TxRt[txIdx].txInProgress = COM_TRUE;
        Com_TxRt[txIdx].mdtTimer = cfg->mdtTicks;
        if ((Com_TxRt[txIdx].startupPending != COM_FALSE) &&
                ((cfg->pduId == COM_TX_PDU_NM3) ||
                 (cfg->pduId == COM_TX_PDU_CANFD_NM3)))
        {
            Com_TxRt[txIdx].mdtTimer = 1u;
        }
        Com_TxRt[txIdx].deadlineTimer = Com_GetTxRetryTimeoutTicks(cfg);
        Com_TxRt[txIdx].dirty = COM_FALSE;
        Com_TxTriggerCounter[txIdx]++;

        /* NM's 100 ms cycle starts at submission, not at a later confirmation. */
        if ((cfg->pduId == COM_TX_PDU_NM3) ||
                (cfg->pduId == COM_TX_PDU_CANFD_NM3))
        {
            Com_TxRt[txIdx].periodTimer = COM_NM_PERIOD_TICKS;
            Com_TxRt[txIdx].periodDue = COM_FALSE;
        }

        if (Com_MainFunctionTxActive != COM_FALSE)
        {
            Com_TxLastTriggerSequence[txIdx] = Com_MainFunctionTxSequence;
        }

        return E_OK;
    }

    return E_NOT_OK;
}

void Com_Init(void)
{
    uint8 i;

    memset(Com_TxRt, 0, sizeof(Com_TxRt));
    memset(Com_RxRt, 0, sizeof(Com_RxRt));

    Com_MainFunctionTxSequence = 0u;
    Com_MainFunctionTxActive = COM_FALSE;

    for (i = 0u; i < COM_TX_IPDU_COUNT; i++)
    {
        memcpy(Com_TxRt[i].buffer, Com_TxIpduCfg[i].init, Com_TxIpduCfg[i].len);
        if (Com_TxIpduCfg[i].periodTicks > 0u)
        {
            Com_TxRt[i].periodTimer = (uint16)(i % Com_TxIpduCfg[i].periodTicks);
        }
        else
        {
            Com_TxRt[i].periodTimer = 0u;
        }
        Com_TxRt[i].deadlineTimer = Com_TxIpduCfg[i].deadlineTicks;
        Com_TxRt[i].active = COM_TRUE;
        Com_TxRt[i].periodDue = COM_FALSE;
        Com_TxRt[i].startupPending = Com_GetStartupTxCount(&Com_TxIpduCfg[i]);
        Com_TxLastTriggerSequence[i] = 0u;
        Com_TxTriggerCounter[i] = 0u;
        Com_TxDuplicateSuppressedCounter[i] = 0u;
        Com_TxBusyRejectedCounter[i] = 0u;
    }

    for (i = 0u; i < COM_RX_IPDU_COUNT; i++)
    {
        memcpy(Com_RxRt[i].buffer, Com_RxIpduCfg[i].init, Com_RxIpduCfg[i].len);
        Com_RxRt[i].deadlineTimer = Com_GetRxDeadlineMainTicks(&Com_RxIpduCfg[i]);
        Com_RxRt[i].active = COM_TRUE;
        Com_RxRt[i].timeout = COM_TRUE;
        Com_RxRt[i].received = COM_FALSE;
    }
}

Std_ReturnType Com_IpduGroupStart(Com_IpduGroupIdType groupId)
{
    uint8 i;

    for (i = 0u; i < COM_TX_IPDU_COUNT; i++)
    {
        if (Com_TxIpduCfg[i].groupId == groupId)
        {
            Com_TxRt[i].active = COM_TRUE;
            Com_TxRt[i].startupPending = Com_GetStartupTxCount(&Com_TxIpduCfg[i]);
        }
    }

    for (i = 0u; i < COM_RX_IPDU_COUNT; i++)
    {
        if (Com_RxIpduCfg[i].groupId == groupId)
        {
            Com_RxRt[i].active = COM_TRUE;
            Com_RxRt[i].timeout = COM_TRUE;
            Com_RxRt[i].received = COM_FALSE;
        }
    }

    return E_OK;
}

void Com_TriggerFullComRestartBurst(uint8 channel)
{
    uint8 i;

    for (i = 0u; i < COM_TX_IPDU_COUNT; i++)
    {
        if ((Com_TxRt[i].active == COM_FALSE) ||
            (Com_GetStartupTxCount(&Com_TxIpduCfg[i]) == COM_FALSE) ||
            (Com_TxIpduBelongsToChannel(Com_TxIpduCfg[i].pduId, channel) == COM_FALSE))
        {
            continue;
        }

        Com_TxRt[i].txInProgress = COM_FALSE;
        Com_TxRt[i].mdtTimer = 0u;
        Com_TxRt[i].dirty = COM_TRUE;
        Com_TxRt[i].periodDue = COM_TRUE;
        Com_TxRt[i].startupPending = Com_GetStartupTxCount(&Com_TxIpduCfg[i]);
    }
}

Std_ReturnType Com_SendSignal(Com_SignalIdType SignalId, const void* SignalDataPtr)
{
    const Com_SignalConfigType* sig;
    uint8 txIdx;
    uint32 value;
    uint32 previousValue;
    uint8 pduChanged = COM_FALSE;
    uint8 triggerOnChange = COM_FALSE;

    COM_DEBUG_ASSIGN(Com_DebugSendSignalLastId, SignalId);
    COM_DEBUG_ASSIGN(Com_DebugSendSignalLastPduId, 0u);
    COM_DEBUG_ASSIGN(Com_DebugSendSignalLastTxIdx, 0xFFu);
    COM_DEBUG_ASSIGN(Com_DebugSendSignalLastRet, E_NOT_OK);
    COM_DEBUG_ASSIGN(Com_DebugSendSignalLastValue, 0u);
    COM_DEBUG_ASSIGN(Com_DebugSendSignalLastSigAddress, 0u);
    if (SignalDataPtr == NULL_PTR)
    {
        return E_NOT_OK;
    }

    sig = Com_FindSignal(SignalId);

    if ((sig == NULL_PTR) || (sig->isTx == COM_FALSE))
    {
        return E_NOT_OK;
    }

    COM_DEBUG_ASSIGN(Com_DebugSendSignalLastSigAddress, (uint32)(const void *)sig);
    COM_DEBUG_ASSIGN(Com_DebugSendSignalLastPduId, sig->pduId);
    txIdx = Com_FindTxIpdu(sig->pduId);
    COM_DEBUG_ASSIGN(Com_DebugSendSignalLastTxIdx, txIdx);
    if ((txIdx == 0xFFu) || (Com_TxRt[txIdx].active == COM_FALSE))
    {
        return E_NOT_OK;
    }

    if (Com_IsValidSignalAccess(sig, Com_TxIpduCfg[txIdx].len) == COM_FALSE)
    {
        return E_NOT_OK;
    }

    value = Com_LoadValue(SignalDataPtr, sig->dataSize);
    if (sig->bitSize < 32u)
    {
        value &= (uint32)((1UL << sig->bitSize) - 1UL);
    }
    COM_DEBUG_ASSIGN(Com_DebugSendSignalLastValue, value);
    previousValue = Com_ReadBits(Com_TxRt[txIdx].buffer, sig->bitPosition, sig->bitSize);
    if (previousValue != value)
    {
        pduChanged = COM_TRUE;
    }

    Com_WriteBits(Com_TxRt[txIdx].buffer, sig->bitPosition, sig->bitSize, value);

    if (sig->hasUpdateBit != COM_FALSE)
    {
        if (Com_ReadBits(Com_TxRt[txIdx].buffer, sig->updateBitPosition, 1u) == 0u)
        {
            pduChanged = COM_TRUE;
        }

        Com_WriteBits(Com_TxRt[txIdx].buffer, sig->updateBitPosition, 1u, 1u);
    }

    if ((pduChanged != COM_FALSE) &&
        (Com_IsTxSignalChangeTriggerExcluded(sig->signalId) == COM_FALSE) &&
        (Com_IsTxModeSendOnChange(Com_TxIpduCfg[txIdx].txMode) != COM_FALSE))
    {
        triggerOnChange = COM_TRUE;
        Com_TxRt[txIdx].dirty = COM_TRUE;
    }

    if ((triggerOnChange != COM_FALSE) &&
        ((Com_TxIpduCfg[txIdx].txMode == COM_TX_MODE_DIRECT) ||
        (Com_TxIpduCfg[txIdx].txMode == COM_TX_MODE_MIXED)))
    {
        Com_TxRt[txIdx].repetitionsLeft = Com_TxIpduCfg[txIdx].repetitions;
        Com_TxRt[txIdx].repetitionTimer = 0u;
    }

    if ((triggerOnChange != COM_FALSE) &&
            (Com_TxRt[txIdx].startupPending == COM_FALSE))
    {
        (void)Com_TriggerTransmit(txIdx);
    }

    COM_DEBUG_ASSIGN(Com_DebugSendSignalLastRet, E_OK);
    return E_OK;
}

Std_ReturnType Com_ReceiveSignal(Com_SignalIdType SignalId, void* SignalDataPtr)
{
    const Com_SignalConfigType* sig;
    uint8 rxIdx;
    uint32 value;

    COM_DEBUG_ASSIGN(Com_DebugReceiveSignalLastId, SignalId);
    COM_DEBUG_ASSIGN(Com_DebugReceiveSignalLastRxIdx, 0xFFu);
    COM_DEBUG_ASSIGN(Com_DebugReceiveSignalLastRet, E_NOT_OK);
    if (SignalDataPtr == NULL_PTR)
    {
        return E_NOT_OK;
    }

    sig = Com_FindSignal(SignalId);

    if ((sig == NULL_PTR) || (sig->isTx != COM_FALSE))
    {
        return E_NOT_OK;
    }

    rxIdx = Com_FindRxIpdu(sig->pduId);
    COM_DEBUG_ASSIGN(Com_DebugReceiveSignalLastPduId, sig->pduId);
    COM_DEBUG_ASSIGN(Com_DebugReceiveSignalLastRxIdx, rxIdx);
    if ((rxIdx == 0xFFu) || (Com_RxRt[rxIdx].active == COM_FALSE))
    {
        return E_NOT_OK;
    }

    if ((Com_RxRt[rxIdx].timeout != COM_FALSE) ||
            (Com_RxRt[rxIdx].received == COM_FALSE))
    {
        return E_NOT_OK;
    }

    if (Com_IsValidSignalAccess(sig, Com_RxIpduCfg[rxIdx].len) == COM_FALSE)
    {
        return E_NOT_OK;
    }

    if (sig->hasUpdateBit != COM_FALSE)
    {
        if (Com_ReadBits(Com_RxRt[rxIdx].buffer, sig->updateBitPosition, 1u) == 0u)
        {
            return E_NOT_OK;
        }
    }

    value = Com_ReadBits(Com_RxRt[rxIdx].buffer, sig->bitPosition, sig->bitSize);
    Com_StoreValue(SignalDataPtr, sig->dataSize, value);
    COM_DEBUG_ASSIGN(Com_DebugReceiveSignalLastValue, value);
    COM_DEBUG_ASSIGN(Com_DebugReceiveSignalLastRet, E_OK);
    return E_OK;
}

Std_ReturnType Com_GetRxPduDiagStatus(PduIdType RxPduId, uint8* StatusPtr)
{
    uint8 rxIdx;

    if (StatusPtr == NULL_PTR)
    {
        return E_NOT_OK;
    }

    rxIdx = Com_FindRxIpdu(RxPduId);

    if ((rxIdx == 0xFFu) || (Com_RxRt[rxIdx].active == COM_FALSE))
    {
        return E_NOT_OK;
    }

    *StatusPtr = COM_RX_DIAG_STATUS_OK;

    if (Com_RxRt[rxIdx].timeout != COM_FALSE)
    {
        *StatusPtr |= COM_RX_DIAG_STATUS_TIMEOUT;
    }

    return E_OK;
}

Std_ReturnType Com_GetRxSignalDiagStatus(Com_SignalIdType SignalId,
        uint32* ValuePtr,
        uint32* InvalidValuePtr,
        uint8* StatusPtr)
{
    const Com_SignalConfigType* sig;
    uint8 rxIdx;
    uint32 value;

    if ((ValuePtr == NULL_PTR) ||
            (InvalidValuePtr == NULL_PTR) ||
            (StatusPtr == NULL_PTR))
    {
        return E_NOT_OK;
    }

    sig = Com_FindSignal(SignalId);

    if ((sig == NULL_PTR) || (sig->isTx != COM_FALSE))
    {
        return E_NOT_OK;
    }

    rxIdx = Com_FindRxIpdu(sig->pduId);

    if ((rxIdx == 0xFFu) || (Com_RxRt[rxIdx].active == COM_FALSE))
    {
        return E_NOT_OK;
    }

    value = Com_ReadBits(Com_RxRt[rxIdx].buffer, sig->bitPosition, sig->bitSize);

    *ValuePtr = value;
    *InvalidValuePtr = sig->invalidValue;
    *StatusPtr = COM_RX_DIAG_STATUS_OK;

    if (Com_RxRt[rxIdx].timeout != COM_FALSE)
    {
        *StatusPtr |= COM_RX_DIAG_STATUS_TIMEOUT;
    }
    else if (value >= sig->invalidValue)
    {
        *StatusPtr |= COM_RX_DIAG_STATUS_INVALID;
    }

    return E_OK;
}

void Com_RxIndication(PduIdType RxPduId, const uint8* data, PduLengthType len)
{
    uint8 rxIdx;

    if ((data == NULL_PTR) || (len == 0u))
    {
        return;
    }

    rxIdx = Com_FindRxIpdu(RxPduId);

    if (rxIdx == 0xFFu)
    {
        return;
    }

    if (Com_RxRt[rxIdx].active == COM_FALSE)
    {
        return;
    }

    if (len > Com_RxIpduCfg[rxIdx].len)
    {
        len = Com_RxIpduCfg[rxIdx].len;
    }

    memcpy(Com_RxRt[rxIdx].buffer, data, len);
    Com_RxRt[rxIdx].deadlineTimer = Com_GetRxDeadlineMainTicks(&Com_RxIpduCfg[rxIdx]);
    Com_RxRt[rxIdx].timeout = COM_FALSE;
    Com_RxRt[rxIdx].received = COM_TRUE;
}

void Com_TxConfirmation(PduIdType TxPduId)
{
    uint8 txIdx;

    txIdx = Com_FindTxIpdu(TxPduId);

    if (txIdx == 0xFFu)
    {
        return;
    }

    Com_TxRt[txIdx].txInProgress = COM_FALSE;

    if ((TxPduId != COM_TX_PDU_NM3) &&
            (TxPduId != COM_TX_PDU_CANFD_NM3) &&
            ((Com_TxIpduCfg[txIdx].txMode == COM_TX_MODE_PERIODIC) ||
            (Com_TxIpduCfg[txIdx].txMode == COM_TX_MODE_MIXED)) &&
            (Com_TxRt[txIdx].periodDue != COM_FALSE))
    {
        Com_TxRt[txIdx].periodTimer = Com_TxIpduCfg[txIdx].periodTicks;
        Com_TxRt[txIdx].periodDue = COM_FALSE;
    }
}

void Com_MainFunctionTx(void)
{
    uint8 i;

    Com_MainFunctionTxSequence++;
    if (Com_MainFunctionTxSequence == 0u)
    {
        memset(Com_TxLastTriggerSequence, 0, sizeof(Com_TxLastTriggerSequence));
        Com_MainFunctionTxSequence = 1u;
    }

    Com_MainFunctionTxActive = COM_TRUE;

    for (i = 0u; i < COM_TX_IPDU_COUNT; i++)
    {
        if (Com_TxRt[i].active == COM_FALSE)
        {
            continue;
        }

        if (Com_TxRt[i].mdtTimer > 0u)
        {
            Com_TxRt[i].mdtTimer--;
        }

        if (Com_TxRt[i].txInProgress != COM_FALSE)
        {
            if (Com_TxRt[i].deadlineTimer > 0u)
            {
                Com_TxRt[i].deadlineTimer--;
            }

            if (Com_TxRt[i].deadlineTimer == 0u)
            {
                Com_TxRt[i].txInProgress = COM_FALSE;
                Com_TxRt[i].dirty = COM_TRUE;
            }
        }

        if (Com_TxRt[i].repetitionTimer > 0u)
        {
            Com_TxRt[i].repetitionTimer--;
        }

        if ((Com_TxRt[i].repetitionsLeft > 0u) &&
            (Com_TxRt[i].startupPending == COM_FALSE) &&
            (Com_TxRt[i].repetitionTimer == 0u) &&
            (Com_TxRt[i].txInProgress == COM_FALSE))
        {
            if (Com_TriggerTransmit(i) == E_OK)
            {
                Com_TxRt[i].repetitionsLeft--;
                Com_TxRt[i].repetitionTimer = Com_TxIpduCfg[i].repetitionPeriodTicks;
            }
        }

        /* A sleeping/busy channel must not block startup or cyclic traffic
         * on another channel. Retry each pending PDU independently.
         */
        if (Com_TxRt[i].startupPending != COM_FALSE)
        {
            if (Com_TriggerTransmit(i) == E_OK)
            {
                Com_TxRt[i].startupPending--;
                Com_TxRt[i].periodDue = COM_FALSE;
                Com_TxRt[i].periodTimer = ((Com_TxIpduCfg[i].pduId == COM_TX_PDU_NM3) ||
                        (Com_TxIpduCfg[i].pduId == COM_TX_PDU_CANFD_NM3)) ?
                        COM_NM_PERIOD_TICKS : Com_TxIpduCfg[i].periodTicks;
            }

            continue;
        }

        if ((Com_TxIpduCfg[i].txMode == COM_TX_MODE_PERIODIC) ||
            (Com_TxIpduCfg[i].txMode == COM_TX_MODE_MIXED))
        {
            if ((Com_TxRt[i].txInProgress == COM_FALSE) ||
                    (Com_TxIpduCfg[i].pduId == COM_TX_PDU_NM3) ||
                    (Com_TxIpduCfg[i].pduId == COM_TX_PDU_CANFD_NM3))
            {
                if (Com_TxRt[i].periodTimer > 0u)
                {
                    Com_TxRt[i].periodTimer--;
                }

                if (Com_TxRt[i].periodTimer == 0u)
                {
                    Com_TxRt[i].dirty = COM_TRUE;
                    Com_TxRt[i].periodDue = COM_TRUE;
                }
            }
        }

        if ((Com_TxRt[i].dirty != COM_FALSE) &&
            (Com_TxRt[i].txInProgress == COM_FALSE) &&
            (Com_TxRt[i].mdtTimer == 0u))
        {
            (void)Com_TriggerTransmit(i);
        }
    }

    Com_MainFunctionTxActive = COM_FALSE;
    Com_MainFunctionTx_Counter++;
}

void Com_MainFunctionRx(void)
{
    uint8 i;

    for (i = 0u; i < COM_RX_IPDU_COUNT; i++)
    {
        if (Com_RxRt[i].active == COM_FALSE)
        {
            continue;
        }

        if (Com_RxIpduCfg[i].deadlineTicks == 0u)
        {
            continue;
        }

        if (Com_RxRt[i].deadlineTimer > 0u)
        {
            Com_RxRt[i].deadlineTimer--;
            if (Com_RxRt[i].deadlineTimer > 0u)
            {
                continue;
            }
        }

        Com_RxRt[i].timeout = COM_TRUE;
        Com_RxRt[i].received = COM_FALSE;
        memcpy(Com_RxRt[i].buffer, Com_RxIpduCfg[i].init, Com_RxIpduCfg[i].len);
    }

    Com_MainFunctionRx_Counter++;
}
