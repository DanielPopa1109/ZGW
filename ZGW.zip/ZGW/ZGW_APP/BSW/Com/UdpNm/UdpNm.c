#include "UdpNm.h"

#include "GatewaySwc.h"
#include "../ComM/ComM.h"
#include "APP/TimeSync/TimeBase.h"

#include <string.h>

#define UDPNM_SOCON_ID                  4u
#define UDPNM_HEADER_LEN                5u
#define UDPNM_MAX_PDU_LEN               (UDPNM_HEADER_LEN + UDPNM_USER_DATA_LEN)
#define UDPNM_MAGIC0                    0x4Eu
#define UDPNM_MAGIC1                    0x4Du
#define UDPNM_VERSION                   0x01u
#define UDPNM_CB_REPEAT_MESSAGE         0x01u
#define UDPNM_CB_ACTIVE_WAKEUP          0x02u
#define UDPNM_TX_PERIOD_NS              (100ull * TIMEBASE_NS_PER_MS)
#define UDPNM_RESTART_TX_PERIOD_NS      (5ull * TIMEBASE_NS_PER_MS)
#define UDPNM_RESTART_TX_COUNT          10u
#define UDPNM_TIMEOUT_TICKS             200u
#define UDPNM_REPEAT_MESSAGE_TICKS      40u
#define UDPNM_READY_SLEEP_TICKS         100u
#define UDPNM_PREPARE_BUS_SLEEP_TICKS   40u

typedef struct
{
    uint8 localRequested;
    uint8 remoteActive;
    Nm_StateType state;
    Nm_ModeType mode;
    uint64 nextTxTimeNs;
    uint8 restartTxRemaining;
    uint8 txWasAllowed;
    uint16 timeoutTimer;
    uint16 repeatTimer;
    uint16 readySleepTimer;
    uint16 prepareSleepTimer;
    uint8 userData[UDPNM_USER_DATA_LEN];
    uint8 userDataLen;
} UdpNm_ChannelStateType;

static UdpNm_ChannelStateType UdpNm_ChannelState;
static uint8 UdpNm_Initialized;

static void UdpNm_UpdateNextTxDeadline(uint64 nowNs)
{
    uint64 periodNs = (UdpNm_ChannelState.restartTxRemaining > 0u) ?
            UDPNM_RESTART_TX_PERIOD_NS : UDPNM_TX_PERIOD_NS;

    /* Keep the phase across normal task jitter. After a missed interval,
     * resume from now instead of sending a backlog in one activation.
     */
    if ((UdpNm_ChannelState.nextTxTimeNs == 0ull) ||
            ((nowNs - UdpNm_ChannelState.nextTxTimeNs) >= periodNs))
    {
        UdpNm_ChannelState.nextTxTimeNs = nowNs;
    }
    UdpNm_ChannelState.nextTxTimeNs += periodNs;
}

static void UdpNm_SetState(Nm_StateType state, Nm_ModeType mode)
{
    if ((UdpNm_ChannelState.state == state) &&
        (UdpNm_ChannelState.mode == mode))
    {
        return;
    }

    UdpNm_ChannelState.state = state;
    UdpNm_ChannelState.mode = mode;

    if (mode == NM_MODE_NETWORK)
    {
        ComM_Nm_NetworkMode(COMM_CH_ETH);
    }
    else if (mode == NM_MODE_PREPARE_BUS_SLEEP)
    {
        ComM_Nm_PrepareBusSleepMode(COMM_CH_ETH);
    }
    else if (mode == NM_MODE_BUS_SLEEP)
    {
        ComM_Nm_BusSleepMode(COMM_CH_ETH);
    }
    else
    {
        /* Synchronize mode is not used by this lab UdpNm subset. */
    }
}

static void UdpNm_EnterNetwork(uint8 repeatMessage)
{
    UdpNm_ChannelState.readySleepTimer = 0u;
    UdpNm_ChannelState.prepareSleepTimer = 0u;

    if (repeatMessage != FALSE)
    {
        UdpNm_ChannelState.repeatTimer = UDPNM_REPEAT_MESSAGE_TICKS;
        UdpNm_SetState(NM_STATE_REPEAT_MESSAGE, NM_MODE_NETWORK);
    }
    else
    {
        UdpNm_ChannelState.repeatTimer = 0u;
        UdpNm_SetState(NM_STATE_NORMAL_OPERATION, NM_MODE_NETWORK);
    }
}

static SoAd_ReturnType UdpNm_TransmitNmPdu(void)
{
    uint8 data[UDPNM_MAX_PDU_LEN];
    uint8 i;
    uint16 len;

    data[0u] = UDPNM_MAGIC0;
    data[1u] = UDPNM_MAGIC1;
    data[2u] = UDPNM_VERSION;
    data[3u] = (UdpNm_ChannelState.state == NM_STATE_REPEAT_MESSAGE) ?
               UDPNM_CB_REPEAT_MESSAGE :
               0u;
    data[3u] |= UDPNM_CB_ACTIVE_WAKEUP;
    data[4u] = UdpNm_ChannelState.userDataLen;

    for (i = 0u; i < UdpNm_ChannelState.userDataLen; i++)
    {
        data[UDPNM_HEADER_LEN + i] = UdpNm_ChannelState.userData[i];
    }

    len = (uint16)(UDPNM_HEADER_LEN + UdpNm_ChannelState.userDataLen);
    return GatewaySwc_RequestSoAdIfTransmit(UDPNM_SOCON_ID, NULL_PTR, data, len);
}

static void UdpNm_HandleReleasedNetwork(void)
{
    if (UdpNm_ChannelState.remoteActive != FALSE)
    {
        UdpNm_SetState(NM_STATE_READY_SLEEP, NM_MODE_NETWORK);
        return;
    }

    if ((UdpNm_ChannelState.state == NM_STATE_NORMAL_OPERATION) ||
        (UdpNm_ChannelState.state == NM_STATE_REPEAT_MESSAGE))
    {
        UdpNm_ChannelState.readySleepTimer = UDPNM_READY_SLEEP_TICKS;
        UdpNm_SetState(NM_STATE_READY_SLEEP, NM_MODE_NETWORK);
    }
    else if (UdpNm_ChannelState.state == NM_STATE_READY_SLEEP)
    {
        if (UdpNm_ChannelState.readySleepTimer > 0u)
        {
            UdpNm_ChannelState.readySleepTimer--;
        }
        else
        {
            UdpNm_ChannelState.prepareSleepTimer =
                UDPNM_PREPARE_BUS_SLEEP_TICKS;
            UdpNm_SetState(NM_STATE_PREPARE_BUS_SLEEP,
                           NM_MODE_PREPARE_BUS_SLEEP);
        }
    }
    else if (UdpNm_ChannelState.state == NM_STATE_PREPARE_BUS_SLEEP)
    {
        if (UdpNm_ChannelState.prepareSleepTimer > 0u)
        {
            UdpNm_ChannelState.prepareSleepTimer--;
        }
        else
        {
            UdpNm_SetState(NM_STATE_BUS_SLEEP, NM_MODE_BUS_SLEEP);
        }
    }
    else
    {
        /* Already in bus sleep. */
    }
}

void UdpNm_Init(void)
{
    if (UdpNm_Initialized != FALSE)
    {
        return;
    }

    UdpNm_ChannelState.localRequested = FALSE;
    UdpNm_ChannelState.remoteActive = FALSE;
    UdpNm_ChannelState.state = NM_STATE_BUS_SLEEP;
    UdpNm_ChannelState.mode = NM_MODE_BUS_SLEEP;
    UdpNm_ChannelState.nextTxTimeNs = 0ull;
    UdpNm_ChannelState.restartTxRemaining = UDPNM_RESTART_TX_COUNT;
    UdpNm_ChannelState.txWasAllowed = FALSE;
    UdpNm_ChannelState.timeoutTimer = 0u;
    UdpNm_ChannelState.repeatTimer = 0u;
    UdpNm_ChannelState.readySleepTimer = 0u;
    UdpNm_ChannelState.prepareSleepTimer = 0u;
    UdpNm_ChannelState.userDataLen = 0u;
    (void)memset(UdpNm_ChannelState.userData,
                 0,
                 sizeof(UdpNm_ChannelState.userData));

    UdpNm_Initialized = TRUE;
}

void UdpNm_MainFunction(void)
{
    uint64 nowNs;
    uint8 txAllowed;

    if (UdpNm_Initialized == FALSE)
    {
        return;
    }

    if (UdpNm_ChannelState.timeoutTimer > 0u)
    {
        UdpNm_ChannelState.timeoutTimer--;
        if (UdpNm_ChannelState.timeoutTimer == 0u)
        {
            UdpNm_ChannelState.remoteActive = FALSE;
        }
    }

    if (UdpNm_ChannelState.localRequested != FALSE)
    {
        if (UdpNm_ChannelState.state == NM_STATE_BUS_SLEEP)
        {
            UdpNm_EnterNetwork(TRUE);
        }
        else if (UdpNm_ChannelState.state == NM_STATE_REPEAT_MESSAGE)
        {
            if (UdpNm_ChannelState.repeatTimer > 0u)
            {
                UdpNm_ChannelState.repeatTimer--;
            }
            else
            {
                UdpNm_SetState(NM_STATE_NORMAL_OPERATION,
                               NM_MODE_NETWORK);
            }
        }
        else if (UdpNm_ChannelState.mode != NM_MODE_NETWORK)
        {
            UdpNm_EnterNetwork(TRUE);
        }
        else
        {
            /* Stay in network mode. */
        }

        txAllowed = ((ComM_IsTxAllowed(COMM_CH_ETH) != FALSE) &&
                (GatewaySwc_IsNormalCommunicationTxEnabled() != FALSE)) ? TRUE : FALSE;
        if (txAllowed == FALSE)
        {
            UdpNm_ChannelState.txWasAllowed = FALSE;
            return;
        }
        if (UdpNm_ChannelState.txWasAllowed == FALSE)
        {
            UdpNm_ChannelState.restartTxRemaining = UDPNM_RESTART_TX_COUNT;
            UdpNm_ChannelState.nextTxTimeNs = 0ull;
        }
        UdpNm_ChannelState.txWasAllowed = TRUE;
        nowNs = TimeBase_PlatformGetCounterNs();

        if ((UdpNm_ChannelState.nextTxTimeNs == 0ull) ||
            (nowNs >= UdpNm_ChannelState.nextTxTimeNs))
        {
            if (UdpNm_TransmitNmPdu() == SOAD_OK)
            {
                if (UdpNm_ChannelState.restartTxRemaining > 0u)
                {
                    UdpNm_ChannelState.restartTxRemaining--;
                }
                UdpNm_UpdateNextTxDeadline(nowNs);
            }
        }
    }
    else
    {
        UdpNm_ChannelState.txWasAllowed = FALSE;
        UdpNm_HandleReleasedNetwork();
    }
}

Std_ReturnType UdpNm_NetworkRequest(uint8 channel)
{
    uint8 startNetwork;

    if ((UdpNm_Initialized == FALSE) || (channel != COMM_CH_ETH))
    {
        return E_NOT_OK;
    }

    startNetwork = ((UdpNm_ChannelState.localRequested == FALSE) ||
                    (UdpNm_ChannelState.mode != NM_MODE_NETWORK)) ?
                   TRUE :
                   FALSE;

    UdpNm_ChannelState.localRequested = TRUE;

    if (startNetwork != FALSE)
    {
        UdpNm_ChannelState.restartTxRemaining = UDPNM_RESTART_TX_COUNT;
        UdpNm_ChannelState.nextTxTimeNs = 0ull;
        UdpNm_EnterNetwork(TRUE);
    }

    return E_OK;
}

Std_ReturnType UdpNm_NetworkRelease(uint8 channel)
{
    if ((UdpNm_Initialized == FALSE) || (channel != COMM_CH_ETH))
    {
        return E_NOT_OK;
    }

    UdpNm_ChannelState.localRequested = FALSE;

    if (UdpNm_ChannelState.mode == NM_MODE_NETWORK)
    {
        UdpNm_ChannelState.readySleepTimer = UDPNM_READY_SLEEP_TICKS;
        UdpNm_SetState(NM_STATE_READY_SLEEP, NM_MODE_NETWORK);
    }

    return E_OK;
}

Std_ReturnType UdpNm_GetState(uint8 channel,
                              Nm_StateType* state,
                              Nm_ModeType* mode)
{
    if ((UdpNm_Initialized == FALSE) ||
        (channel != COMM_CH_ETH) ||
        (state == NULL_PTR) ||
        (mode == NULL_PTR))
    {
        return E_NOT_OK;
    }

    *state = UdpNm_ChannelState.state;
    *mode = UdpNm_ChannelState.mode;
    return E_OK;
}

uint8 UdpNm_SoAdRxIndication(SoAd_SoConIdType soConId,
                             const TcpIp_SockAddrType* remoteAddr,
                             const uint8* data,
                             uint16 len)
{
    uint8 userLen;

    (void)remoteAddr;

    if ((UdpNm_Initialized == FALSE) ||
        (soConId != UDPNM_SOCON_ID) ||
        (data == NULL_PTR) ||
        (len < UDPNM_HEADER_LEN) ||
        (len > UDPNM_MAX_PDU_LEN))
    {
        return FALSE;
    }

    if ((data[0u] != UDPNM_MAGIC0) ||
        (data[1u] != UDPNM_MAGIC1) ||
        (data[2u] != UDPNM_VERSION))
    {
        return FALSE;
    }

    userLen = data[4u];

    if ((userLen > UDPNM_USER_DATA_LEN) ||
        (((uint16)userLen + UDPNM_HEADER_LEN) > len))
    {
        return TRUE;
    }

    UdpNm_ChannelState.remoteActive = TRUE;
    UdpNm_ChannelState.timeoutTimer = UDPNM_TIMEOUT_TICKS;
    UdpNm_ChannelState.userDataLen = userLen;

    if (userLen != 0u)
    {
        (void)memcpy(UdpNm_ChannelState.userData,
                     &data[UDPNM_HEADER_LEN],
                     userLen);
    }

    if ((UdpNm_ChannelState.state == NM_STATE_BUS_SLEEP) ||
        (UdpNm_ChannelState.state == NM_STATE_PREPARE_BUS_SLEEP))
    {
        ComM_Nm_NetworkStartIndication(COMM_CH_ETH);
    }

    UdpNm_EnterNetwork(((data[3u] & UDPNM_CB_REPEAT_MESSAGE) != 0u) ?
                       TRUE :
                       FALSE);
    return TRUE;
}
