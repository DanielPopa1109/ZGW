#include "CodingApp.h"

#include <string.h>

#include "Dem.h"
#include "Fee.h"
#include "Fls.h"
#include "NvM.h"
#include "NvM_Cfg.h"
#include "APP/GatewaySwc/GatewaySwc.h"

#define CODINGAPP_UNUSED(x)                  ((void)(x))

#define CODINGAPP_DEM_STATE_UNKNOWN          0xFFu
#define CODINGAPP_NVM_PENDING_POLL_LIMIT     0x20u
#define CODINGAPP_NVM_PUMP_CYCLE_BUDGET      4096u

typedef enum
{
    CODINGAPP_NVM_JOB_NONE = 0,
    CODINGAPP_NVM_JOB_WRITE_ALL,
    CODINGAPP_NVM_JOB_READ_BLOCK
} CodingApp_NvMJobType;

typedef struct
{
    uint8 initialized;
    uint8 state;
    uint8 validationStatus;
    uint8 dirty;
    uint16 rxMessageCount;
    uint16 rxMessageExpectedCount;
    uint16 nvImageLength;
    uint32 generation;
    uint32 validationCounter;
    uint32 invalidCodingCounter;
    uint32 writeAllCounter;
    uint8 lastNvMResult;
} CodingApp_StatusType;

static CodingApp_NvImageType CodingApp_ActiveImage;
static CodingApp_StatusType CodingApp_Status;
static CodingApp_NvMJobType CodingApp_PendingNvMJob = CODINGAPP_NVM_JOB_NONE;
static boolean CodingApp_PendingNvMStarted = FALSE;
static uint8 CodingApp_PendingNvMPollCount = 0u;
static uint8 CodingApp_DemNotCodedState = CODINGAPP_DEM_STATE_UNKNOWN;
static uint8 CodingApp_DemInvalidState = CODINGAPP_DEM_STATE_UNKNOWN;

#if CODINGAPP_DEBUG_INSTRUMENTATION
volatile uint8 CodingApp_DebugState = CODINGAPP_STATE_NOT_CODED;
volatile uint8 CodingApp_DebugValidationStatus = CODINGAPP_VALIDATION_NOT_CODED;
volatile uint8 CodingApp_DebugDirty = 0u;
volatile uint16 CodingApp_DebugRxMessageExpectedCount = 0u;
volatile uint32 CodingApp_DebugGeneration = 0u;
volatile uint32 CodingApp_DebugInvalidCodingCounter = 0u;
volatile uint32 CodingApp_DebugWriteAllCounter = 0u;
volatile uint8 CodingApp_DebugLastNvMResult = NVM_REQ_NOT_OK;
#endif

#if CODINGAPP_DEBUG_INSTRUMENTATION
#define CODINGAPP_DEBUG_ASSIGN(lhs, rhs) do { (lhs) = (rhs); } while (0)
#endif

static boolean CodingApp_IsBlank(const uint8 *data, uint16 len);
static uint8 CodingApp_ValidateImage(const CodingApp_NvImageType *image);
static uint16 CodingApp_CountExpectedMessages(const CodingApp_NvImageType *image);
static boolean CodingApp_IsSameCodingPayload(
    const CodingApp_NvImageType *left,
    const CodingApp_NvImageType *right
);
static uint16 CodingApp_GetCodingVersion(void);
static void CodingApp_SetExpectedBit(CodingApp_NvImageType *image, uint16 index, boolean expected);
static boolean CodingApp_GetExpectedBit(const CodingApp_NvImageType *image, uint16 index);
static void CodingApp_SetTxPduEnabledBit(CodingApp_NvImageType *image, PduIdType txPduId, boolean enabled);
static boolean CodingApp_GetTxPduEnabledBit(const CodingApp_NvImageType *image, PduIdType txPduId);
static boolean CodingApp_GetTxPduCodingIndex(PduIdType txPduId, uint16 *index);
static boolean CodingApp_IsTxPduCodingExempt(PduIdType txPduId);
#if CODINGAPP_DEBUG_INSTRUMENTATION
static void CodingApp_UpdateDebug(void);
#else
#define CodingApp_UpdateDebug() ((void)0)
#endif
static void CodingApp_SetState(uint8 state, uint8 validationStatus);
static void CodingApp_BuildImageFromMask(
    CodingApp_NvImageType *image,
    const uint8 *mask,
    Dcm_PduLengthType maskLen,
    uint32 generation
);
static void CodingApp_BuildDefaultImage(CodingApp_NvImageType *image, uint32 generation);
static Std_ReturnType CodingApp_ApplyValidImage(const CodingApp_NvImageType *image, boolean markDirty);
static void CodingApp_LoadFromNvRam(void);
static Dcm_ReturnType CodingApp_StartWriteAll(uint8 *respData, Dcm_PduLengthType *respLen);
static Dcm_ReturnType CodingApp_PollWriteAll(uint8 *respData, Dcm_PduLengthType *respLen);
static boolean CodingApp_IsNvMStackBusy(void);
static void CodingApp_PumpNvMStack(void);
static boolean CodingApp_CountNvMPendingPoll(void);
static void CodingApp_ClearPendingNvMJob(void);
static void CodingApp_FillRoutineResponse(uint8 status, uint8 *respData, Dcm_PduLengthType *respLen);

static const PduIdType CodingApp_TxPduCodingList[CODINGAPP_TX_PDU_COUNT] =
{
    COM_TX_PDU_DISPLAYOUTTEMP,
    COM_TX_PDU_STATUSBODYDATA1,
    COM_TX_PDU_COMMANDDISPLAYSTATUS,
    COM_TX_PDU_LOADREQUEST,
    COM_TX_PDU_CANFD_INFOTAINMENTDATA1,
    COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA2,
    COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA1,
    COM_TX_PDU_CANFD_LIGHTDATA1,
    COM_TX_PDU_CANFD_BODYDATA1,
    COM_TX_PDU_CANFD_COMMANDLOAD_PDM1,
    COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA3,
    COM_TX_PDU_LIN_ZGW_REQUEST_HVDCDC,
    CODINGAPP_TX_PDU_ETH_SUMMARY,
    CODINGAPP_TX_PDU_ETH_DTC_TRANSITION,
    CODINGAPP_TX_PDU_ETH_MCU_STATUS,
    CODINGAPP_TX_PDU_ETH_AI_MODEL,
    CODINGAPP_TX_PDU_ETH_CPU_PERF
};

void DcmAppl_DiagnosticSessionChanged(uint8 connIdx, uint8 session)
{
    CODINGAPP_UNUSED(connIdx);

    if (session == DCM_SESSION_DEFAULT)
    {
        CodingApp_ClearPendingNvMJob();
    }
}

void CodingApp_Init(void)
{
    memset(&CodingApp_ActiveImage, 0, sizeof(CodingApp_ActiveImage));
    memset(&CodingApp_Status, 0, sizeof(CodingApp_Status));

    CodingApp_Status.initialized = TRUE;
    CodingApp_Status.nvImageLength = (uint16)sizeof(CodingApp_NvImageType);
    CodingApp_Status.rxMessageCount = (uint16)GATEWAYSWC_RX_MESSAGE_DIAG_COUNT;
    CodingApp_Status.validationStatus = CODINGAPP_VALIDATION_NOT_CODED;
    CodingApp_Status.state = CODINGAPP_STATE_NOT_CODED;
    CodingApp_Status.lastNvMResult = NVM_REQ_NOT_OK;

    CodingApp_ClearPendingNvMJob();
    CodingApp_DemNotCodedState = CODINGAPP_DEM_STATE_UNKNOWN;
    CodingApp_DemInvalidState = CODINGAPP_DEM_STATE_UNKNOWN;

    CodingApp_LoadFromNvRam();
    CodingApp_UpdateDebug();
}

void CodingApp_MainFunction(void)
{
    Dem_EventStatusType notCodedStatus;
    Dem_EventStatusType invalidStatus;

    if (CodingApp_Status.initialized == FALSE)
    {
        return;
    }

    if (Dem_IsReady() == FALSE)
    {
        return;
    }

    notCodedStatus = (CodingApp_Status.state == CODINGAPP_STATE_CODED) ?
            DEM_EVENT_STATUS_PASSED :
            DEM_EVENT_STATUS_FAILED;

    invalidStatus = (CodingApp_Status.state == CODINGAPP_STATE_INVALID) ?
            DEM_EVENT_STATUS_FAILED :
            DEM_EVENT_STATUS_PASSED;

    if (CodingApp_DemNotCodedState != (uint8)notCodedStatus)
    {
        if (Dem_ReportErrorStatus(DEM_EVENT_ID_CODING_ECU_NOT_CODED, notCodedStatus) == E_OK)
        {
            CodingApp_DemNotCodedState = (uint8)notCodedStatus;
        }
    }

    if (CodingApp_DemInvalidState != (uint8)invalidStatus)
    {
        if (Dem_ReportErrorStatus(DEM_EVENT_ID_CODING_INVALID, invalidStatus) == E_OK)
        {
            CodingApp_DemInvalidState = (uint8)invalidStatus;
        }
    }
}

void CodingApp_OnNvMReadAllComplete(void)
{
    if (CodingApp_Status.initialized == FALSE)
    {
        return;
    }

    CodingApp_LoadFromNvRam();
    CodingApp_UpdateDebug();
}

void CodingApp_OnDemEventCleared(Dem_EventIdType eventId)
{
    if (eventId == DEM_EVENT_ID_CODING_ECU_NOT_CODED)
    {
        CodingApp_DemNotCodedState = CODINGAPP_DEM_STATE_UNKNOWN;
    }
    else if (eventId == DEM_EVENT_ID_CODING_INVALID)
    {
        CodingApp_DemInvalidState = CODINGAPP_DEM_STATE_UNKNOWN;
    }
}

boolean CodingApp_IsCoded(void)
{
    return (CodingApp_Status.state == CODINGAPP_STATE_CODED) ? TRUE : FALSE;
}

boolean CodingApp_IsRxMessageExpected(uint16 diagIndex)
{
    if (CodingApp_Status.state != CODINGAPP_STATE_CODED)
    {
        return FALSE;
    }

    return CodingApp_GetExpectedBit(&CodingApp_ActiveImage, diagIndex);
}

boolean CodingApp_IsTxPduEnabled(PduIdType txPduId)
{
    if (CodingApp_IsTxPduCodingExempt(txPduId) != FALSE)
    {
        return TRUE;
    }

    if (CodingApp_Status.state != CODINGAPP_STATE_CODED)
    {
        return TRUE;
    }

    return CodingApp_GetTxPduEnabledBit(&CodingApp_ActiveImage, txPduId);
}

Std_ReturnType CodingApp_ReadDid(uint16 did, uint8 *data, Dcm_PduLengthType *dataLen)
{
    Dcm_PduLengthType requiredLen;

    if ((data == NULL_PTR) || (dataLen == NULL_PTR))
    {
        return E_NOT_OK;
    }

    if (did == CODINGAPP_DID_STATUS)
    {
        requiredLen = 39u;
        if (*dataLen < requiredLen)
        {
            return E_NOT_OK;
        }

        data[0u] = CodingApp_Status.initialized;
        data[1u] = CodingApp_Status.state;
        data[2u] = CodingApp_Status.validationStatus;
        data[3u] = CodingApp_Status.dirty;
        data[4u] = (uint8)((CodingApp_Status.rxMessageCount >> 8u) & 0xFFu);
        data[5u] = (uint8)(CodingApp_Status.rxMessageCount & 0xFFu);
        data[6u] = (uint8)((CodingApp_Status.rxMessageExpectedCount >> 8u) & 0xFFu);
        data[7u] = (uint8)(CodingApp_Status.rxMessageExpectedCount & 0xFFu);
        data[8u] = (uint8)((CodingApp_Status.nvImageLength >> 8u) & 0xFFu);
        data[9u] = (uint8)(CodingApp_Status.nvImageLength & 0xFFu);
        data[10u] = (uint8)((CodingApp_Status.generation >> 24u) & 0xFFu);
        data[11u] = (uint8)((CodingApp_Status.generation >> 16u) & 0xFFu);
        data[12u] = (uint8)((CodingApp_Status.generation >> 8u) & 0xFFu);
        data[13u] = (uint8)(CodingApp_Status.generation & 0xFFu);
        data[14u] = (uint8)((CodingApp_Status.validationCounter >> 24u) & 0xFFu);
        data[15u] = (uint8)((CodingApp_Status.validationCounter >> 16u) & 0xFFu);
        data[16u] = (uint8)((CodingApp_Status.validationCounter >> 8u) & 0xFFu);
        data[17u] = (uint8)(CodingApp_Status.validationCounter & 0xFFu);
        data[18u] = CodingApp_Status.lastNvMResult;
        data[19u] = (uint8)CodingApp_PendingNvMJob;
        data[20u] = (uint8)NvM_GetStatus();
        data[21u] = (uint8)Fee_GetStatus();
        data[22u] = (uint8)Fee_GetJobResult();
        data[23u] = (uint8)Fls_GetStatus();
        data[24u] = (uint8)Fls_GetJobResult();
        data[25u] = CodingApp_PendingNvMPollCount;
        data[26u] = CODINGAPP_NVM_PENDING_POLL_LIMIT;
        data[27u] = (uint8)((NvM_WriteAllActiveIndex >> 8u) & 0xFFu);
        data[28u] = (uint8)(NvM_WriteAllActiveIndex & 0xFFu);
        data[29u] = (uint8)((NvM_WriteAllActiveBlockId >> 8u) & 0xFFu);
        data[30u] = (uint8)(NvM_WriteAllActiveBlockId & 0xFFu);
        data[31u] = (uint8)((NvM_WriteAllBlocksPlanned >> 8u) & 0xFFu);
        data[32u] = (uint8)(NvM_WriteAllBlocksPlanned & 0xFFu);
        data[33u] = (uint8)((NvM_WriteAllBlocksStarted >> 8u) & 0xFFu);
        data[34u] = (uint8)(NvM_WriteAllBlocksStarted & 0xFFu);
        data[35u] = (uint8)((NvM_WriteAllBlocksWritten >> 8u) & 0xFFu);
        data[36u] = (uint8)(NvM_WriteAllBlocksWritten & 0xFFu);
        data[37u] = (uint8)((NvM_WriteAllBlocksFailed >> 8u) & 0xFFu);
        data[38u] = (uint8)(NvM_WriteAllBlocksFailed & 0xFFu);
        *dataLen = requiredLen;
        return E_OK;
    }

    if (did == CODINGAPP_DID_IMAGE)
    {
        requiredLen = (Dcm_PduLengthType)sizeof(CodingApp_NvImageType);
        if (*dataLen < requiredLen)
        {
            return E_NOT_OK;
        }

        if (CodingApp_Status.state == CODINGAPP_STATE_CODED)
        {
            memcpy(data, &CodingApp_ActiveImage, requiredLen);
        }
        else
        {
            memcpy(data, NvM_AppData_Ram, requiredLen);
        }

        *dataLen = requiredLen;
        return E_OK;
    }

    if (did == CODINGAPP_DID_RX_MESSAGE_EXPECTED)
    {
        requiredLen = (Dcm_PduLengthType)CODINGAPP_MASK_BYTES;
        if (*dataLen < requiredLen)
        {
            return E_NOT_OK;
        }

        if (CodingApp_Status.state == CODINGAPP_STATE_CODED)
        {
            memcpy(data, CodingApp_ActiveImage.rxMessageExpected, CODINGAPP_RX_MESSAGE_EXPECTED_BYTES);
            memcpy(&data[CODINGAPP_RX_MESSAGE_EXPECTED_BYTES],
                    CodingApp_ActiveImage.txPduEnabled,
                    CODINGAPP_TX_PDU_ENABLED_BYTES);
        }
        else
        {
            memset(data, 0, CODINGAPP_RX_MESSAGE_EXPECTED_BYTES);
            memset(&data[CODINGAPP_RX_MESSAGE_EXPECTED_BYTES], 0xFF, CODINGAPP_TX_PDU_ENABLED_BYTES);
        }

        *dataLen = requiredLen;
        return E_OK;
    }

    if (did == CODINGAPP_DID_CODING_VERSION)
    {
        uint16 codingVersion;

        requiredLen = 2u;
        if (*dataLen < requiredLen)
        {
            return E_NOT_OK;
        }

        codingVersion = CodingApp_GetCodingVersion();
        data[0u] = (uint8)((codingVersion >> 8u) & 0xFFu);
        data[1u] = (uint8)(codingVersion & 0xFFu);
        *dataLen = requiredLen;
        return E_OK;
    }

    return E_NOT_OK;
}

Dcm_ReturnType CodingApp_WriteDid(uint16 did, const uint8 *data, Dcm_PduLengthType dataLen)
{
    CodingApp_NvImageType image;
    uint8 validationStatus;

    if (data == NULL_PTR)
    {
        return DCM_NRC_INCORRECT_LENGTH;
    }

    if (did == CODINGAPP_DID_IMAGE)
    {
        if (dataLen != (Dcm_PduLengthType)sizeof(CodingApp_NvImageType))
        {
            return DCM_NRC_INCORRECT_LENGTH;
        }

        memcpy(&image, data, sizeof(image));
        validationStatus = CodingApp_ValidateImage(&image);
        if (validationStatus != CODINGAPP_VALIDATION_OK)
        {
            CodingApp_Status.validationStatus = validationStatus;
            CodingApp_Status.invalidCodingCounter++;
            CodingApp_UpdateDebug();
            return DCM_NRC_REQUEST_OUT_OF_RANGE;
        }

        if (CodingApp_ApplyValidImage(&image, TRUE) != E_OK)
        {
            return DCM_NRC_GENERAL_PROGRAMMING_FAILURE;
        }

        return DCM_E_OK;
    }

    if (did == CODINGAPP_DID_RX_MESSAGE_EXPECTED)
    {
        if ((dataLen == 0u) || (dataLen > (Dcm_PduLengthType)CODINGAPP_MASK_BYTES))
        {
            return DCM_NRC_INCORRECT_LENGTH;
        }

        CodingApp_BuildImageFromMask(&image, data, dataLen, CodingApp_Status.generation + 1u);

        if ((CodingApp_Status.state == CODINGAPP_STATE_CODED) &&
                (CodingApp_Status.dirty == FALSE) &&
                (CodingApp_IsSameCodingPayload(&image, &CodingApp_ActiveImage) != FALSE))
        {
            return DCM_E_OK;
        }

        if (CodingApp_ApplyValidImage(&image, TRUE) != E_OK)
        {
            return DCM_NRC_GENERAL_PROGRAMMING_FAILURE;
        }

        return DCM_E_OK;
    }

    return DCM_NRC_REQUEST_OUT_OF_RANGE;
}

Dcm_ReturnType CodingApp_RoutineControl(
    Dcm_OpStatusType opStatus,
    uint8 routineControlType,
    uint16 routineId,
    const uint8 *reqData,
    Dcm_PduLengthType reqLen,
    uint8 *respData,
    Dcm_PduLengthType *respLen
)
{
    CodingApp_NvImageType image;
    uint8 validationStatus;

    if ((respData == NULL_PTR) || (respLen == NULL_PTR))
    {
        return DCM_NRC_GENERAL_REJECT;
    }

    if ((routineControlType != CODINGAPP_ROUTINE_START) &&
        (routineControlType != CODINGAPP_ROUTINE_REQUEST_RESULTS))
    {
        return DCM_NRC_SUBFUNCTION_NOT_SUPPORTED;
    }

    if (opStatus == DCM_CANCEL)
    {
        CodingApp_ClearPendingNvMJob();
        CodingApp_FillRoutineResponse(CODINGAPP_ROUTINE_STATUS_FAILED, respData, respLen);
        return DCM_E_OK;
    }

    if (routineId == CODINGAPP_ROUTINE_VALIDATE)
    {
        if (reqLen != 0u)
        {
            return DCM_NRC_INCORRECT_LENGTH;
        }

        memcpy(&image, NvM_AppData_Ram, sizeof(image));
        validationStatus = CodingApp_ValidateImage(&image);
        CodingApp_Status.validationCounter++;

        if (validationStatus == CODINGAPP_VALIDATION_OK)
        {
            (void)CodingApp_ApplyValidImage(&image, FALSE);
        }
        else
        {
            CodingApp_SetState(
                CodingApp_IsBlank(NvM_AppData_Ram, (uint16)sizeof(image)) ? CODINGAPP_STATE_NOT_CODED : CODINGAPP_STATE_INVALID,
                validationStatus
            );
        }

        CodingApp_FillRoutineResponse(
            (validationStatus == CODINGAPP_VALIDATION_OK) ? CODINGAPP_ROUTINE_STATUS_OK : CODINGAPP_ROUTINE_STATUS_FAILED,
            respData,
            respLen
        );
        return DCM_E_OK;
    }

    if (routineId == CODINGAPP_ROUTINE_WRITE_ALL)
    {
        if (reqLen > (Dcm_PduLengthType)CODINGAPP_MASK_BYTES)
        {
            return DCM_NRC_INCORRECT_LENGTH;
        }

        if ((reqLen != 0u) && (reqData == NULL_PTR))
        {
            return DCM_NRC_INCORRECT_LENGTH;
        }

        if (CodingApp_PendingNvMJob == CODINGAPP_NVM_JOB_WRITE_ALL)
        {
            return CodingApp_PollWriteAll(respData, respLen);
        }

        /* Start vs. result-poll must be decided from the RoutineControl sub-function,
         * not from opStatus: the DCM hands every fresh UDS request to the handler with
         * opStatus == DCM_INITIAL (it only flips to DCM_PENDING while looping the NRC
         * 0x78 response-pending path within one request). Keying off opStatus made each
         * 0x31 0x03 requestResults poll re-enter CodingApp_StartWriteAll and kick off a
         * brand-new NvM job, so the routine never harvested its result. Pending
         * re-entry while the original start request is still active is handled above. */
        if (routineControlType == CODINGAPP_ROUTINE_START)
        {
            /* The coding mask is delivered as the routine option record. Writes are
             * performed via RoutineControl - WriteDataByIdentifier (0x2E) is no
             * longer supported. A zero-length request commits the image already
             * staged in RAM; a shorter mask is zero-padded by
             * CodingApp_BuildImageFromMask. */
            if (reqLen != 0u)
            {
                CodingApp_BuildImageFromMask(&image, reqData, reqLen, CodingApp_Status.generation + 1u);

                if ((CodingApp_Status.state == CODINGAPP_STATE_CODED) &&
                        (CodingApp_Status.dirty == FALSE) &&
                        (CodingApp_IsSameCodingPayload(&image, &CodingApp_ActiveImage) != FALSE))
                {
                    CodingApp_ClearPendingNvMJob();
                    CodingApp_UpdateDebug();
                    CodingApp_FillRoutineResponse(CODINGAPP_ROUTINE_STATUS_OK, respData, respLen);
                    return DCM_E_OK;
                }

                if (CodingApp_ApplyValidImage(&image, TRUE) != E_OK)
                {
                    return DCM_NRC_GENERAL_PROGRAMMING_FAILURE;
                }
            }

            return CodingApp_StartWriteAll(respData, respLen);
        }

        return CodingApp_PollWriteAll(respData, respLen);
    }

    if (routineId == CODINGAPP_ROUTINE_READ_NVM)
    {
        if (reqLen != 0u)
        {
            return DCM_NRC_INCORRECT_LENGTH;
        }

        /* Return the active coding image synchronously. The active image is loaded
         * from NVM at init and refreshed on every coding write, so it already
         * mirrors the persisted block - there is no need for an asynchronous
         * NvM_ReadBlock here. Doing it synchronously also avoids driving the DCM
         * response-pending path twice in a row (start sub-function then
         * requestResults), which could leave the DoIP request context busy and
         * silently drop every later request. The routine result carries the
         * rxMessageExpected bitmask appended after the status block, so the coding
         * can be read back through RoutineControl 0x0203 itself. */
        CodingApp_FillRoutineResponse(
            (CodingApp_Status.state == CODINGAPP_STATE_CODED) ?
                CODINGAPP_ROUTINE_STATUS_OK : CODINGAPP_ROUTINE_STATUS_FAILED,
            respData,
            respLen
        );

        if (CodingApp_Status.state == CODINGAPP_STATE_CODED)
        {
            memcpy(&respData[*respLen], CodingApp_ActiveImage.rxMessageExpected, CODINGAPP_RX_MESSAGE_EXPECTED_BYTES);
            memcpy(&respData[*respLen + CODINGAPP_RX_MESSAGE_EXPECTED_BYTES],
                    CodingApp_ActiveImage.txPduEnabled,
                    CODINGAPP_TX_PDU_ENABLED_BYTES);
        }
        else
        {
            memset(&respData[*respLen], 0, CODINGAPP_RX_MESSAGE_EXPECTED_BYTES);
            memset(&respData[*respLen + CODINGAPP_RX_MESSAGE_EXPECTED_BYTES],
                    0xFF,
                    CODINGAPP_TX_PDU_ENABLED_BYTES);
        }

        *respLen = (Dcm_PduLengthType)(*respLen + (Dcm_PduLengthType)CODINGAPP_MASK_BYTES);
        return DCM_E_OK;
    }

    if (routineId == CODINGAPP_ROUTINE_LOAD_DEFAULTS)
    {
        if (reqLen != 0u)
        {
            return DCM_NRC_INCORRECT_LENGTH;
        }

        CodingApp_BuildDefaultImage(&image, CodingApp_Status.generation + 1u);
        if ((CodingApp_Status.state == CODINGAPP_STATE_CODED) &&
                (CodingApp_Status.dirty == FALSE) &&
                (CodingApp_IsSameCodingPayload(&image, &CodingApp_ActiveImage) != FALSE))
        {
            CodingApp_FillRoutineResponse(CODINGAPP_ROUTINE_STATUS_OK, respData, respLen);
            return DCM_E_OK;
        }

        if (CodingApp_ApplyValidImage(&image, TRUE) != E_OK)
        {
            return DCM_NRC_GENERAL_PROGRAMMING_FAILURE;
        }

        CodingApp_FillRoutineResponse(CODINGAPP_ROUTINE_STATUS_OK, respData, respLen);
        return DCM_E_OK;
    }

    return DCM_NRC_REQUEST_OUT_OF_RANGE;
}

Dcm_ReturnType DcmAppl_ReadDataByIdentifier(
        uint8 connIdx,
        Dcm_OpStatusType opStatus,
        uint16 did,
        uint8* data,
        Dcm_PduLengthType* dataLen)
{
    CODINGAPP_UNUSED(connIdx);
    CODINGAPP_UNUSED(opStatus);

    if (GatewaySwc_ReadDid(did, data, dataLen) == E_OK)
    {
        return DCM_E_OK;
    }

    if (CodingApp_ReadDid(did, data, dataLen) == E_OK)
    {
        return DCM_E_OK;
    }

    return DCM_NRC_REQUEST_OUT_OF_RANGE;
}

Dcm_ReturnType DcmAppl_WriteDataByIdentifier(
        uint8 connIdx,
        Dcm_OpStatusType opStatus,
        uint16 did,
        const uint8* data,
        Dcm_PduLengthType dataLen)
{
    CODINGAPP_UNUSED(connIdx);
    CODINGAPP_UNUSED(opStatus);

    return CodingApp_WriteDid(did, data, dataLen);
}

Dcm_ReturnType DcmAppl_RoutineControl(
        uint8 connIdx,
        Dcm_OpStatusType opStatus,
        uint8 routineControlType,
        uint16 routineId,
        const uint8* reqData,
        Dcm_PduLengthType reqLen,
        uint8* respData,
        Dcm_PduLengthType* respLen)
{
    CODINGAPP_UNUSED(connIdx);

    return CodingApp_RoutineControl(
        opStatus,
        routineControlType,
        routineId,
        reqData,
        reqLen,
        respData,
        respLen
    );
}

static boolean CodingApp_IsBlank(const uint8 *data, uint16 len)
{
    uint16 i;

    if (data == NULL_PTR)
    {
        return FALSE;
    }

    for (i = 0u; i < len; i++)
    {
        if (data[i] != 0u)
        {
            return FALSE;
        }
    }

    return TRUE;
}

static uint8 CodingApp_ValidateImage(const CodingApp_NvImageType *image)
{
    if (image == NULL_PTR)
    {
        return CODINGAPP_VALIDATION_NOT_CODED;
    }

    if (image->magic != CODINGAPP_IMAGE_MAGIC)
    {
        return CODINGAPP_VALIDATION_BAD_MAGIC;
    }

    if (image->version != CODINGAPP_IMAGE_VERSION)
    {
        return CODINGAPP_VALIDATION_BAD_VERSION;
    }

    if (image->length != (uint16)sizeof(CodingApp_NvImageType))
    {
        return CODINGAPP_VALIDATION_BAD_LENGTH;
    }

    if (image->rxMessageCount != (uint16)GATEWAYSWC_RX_MESSAGE_DIAG_COUNT)
    {
        return CODINGAPP_VALIDATION_BAD_MESSAGE_COUNT;
    }

    if (image->txPduCount != (uint16)CODINGAPP_TX_PDU_COUNT)
    {
        return CODINGAPP_VALIDATION_BAD_MESSAGE_COUNT;
    }

    return CODINGAPP_VALIDATION_OK;
}

static uint16 CodingApp_CountExpectedMessages(const CodingApp_NvImageType *image)
{
    uint16 i;
    uint16 count = 0u;

    if (image == NULL_PTR)
    {
        return 0u;
    }

    for (i = 0u; i < (uint16)GATEWAYSWC_RX_MESSAGE_DIAG_COUNT; i++)
    {
        if (CodingApp_GetExpectedBit(image, i) != FALSE)
        {
            count++;
        }
    }

    return count;
}

static boolean CodingApp_IsSameCodingPayload(
    const CodingApp_NvImageType *left,
    const CodingApp_NvImageType *right
)
{
    if ((left == NULL_PTR) || (right == NULL_PTR))
    {
        return FALSE;
    }

    if ((left->magic != right->magic) ||
            (left->version != right->version) ||
            (left->length != right->length) ||
            (left->rxMessageCount != right->rxMessageCount) ||
            (left->txPduCount != right->txPduCount))
    {
        return FALSE;
    }

    if (memcmp(left->rxMessageExpected,
               right->rxMessageExpected,
               CODINGAPP_RX_MESSAGE_EXPECTED_BYTES) != 0)
    {
        return FALSE;
    }

    if (memcmp(left->txPduEnabled,
               right->txPduEnabled,
               CODINGAPP_TX_PDU_ENABLED_BYTES) != 0)
    {
        return FALSE;
    }

    return TRUE;
}

static uint16 CodingApp_GetCodingVersion(void)
{
    const CodingApp_NvImageType *nvImage;

    if (CodingApp_Status.state == CODINGAPP_STATE_CODED)
    {
        return CodingApp_ActiveImage.version;
    }

    nvImage = (const CodingApp_NvImageType *)NvM_AppData_Ram;
    if ((nvImage->magic == CODINGAPP_IMAGE_MAGIC) &&
        (nvImage->length == (uint16)sizeof(CodingApp_NvImageType)) &&
        (nvImage->version != 0u) &&
        (nvImage->version != 0xFFFFu))
    {
        return nvImage->version;
    }

    return CODINGAPP_IMAGE_VERSION;
}

static void CodingApp_SetExpectedBit(CodingApp_NvImageType *image, uint16 index, boolean expected)
{
    uint16 byteIndex;
    uint8 bitMask;

    if ((image == NULL_PTR) || (index >= (uint16)GATEWAYSWC_RX_MESSAGE_DIAG_COUNT))
    {
        return;
    }

    byteIndex = (uint16)(index >> 3u);
    bitMask = (uint8)(1u << (index & 0x07u));

    if (expected != FALSE)
    {
        image->rxMessageExpected[byteIndex] |= bitMask;
    }
    else
    {
        image->rxMessageExpected[byteIndex] &= (uint8)~bitMask;
    }
}

static boolean CodingApp_GetExpectedBit(const CodingApp_NvImageType *image, uint16 index)
{
    uint16 byteIndex;
    uint8 bitMask;

    if ((image == NULL_PTR) || (index >= (uint16)GATEWAYSWC_RX_MESSAGE_DIAG_COUNT))
    {
        return FALSE;
    }

    byteIndex = (uint16)(index >> 3u);
    bitMask = (uint8)(1u << (index & 0x07u));

    return ((image->rxMessageExpected[byteIndex] & bitMask) != 0u) ? TRUE : FALSE;
}

static void CodingApp_SetTxPduEnabledBit(CodingApp_NvImageType *image, PduIdType txPduId, boolean enabled)
{
    uint16 txIndex;
    uint16 byteIndex;
    uint8 bitMask;

    if ((image == NULL_PTR) || (CodingApp_GetTxPduCodingIndex(txPduId, &txIndex) == FALSE))
    {
        return;
    }

    byteIndex = (uint16)(txIndex >> 3u);
    bitMask = (uint8)(1u << (txIndex & 0x07u));

    if (enabled != FALSE)
    {
        image->txPduEnabled[byteIndex] |= bitMask;
    }
    else
    {
        image->txPduEnabled[byteIndex] &= (uint8)~bitMask;
    }
}

static boolean CodingApp_GetTxPduEnabledBit(const CodingApp_NvImageType *image, PduIdType txPduId)
{
    uint16 txIndex;
    uint16 byteIndex;
    uint8 bitMask;

    if ((image == NULL_PTR) || (CodingApp_GetTxPduCodingIndex(txPduId, &txIndex) == FALSE))
    {
        return TRUE;
    }

    byteIndex = (uint16)(txIndex >> 3u);
    bitMask = (uint8)(1u << (txIndex & 0x07u));

    return ((image->txPduEnabled[byteIndex] & bitMask) != 0u) ? TRUE : FALSE;
}

static boolean CodingApp_GetTxPduCodingIndex(PduIdType txPduId, uint16 *index)
{
    uint16 i;

    if (index == NULL_PTR)
    {
        return FALSE;
    }

    for (i = 0u; i < (uint16)CODINGAPP_TX_PDU_COUNT; i++)
    {
        if (CodingApp_TxPduCodingList[i] == txPduId)
        {
            *index = i;
            return TRUE;
        }
    }

    return FALSE;
}

static boolean CodingApp_IsTxPduCodingExempt(PduIdType txPduId)
{
    if (((txPduId >= COM_TX_PDU_XCPREQUEST_7C8) && (txPduId <= COM_TX_PDU_XCPREQUEST_7C0)) ||
        ((txPduId >= COM_TX_PDU_DIAGREQUEST_706) && (txPduId <= COM_TX_PDU_DIAGREQUEST_700)) ||
        (txPduId == COM_TX_PDU_CANFD_PDM1_DIAGREQUEST) ||
        (txPduId == COM_TX_PDU_VEHICLESTATE) ||
        (txPduId == COM_TX_PDU_SDAT) ||
        (txPduId == COM_TX_PDU_NM3) ||
        (txPduId == COM_TX_PDU_CANFD_VEHICLESTATE) ||
        (txPduId == COM_TX_PDU_CANFD_NM3) ||
        (txPduId == COM_TX_PDU_CANFD_SDAT) ||
        (txPduId == COM_TX_PDU_LIN_ZGW_SDAT) ||
        (txPduId == CODINGAPP_TX_PDU_ETH_VEHICLESTATE))
    {
        return TRUE;
    }

    return FALSE;
}

#if CODINGAPP_DEBUG_INSTRUMENTATION
static void CodingApp_UpdateDebug(void)
{
    CODINGAPP_DEBUG_ASSIGN(CodingApp_DebugState, CodingApp_Status.state);
    CODINGAPP_DEBUG_ASSIGN(CodingApp_DebugValidationStatus, CodingApp_Status.validationStatus);
    CODINGAPP_DEBUG_ASSIGN(CodingApp_DebugDirty, CodingApp_Status.dirty);
    CODINGAPP_DEBUG_ASSIGN(CodingApp_DebugRxMessageExpectedCount, CodingApp_Status.rxMessageExpectedCount);
    CODINGAPP_DEBUG_ASSIGN(CodingApp_DebugGeneration, CodingApp_Status.generation);
    CODINGAPP_DEBUG_ASSIGN(CodingApp_DebugInvalidCodingCounter, CodingApp_Status.invalidCodingCounter);
    CODINGAPP_DEBUG_ASSIGN(CodingApp_DebugWriteAllCounter, CodingApp_Status.writeAllCounter);
    CODINGAPP_DEBUG_ASSIGN(CodingApp_DebugLastNvMResult, CodingApp_Status.lastNvMResult);
}
#endif

static void CodingApp_SetState(uint8 state, uint8 validationStatus)
{
    CodingApp_Status.state = state;
    CodingApp_Status.validationStatus = validationStatus;

    if (state != CODINGAPP_STATE_CODED)
    {
        CodingApp_Status.rxMessageExpectedCount = 0u;
    }

    if (state == CODINGAPP_STATE_INVALID)
    {
        CodingApp_Status.invalidCodingCounter++;
    }

    CodingApp_UpdateDebug();
}

static void CodingApp_BuildImageFromMask(
    CodingApp_NvImageType *image,
    const uint8 *mask,
    Dcm_PduLengthType maskLen,
    uint32 generation
)
{
    Dcm_PduLengthType copyLen;

    if (image == NULL_PTR)
    {
        return;
    }

    memset(image, 0, sizeof(*image));

    image->magic = CODINGAPP_IMAGE_MAGIC;
    image->version = CODINGAPP_IMAGE_VERSION;
    image->length = (uint16)sizeof(CodingApp_NvImageType);
    image->generation = generation;
    image->rxMessageCount = (uint16)GATEWAYSWC_RX_MESSAGE_DIAG_COUNT;
    image->txPduCount = (uint16)CODINGAPP_TX_PDU_COUNT;
    memset(image->txPduEnabled, 0xFF, CODINGAPP_TX_PDU_ENABLED_BYTES);

    if (mask != NULL_PTR)
    {
        copyLen = maskLen;
        if (copyLen > (Dcm_PduLengthType)CODINGAPP_RX_MESSAGE_EXPECTED_BYTES)
        {
            copyLen = (Dcm_PduLengthType)CODINGAPP_RX_MESSAGE_EXPECTED_BYTES;
        }

        memcpy(image->rxMessageExpected, mask, copyLen);

        if (maskLen > (Dcm_PduLengthType)CODINGAPP_RX_MESSAGE_EXPECTED_BYTES)
        {
            copyLen = (Dcm_PduLengthType)(maskLen - (Dcm_PduLengthType)CODINGAPP_RX_MESSAGE_EXPECTED_BYTES);
            if (copyLen > (Dcm_PduLengthType)CODINGAPP_TX_PDU_ENABLED_BYTES)
            {
                copyLen = (Dcm_PduLengthType)CODINGAPP_TX_PDU_ENABLED_BYTES;
            }

            memcpy(image->txPduEnabled, &mask[CODINGAPP_RX_MESSAGE_EXPECTED_BYTES], copyLen);
        }
    }

    CodingApp_SetTxPduEnabledBit(image, COM_TX_PDU_XCPREQUEST_7C8, TRUE);
    CodingApp_SetTxPduEnabledBit(image, COM_TX_PDU_XCPREQUEST_7C6, TRUE);
    CodingApp_SetTxPduEnabledBit(image, COM_TX_PDU_XCPREQUEST_7C4, TRUE);
    CodingApp_SetTxPduEnabledBit(image, COM_TX_PDU_XCPREQUEST_7C2, TRUE);
    CodingApp_SetTxPduEnabledBit(image, COM_TX_PDU_XCPREQUEST_7C0, TRUE);
    CodingApp_SetTxPduEnabledBit(image, COM_TX_PDU_DIAGREQUEST_706, TRUE);
    CodingApp_SetTxPduEnabledBit(image, COM_TX_PDU_DIAGREQUEST_704, TRUE);
    CodingApp_SetTxPduEnabledBit(image, COM_TX_PDU_DIAGREQUEST_702, TRUE);
    CodingApp_SetTxPduEnabledBit(image, COM_TX_PDU_DIAGREQUEST_700, TRUE);
    CodingApp_SetTxPduEnabledBit(image, COM_TX_PDU_CANFD_PDM1_DIAGREQUEST, TRUE);

}

static void CodingApp_BuildDefaultImage(CodingApp_NvImageType *image, uint32 generation)
{
    uint16 i;

    CodingApp_BuildImageFromMask(image, NULL_PTR, 0u, generation);

    for (i = 0u; i < (uint16)GATEWAYSWC_RX_MESSAGE_DIAG_COUNT; i++)
    {
        CodingApp_SetExpectedBit(image, i, TRUE);
    }
}

static Std_ReturnType CodingApp_ApplyValidImage(const CodingApp_NvImageType *image, boolean markDirty)
{
    CodingApp_NvImageType normalizedImage;

    if ((image == NULL_PTR) || (CodingApp_ValidateImage(image) != CODINGAPP_VALIDATION_OK))
    {
        return E_NOT_OK;
    }

    normalizedImage = *image;
    normalizedImage.reserved = 0u;

    CodingApp_ActiveImage = normalizedImage;
    CodingApp_Status.state = CODINGAPP_STATE_CODED;
    CodingApp_Status.validationStatus = CODINGAPP_VALIDATION_OK;
    CodingApp_Status.rxMessageCount = normalizedImage.rxMessageCount;
    CodingApp_Status.rxMessageExpectedCount = CodingApp_CountExpectedMessages(&normalizedImage);
    CodingApp_Status.nvImageLength = normalizedImage.length;
    CodingApp_Status.generation = normalizedImage.generation;

    if (markDirty != FALSE)
    {
        memset(NvM_AppData_Ram, 0, NVM_BLOCK_APP_DATA_LENGTH);
        memcpy(NvM_AppData_Ram, &normalizedImage, sizeof(normalizedImage));
        if (NvM_SetRamBlockStatus(NVM_BLOCK_ID_APP_DATA, TRUE) == E_OK)
        {
            CodingApp_Status.dirty = TRUE;
        }
        else
        {
            CodingApp_Status.validationStatus = CODINGAPP_VALIDATION_NVM_ERROR;
            CodingApp_UpdateDebug();
            return E_NOT_OK;
        }
    }

    CodingApp_UpdateDebug();
    return E_OK;
}

static void CodingApp_LoadFromNvRam(void)
{
    CodingApp_NvImageType image;
    NvM_RequestResultType nvmResult;
    uint8 validationStatus;

    memcpy(&image, NvM_AppData_Ram, sizeof(image));

    if (NvM_GetErrorStatus(NVM_BLOCK_ID_APP_DATA, &nvmResult) == E_OK)
    {
        CodingApp_Status.lastNvMResult = (uint8)nvmResult;
    }
    else
    {
        CodingApp_Status.lastNvMResult = NVM_REQ_NOT_OK;
    }

    if (CodingApp_IsBlank(NvM_AppData_Ram, (uint16)sizeof(image)) != FALSE)
    {
        CodingApp_SetState(CODINGAPP_STATE_NOT_CODED, CODINGAPP_VALIDATION_NOT_CODED);
        return;
    }

    validationStatus = CodingApp_ValidateImage(&image);
    CodingApp_Status.validationCounter++;

    if (validationStatus == CODINGAPP_VALIDATION_OK)
    {
        (void)CodingApp_ApplyValidImage(&image, FALSE);
    }
    else
    {
        CodingApp_SetState(CODINGAPP_STATE_INVALID, validationStatus);
    }
}

static Dcm_ReturnType CodingApp_StartWriteAll(uint8 *respData, Dcm_PduLengthType *respLen)
{
    if (CodingApp_Status.state != CODINGAPP_STATE_CODED)
    {
        return DCM_NRC_CONDITIONS_NOT_CORRECT;
    }

    if (CodingApp_Status.dirty == FALSE)
    {
        CodingApp_ClearPendingNvMJob();
        CodingApp_UpdateDebug();
        CodingApp_FillRoutineResponse(CODINGAPP_ROUTINE_STATUS_OK, respData, respLen);
        return DCM_E_OK;
    }

    CodingApp_PendingNvMJob = CODINGAPP_NVM_JOB_WRITE_ALL;
    CodingApp_PendingNvMStarted = FALSE;
    CodingApp_PendingNvMPollCount = 0u;
    CodingApp_Status.lastNvMResult = NVM_REQ_PENDING;
    CodingApp_UpdateDebug();

    return CodingApp_PollWriteAll(respData, respLen);
}

static Dcm_ReturnType CodingApp_PollWriteAll(uint8 *respData, Dcm_PduLengthType *respLen)
{
    NvM_RequestResultType nvmResult;

    if (CodingApp_Status.state != CODINGAPP_STATE_CODED)
    {
        CodingApp_ClearPendingNvMJob();
        CodingApp_FillRoutineResponse(CODINGAPP_ROUTINE_STATUS_FAILED, respData, respLen);
        return DCM_E_OK;
    }

    if (CodingApp_PendingNvMJob != CODINGAPP_NVM_JOB_WRITE_ALL)
    {
        CodingApp_FillRoutineResponse(
            (CodingApp_Status.dirty == FALSE) ?
                CODINGAPP_ROUTINE_STATUS_OK : CODINGAPP_ROUTINE_STATUS_FAILED,
            respData,
            respLen);
        return DCM_E_OK;
    }

    if (NvM_GetStatus() == NVM_UNINIT)
    {
        CodingApp_Status.lastNvMResult = NVM_REQ_NOT_OK;
        CodingApp_Status.validationStatus = CODINGAPP_VALIDATION_NVM_ERROR;
        CodingApp_ClearPendingNvMJob();
        CodingApp_UpdateDebug();
        return DCM_NRC_GENERAL_PROGRAMMING_FAILURE;
    }

    (void)NvM_StartDeferredDefaultImage();
    CodingApp_PumpNvMStack();

    if (CodingApp_PendingNvMStarted == FALSE)
    {
    if (NvM_GetStatus() != NVM_IDLE)
    {
        if (CodingApp_CountNvMPendingPoll() != FALSE)
        {
            CodingApp_UpdateDebug();
            return DCM_E_PENDING;
        }

        CodingApp_Status.lastNvMResult = NVM_REQ_NOT_OK;
        CodingApp_Status.validationStatus = CODINGAPP_VALIDATION_NVM_ERROR;
        CodingApp_ClearPendingNvMJob();
        CodingApp_UpdateDebug();
        return DCM_NRC_GENERAL_PROGRAMMING_FAILURE;
    }

        if (NvM_WriteBlock(NVM_BLOCK_ID_APP_DATA, NULL_PTR) != E_OK)
        {
            CodingApp_Status.lastNvMResult = NVM_REQ_NOT_OK;
            CodingApp_Status.validationStatus = CODINGAPP_VALIDATION_NVM_ERROR;
            CodingApp_ClearPendingNvMJob();
            CodingApp_UpdateDebug();
            return DCM_NRC_GENERAL_PROGRAMMING_FAILURE;
        }

        CodingApp_PendingNvMStarted = TRUE;
        CodingApp_PendingNvMPollCount = 0u;
        CodingApp_Status.lastNvMResult = NVM_REQ_PENDING;
        CodingApp_UpdateDebug();

        CodingApp_PumpNvMStack();
    }

    if (NvM_GetStatus() != NVM_IDLE)
    {
        if (CodingApp_CountNvMPendingPoll() != FALSE)
        {
            CodingApp_UpdateDebug();
            return DCM_E_PENDING;
        }

        CodingApp_Status.lastNvMResult = NVM_REQ_NOT_OK;
        CodingApp_Status.validationStatus = CODINGAPP_VALIDATION_NVM_ERROR;
        CodingApp_ClearPendingNvMJob();
        CodingApp_UpdateDebug();
        return DCM_NRC_GENERAL_PROGRAMMING_FAILURE;
    }

    if (NvM_GetErrorStatus(NVM_BLOCK_ID_APP_DATA, &nvmResult) != E_OK)
    {
        nvmResult = NVM_REQ_NOT_OK;
    }

    CodingApp_Status.lastNvMResult = (uint8)nvmResult;

    if (nvmResult != NVM_REQ_OK)
    {
        CodingApp_Status.validationStatus = CODINGAPP_VALIDATION_NVM_ERROR;
        CodingApp_ClearPendingNvMJob();
        CodingApp_UpdateDebug();
        return DCM_NRC_GENERAL_PROGRAMMING_FAILURE;
    }

    CodingApp_Status.dirty = FALSE;
    CodingApp_Status.writeAllCounter++;
    CodingApp_ClearPendingNvMJob();
    CodingApp_UpdateDebug();
    CodingApp_FillRoutineResponse(CODINGAPP_ROUTINE_STATUS_OK, respData, respLen);
    return DCM_E_OK;
}

static boolean CodingApp_IsNvMStackBusy(void)
{
    NvM_StatusType nvmStatus;
    MemIf_StatusType feeStatus;
    MemIf_StatusType flsStatus;

    nvmStatus = NvM_GetStatus();
    feeStatus = Fee_GetStatus();
    flsStatus = Fls_GetStatus();

    if ((nvmStatus == NVM_BUSY) || (nvmStatus == NVM_BUSY_INTERNAL))
    {
        return TRUE;
    }

    if ((feeStatus == MEMIF_BUSY) || (feeStatus == MEMIF_BUSY_INTERNAL))
    {
        return TRUE;
    }

    if (flsStatus == MEMIF_BUSY)
    {
        return TRUE;
    }

    return FALSE;
}

static void CodingApp_PumpNvMStack(void)
{
    uint16 cycleBudget;

    cycleBudget = CODINGAPP_NVM_PUMP_CYCLE_BUDGET;
    while ((cycleBudget > 0u) && (CodingApp_IsNvMStackBusy() != FALSE))
    {
        Fls_MainFunction();
        Fee_MainFunction();
        NvM_MainFunction();
        cycleBudget--;
    }
}

static boolean CodingApp_CountNvMPendingPoll(void)
{
    if (CodingApp_PendingNvMPollCount < CODINGAPP_NVM_PENDING_POLL_LIMIT)
    {
        CodingApp_PendingNvMPollCount++;
        return TRUE;
    }

    return FALSE;
}

static void CodingApp_ClearPendingNvMJob(void)
{
    CodingApp_PendingNvMJob = CODINGAPP_NVM_JOB_NONE;
    CodingApp_PendingNvMStarted = FALSE;
    CodingApp_PendingNvMPollCount = 0u;
}

static void CodingApp_FillRoutineResponse(uint8 status, uint8 *respData, Dcm_PduLengthType *respLen)
{
    if ((respData == NULL_PTR) || (respLen == NULL_PTR))
    {
        return;
    }

    respData[0u] = status;
    respData[1u] = CodingApp_Status.state;
    respData[2u] = CodingApp_Status.validationStatus;
    respData[3u] = CodingApp_Status.dirty;
    respData[4u] = (uint8)((CodingApp_Status.rxMessageExpectedCount >> 8u) & 0xFFu);
    respData[5u] = (uint8)(CodingApp_Status.rxMessageExpectedCount & 0xFFu);
    respData[6u] = (uint8)((CodingApp_Status.generation >> 24u) & 0xFFu);
    respData[7u] = (uint8)((CodingApp_Status.generation >> 16u) & 0xFFu);
    respData[8u] = (uint8)((CodingApp_Status.generation >> 8u) & 0xFFu);
    respData[9u] = (uint8)(CodingApp_Status.generation & 0xFFu);
    *respLen = 10u;
}
