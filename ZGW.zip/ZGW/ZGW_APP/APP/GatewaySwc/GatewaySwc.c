#include "GatewaySwc.h"
#include "CanIf.h"
#include "CanDiag.h"
#include "Com.h"
#include "ComM.h"
#include "Dcm.h"
#include "Dem.h"
#include "LinIf.h"
#include "LinDiag.h"
#include "SoAd.h"
#include "Crc.h"
#include "Nm.h"
#include "SysMgr.h"
#include "NvM.h"
#include "IfxCpu.h"
#include "APP/CodingApp/CodingApp.h"
#include "APP/AiModel/AiModel.h"
#include "APP/TimeSync/TimeBase.h"
#include "BSW/Com/Ethernet/EthStartupTiming.h"
#include "BSW/Sys/Os/Os.h"
#include "BSW/Sys/CpuPerf/CpuPerf.h"
#include "BSW/Sys/SmM/SafetyKit_Main.h"

#define GATEWAYSWC_MAGIC0                             0x5Au
#define GATEWAYSWC_MAGIC1                             0x47u
#define GATEWAYSWC_MAGIC2                             0x57u

#define GATEWAYSWC_FRAME_SUMMARY                      0x01u
#define GATEWAYSWC_FRAME_COMMAND_SIGNAL               0x02u
#define GATEWAYSWC_FRAME_COMMAND_BLOCK                0x03u
#define GATEWAYSWC_FRAME_DTC_TRANSITION               0x04u
#define GATEWAYSWC_FRAME_AI_MODEL                     0x05u
#define GATEWAYSWC_FRAME_CPU_PERF                     0x06u
#define GATEWAYSWC_FRAME_VEHICLESTATE                 0x07u

#define GATEWAYSWC_AI_MODEL_GLOBAL_LEN                61u
#define GATEWAYSWC_AI_MODEL_CHANNEL_LEN               43u
#define GATEWAYSWC_CPU_PERF_HEADER_LEN                8u
#define GATEWAYSWC_HEADER_LEN                         12u
#define GATEWAYSWC_ENTRY_LEN                          7u
#define GATEWAYSWC_DTC_TRANSITION_LEN                 17u
#define GATEWAYSWC_DTC_TRANSITION_QUEUE_SIZE          8u
#define GATEWAYSWC_DTC_QUEUE_LOCK_TIMEOUT             100000u
#define GATEWAYSWC_CPU_CORE_COUNT                     6u
#define GATEWAYSWC_CROSS_CORE_LOCK_TIMEOUT            100000u
#define GATEWAYSWC_ETH_TX_QUEUE_SIZE                  32u
#define GATEWAYSWC_ETH_RX_QUEUE_SIZE                  8u
#define GATEWAYSWC_ETH_TX_RESULT_QUEUE_SIZE           32u
#define GATEWAYSWC_ETH_RX_QUEUE_MAX_PAYLOAD           GATEWAYSWC_ETH_MAX_PAYLOAD
#define GATEWAYSWC_ETH_TX_DRAIN_BUDGET                4u

#define GATEWAYSWC_ETH_TX_KIND_SUMMARY                1u
#define GATEWAYSWC_ETH_TX_KIND_DTC_TRANSITION         2u
#define GATEWAYSWC_ETH_TX_KIND_MCU_STATUS             3u
#define GATEWAYSWC_ETH_TX_KIND_AI_MODEL               4u
#define GATEWAYSWC_ETH_TX_KIND_CPU_PERF               5u
#define GATEWAYSWC_ETH_TX_KIND_VEHICLESTATE           6u

#define GATEWAYSWC_DIAG_PERIOD_MS                     1000u
#define GATEWAYSWC_ETH_RX_TIMEOUT_MS                  3000u
#define GATEWAYSWC_ETH_PERIOD_NS                      ((uint64)GATEWAYSWC_ETH_PERIOD_MS * TIMEBASE_NS_PER_MS)
#define GATEWAYSWC_AI_MODEL_PUBLISH_PERIOD_MS         200u
#define GATEWAYSWC_CPU_PERF_PUBLISH_PERIOD_MS         1000u

#define GATEWAYSWC_MCU_STATUS_MAGIC                   0x5A4D4355u
#define GATEWAYSWC_MCU_STATUS_VERSION                 1u
#define GATEWAYSWC_MCU_STATUS_MESSAGE_STATUS          2u
#define GATEWAYSWC_MCU_STATUS_CRC_OFFSET              60u
#define GATEWAYSWC_MCU_STATUS_TX_PERIOD_NS            ((uint64)GATEWAYSWC_MCU_STATUS_UDP_PERIOD_MS * TIMEBASE_NS_PER_MS)

#define GATEWAYSWC_SDAT_YEAR_BASE                     2000u
#define GATEWAYSWC_SDAT_YEAR_MAX_RAW                  63u
#define GATEWAYSWC_SDAT_MS_RESOLUTION                 4u
#define GATEWAYSWC_SDAT_MS_MAX_RAW                    255u

#define GATEWAYSWC_SDAT_SOURCE_DEFAULT                0u
#define GATEWAYSWC_SDAT_SOURCE_UDS                    1u
#define GATEWAYSWC_SDAT_SOURCE_GPTP                   2u
#define GATEWAYSWC_SDAT_SOURCE_INVALID                3u

#ifndef GATEWAYSWC_ETH_RX_CAPTURE_SLOT_COUNT
#define GATEWAYSWC_ETH_RX_CAPTURE_SLOT_COUNT           8u
#endif

#ifndef GATEWAYSWC_ETH_RX_CAPTURE_MAX_PAYLOAD
#define GATEWAYSWC_ETH_RX_CAPTURE_MAX_PAYLOAD          256u
#endif

#ifndef GATEWAYSWC_ETH_RX_CAPTURE_DEFAULT_ENABLE
#define GATEWAYSWC_ETH_RX_CAPTURE_DEFAULT_ENABLE       1u
#endif

#define GATEWAYSWC_ETH_RX_CAPTURE_FILTER_OFF           0u
#define GATEWAYSWC_ETH_RX_CAPTURE_FILTER_SOCON         1u


#define GATEWAYSWC_DEM_STATE_UNKNOWN                   0xFFu

#define GATEWAYSWC_COMM_UNKNOWN                       0xFFu
#define GATEWAYSWC_COMM_NO                            0u
#define GATEWAYSWC_COMM_FULL                          1u

#define GATEWAYSWC_ROUTE_PHASE_IDLE                   0u
#define GATEWAYSWC_ROUTE_PHASE_RECEIVE                1u
#define GATEWAYSWC_ROUTE_PHASE_RECEIVED               2u
#define GATEWAYSWC_ROUTE_PHASE_SEND                   3u
#define GATEWAYSWC_ROUTE_PHASE_SENT                   4u

#define GATEWAYSWC_PDM_CMD_IDX_PDM1                   0u

typedef struct
{
        uint32 mainCycles;
        uint32 routedSignals;
        uint32 generatedSignals;
        uint32 sendSignalOk;
        uint32 sendSignalFailed;
        uint32 receiveSignalFailed;
        uint32 ethFramesSent;
        uint32 ethFramesFailed;
        uint32 ethSignalsPublished;
        uint8 ethLastOpenResult;
        uint8 ethLastSoAdResult;
        uint8 ethLastTransmitOk;
        uint16 ethLastPayloadLength;
        uint16 configuredRoutes;
        uint16 rxDiagConfiguredMessages;
        uint16 rxDiagConfiguredSignals;
        uint16 rxDiagTimedOutMessages;
        uint16 rxDiagInvalidSignals;
        uint32 rxDiagTimeoutEvents;
        uint32 rxDiagInvalidEvents;
        uint16 rxDiagLastTimeoutPduId;
        uint16 rxDiagLastInvalidSignalId;
        uint32 rxDiagLastInvalidValue;
} GatewaySwc_StatusType;

typedef struct
{
        uint32 pdmCommandLoad[1u][GATEWAYSWC_PDM_LOADS_PER_PDM];
        uint32 linHvDcdcEnable;
        uint32 linHvDcdcTargetVoltage;
        uint32 vehicleStatus;
        uint32 nmPn1;
} GatewaySwc_CommandType;

typedef struct
{
        Com_SignalIdType rxSignalId;
        Com_SignalIdType txSignalId;
} GatewaySwc_RouteMapType;

typedef struct
{
        Com_SignalIdType firstSignalId;
        Com_SignalIdType lastSignalId;
        GatewaySwc_BusType bus;
} GatewaySwc_SignalRangeType;

typedef struct
{
        PduIdType firstPduId;
        PduIdType lastPduId;
        GatewaySwc_BusType bus;
} GatewaySwc_PduRangeType;

typedef struct
{
        Dem_DTCType dtc;
        Dem_UdsStatusByteType status;
} GatewaySwc_DtcTransitionType;

typedef struct
{
        uint32 year;
        uint32 month;
        uint32 day;
        uint32 hour;
        uint32 minute;
        uint32 second;
        uint32 millisecond;
        uint32 utcValid;
        uint32 timeSource;
        uint32 defaultTime;
        uint32 nvmRestored;
} GatewaySwc_SdatTimeType;

typedef struct
{
        uint8 kind;
        SoAd_SoConIdType soConId;
        uint8 hasRemoteAddr;
        TcpIp_SockAddrType remoteAddr;
        uint16 len;
        uint8 data[GATEWAYSWC_ETH_MAX_PAYLOAD];
} GatewaySwc_EthTxJobType;

typedef struct
{
        uint8 kind;
        uint8 openResult;
        uint16 len;
        sint32 result;
} GatewaySwc_EthTxResultType;

typedef struct
{
        uint8 soConId;
        uint8 hasRemoteAddr;
        TcpIp_SockAddrType remoteAddr;
        uint16 len;
        uint8 data[GATEWAYSWC_ETH_RX_QUEUE_MAX_PAYLOAD];
} GatewaySwc_EthRxJobType;

static uint8 GatewaySwc_EthBuffer[GATEWAYSWC_ETH_MAX_PAYLOAD];
static uint8 GatewaySwc_DtcTransitionPayload[GATEWAYSWC_DTC_TRANSITION_LEN];

static GatewaySwc_StatusType GatewaySwc_Status;
static volatile uint8 GatewaySwc_Initialized = 0u;
static GatewaySwc_CommandType GatewaySwc_Command;
static GatewaySwc_DtcTransitionType GatewaySwc_DtcTransitionQueue[GATEWAYSWC_DTC_TRANSITION_QUEUE_SIZE];
static volatile uint8 GatewaySwc_DtcTransitionHead;
static volatile uint8 GatewaySwc_DtcTransitionTail;
static IfxCpu_spinLock GatewaySwc_DtcQueueLock;
static boolean GatewaySwc_DtcQueueIrqState[GATEWAYSWC_CPU_CORE_COUNT];
static volatile uint8 GatewaySwc_DtcQueueLockOwned[GATEWAYSWC_CPU_CORE_COUNT];
static GatewaySwc_EthTxJobType GatewaySwc_EthTxQueue[GATEWAYSWC_ETH_TX_QUEUE_SIZE];
static GatewaySwc_EthTxResultType GatewaySwc_EthTxResultQueue[GATEWAYSWC_ETH_TX_RESULT_QUEUE_SIZE];
static GatewaySwc_EthRxJobType GatewaySwc_EthRxQueue[GATEWAYSWC_ETH_RX_QUEUE_SIZE];
static volatile uint8 GatewaySwc_EthTxHead;
static volatile uint8 GatewaySwc_EthTxTail;
static volatile uint8 GatewaySwc_EthTxResultHead;
static volatile uint8 GatewaySwc_EthTxResultTail;
static volatile uint8 GatewaySwc_EthRxHead;
static volatile uint8 GatewaySwc_EthRxTail;
static IfxCpu_spinLock GatewaySwc_CrossCoreLock;
static boolean GatewaySwc_CrossCoreIrqState[GATEWAYSWC_CPU_CORE_COUNT];
static volatile uint8 GatewaySwc_CrossCoreLockOwned[GATEWAYSWC_CPU_CORE_COUNT];

static uint16 GatewaySwc_RouteTimerMs;
static uint16 GatewaySwc_OutputTimerMs;
static uint16 GatewaySwc_AiModelPublishTimerMs;
static uint16 GatewaySwc_CpuPerfPublishTimerMs;
static uint64 GatewaySwc_NextEthPublishTimeNs;
static TcpIp_SocketIdType GatewaySwc_McuStatusSocket = TCPIP_INVALID_SOCKET;
static uint64 GatewaySwc_McuStatusNextTxTimeNs = 0ull;
static uint32 GatewaySwc_McuStatusSequenceCounter = 0u;
static uint8 GatewaySwc_McuStatusStatus = GATEWAYSWC_MCU_STATUS_DISABLED;
static uint32 GatewaySwc_McuStatusTxCounter = 0u;
static volatile uint8 GatewaySwc_McuStatusTxPending = 0u;
static uint16 GatewaySwc_DiagTimerMs;
static uint8 GatewaySwc_LoadRequestAliveCounter;
static uint8 GatewaySwc_LoadRequest_Status = 0u;
static uint8 GatewaySwc_LoadRequest_DataId = 7;
static uint8 GatewaySwc_RxMessageDiagStatus[GATEWAYSWC_RX_MESSAGE_DIAG_COUNT];
static uint8 GatewaySwc_RxSignalDiagStatus[GATEWAYSWC_RX_SIGNAL_DIAG_COUNT];
static uint32 GatewaySwc_RxSignalDiagValue[GATEWAYSWC_RX_SIGNAL_DIAG_COUNT];
static uint32 GatewaySwc_RxSignalDiagInvalidValue[GATEWAYSWC_RX_SIGNAL_DIAG_COUNT];
static uint8 GatewaySwc_DemMessageTimeoutState[GATEWAYSWC_RX_MESSAGE_DIAG_COUNT];
static uint32 GatewaySwc_EthRxAgeMs[GATEWAYSWC_ETH_RX_MESSAGE_COUNT];
static uint8 GatewaySwc_ComModeRequestState = GATEWAYSWC_COMM_UNKNOWN;

volatile uint8 GatewaySwc_ComFullRequested = 0u;
#if GATEWAYSWC_DEBUG_INSTRUMENTATION
volatile uint16 GatewaySwc_RxMessageDiagDebugPduId[GATEWAYSWC_RX_MESSAGE_DIAG_COUNT];
volatile uint8 GatewaySwc_RxMessageDiagDebugStatus[GATEWAYSWC_RX_MESSAGE_DIAG_COUNT];
#endif
volatile uint32 GatewaySwc_RxMessageTimeoutCounter[GATEWAYSWC_RX_MESSAGE_DIAG_COUNT];
volatile uint32 GatewaySwc_RxMessageTimeoutActiveSamples[GATEWAYSWC_RX_MESSAGE_DIAG_COUNT];
#if GATEWAYSWC_DEBUG_INSTRUMENTATION
volatile uint16 GatewaySwc_RxSignalDiagDebugSignalId[GATEWAYSWC_RX_SIGNAL_DIAG_COUNT];
volatile uint8 GatewaySwc_RxSignalDiagDebugStatus[GATEWAYSWC_RX_SIGNAL_DIAG_COUNT];
volatile uint32 GatewaySwc_RxSignalDiagDebugValue[GATEWAYSWC_RX_SIGNAL_DIAG_COUNT];
volatile uint32 GatewaySwc_RxSignalDiagDebugInvalidValue[GATEWAYSWC_RX_SIGNAL_DIAG_COUNT];
#endif
volatile uint32 GatewaySwc_RxSignalTimeoutCounter[GATEWAYSWC_RX_SIGNAL_DIAG_COUNT];
volatile uint32 GatewaySwc_RxSignalTimeoutActiveSamples[GATEWAYSWC_RX_SIGNAL_DIAG_COUNT];
volatile uint32 GatewaySwc_RxSignalInvalidCounter[GATEWAYSWC_RX_SIGNAL_DIAG_COUNT];
volatile uint32 GatewaySwc_RxSignalInvalidActiveSamples[GATEWAYSWC_RX_SIGNAL_DIAG_COUNT];
#if GATEWAYSWC_DEBUG_INSTRUMENTATION
volatile uint16 GatewaySwc_DebugPublishFirstSignalId = 0u;
volatile uint16 GatewaySwc_DebugPublishLastSignalId = 0u;
volatile uint16 GatewaySwc_DebugPublishSignalId = 0u;
volatile uint16 GatewaySwc_DebugPublishLen = 0u;
volatile uint8 GatewaySwc_DebugPublishBus = 0u;
volatile uint8 GatewaySwc_DebugPublishReceiveResult = E_NOT_OK;
volatile uint32 GatewaySwc_DebugPublishValue = 0u;
volatile uint16 GatewaySwc_DebugRouteIndex = 0xFFFFu;
volatile uint16 GatewaySwc_DebugRouteCount = 0u;
volatile uint16 GatewaySwc_DebugRouteRxSignalId = 0u;
volatile uint16 GatewaySwc_DebugRouteTxSignalId = 0u;
volatile uint8 GatewaySwc_DebugRoutePhase = GATEWAYSWC_ROUTE_PHASE_IDLE;
volatile uint8 GatewaySwc_DebugRouteReceiveResult = E_NOT_OK;
volatile uint8 GatewaySwc_DebugRouteSendResult = E_NOT_OK;
volatile uint32 GatewaySwc_DebugRouteValue = 0u;
volatile uint32 GatewaySwc_DebugLoadRequestCounter = 0u;
volatile uint32 GatewaySwc_DebugLoadRequestCrc = 0u;
volatile uint32 GatewaySwc_DebugLoadRequestAlive = 0u;
volatile uint8 GatewaySwc_DebugLoadRequestChanged = 0u;
volatile uint8 GatewaySwc_DebugPublishInvalidRange = 0u;
volatile uint8 GatewaySwc_DebugDtcQueueHead = 0u;
volatile uint8 GatewaySwc_DebugDtcQueueTail = 0u;
volatile uint8 GatewaySwc_DebugDtcQueueCount = 0u;
volatile uint32 GatewaySwc_DebugDtcDropped = 0u;
volatile uint32 GatewaySwc_DebugDtcFlushed = 0u;
volatile uint32 GatewaySwc_DebugDtcLastDtc = 0u;
volatile uint8 GatewaySwc_DebugDtcLastStatus = 0u;
volatile uint8 GatewaySwc_DebugDtcLastOpenResult = 0u;
volatile uint8 GatewaySwc_DebugDtcLastTxResult = SOAD_NOT_OK;
volatile uint32 GatewaySwc_DebugDtcQueueLockTimeout = 0u;
volatile uint32 GatewaySwc_DebugEthTxQueueDropped = 0u;
volatile uint32 GatewaySwc_DebugEthTxResultQueueDropped = 0u;
volatile uint32 GatewaySwc_DebugEthRxQueueDropped = 0u;
volatile uint32 GatewaySwc_DebugCrossCoreLockTimeout = 0u;

volatile uint8 GatewaySwc_EthRxCaptureEnable = GATEWAYSWC_ETH_RX_CAPTURE_DEFAULT_ENABLE;
volatile uint8 GatewaySwc_EthRxCaptureFilterMode = GATEWAYSWC_ETH_RX_CAPTURE_FILTER_OFF;
volatile uint8 GatewaySwc_EthRxCaptureFilterSoConId = GATEWAYSWC_ETH_SOCON_ID;
volatile uint16 GatewaySwc_EthRxCaptureMaxLen = GATEWAYSWC_ETH_RX_CAPTURE_MAX_PAYLOAD;
volatile uint8 GatewaySwc_EthRxCaptureWriteIndex = 0u;
volatile uint8 GatewaySwc_EthRxCaptureLastIndex = 0u;
volatile uint32 GatewaySwc_EthRxCaptureCounter = 0u;
volatile uint32 GatewaySwc_EthRxCaptureDroppedCounter = 0u;
volatile uint32 GatewaySwc_EthRxCaptureTruncatedCounter = 0u;
volatile uint8 GatewaySwc_EthRxCaptureSoConId[GATEWAYSWC_ETH_RX_CAPTURE_SLOT_COUNT];
volatile uint16 GatewaySwc_EthRxCaptureLen[GATEWAYSWC_ETH_RX_CAPTURE_SLOT_COUNT];
volatile uint16 GatewaySwc_EthRxCaptureCopiedLen[GATEWAYSWC_ETH_RX_CAPTURE_SLOT_COUNT];
volatile uint32 GatewaySwc_EthRxCaptureMainCycle[GATEWAYSWC_ETH_RX_CAPTURE_SLOT_COUNT];
volatile uint32 GatewaySwc_EthRxCaptureRemoteAddrPtr[GATEWAYSWC_ETH_RX_CAPTURE_SLOT_COUNT];
volatile uint8 GatewaySwc_EthRxCaptureData[GATEWAYSWC_ETH_RX_CAPTURE_SLOT_COUNT][GATEWAYSWC_ETH_RX_CAPTURE_MAX_PAYLOAD];
#define GATEWAYSWC_DEBUG_ASSIGN(lhs, rhs) do { (lhs) = (rhs); } while (0)
#define GATEWAYSWC_DEBUG_INC(lhs) do { (lhs)++; } while (0)
#else
#define GATEWAYSWC_DEBUG_ASSIGN(lhs, rhs) do { } while (0)
#define GATEWAYSWC_DEBUG_INC(lhs) do { } while (0)
#endif

long long GatewaySwc_MainFunction_Counter = 0;
static volatile boolean GatewaySwc_NormalCommunicationRxEnabled = TRUE;
static volatile boolean GatewaySwc_NormalCommunicationTxEnabled = TRUE;

Dcm_ReturnType GatewaySwc_SetDiagnosticCommunicationControl(uint8 controlType, uint8 communicationType)
{
    if ((communicationType == 0u) || ((communicationType & (uint8)~0x03u) != 0u))
    {
        return DCM_NRC_REQUEST_OUT_OF_RANGE;
    }

    if (((controlType == 0x00u) || (controlType == 0x02u)) &&
            (GatewaySwc_NormalCommunicationTxEnabled == FALSE))
    {
        Com_TriggerFullComRestartBurst(COMM_CH_CAN);
        Com_TriggerFullComRestartBurst(COMM_CH_CANFD);
        Com_TriggerFullComRestartBurst(COMM_CH_LIN);
    }

    switch (controlType)
    {
        case 0x00u:
            GatewaySwc_NormalCommunicationRxEnabled = TRUE;
            GatewaySwc_NormalCommunicationTxEnabled = TRUE;
            return DCM_E_OK;

        case 0x01u:
            GatewaySwc_NormalCommunicationRxEnabled = TRUE;
            GatewaySwc_NormalCommunicationTxEnabled = FALSE;
            return DCM_E_OK;

        case 0x02u:
            GatewaySwc_NormalCommunicationRxEnabled = FALSE;
            GatewaySwc_NormalCommunicationTxEnabled = TRUE;
            return DCM_E_OK;

        case 0x03u:
            GatewaySwc_NormalCommunicationRxEnabled = FALSE;
            GatewaySwc_NormalCommunicationTxEnabled = FALSE;
            return DCM_E_OK;

        default:
            return DCM_NRC_SUBFUNCTION_NOT_SUPPORTED;
    }
}

boolean GatewaySwc_IsNormalCommunicationRxEnabled(void)
{
    return (GatewaySwc_NormalCommunicationRxEnabled != FALSE) ? TRUE : FALSE;
}

boolean GatewaySwc_IsNormalCommunicationTxEnabled(void)
{
    return (GatewaySwc_NormalCommunicationTxEnabled != FALSE) ? TRUE : FALSE;
}

Dcm_ReturnType DcmAppl_CommunicationControl(
    uint8 connIdx,
    Dcm_OpStatusType opStatus,
    uint8 controlType,
    uint8 communicationType)
{
    (void)connIdx;
    (void)opStatus;

    return GatewaySwc_SetDiagnosticCommunicationControl(controlType, communicationType);
}

Dcm_ReturnType DcmAppl_ControlDtcSetting(
    uint8 connIdx,
    Dcm_OpStatusType opStatus,
    uint8 settingType)
{
    (void)connIdx;
    (void)opStatus;

    switch (settingType)
    {
        case 0x01u:
            return (Dem_SetDtcSetting(TRUE) == E_OK) ? DCM_E_OK : DCM_NRC_REQUEST_OUT_OF_RANGE;

        case 0x02u:
            return (Dem_SetDtcSetting(FALSE) == E_OK) ? DCM_E_OK : DCM_NRC_REQUEST_OUT_OF_RANGE;

        default:
            return DCM_NRC_SUBFUNCTION_NOT_SUPPORTED;
    }
}

Std_ReturnType GatewaySwc_RequestComSendSignal(Com_SignalIdType signalId, const void *data)
{
    if (GatewaySwc_NormalCommunicationTxEnabled == FALSE)
    {
        return E_NOT_OK;
    }

    return Com_SendSignal(signalId, data);
}

void GatewaySwc_RequestComMainFunctionTx(void)
{
    if (GatewaySwc_NormalCommunicationTxEnabled != FALSE)
    {
        Com_MainFunctionTx();
    }
}

Std_ReturnType GatewaySwc_RequestCanIfTransmit(PduIdType txPduId, const uint8 *data, PduLengthType len)
{
    return CanIf_Transmit(txPduId, data, len);
}

Std_ReturnType GatewaySwc_RequestLinIfTransmit(PduIdType txPduId, const uint8 *data, PduLengthType len)
{
    return LinIf_Transmit(txPduId, data, len);
}

SoAd_ReturnType GatewaySwc_RequestSoAdIfTransmit(SoAd_SoConIdType soConId,
        const TcpIp_SockAddrType *remoteAddr,
        const uint8 *data,
        uint16 len)
{
    EthStartupTiming_Capture(ETHSTARTUPTIMING_EVENT_FIRST_APP_TX_REQUEST);
    return SoAd_IfTransmit(soConId, remoteAddr, data, len);
}

sint32 GatewaySwc_RequestTcpIpSendTo(TcpIp_SocketIdType sock,
        const TcpIp_SockAddrType *remoteAddr,
        const uint8 *data,
        uint16 len)
{
    EthStartupTiming_Capture(ETHSTARTUPTIMING_EVENT_FIRST_APP_TX_REQUEST);
    return TcpIp_SendTo(sock, remoteAddr, data, len);
}

void GatewaySwc_RequestLinIfMainFunction(void)
{
    LinIf_MainFunction();
}

static const GatewaySwc_RouteMapType GatewaySwc_RouteMap[] =
{
        { COM_SIG_RX_CENTRALCOMMAND1_CENTRALLOCKCOMMAND,       COM_SIG_TX_STATUSBODYDATA1_BD1_CENTRALLOCKCOMMAND },
        { COM_SIG_RX_CENTRALCOMMAND1_TURNSIGNALCOMMAND,        COM_SIG_TX_STATUSBODYDATA1_BD1_TURNSIGNALCOMMAND },
        { COM_SIG_RX_CENTRALCOMMAND1_RLSCOMMAND,               COM_SIG_TX_STATUSBODYDATA1_BD1_RLSCOMMAND },
        { COM_SIG_RX_CENTRALCOMMAND1_LIGTHSENSOR,              COM_SIG_TX_STATUSBODYDATA1_BD1_LIGTHSENSOR },
        { COM_SIG_RX_CENTRALCOMMAND1_IGNITION,                 COM_SIG_TX_STATUSBODYDATA1_BD1_IGNITION },
        { COM_SIG_RX_CENTRALCOMMAND1_HIGHBEAMCOMMAND,          COM_SIG_TX_STATUSBODYDATA1_BD1_HIGHBEAMCOMMAND },
        { COM_SIG_RX_CENTRALCOMMAND1_GEARBOX,                  COM_SIG_TX_STATUSBODYDATA1_BD1_GEARBOX },
        { COM_SIG_RX_CENTRALCOMMAND1_FOGLIGHTSCOMMAND,         COM_SIG_TX_STATUSBODYDATA1_BD1_FOGLIGHTSCOMMAND },

        { COM_SIG_RX_CENTRALCOMMAND1_RECIRCULATIONCOMMAND,      COM_SIG_TX_COMMANDDISPLAYSTATUS_COMMANDDISPLAYRECIRCULATION },
        { COM_SIG_RX_CENTRALCOMMAND1_CLIMATEAUTOCOMMAND,       COM_SIG_TX_COMMANDDISPLAYSTATUS_COMMANDDISPLAYCLIMATEAUTO },
        { COM_SIG_RX_CENTRALCOMMAND1_CLIMATETEMPERATURECOMMAND, COM_SIG_TX_COMMANDDISPLAYSTATUS_COMMANDDISPLAYCLIMATEMP },
        { COM_SIG_RX_CENTRALCOMMAND1_CLIMATEFANCOMMAND,        COM_SIG_TX_COMMANDDISPLAYSTATUS_COMMANDDISPLAYCLIMAFAN },

        { COM_SIG_RX_MILEAGE_MILEAGETRIP,                      COM_SIG_TX_CANFD_INFOTAINMENTDATA1_IT1_MILEAGETRIP },
        { COM_SIG_RX_MILEAGE_MILEAGETOTAL,                     COM_SIG_TX_CANFD_INFOTAINMENTDATA1_IT1_MILEAGETOTAL },
        { COM_SIG_RX_DMUSTATUS_DISPLAYCAMERASTATUS,            COM_SIG_TX_CANFD_INFOTAINMENTDATA1_IT1_DISPLAYCAMERASTATUS },
        { COM_SIG_RX_DMU_ALIVE_ALIVEINDICATION,                COM_SIG_TX_CANFD_INFOTAINMENTDATA1_IT1_ALIVEINDICATION },

        { COM_SIG_RX_CENTRALLOCKDATA_VIBRATIONSENSORSTATUS,    COM_SIG_TX_CANFD_BODYDATA1_BD1_VIBRATIONSENSORSTATUS },
        { COM_SIG_RX_CENTRALLOCKDATA_CENTRALLOCKSTATUS,        COM_SIG_TX_CANFD_BODYDATA1_BD1_CENTRALLOCKSTATUS },
        { COM_SIG_RX_CENTRALLOCKDATA_CENTRALLOCKBUZZER,        COM_SIG_TX_CANFD_BODYDATA1_BD1_CENTRALLOCKBUZZER },
        { COM_SIG_RX_LIGHTDATA1_REVERSELIGTHSTATUS,            COM_SIG_TX_CANFD_LIGHTDATA1_LD1_REVERSELIGTHSTATUS },
        { COM_SIG_RX_LIGHTDATA1_POSITIONLIGHTSTATUS,           COM_SIG_TX_CANFD_LIGHTDATA1_LD1_POSITIONLIGHTSTATUS },
        { COM_SIG_RX_LIGHTDATA1_LOWBEAMSTATUS,                 COM_SIG_TX_CANFD_LIGHTDATA1_LD1_LOWBEAMSTATUS },
        { COM_SIG_RX_LIGHTDATA1_INTERIORLIGHTSTATUS,           COM_SIG_TX_CANFD_LIGHTDATA1_LD1_INTERIORLIGHTSTATUS },
        { COM_SIG_RX_LIGHTDATA1_HIGHBEAMSTATUS,                COM_SIG_TX_CANFD_LIGHTDATA1_LD1_HIGHBEAMSTATUS },
        { COM_SIG_RX_LIGHTDATA1_FOGLIGHTSSTATUS,               COM_SIG_TX_CANFD_LIGHTDATA1_LD1_FOGLIGHTSSTATUS },
        { COM_SIG_RX_LIGHTDATA1_TURNSIGNALSSTATUS,             COM_SIG_TX_CANFD_LIGHTDATA1_LD1_TURNSIGNALSSTATUS },
        { COM_SIG_RX_LIGHTDATA1_BRAKELIGHTSTATUS,              COM_SIG_TX_CANFD_BODYDATA1_BD1_BRAKELIGHTSTATUS },
        { COM_SIG_RX_STATUSACTUATOR_STATUSWIPERS,              COM_SIG_TX_CANFD_BODYDATA1_BD1_STATUSWIPERS },
        { COM_SIG_RX_STATUSACTUATOR_STATUSDOORS,               COM_SIG_TX_CANFD_BODYDATA1_BD1_STATUSDOORS },
        { COM_SIG_RX_OUTSIDETEMPERATURESTATUS_OUTSIDETEMPERATURE, COM_SIG_TX_CANFD_BODYDATA1_BD1_OUTSIDETEMPERATURE },

        { COM_SIG_RX_CENTRALCOMMAND1_HIGHBEAMCOMMAND,          COM_SIG_TX_CANFD_BODYDATA1_BD1_HIGHBEAMCOMMAND },
        { COM_SIG_RX_CENTRALCOMMAND1_HC05CONNECTIONSTATUS,     COM_SIG_TX_CANFD_BODYDATA1_BD1_HC05CONNECTIONSTATUS },
        { COM_SIG_RX_CENTRALCOMMAND1_GEARBOX,                  COM_SIG_TX_CANFD_BODYDATA1_BD1_GEARBOX },
        { COM_SIG_RX_CENTRALCOMMAND1_RECIRCULATIONCOMMAND,     COM_SIG_TX_CANFD_BODYDATA1_BD1_RECIRCULATIONCOMMAND },
        { COM_SIG_RX_CENTRALCOMMAND1_TURNSIGNALCOMMAND,        COM_SIG_TX_CANFD_LIGHTDATA1_LD1_TURNSIGNALCOMMAND },
        { COM_SIG_RX_CENTRALCOMMAND1_IGNITION,                 COM_SIG_TX_CANFD_BODYDATA1_BD1_IGNITION },
        { COM_SIG_RX_CENTRALCOMMAND1_CLIMATEFANCOMMAND,        COM_SIG_TX_CANFD_BODYDATA1_BD1_CLIMATEFANCOMMAND },
        { COM_SIG_RX_CENTRALCOMMAND1_FOGLIGHTSCOMMAND,         COM_SIG_TX_CANFD_BODYDATA1_BD1_FOGLIGHTSCOMMAND },
        { COM_SIG_RX_CENTRALCOMMAND1_RLSCOMMAND,               COM_SIG_TX_CANFD_BODYDATA1_BD1_RLSCOMMAND },
        { COM_SIG_RX_CENTRALCOMMAND1_CLIMATEAUTOCOMMAND,       COM_SIG_TX_CANFD_BODYDATA1_BD1_CLIMATEAUTOCOMMAND },
        { COM_SIG_RX_CENTRALCOMMAND1_CLIMATETEMPERATURECOMMAND, COM_SIG_TX_CANFD_BODYDATA1_BD1_CLIMATETEMPERATURECOMMAND },
        { COM_SIG_RX_CENTRALCOMMAND1_WIPERSTOCKCOMMAND,        COM_SIG_TX_CANFD_BODYDATA1_BD1_WIPERSTOCKCOMMAND },
        { COM_SIG_RX_CENTRALCOMMAND1_LIGTHSENSOR,              COM_SIG_TX_CANFD_BODYDATA1_BD1_LIGTHSENSOR },
        { COM_SIG_RX_CENTRALCOMMAND1_CENTRALLOCKCOMMAND,       COM_SIG_TX_CANFD_BODYDATA1_BD1_CENTRALLOCKCOMMAND },



        { COM_SIG_RX_PDCSTAT_PDCDISTANCEREAR,                  COM_SIG_TX_CANFD_BODYDATA1_BD1_PDCDISTANCEREAR },
        { COM_SIG_RX_PDCSTAT_PDCDISTANCEFRONT,                 COM_SIG_TX_CANFD_BODYDATA1_BD1_PDCDISTANCEFRONT },
        { COM_SIG_RX_PDCSTAT_PDCBUZZERFRONTREAR,               COM_SIG_TX_CANFD_BODYDATA1_BD1_PDCBUZZERFRONTREAR },

        { COM_SIG_RX_BATTFULLSTAT_TIMETOFULL,                  COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA1_EM1_TIMETOFULL },
        { COM_SIG_RX_CANFD_PDM1_INPUTT30_INPUTT30,             COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA1_EM1_T30VOLTAGE },
        { COM_SIG_RX_BATTSOCSOH_SOH,                           COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA1_EM1_SOH },
        { COM_SIG_RX_BATTSOC_SOCOCV,                           COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA1_EM1_SOCOCV },
        { COM_SIG_RX_BATTSOCSOH_SOCHYBRID,                     COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA1_EM1_SOCHYBRID },
        { COM_SIG_RX_BATTSOC_SOCCOULOMB,                       COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA1_EM1_SOCCOULOMB },
        { COM_SIG_RX_BATTFULLSTAT_RUNTIMEREMAINING,            COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA1_EM1_RUNTIMEREMAINING },
        { COM_SIG_RX_TEMPMEAS_MCUTEMP,                         COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA1_EM1_MCUTEMP },
        { COM_SIG_RX_VOLTAGECURRENT_L1VOLTAGE,                 COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA1_EM1_L1VOLTAGE },
        { COM_SIG_RX_TEMPMEAS_L1TEMP,                          COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA1_EM1_L1TEMP },
        { COM_SIG_RX_VOLTAGECURRENT_L1ISENSE,                  COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA1_EM1_L1ISENSE },
        { COM_SIG_RX_BATTCAPRES_INTRESISTANCE,                 COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA1_EM1_INTRESISTANCE },
        { COM_SIG_RX_L1_I2T_COUNTER_I2TCOUNTER,                COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA1_EM1_I2TCOUNTER },
        { COM_SIG_RX_BATTCAPDISCHARGE_DISCHARGEAH,             COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA1_EM1_DISCHARGEAH },
        { COM_SIG_RX_BATTCAPDISCHARGE_CHARGEAH,                COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA1_EM1_CHARGEAH },
        { COM_SIG_RX_BATTCURRENT_AVGDISCHARGECURRENT,          COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA1_EM1_AVGDISCHARGECURRENT },
        { COM_SIG_RX_BATTCURRENT_AVGCHARGECURRENT,             COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA1_EM1_AVGCHARGECURRENT },

        { COM_SIG_RX_BATTDIAGNOSIS_WEAKBATTERY,                COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA2_EM1_WEAKBATTERY },
        { COM_SIG_RX_BATTDIAGNOSIS_VALIDOCVCALIBRATION,        COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA2_EM1_VALIDOCVCALIBRATION },
        { COM_SIG_RX_LOADSTATUS_LOADSTATUS,                    COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA2_EM1_LOADSTATUS },
        { COM_SIG_RX_BATTDIAGNOSIS_DISCHARGING,                COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA2_EM1_DISCHARGING },
        { COM_SIG_RX_BATTDIAGNOSIS_DEEPDISCHARGE,              COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA2_EM1_DEEPDISCHARGE },
        { COM_SIG_RX_BATTDIAGNOSIS_CRANKINGEVENT,              COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA2_EM1_CRANKINGEVENT },
        { COM_SIG_RX_BATTDIAGNOSIS_CONFINDENCE,                COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA2_EM1_CONFINDENCE },
        { COM_SIG_RX_BATTDIAGNOSIS_CHARGING,                   COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA2_EM1_CHARGING },
        { COM_SIG_RX_BATTCAPRES_CAPACITYAH,                    COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA2_EM1_CAPACITYAH },
        { COM_SIG_RX_BATTDIAGNOSIS_BATTREST,                   COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA2_EM1_BATTREST },

        { COM_SIG_RX_LIN_HVDCDC_STATUS_HVDCDC_RESPONSEERROR,   COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA3_HVDCDC_RESPONSEERROR },
        { COM_SIG_RX_LIN_HVDCDC_STATUS_HVDCDC_LV_VOLTAGE,      COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA3_HVDCDC_LV_VOLTAGE },
        { COM_SIG_RX_LIN_HVDCDC_STATUS_HVDCDC_LV_CURRENT,      COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA3_HVDCDC_LV_CURRENT },
        { COM_SIG_RX_LIN_HVDCDC_STATUS_HVDCDC_HV_VOLTAGE,      COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA3_HVDCDC_HV_VOLTAGE },
        { COM_SIG_RX_LIN_HVDCDC_STATUS_HVDCDC_HV_CURRENT,      COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA3_HVDCDC_HV_CURRENT }
};

static const GatewaySwc_PduRangeType GatewaySwc_RxMessageDiagRanges[] =
{
        { COM_RX_PDU_CENTRALLOCKDATA,        COM_RX_PDU_DMUSTATUS,                       GATEWAYSWC_BUS_CAN },
        { COM_RX_PDU_BATTFULLSTAT,           COM_RX_PDU_BATTFULLSTAT,                    GATEWAYSWC_BUS_CAN },
        { COM_RX_PDU_PDCSTAT,                COM_RX_PDU_DMU_ALIVE,                       GATEWAYSWC_BUS_CAN },
        { COM_RX_PDU_VOLTAGECURRENT,         COM_RX_PDU_L1_I2T_COUNTER,                  GATEWAYSWC_BUS_CAN },
        { COM_RX_PDU_BATTSOCSOH,             COM_RX_PDU_BATTCAPRES,                      GATEWAYSWC_BUS_CAN },
        { COM_RX_PDU_CANFD_PDM1_LOADSTATUS,  COM_RX_PDU_CANFD_PDM1_LOADSTATUS,            GATEWAYSWC_BUS_CANFD },
        { COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_1, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_5, GATEWAYSWC_BUS_CANFD },
        { COM_RX_PDU_CANFD_PDM1_INPUTT30,    COM_RX_PDU_CANFD_PDM1_INPUTT30,              GATEWAYSWC_BUS_CANFD },
        { COM_RX_PDU_LIN_HVDCDC_STATUS,      COM_RX_PDU_LIN_HVDCDC_STATUS,                GATEWAYSWC_BUS_LIN },
        { GATEWAYSWC_ETH_RX_PDU_COMMAND_SIGNAL, GATEWAYSWC_ETH_RX_PDU_COMMAND_BLOCK,       GATEWAYSWC_BUS_ETH }
};

static const GatewaySwc_SignalRangeType GatewaySwc_EthSignalRanges[] =
{
        { GATEWAYSWC_CAN_RX_FIRST_0, GATEWAYSWC_CAN_RX_LAST_0, GATEWAYSWC_BUS_CAN },
        { GATEWAYSWC_CAN_RX_FIRST_1, GATEWAYSWC_CAN_RX_LAST_1, GATEWAYSWC_BUS_CAN },
        { GATEWAYSWC_CAN_RX_FIRST_2, GATEWAYSWC_CAN_RX_LAST_2, GATEWAYSWC_BUS_CAN },
        { GATEWAYSWC_CAN_RX_FIRST_3, GATEWAYSWC_CAN_RX_LAST_3, GATEWAYSWC_BUS_CAN },
        { GATEWAYSWC_CANFD_LOAD_RX_FIRST, GATEWAYSWC_CANFD_LOAD_RX_LAST, GATEWAYSWC_BUS_CANFD },
        { GATEWAYSWC_CANFD_INPUTT30_RX_FIRST, GATEWAYSWC_CANFD_INPUTT30_RX_LAST, GATEWAYSWC_BUS_CANFD },
        { GATEWAYSWC_CANFD_CURRENT_RX_FIRST, GATEWAYSWC_CANFD_CURRENT_RX_LAST, GATEWAYSWC_BUS_CANFD },
        { GATEWAYSWC_LIN_RX_FIRST,   GATEWAYSWC_LIN_RX_LAST,   GATEWAYSWC_BUS_LIN }
};

static void GatewaySwc_LoadDefaultCommands(void);
static void GatewaySwc_RouteSignals(void);
static void GatewaySwc_GenerateOwnedOutputs(void);
static void GatewaySwc_GenerateSdatOutputs(void);
static Std_ReturnType GatewaySwc_GetSdatTime(GatewaySwc_SdatTimeType *time);
static uint32 GatewaySwc_MapSdatTimeSource(uint8 timeSource);
static void GatewaySwc_SendCanSdat(const GatewaySwc_SdatTimeType *time);
static void GatewaySwc_SendCanFdSdat(const GatewaySwc_SdatTimeType *time);
static void GatewaySwc_SendLinSdat(const GatewaySwc_SdatTimeType *time);
static void GatewaySwc_GenerateCanOutputs(void);
static void GatewaySwc_GenerateCanFdOutputs(void);
static void GatewaySwc_GenerateLinOutputs(void);
static void GatewaySwc_PublishEthernetSummary(void);
static void GatewaySwc_PublishEthernetVehicleState(void);
static void GatewaySwc_PublishAiModelResult(void);
static void GatewaySwc_PublishCpuPerf(void);
static void GatewaySwc_McuStatusInit(void);
static void GatewaySwc_McuStatusMainFunction(uint64 nowNs);
static void GatewaySwc_McuStatusOpenSocket(void);
static void GatewaySwc_McuStatusCloseSocket(void);
static void GatewaySwc_McuStatusBuildPacket(uint8 *packet);
static void GatewaySwc_McuStatusStorePacketForWriteAll(const uint8 *packet);
static void GatewaySwc_McuStatusSendPacket(void);
static void GatewaySwc_McuStatusUpdateNextTxDeadline(uint64 nowNs);
static uint16 GatewaySwc_McuStatusScaleMilliVolt(float32 voltage);
static sint16 GatewaySwc_McuStatusScaleCentiDeg(float32 temperature);
static void GatewaySwc_PublishRange(GatewaySwc_BusType bus,
        Com_SignalIdType firstSignalId,
        Com_SignalIdType lastSignalId);
static void GatewaySwc_ResetRxDiagnostics(void);
static void GatewaySwc_UpdateRxDiagnostics(void);
static void GatewaySwc_UpdateComModeFromBusActivity(void);
static void GatewaySwc_RequestFullCom(void);
static void GatewaySwc_RequestNoCom(void);
static void GatewaySwc_ReportRxMessageTimeoutToDem(uint16 index, uint8 status);
static Std_ReturnType GatewaySwc_GetPduDiagConfig(uint16 index, PduIdType *pduId, GatewaySwc_BusType *bus);
static Std_ReturnType GatewaySwc_GetSignalDiagConfig(uint16 index, Com_SignalIdType *signalId, GatewaySwc_BusType *bus);
static uint8 GatewaySwc_IsNmActiveForBus(GatewaySwc_BusType bus);
static uint8 GatewaySwc_IsEthComActive(void);
static boolean GatewaySwc_IsRxDiagSuppressedForBus(GatewaySwc_BusType bus);
static void GatewaySwc_ProcessCore0Async(void);
static void GatewaySwc_ProcessEthTxResults(void);
static void GatewaySwc_ProcessEthRxQueue(void);
static void GatewaySwc_ProcessEthTxQueueCore2(void);
static void GatewaySwc_HandleEthRxMessage(uint8 soConId,
        const TcpIp_SockAddrType *remoteAddr,
        const uint8 *data,
        uint16 len);
static uint8 GatewaySwc_QueueEthTx(uint8 kind,
        SoAd_SoConIdType soConId,
        const TcpIp_SockAddrType *remoteAddr,
        const uint8 *data,
        uint16 len);
static boolean GatewaySwc_GetEthTxCodingPduId(uint8 kind, PduIdType *pduId);
static boolean GatewaySwc_IsEthTxKindEnabled(uint8 kind);
static uint8 GatewaySwc_PopEthTx(GatewaySwc_EthTxJobType *job);
static uint8 GatewaySwc_QueueEthTxResult(uint8 kind,
        uint8 openResult,
        uint16 len,
        sint32 result);
static uint8 GatewaySwc_PopEthTxResult(GatewaySwc_EthTxResultType *result);
static uint8 GatewaySwc_QueueEthRx(uint8 soConId,
        const TcpIp_SockAddrType *remoteAddr,
        const uint8 *data,
        uint16 len);
static uint8 GatewaySwc_PopEthRx(GatewaySwc_EthRxJobType *job);
static void GatewaySwc_ApplyEthTxResult(const GatewaySwc_EthTxResultType *result);
static SoAd_ReturnType GatewaySwc_Core2TransmitSoAd(const GatewaySwc_EthTxJobType *job,
        uint8 *openResult);
static sint32 GatewaySwc_Core2TransmitMcuStatus(const GatewaySwc_EthTxJobType *job);
static uint8 GatewaySwc_EnterCrossCoreCritical(void);
static void GatewaySwc_ExitCrossCoreCritical(void);
static void GatewaySwc_ResetEthFrame(uint16 *len, GatewaySwc_BusType bus);
static void GatewaySwc_FlushEthFrame(uint16 *len);
#if GATEWAYSWC_DEBUG_INSTRUMENTATION
static void GatewaySwc_UpdateDtcDebugQueueState(void);
#else
#define GatewaySwc_UpdateDtcDebugQueueState() ((void)0)
#endif
static void GatewaySwc_FlushDtcTransitionQueue(void);
static uint8 GatewaySwc_EnterDtcQueueCritical(void);
static void GatewaySwc_ExitDtcQueueCritical(void);
static uint8 GatewaySwc_PopDtcTransition(GatewaySwc_DtcTransitionType *transition);
static void GatewaySwc_PublishDtcTransition(Dem_DTCType dtc, Dem_UdsStatusByteType status);
static void GatewaySwc_AppendU8(uint16 *len, uint8 value);
static void GatewaySwc_AppendU16(uint16 *len, uint16 value);
static void GatewaySwc_AppendU32(uint16 *len, uint32 value);
static void GatewaySwc_AppendF32(uint16 *len, float32 value);
static void GatewaySwc_StoreU16(uint8 *buffer, uint16 offset, uint16 value);
static void GatewaySwc_StoreS16(uint8 *buffer, uint16 offset, sint16 value);
static void GatewaySwc_StoreU32(uint8 *buffer, uint16 offset, uint32 value);
static void GatewaySwc_StoreU64(uint8 *buffer, uint16 offset, uint64 value);
static Std_ReturnType GatewaySwc_SendU32(Com_SignalIdType signalId, uint32 value);
static Std_ReturnType GatewaySwc_ReceiveU32(Com_SignalIdType signalId, uint32 *value);
#if GATEWAYSWC_DEBUG_INSTRUMENTATION
static void GatewaySwc_CaptureEthRxMessage(uint8 soConId,
        const TcpIp_SockAddrType *remoteAddr,
        const uint8 *data,
        uint16 len);
#else
#define GatewaySwc_CaptureEthRxMessage(soConId, remoteAddr, data, len) ((void)0)
#endif

void GatewaySwc_Init(void)
{
    uint8 ethRxIndex;

    GatewaySwc_Initialized = 0u;
    GatewaySwc_Status.mainCycles = 0u;
    GatewaySwc_Status.routedSignals = 0u;
    GatewaySwc_Status.generatedSignals = 0u;
    GatewaySwc_Status.sendSignalOk = 0u;
    GatewaySwc_Status.sendSignalFailed = 0u;
    GatewaySwc_Status.receiveSignalFailed = 0u;
    GatewaySwc_Status.ethFramesSent = 0u;
    GatewaySwc_Status.ethFramesFailed = 0u;
    GatewaySwc_Status.ethSignalsPublished = 0u;
    GatewaySwc_Status.ethLastOpenResult = 0u;
    GatewaySwc_Status.ethLastSoAdResult = (uint8)SOAD_NOT_OK;
    GatewaySwc_Status.ethLastTransmitOk = 0u;
    GatewaySwc_Status.ethLastPayloadLength = 0u;
    GatewaySwc_Status.configuredRoutes = (uint16)(sizeof(GatewaySwc_RouteMap) / sizeof(GatewaySwc_RouteMap[0]));
    GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_DebugRouteIndex, 0xFFFFu);
    GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_DebugRouteCount, GatewaySwc_Status.configuredRoutes);
    GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_DebugRouteRxSignalId, 0u);
    GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_DebugRouteTxSignalId, 0u);
    GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_DebugRoutePhase, GATEWAYSWC_ROUTE_PHASE_IDLE);
    GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_DebugRouteReceiveResult, E_NOT_OK);
    GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_DebugRouteSendResult, E_NOT_OK);
    GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_DebugRouteValue, 0u);
    GatewaySwc_Status.rxDiagConfiguredMessages = (uint16)GATEWAYSWC_RX_MESSAGE_DIAG_COUNT;
    GatewaySwc_Status.rxDiagConfiguredSignals = (uint16)GATEWAYSWC_RX_SIGNAL_DIAG_COUNT;
    GatewaySwc_Status.rxDiagTimedOutMessages = 0u;
    GatewaySwc_Status.rxDiagInvalidSignals = 0u;
    GatewaySwc_Status.rxDiagTimeoutEvents = 0u;
    GatewaySwc_Status.rxDiagInvalidEvents = 0u;
    GatewaySwc_Status.rxDiagLastTimeoutPduId = 0u;
    GatewaySwc_Status.rxDiagLastInvalidSignalId = 0u;
    GatewaySwc_Status.rxDiagLastInvalidValue = 0u;

    GatewaySwc_RouteTimerMs = 0u;
    GatewaySwc_OutputTimerMs = 0u;
    GatewaySwc_AiModelPublishTimerMs = 0u;
    GatewaySwc_CpuPerfPublishTimerMs = 0u;
    GatewaySwc_NextEthPublishTimeNs = 0ull;
    GatewaySwc_McuStatusInit();
    GatewaySwc_EthTxHead = 0u;
    GatewaySwc_EthTxTail = 0u;
    GatewaySwc_EthTxResultHead = 0u;
    GatewaySwc_EthTxResultTail = 0u;
    GatewaySwc_EthRxHead = 0u;
    GatewaySwc_EthRxTail = 0u;
    GatewaySwc_McuStatusTxPending = 0u;
    GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_DebugEthTxQueueDropped, 0u);
    GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_DebugEthTxResultQueueDropped, 0u);
    GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_DebugEthRxQueueDropped, 0u);
    GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_DebugCrossCoreLockTimeout, 0u);
    GatewaySwc_DiagTimerMs = 0u;
    for (ethRxIndex = 0u; ethRxIndex < GATEWAYSWC_ETH_RX_MESSAGE_COUNT; ethRxIndex++)
    {
        GatewaySwc_EthRxAgeMs[ethRxIndex] = 0u;
    }
    GatewaySwc_LoadRequestAliveCounter = 0u;
    GatewaySwc_DtcTransitionHead = 0u;
    GatewaySwc_DtcTransitionTail = 0u;
    GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_DebugDtcDropped, 0u);
    GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_DebugDtcFlushed, 0u);
    GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_DebugDtcLastDtc, 0u);
    GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_DebugDtcLastStatus, 0u);
    GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_DebugDtcLastOpenResult, 0u);
    GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_DebugDtcLastTxResult, SOAD_NOT_OK);
    GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_DebugDtcQueueLockTimeout, 0u);
    GatewaySwc_UpdateDtcDebugQueueState();
    GatewaySwc_ComModeRequestState = GATEWAYSWC_COMM_UNKNOWN;
    GatewaySwc_ComFullRequested = 0u;
    GatewaySwc_ResetRxDiagnostics();

    GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_EthRxCaptureEnable, GATEWAYSWC_ETH_RX_CAPTURE_DEFAULT_ENABLE);
    GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_EthRxCaptureFilterMode, GATEWAYSWC_ETH_RX_CAPTURE_FILTER_OFF);
    GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_EthRxCaptureFilterSoConId, GATEWAYSWC_ETH_SOCON_ID);
    GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_EthRxCaptureMaxLen, GATEWAYSWC_ETH_RX_CAPTURE_MAX_PAYLOAD);
    GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_EthRxCaptureWriteIndex, 0u);
    GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_EthRxCaptureLastIndex, 0u);
    GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_EthRxCaptureCounter, 0u);
    GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_EthRxCaptureDroppedCounter, 0u);
    GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_EthRxCaptureTruncatedCounter, 0u);

    GatewaySwc_LoadDefaultCommands();

    (void)Com_IpduGroupStart(COM_IPDU_GROUP_0);
    (void)Com_IpduGroupStart(COM_IPDU_GROUP_1);

    GatewaySwc_GenerateOwnedOutputs();
    GatewaySwc_RouteSignals();
    __dsync();
    GatewaySwc_Initialized = 1u;
}

void GatewaySwc_MainFunction(void)
{
    CpuPerf_ContextType cpuPerfCtx;
    uint64 nowNs;

    if (GatewaySwc_Initialized == 0u)
    {
        return;
    }

    CpuPerf_Start(CPUPERF_ID_GATEWAY_MAIN_C0, &cpuPerfCtx);

    GatewaySwc_ProcessCore0Async();

    GatewaySwc_Status.mainCycles++;

    GatewaySwc_UpdateComModeFromBusActivity();

    nowNs = TimeBase_PlatformGetCounterNs();
    if (GatewaySwc_NormalCommunicationTxEnabled != FALSE)
    {
        GatewaySwc_McuStatusMainFunction(nowNs);
    }

    if (GatewaySwc_NormalCommunicationTxEnabled == FALSE)
    {
        GatewaySwc_NextEthPublishTimeNs = 0ull;
        GatewaySwc_AiModelPublishTimerMs = 0u;
        GatewaySwc_CpuPerfPublishTimerMs = 0u;
    }
    else if (GatewaySwc_NextEthPublishTimeNs == 0ull)
    {
        GatewaySwc_NextEthPublishTimeNs = nowNs + GATEWAYSWC_ETH_PERIOD_NS;
    }
    else if (nowNs >= GatewaySwc_NextEthPublishTimeNs)
    {
        GatewaySwc_PublishEthernetSummary();
        GatewaySwc_NextEthPublishTimeNs = nowNs + GATEWAYSWC_ETH_PERIOD_NS;
    }

    if (GatewaySwc_NormalCommunicationTxEnabled != FALSE)
    {
        GatewaySwc_FlushDtcTransitionQueue();
    }

    GatewaySwc_RouteTimerMs += GATEWAYSWC_MAIN_PERIOD_MS;
    GatewaySwc_OutputTimerMs += GATEWAYSWC_MAIN_PERIOD_MS;
    GatewaySwc_DiagTimerMs += GATEWAYSWC_MAIN_PERIOD_MS;

    if (GatewaySwc_NormalCommunicationTxEnabled != FALSE)
    {
        GatewaySwc_AiModelPublishTimerMs += GATEWAYSWC_MAIN_PERIOD_MS;
        GatewaySwc_CpuPerfPublishTimerMs += GATEWAYSWC_MAIN_PERIOD_MS;

        if (GatewaySwc_AiModelPublishTimerMs >= GATEWAYSWC_AI_MODEL_PUBLISH_PERIOD_MS)
        {
            GatewaySwc_AiModelPublishTimerMs = 0u;
            GatewaySwc_PublishAiModelResult();
        }

        if (GatewaySwc_CpuPerfPublishTimerMs >= GATEWAYSWC_CPU_PERF_PUBLISH_PERIOD_MS)
        {
            GatewaySwc_CpuPerfPublishTimerMs = 0u;
            GatewaySwc_PublishCpuPerf();
        }
    }

    if ((GatewaySwc_RouteTimerMs >= GATEWAYSWC_ROUTE_PERIOD_MS) &&
            (GatewaySwc_NormalCommunicationRxEnabled != FALSE) &&
            (GatewaySwc_NormalCommunicationTxEnabled != FALSE))
    {
        GatewaySwc_RouteTimerMs = 0u;
        GatewaySwc_RouteSignals();
    }

    if ((GatewaySwc_OutputTimerMs >= GATEWAYSWC_OUTPUT_PERIOD_MS) &&
            (GatewaySwc_NormalCommunicationTxEnabled != FALSE))
    {
        GatewaySwc_OutputTimerMs = 0u;
        GatewaySwc_GenerateOwnedOutputs();
    }

    if (GatewaySwc_DiagTimerMs >= GATEWAYSWC_DIAG_PERIOD_MS)
    {
        GatewaySwc_DiagTimerMs = 0u;
        GatewaySwc_UpdateRxDiagnostics();
    }

    GatewaySwc_MainFunction_Counter++;
    CpuPerf_Stop(CPUPERF_ID_GATEWAY_MAIN_C0, &cpuPerfCtx);
}

void GatewaySwc_EthernetMainFunction(void)
{
    CpuPerf_ContextType cpuPerfCtx;

    if (GatewaySwc_Initialized == 0u)
    {
        return;
    }

    CpuPerf_Start(CPUPERF_ID_GATEWAY_ETH_MAIN_C2, &cpuPerfCtx);
    GatewaySwc_ProcessEthTxQueueCore2();
    CpuPerf_Stop(CPUPERF_ID_GATEWAY_ETH_MAIN_C2, &cpuPerfCtx);
}

Std_ReturnType GatewaySwc_CaptureRxDiagSnapshotData(Dem_EventIdType eventId, uint8 *buffer, uint16 *length)
{
    if ((buffer == NULL_PTR) ||
        (length == NULL_PTR) ||
        (*length < DEM_DTC_TIMESTAMP_DATA_SIZE))
    {
        return E_NOT_OK;
    }

    if ((eventId < DEM_EVENT_ID_GATEWAY_RX_MESSAGE_TIMEOUT_FIRST) ||
        (eventId > DEM_EVENT_ID_GATEWAY_RX_MESSAGE_TIMEOUT_LAST))
    {
        return E_NOT_OK;
    }

    return Dem_Cfg_CaptureTimestampTemperatureData(buffer, length, DEM_SNAPSHOT_KIND_COMMON);
}

void GatewaySwc_EthRxIndication(uint8 soConId,
        const TcpIp_SockAddrType *remoteAddr,
        const uint8 *data,
        uint16 len)
{
    EthStartupTiming_CaptureFirstRx(ETHSTARTUPTIMING_RX_IPV4_UDP);
    (void)GatewaySwc_QueueEthRx(soConId, remoteAddr, data, len);
}

static void GatewaySwc_HandleEthRxMessage(uint8 soConId,
        const TcpIp_SockAddrType *remoteAddr,
        const uint8 *data,
        uint16 len)
{
    uint16 signalId;
    uint32 value;
    GatewaySwc_CommandType cmd;

    GatewaySwc_CaptureEthRxMessage(soConId, remoteAddr, data, len);

    if ((soConId != GATEWAYSWC_ETH_SOCON_ID) || (data == NULL_PTR) || (len < 4u))
    {
        return;
    }

    if (GatewaySwc_NormalCommunicationRxEnabled == FALSE)
    {
        return;
    }

    if ((data[0] != GATEWAYSWC_MAGIC0) ||
            (data[1] != GATEWAYSWC_MAGIC1) ||
            (data[2] != GATEWAYSWC_MAGIC2))
    {
        return;
    }

    if ((data[3] == GATEWAYSWC_FRAME_COMMAND_SIGNAL) && (len >= 10u))
    {
        GatewaySwc_EthRxAgeMs[0u] = 0u;
        signalId = (uint16)(((uint16)data[4] << 8u) | (uint16)data[5]);

        value = ((uint32)data[6] << 24u) |
                ((uint32)data[7] << 16u) |
                ((uint32)data[8] << 8u) |
                ((uint32)data[9]);

        (void)GatewaySwc_SendU32((Com_SignalIdType)signalId, value);
    }
    else if ((data[3] == GATEWAYSWC_FRAME_COMMAND_BLOCK) && (len >= 32u))
    {
        uint16 idx = 4u;
        uint8 p;
        uint8 l;

        GatewaySwc_EthRxAgeMs[1u] = 0u;
        cmd = GatewaySwc_Command;

        for (p = 0u; p < (uint8)(sizeof(cmd.pdmCommandLoad) / sizeof(cmd.pdmCommandLoad[0])); p++)
        {
            for (l = 0u; l < GATEWAYSWC_PDM_LOADS_PER_PDM; l++)
            {
                cmd.pdmCommandLoad[p][l] = ((uint32)data[idx] << 24u) |
                        ((uint32)data[idx + 1u] << 16u) |
                        ((uint32)data[idx + 2u] << 8u) |
                        ((uint32)data[idx + 3u]);
                idx += 4u;
            }
        }

        cmd.linHvDcdcEnable = ((uint32)data[idx] << 24u) | ((uint32)data[idx + 1u] << 16u) | ((uint32)data[idx + 2u] << 8u) | ((uint32)data[idx + 3u]); idx += 4u;
        cmd.linHvDcdcTargetVoltage = ((uint32)data[idx] << 24u) | ((uint32)data[idx + 1u] << 16u) | ((uint32)data[idx + 2u] << 8u) | ((uint32)data[idx + 3u]); idx += 4u;
        cmd.vehicleStatus = ((uint32)data[idx] << 24u) | ((uint32)data[idx + 1u] << 16u) | ((uint32)data[idx + 2u] << 8u) | ((uint32)data[idx + 3u]); idx += 4u;
        cmd.nmPn1 = ((uint32)data[idx] << 24u) | ((uint32)data[idx + 1u] << 16u) | ((uint32)data[idx + 2u] << 8u) | ((uint32)data[idx + 3u]);

        GatewaySwc_Command = cmd;
        GatewaySwc_GenerateOwnedOutputs();
    }
    else
    {
        /* Unknown command frame. */
    }
}


#if GATEWAYSWC_DEBUG_INSTRUMENTATION
static void GatewaySwc_CaptureEthRxMessage(uint8 soConId,
        const TcpIp_SockAddrType *remoteAddr,
        const uint8 *data,
        uint16 len)
{
    uint8 slot;
    uint16 i;
    uint16 copyLen;
    uint16 configuredMaxLen;

    if (GatewaySwc_EthRxCaptureEnable == 0u)
    {
        return;
    }

    if (data == NULL_PTR)
    {
        GATEWAYSWC_DEBUG_INC(GatewaySwc_EthRxCaptureDroppedCounter);
        return;
    }

    if ((GatewaySwc_EthRxCaptureFilterMode == GATEWAYSWC_ETH_RX_CAPTURE_FILTER_SOCON) &&
            (soConId != GatewaySwc_EthRxCaptureFilterSoConId))
    {
        return;
    }

    configuredMaxLen = GatewaySwc_EthRxCaptureMaxLen;

    if (configuredMaxLen > GATEWAYSWC_ETH_RX_CAPTURE_MAX_PAYLOAD)
    {
        configuredMaxLen = GATEWAYSWC_ETH_RX_CAPTURE_MAX_PAYLOAD;
    }

    if (configuredMaxLen == 0u)
    {
        GATEWAYSWC_DEBUG_INC(GatewaySwc_EthRxCaptureDroppedCounter);
        return;
    }

    copyLen = len;

    if (copyLen > configuredMaxLen)
    {
        copyLen = configuredMaxLen;
        GATEWAYSWC_DEBUG_INC(GatewaySwc_EthRxCaptureTruncatedCounter);
    }

    slot = GatewaySwc_EthRxCaptureWriteIndex;

    if (slot >= GATEWAYSWC_ETH_RX_CAPTURE_SLOT_COUNT)
    {
        slot = 0u;
    }

    for (i = 0u; i < copyLen; i++)
    {
        GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_EthRxCaptureData[slot][i], data[i]);
    }

    for (i = copyLen; i < GATEWAYSWC_ETH_RX_CAPTURE_MAX_PAYLOAD; i++)
    {
        GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_EthRxCaptureData[slot][i], 0u);
    }

    GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_EthRxCaptureSoConId[slot], soConId);
    GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_EthRxCaptureLen[slot], len);
    GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_EthRxCaptureCopiedLen[slot], copyLen);
    GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_EthRxCaptureMainCycle[slot], GatewaySwc_Status.mainCycles);
    GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_EthRxCaptureRemoteAddrPtr[slot], (uint32)remoteAddr);
    GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_EthRxCaptureLastIndex, slot);
    GATEWAYSWC_DEBUG_INC(GatewaySwc_EthRxCaptureCounter);

    slot++;

    if (slot >= GATEWAYSWC_ETH_RX_CAPTURE_SLOT_COUNT)
    {
        slot = 0u;
    }

    GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_EthRxCaptureWriteIndex, slot);
}
#endif


static void GatewaySwc_LoadDefaultCommands(void)
{
    uint8 p;
    uint8 l;

    for (p = 0u; p < (uint8)(sizeof(GatewaySwc_Command.pdmCommandLoad) / sizeof(GatewaySwc_Command.pdmCommandLoad[0])); p++)
    {
        for (l = 0u; l < GATEWAYSWC_PDM_LOADS_PER_PDM; l++)
        {
            GatewaySwc_Command.pdmCommandLoad[p][l] = 0u;
        }
    }

    GatewaySwc_Command.linHvDcdcEnable = 1u;
    GatewaySwc_Command.linHvDcdcTargetVoltage = 48000u;

    GatewaySwc_Command.vehicleStatus = 6u;
    GatewaySwc_Command.nmPn1 = 0xFFu;
}

static void GatewaySwc_RouteSignals(void)
{
    uint16 i;
    uint32 value;
    Std_ReturnType receiveResult;
    Std_ReturnType sendResult;
    Com_SignalIdType rxSignalId;
    Com_SignalIdType txSignalId;

    GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_DebugRouteCount, (uint16)(sizeof(GatewaySwc_RouteMap) / sizeof(GatewaySwc_RouteMap[0])));
    for (i = 0u; i < (uint16)(sizeof(GatewaySwc_RouteMap) / sizeof(GatewaySwc_RouteMap[0])); i++)
    {
        rxSignalId = GatewaySwc_RouteMap[i].rxSignalId;
        txSignalId = GatewaySwc_RouteMap[i].txSignalId;

        GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_DebugRouteIndex, i);
        GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_DebugRouteRxSignalId, rxSignalId);
        GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_DebugRouteTxSignalId, txSignalId);
        GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_DebugRouteReceiveResult, E_NOT_OK);
        GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_DebugRouteSendResult, E_NOT_OK);
        GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_DebugRoutePhase, GATEWAYSWC_ROUTE_PHASE_RECEIVE);

        receiveResult = GatewaySwc_ReceiveU32(rxSignalId, &value);
        GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_DebugRouteReceiveResult, (uint8)receiveResult);
        if (receiveResult == E_OK)
        {
            GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_DebugRouteValue, value);
            GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_DebugRoutePhase, GATEWAYSWC_ROUTE_PHASE_SEND);

            sendResult = GatewaySwc_SendU32(txSignalId, value);
            GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_DebugRouteSendResult, (uint8)sendResult);
            GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_DebugRoutePhase, GATEWAYSWC_ROUTE_PHASE_SENT);

            if (sendResult == E_OK)
            {
                GatewaySwc_Status.routedSignals++;
            }
        }
        else
        {
            GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_DebugRoutePhase, GATEWAYSWC_ROUTE_PHASE_RECEIVED);
        }
    }

    GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_DebugRoutePhase, GATEWAYSWC_ROUTE_PHASE_IDLE);
}

static void GatewaySwc_GenerateOwnedOutputs(void)
{
    GatewaySwc_GenerateCanOutputs();
    GatewaySwc_GenerateCanFdOutputs();
    GatewaySwc_GenerateSdatOutputs();
    GatewaySwc_GenerateLinOutputs();
}

static void GatewaySwc_GenerateSdatOutputs(void)
{
    GatewaySwc_SdatTimeType time;

    if (GatewaySwc_GetSdatTime(&time) == E_OK)
    {
        GatewaySwc_SendCanSdat(&time);
        GatewaySwc_SendCanFdSdat(&time);
        GatewaySwc_SendLinSdat(&time);
    }
}

static Std_ReturnType GatewaySwc_GetSdatTime(GatewaySwc_SdatTimeType *time)
{
    TimeBase_TimestampSnapshotType snapshot;
    TimeBase_DateTimeType dateTime;
    uint32 yearRaw;
    uint32 millisecondRaw;

    if (time == NULL_PTR)
    {
        return E_NOT_OK;
    }

    TimeBase_GetTimestampSnapshot(&snapshot);
    time->utcValid = (snapshot.utc_valid != FALSE) ? 1u : 0u;
    time->timeSource = GatewaySwc_MapSdatTimeSource(snapshot.time_source);
    time->defaultTime = (snapshot.time_source == (uint8)TIMEBASE_SOURCE_DEFAULT_COMPILETIME) ? 1u : 0u;
    time->nvmRestored = ((snapshot.sync_status & TIMEBASE_SYNC_STATUS_NVM_RESTORED) != 0u) ? 1u : 0u;

    if ((snapshot.utc_valid == FALSE) ||
        (TimeBase_ConvertUtcNsToDateTime(snapshot.utc_time_ns, &dateTime) != E_OK))
    {
        time->year = 0u;
        time->month = 0u;
        time->day = 0u;
        time->hour = 0u;
        time->minute = 0u;
        time->second = 0u;
        time->millisecond = 0u;
        time->utcValid = 0u;
        time->timeSource = GATEWAYSWC_SDAT_SOURCE_INVALID;
        time->defaultTime = 0u;
        time->nvmRestored = 0u;
        return E_OK;
    }

    if (dateTime.year <= (uint16)GATEWAYSWC_SDAT_YEAR_BASE)
    {
        yearRaw = 0u;
    }
    else
    {
        yearRaw = (uint32)dateTime.year - GATEWAYSWC_SDAT_YEAR_BASE;
        if (yearRaw > GATEWAYSWC_SDAT_YEAR_MAX_RAW)
        {
            yearRaw = GATEWAYSWC_SDAT_YEAR_MAX_RAW;
        }
    }

    millisecondRaw = ((uint32)dateTime.millisecond + (GATEWAYSWC_SDAT_MS_RESOLUTION / 2u)) /
            GATEWAYSWC_SDAT_MS_RESOLUTION;
    if (millisecondRaw > GATEWAYSWC_SDAT_MS_MAX_RAW)
    {
        millisecondRaw = GATEWAYSWC_SDAT_MS_MAX_RAW;
    }

    time->year = yearRaw;
    time->month = (uint32)dateTime.month;
    time->day = (uint32)dateTime.day;
    time->hour = (uint32)dateTime.hour;
    time->minute = (uint32)dateTime.minute;
    time->second = (uint32)dateTime.second;
    time->millisecond = millisecondRaw;

    return E_OK;
}

static uint32 GatewaySwc_MapSdatTimeSource(uint8 timeSource)
{
    switch ((TimeBase_TimeSourceType)timeSource)
    {
        case TIMEBASE_SOURCE_DEFAULT_COMPILETIME:
            return GATEWAYSWC_SDAT_SOURCE_DEFAULT;

        case TIMEBASE_SOURCE_UDS_ROUTINE:
            return GATEWAYSWC_SDAT_SOURCE_UDS;

        case TIMEBASE_SOURCE_GPTP_MASTER:
            return GATEWAYSWC_SDAT_SOURCE_GPTP;

        default:
            return GATEWAYSWC_SDAT_SOURCE_INVALID;
    }
}

static void GatewaySwc_SendCanSdat(const GatewaySwc_SdatTimeType *time)
{
    if (time == NULL_PTR)
    {
        return;
    }

    (void)GatewaySwc_SendU32(COM_SIG_TX_SDAT_CSB_SDAT_YEAR, time->year);
    (void)GatewaySwc_SendU32(COM_SIG_TX_SDAT_CSB_SDAT_SECOND, time->second);
    (void)GatewaySwc_SendU32(COM_SIG_TX_SDAT_CSB_SDAT_MONTH, time->month);
    (void)GatewaySwc_SendU32(COM_SIG_TX_SDAT_CSB_SDAT_MINUTE, time->minute);
    (void)GatewaySwc_SendU32(COM_SIG_TX_SDAT_CSB_SDAT_MILLISECOND, time->millisecond);
    (void)GatewaySwc_SendU32(COM_SIG_TX_SDAT_CSB_SDAT_HOUR, time->hour);
    (void)GatewaySwc_SendU32(COM_SIG_TX_SDAT_CSB_SDAT_DAY, time->day);
    (void)GatewaySwc_SendU32(COM_SIG_TX_SDAT_CSB_SDAT_TIMESOURCE, time->timeSource);
    (void)GatewaySwc_SendU32(COM_SIG_TX_SDAT_CSB_SDAT_UTCVALID, time->utcValid);
    (void)GatewaySwc_SendU32(COM_SIG_TX_SDAT_CSB_SDAT_DEFAULTTIME, time->defaultTime);
    (void)GatewaySwc_SendU32(COM_SIG_TX_SDAT_CSB_SDAT_NVMRESTORED, time->nvmRestored);
}

static void GatewaySwc_SendCanFdSdat(const GatewaySwc_SdatTimeType *time)
{
    if (time == NULL_PTR)
    {
        return;
    }

    (void)GatewaySwc_SendU32(COM_SIG_TX_CANFD_SDAT_CANFD_SDAT_YEAR, time->year);
    (void)GatewaySwc_SendU32(COM_SIG_TX_CANFD_SDAT_CANFD_SDAT_SECOND, time->second);
    (void)GatewaySwc_SendU32(COM_SIG_TX_CANFD_SDAT_CANFD_SDAT_MONTH, time->month);
    (void)GatewaySwc_SendU32(COM_SIG_TX_CANFD_SDAT_CANFD_SDAT_MINUTE, time->minute);
    (void)GatewaySwc_SendU32(COM_SIG_TX_CANFD_SDAT_CANFD_SDAT_MILLISECOND, time->millisecond);
    (void)GatewaySwc_SendU32(COM_SIG_TX_CANFD_SDAT_CANFD_SDAT_HOUR, time->hour);
    (void)GatewaySwc_SendU32(COM_SIG_TX_CANFD_SDAT_CANFD_SDAT_DAY, time->day);
    (void)GatewaySwc_SendU32(COM_SIG_TX_CANFD_SDAT_CANFD_SDAT_TIMESOURCE, time->timeSource);
    (void)GatewaySwc_SendU32(COM_SIG_TX_CANFD_SDAT_CANFD_SDAT_UTCVALID, time->utcValid);
    (void)GatewaySwc_SendU32(COM_SIG_TX_CANFD_SDAT_CANFD_SDAT_DEFAULTTIME, time->defaultTime);
    (void)GatewaySwc_SendU32(COM_SIG_TX_CANFD_SDAT_CANFD_SDAT_NVMRESTORED, time->nvmRestored);
}

static void GatewaySwc_GenerateCanOutputs(void)
{
    static uint32 counter = 0u;
    static uint8 prevStat_LoadRequestStatus = 0u;
    uint32 alive;
    uint32 crc;
    uint8 hasChanged = 0u;
    uint8 crcarr[3];

    counter++;
    GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_DebugLoadRequestCounter, counter);

    if(prevStat_LoadRequestStatus != GatewaySwc_LoadRequest_Status)
    {
        prevStat_LoadRequestStatus = GatewaySwc_LoadRequest_Status;
        hasChanged = 1;
    }

    GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_DebugLoadRequestChanged, hasChanged);

    GatewaySwc_LoadRequestAliveCounter++;
    GatewaySwc_LoadRequestAliveCounter &= 0x0Fu;

    alive = (uint32)GatewaySwc_LoadRequestAliveCounter;
    crcarr[0] = GatewaySwc_LoadRequestAliveCounter;
    crcarr[1] = GatewaySwc_LoadRequest_Status;
    crcarr[2] = GatewaySwc_LoadRequest_DataId;
    crc = Crc_CalculateCRC32(&crcarr[0u], 3, 0xFFFFFFFFu, 1u);
    GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_DebugLoadRequestAlive, alive);
    GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_DebugLoadRequestCrc, crc);

    (void)GatewaySwc_SendU32(COM_SIG_TX_VEHICLESTATE_VEHICLESTATUS, GatewaySwc_Command.vehicleStatus);
    (void)GatewaySwc_SendU32(COM_SIG_TX_NM3_NM3_PN1, GatewaySwc_Command.nmPn1);

    (void)GatewaySwc_SendU32(COM_SIG_TX_LOADREQUEST_LOADREQUESTSTATUS, GatewaySwc_LoadRequest_Status);
    (void)GatewaySwc_SendU32(COM_SIG_TX_LOADREQUEST_LOADREQUESTDATAID, GatewaySwc_LoadRequest_DataId);
    (void)GatewaySwc_SendU32(COM_SIG_TX_LOADREQUEST_LOADREQUESTCRC, crc);
    (void)GatewaySwc_SendU32(COM_SIG_TX_LOADREQUEST_LOADREQUESTALIVECOUNTER, alive);
}

static void GatewaySwc_GenerateCanFdOutputs(void)
{
    (void)GatewaySwc_SendU32(COM_SIG_TX_CANFD_VEHICLESTATE_VEHICLESTATUS, GatewaySwc_Command.vehicleStatus);
    (void)GatewaySwc_SendU32(COM_SIG_TX_CANFD_NM3_NM3_PN1, GatewaySwc_Command.nmPn1);

    (void)GatewaySwc_SendU32(COM_SIG_TX_CANFD_COMMANDLOAD_PDM1_PDM1_COMMANDLOAD_01, GatewaySwc_Command.pdmCommandLoad[0u][0u]);
    (void)GatewaySwc_SendU32(COM_SIG_TX_CANFD_COMMANDLOAD_PDM1_PDM1_COMMANDLOAD_02, GatewaySwc_Command.pdmCommandLoad[0u][1u]);
    (void)GatewaySwc_SendU32(COM_SIG_TX_CANFD_COMMANDLOAD_PDM1_PDM1_COMMANDLOAD_03, GatewaySwc_Command.pdmCommandLoad[0u][2u]);
}

static void GatewaySwc_GenerateLinOutputs(void)
{
    (void)GatewaySwc_SendU32(COM_SIG_TX_LIN_ZGW_REQUEST_HVDCDC_ZGW_ENABLE_HVDCDC, GatewaySwc_Command.linHvDcdcEnable);
    (void)GatewaySwc_SendU32(COM_SIG_TX_LIN_ZGW_REQUEST_HVDCDC_ZGW_TARGETVOLTAGE_HVDCDC, GatewaySwc_Command.linHvDcdcTargetVoltage);
}

static void GatewaySwc_PublishEthernetSummary(void)
{
    uint16 i;

    for (i = 0u; i < (uint16)(sizeof(GatewaySwc_EthSignalRanges) / sizeof(GatewaySwc_EthSignalRanges[0])); i++)
    {
        GatewaySwc_PublishRange(GatewaySwc_EthSignalRanges[i].bus,
                GatewaySwc_EthSignalRanges[i].firstSignalId,
                GatewaySwc_EthSignalRanges[i].lastSignalId);
    }

    GatewaySwc_PublishEthernetVehicleState();
}

static void GatewaySwc_PublishEthernetVehicleState(void)
{
    uint8 payload[12u];

    payload[0u] = GATEWAYSWC_MAGIC0;
    payload[1u] = GATEWAYSWC_MAGIC1;
    payload[2u] = GATEWAYSWC_MAGIC2;
    payload[3u] = GATEWAYSWC_FRAME_VEHICLESTATE;
    GatewaySwc_StoreU32(payload, 4u, GatewaySwc_Status.mainCycles);
    GatewaySwc_StoreU32(payload, 8u, GatewaySwc_Command.vehicleStatus);

    GatewaySwc_Status.ethLastPayloadLength = (uint16)sizeof(payload);
    if (GatewaySwc_QueueEthTx(GATEWAYSWC_ETH_TX_KIND_VEHICLESTATE,
            (SoAd_SoConIdType)GATEWAYSWC_ETH_SOCON_ID,
            NULL_PTR,
            payload,
            (uint16)sizeof(payload)) == FALSE)
    {
        GatewaySwc_Status.ethLastOpenResult = 0u;
        GatewaySwc_Status.ethLastSoAdResult = SOAD_NOT_OK;
        GatewaySwc_Status.ethLastTransmitOk = 0u;
        GatewaySwc_Status.ethFramesFailed++;
    }
}

static void GatewaySwc_PublishCpuPerf(void)
{
    uint8 startId;
    uint16 payloadLen;
    uint8 maxEntries;

    maxEntries = (uint8)((GATEWAYSWC_ETH_MAX_PAYLOAD - GATEWAYSWC_CPU_PERF_HEADER_LEN -
            CPUPERF_RESPONSE_HEADER_LEN) / CPUPERF_RESPONSE_ENTRY_LEN);
    if (maxEntries == 0u)
    {
        return;
    }
    if (maxEntries > CPUPERF_RESPONSE_MAX_ENTRIES)
    {
        maxEntries = CPUPERF_RESPONSE_MAX_ENTRIES;
    }

    for (startId = 0u; startId < (uint8)CPUPERF_ID_COUNT; startId = (uint8)(startId + maxEntries))
    {
        GatewaySwc_EthBuffer[0u] = GATEWAYSWC_MAGIC0;
        GatewaySwc_EthBuffer[1u] = GATEWAYSWC_MAGIC1;
        GatewaySwc_EthBuffer[2u] = GATEWAYSWC_MAGIC2;
        GatewaySwc_EthBuffer[3u] = GATEWAYSWC_FRAME_CPU_PERF;
        GatewaySwc_StoreU32(GatewaySwc_EthBuffer, 4u, GatewaySwc_Status.mainCycles);

        if (CpuPerf_BuildSnapshotPayload(
                startId,
                maxEntries,
                &GatewaySwc_EthBuffer[GATEWAYSWC_CPU_PERF_HEADER_LEN],
                &payloadLen) != E_OK)
        {
            continue;
        }

        payloadLen = (uint16)(payloadLen + GATEWAYSWC_CPU_PERF_HEADER_LEN);
        GatewaySwc_Status.ethLastPayloadLength = payloadLen;
        if (GatewaySwc_QueueEthTx(GATEWAYSWC_ETH_TX_KIND_CPU_PERF,
                (SoAd_SoConIdType)GATEWAYSWC_ETH_SOCON_ID,
                NULL_PTR,
                GatewaySwc_EthBuffer,
                payloadLen) == FALSE)
        {
            GatewaySwc_Status.ethLastOpenResult = 0u;
            GatewaySwc_Status.ethLastSoAdResult = SOAD_NOT_OK;
            GatewaySwc_Status.ethLastTransmitOk = 0u;
            GatewaySwc_Status.ethFramesFailed++;
            break;
        }
    }
}

static void GatewaySwc_PublishAiModelResult(void)
{
    AiModel_GlobalResultType result;
    AiModel_ChannelResultType channelResult;
    uint16 len;
    uint8 channelOffset;
    uint8 maxChannelsPerFrame;
    uint8 channel;
    uint8 channelCount;
    uint8 fault;

    if (AiModel_GetLatestGlobalResult(&result) != E_OK)
    {
        return;
    }

    maxChannelsPerFrame = (uint8)((GATEWAYSWC_ETH_MAX_PAYLOAD - GATEWAYSWC_AI_MODEL_GLOBAL_LEN) /
            GATEWAYSWC_AI_MODEL_CHANNEL_LEN);
    if (maxChannelsPerFrame == 0u)
    {
        return;
    }

    for (channelOffset = 0u; channelOffset < BCM_NUM_CHANNELS; channelOffset = (uint8)(channelOffset + channelCount))
    {
        channelCount = (uint8)(BCM_NUM_CHANNELS - channelOffset);
        if (channelCount > maxChannelsPerFrame)
        {
            channelCount = maxChannelsPerFrame;
        }

        len = 0u;
        GatewaySwc_AppendU8(&len, GATEWAYSWC_MAGIC0);
        GatewaySwc_AppendU8(&len, GATEWAYSWC_MAGIC1);
        GatewaySwc_AppendU8(&len, GATEWAYSWC_MAGIC2);
        GatewaySwc_AppendU8(&len, GATEWAYSWC_FRAME_AI_MODEL);
        GatewaySwc_AppendU32(&len, GatewaySwc_Status.mainCycles);
        GatewaySwc_AppendU8(&len, GATEWAYSWC_BUS_CANFD);
        GatewaySwc_AppendU8(&len, result.inputValid);
        GatewaySwc_AppendU8(&len, result.inferenceValid);
        GatewaySwc_AppendU8(&len, result.windowReady);
        GatewaySwc_AppendU8(&len, result.undervoltage);
        GatewaySwc_AppendU8(&len, result.overvoltage);
        GatewaySwc_AppendU8(&len, channelCount);
        GatewaySwc_AppendU8(&len, channelOffset);
        GatewaySwc_AppendU8(&len, BCM_NUM_CHANNELS);

        GatewaySwc_AppendF32(&len, result.inputVoltage_V);
        GatewaySwc_AppendU8(&len, result.dominantFaultChannel);
        GatewaySwc_AppendU8(&len, result.dominantFault);
        GatewaySwc_AppendU16(&len, 0u);
        GatewaySwc_AppendU32(&len, result.inputTimestamp);
        GatewaySwc_AppendU32(&len, result.inferenceSequence);
        GatewaySwc_AppendU32(&len, result.channelExecutionTimeUs);
        GatewaySwc_AppendU32(&len, result.totalInferenceTimeUs);
        GatewaySwc_AppendU32(&len, result.processingTimeUs);
        GatewaySwc_AppendU32(&len, result.maxChannelExecutionTimeUs);
        GatewaySwc_AppendU32(&len, result.maxTotalInferenceTimeUs);
        GatewaySwc_AppendU32(&len, result.maxProcessingTimeUs);
        GatewaySwc_AppendU32(&len, result.errorFlags);

        for (channel = channelOffset; channel < (uint8)(channelOffset + channelCount); channel++)
        {
            if (AiModel_GetLatestChannelResult(channel, &channelResult) != E_OK)
            {
                channelResult.channelId = channel;
                channelResult.measuredCurrent_A = 0.0f;
                channelResult.currentRating_A = 0.0f;
                channelResult.predictedCurrent_A = 0.0f;
                channelResult.faultSoonProbability = 0.0f;
                channelResult.faultProbability[0u] = 0.0f;
                channelResult.faultProbability[1u] = 0.0f;
                channelResult.faultProbability[2u] = 0.0f;
                channelResult.faultProbability[3u] = 0.0f;
                channelResult.currentUtilization = 0.0f;
                channelResult.predictedFaultClass = 0u;
                channelResult.impendingOvercurrent = 0u;
                channelResult.actualOvercurrent = 0u;
                channelResult.inferenceValid = 0u;
            }

            GatewaySwc_AppendU8(&len, channelResult.channelId);
            GatewaySwc_AppendU8(&len, channelResult.predictedFaultClass);
            GatewaySwc_AppendU8(&len, channelResult.impendingOvercurrent);
            GatewaySwc_AppendU8(&len, channelResult.actualOvercurrent);
            GatewaySwc_AppendU8(&len, channelResult.inferenceValid);
            GatewaySwc_AppendU8(&len, 0u);
            GatewaySwc_AppendU8(&len, 0u);
            GatewaySwc_AppendF32(&len, channelResult.measuredCurrent_A);
            GatewaySwc_AppendF32(&len, channelResult.currentRating_A);
            GatewaySwc_AppendF32(&len, channelResult.predictedCurrent_A);
            GatewaySwc_AppendF32(&len, channelResult.faultSoonProbability);
            GatewaySwc_AppendF32(&len, channelResult.currentUtilization);
            for (fault = 0u; fault < BCM_NUM_FAULT_CLASSES; fault++)
            {
                GatewaySwc_AppendF32(&len, channelResult.faultProbability[fault]);
            }
        }

        GatewaySwc_Status.ethLastPayloadLength = len;
        if (GatewaySwc_QueueEthTx(GATEWAYSWC_ETH_TX_KIND_AI_MODEL,
                (SoAd_SoConIdType)GATEWAYSWC_ETH_SOCON_ID,
                NULL_PTR,
                GatewaySwc_EthBuffer,
                len) == FALSE)
        {
            GatewaySwc_Status.ethLastOpenResult = 0u;
            GatewaySwc_Status.ethLastSoAdResult = SOAD_NOT_OK;
            GatewaySwc_Status.ethLastTransmitOk = 0u;
            GatewaySwc_Status.ethFramesFailed++;
            break;
        }
    }
}

static void GatewaySwc_McuStatusInit(void)
{
#if (GATEWAYSWC_MCU_STATUS_UDP_ENABLE == STD_ON)
    GatewaySwc_McuStatusNextTxTimeNs = 0ull;
    GatewaySwc_McuStatusSequenceCounter = 0u;
    GatewaySwc_McuStatusTxCounter = 0u;
    GatewaySwc_McuStatusStatus = GATEWAYSWC_MCU_STATUS_WAIT_LINK;
#else
    GatewaySwc_McuStatusStatus = GATEWAYSWC_MCU_STATUS_DISABLED;
#endif
}

static void GatewaySwc_McuStatusMainFunction(uint64 nowNs)
{
#if (GATEWAYSWC_MCU_STATUS_UDP_ENABLE == STD_ON)
    if (GatewaySwc_McuStatusNextTxTimeNs == 0ull)
    {
        if (GatewaySwc_McuStatusTxPending == 0u)
        {
            GatewaySwc_McuStatusSendPacket();
        }
        GatewaySwc_McuStatusUpdateNextTxDeadline(nowNs);
    }
    else if (nowNs >= GatewaySwc_McuStatusNextTxTimeNs)
    {
        if (GatewaySwc_McuStatusTxPending == 0u)
        {
            GatewaySwc_McuStatusSendPacket();
            GatewaySwc_McuStatusUpdateNextTxDeadline(nowNs);
        }
    }
#else
    (void)nowNs;
#endif
}

static void GatewaySwc_McuStatusOpenSocket(void)
{
#if (GATEWAYSWC_MCU_STATUS_UDP_ENABLE == STD_ON)
    if (GatewaySwc_McuStatusSocket != TCPIP_INVALID_SOCKET)
    {
        return;
    }

    if (TcpIp_IsLinkAvailable() == 0u)
    {
        return;
    }

    GatewaySwc_McuStatusSocket = TcpIp_Create(0u);
    if (GatewaySwc_McuStatusSocket == TCPIP_INVALID_SOCKET)
    {
        return;
    }

    if (TcpIp_Bind(GatewaySwc_McuStatusSocket, 0u) < 0)
    {
        GatewaySwc_McuStatusCloseSocket();
        return;
    }
#endif
}

static void GatewaySwc_McuStatusCloseSocket(void)
{
#if (GATEWAYSWC_MCU_STATUS_UDP_ENABLE == STD_ON)
    if (GatewaySwc_McuStatusSocket != TCPIP_INVALID_SOCKET)
    {
        TcpIp_Close(GatewaySwc_McuStatusSocket);
        GatewaySwc_McuStatusSocket = TCPIP_INVALID_SOCKET;
    }
#endif
}

static void GatewaySwc_McuStatusBuildPacket(uint8 *packet)
{
    TimeBase_TimestampSnapshotType snapshot;
    uint32 crc;
    uint16 i;

    TimeBase_GetTimestampSnapshot(&snapshot);

    for (i = 0u; i < GATEWAYSWC_MCU_STATUS_PACKET_LENGTH; i++)
    {
        packet[i] = 0u;
    }

    GatewaySwc_StoreU32(packet, 0u, GATEWAYSWC_MCU_STATUS_MAGIC);
    packet[4u] = GATEWAYSWC_MCU_STATUS_VERSION;
    packet[5u] = GATEWAYSWC_MCU_STATUS_MESSAGE_STATUS;
    GatewaySwc_StoreU16(packet, 6u, GATEWAYSWC_MCU_STATUS_PACKET_LENGTH);
    GatewaySwc_StoreU32(packet, 8u, GatewaySwc_McuStatusSequenceCounter);
    GatewaySwc_StoreU64(packet, 12u, snapshot.vehicle_time_ns);
    packet[20u] = (uint8)g_SafetyKitStatus.safetyKitInitDone;
    packet[21u] = (uint8)g_SafetyKitStatus.wakeupFromStandby;
    GatewaySwc_StoreU16(packet, 22u, (uint16)g_SafetyKitStatus.resetCode.resetType);
    GatewaySwc_StoreU16(packet, 24u, (uint16)g_SafetyKitStatus.resetCode.resetTrigger);
    GatewaySwc_StoreU16(packet, 26u, g_SafetyKitStatus.resetCode.resetReason);
    GatewaySwc_StoreU16(packet, 28u, GatewaySwc_McuStatusScaleMilliVolt(g_SafetyKitStatus.voltStatus.vextVoltage));
    GatewaySwc_StoreU16(packet, 30u, GatewaySwc_McuStatusScaleMilliVolt(g_SafetyKitStatus.voltStatus.vddp3Voltage));
    GatewaySwc_StoreU16(packet, 32u, GatewaySwc_McuStatusScaleMilliVolt(g_SafetyKitStatus.voltStatus.coreVoltage));
    GatewaySwc_StoreU16(packet, 34u, GatewaySwc_McuStatusScaleMilliVolt(g_SafetyKitStatus.voltStatus.coreVoltageHighest));
    GatewaySwc_StoreU16(packet, 36u, GatewaySwc_McuStatusScaleMilliVolt(g_SafetyKitStatus.voltStatus.coreVoltageLowest));
    GatewaySwc_StoreU16(packet, 38u, GatewaySwc_McuStatusScaleMilliVolt(g_SafetyKitStatus.voltStatus.coreVoltageUvLimit));
    GatewaySwc_StoreS16(packet, 40u, GatewaySwc_McuStatusScaleCentiDeg(g_SafetyKitStatus.dieTempStatus.dieTemperaturePms));
    GatewaySwc_StoreS16(packet, 42u, GatewaySwc_McuStatusScaleCentiDeg(g_SafetyKitStatus.dieTempStatus.dieTemperatureCore));
    GatewaySwc_StoreS16(packet, 44u, GatewaySwc_McuStatusScaleCentiDeg(g_SafetyKitStatus.dieTempStatus.dieTempDifference));
    GatewaySwc_StoreS16(packet, 46u, GatewaySwc_McuStatusScaleCentiDeg(g_SafetyKitStatus.dieTempStatus.dieTempHighest));
    GatewaySwc_StoreS16(packet, 48u, GatewaySwc_McuStatusScaleCentiDeg(g_SafetyKitStatus.dieTempStatus.dieTempLowest));
    GatewaySwc_StoreU16(packet, 50u, Os_GetCpuLoadPermille(0u));
    GatewaySwc_StoreU16(packet, 52u, Os_GetCpuLoadPermille(1u));
    GatewaySwc_StoreU16(packet, 54u, Os_GetCpuLoadPermille(2u));

    crc = Crc_CalculateCRC32(packet, GATEWAYSWC_MCU_STATUS_CRC_OFFSET, 0u, TRUE);
    GatewaySwc_StoreU32(packet, GATEWAYSWC_MCU_STATUS_CRC_OFFSET, crc);
}

static void GatewaySwc_McuStatusStorePacketForWriteAll(const uint8 *packet)
{
    if (packet == NULL_PTR)
    {
        return;
    }

    if (memcmp(NvM_McuStatus_Ram, packet, GATEWAYSWC_MCU_STATUS_NVM_IMAGE_SIZE) != 0)
    {
        memcpy(NvM_McuStatus_Ram, packet, GATEWAYSWC_MCU_STATUS_NVM_IMAGE_SIZE);
        (void)NvM_SetRamBlockStatus(NVM_BLOCK_ID_MCU_STATUS, TRUE);
    }
}

static void GatewaySwc_McuStatusSendPacket(void)
{
#if (GATEWAYSWC_MCU_STATUS_UDP_ENABLE == STD_ON)
    uint8 packet[GATEWAYSWC_MCU_STATUS_PACKET_LENGTH];
    TcpIp_SockAddrType remoteAddr;

    if (GatewaySwc_IsEthTxKindEnabled(GATEWAYSWC_ETH_TX_KIND_MCU_STATUS) == FALSE)
    {
        return;
    }

    remoteAddr.addr = GATEWAYSWC_MCU_STATUS_UDP_BROADCAST_ADDR;
    remoteAddr.port = GATEWAYSWC_MCU_STATUS_UDP_PORT;

    GatewaySwc_McuStatusBuildPacket(packet);
    GatewaySwc_McuStatusStorePacketForWriteAll(packet);
    GatewaySwc_Status.ethLastPayloadLength = GATEWAYSWC_MCU_STATUS_PACKET_LENGTH;
    if (GatewaySwc_QueueEthTx(GATEWAYSWC_ETH_TX_KIND_MCU_STATUS,
            0u,
            &remoteAddr,
            packet,
            GATEWAYSWC_MCU_STATUS_PACKET_LENGTH) != FALSE)
    {
        GatewaySwc_McuStatusTxPending = 1u;
    }
    else
    {
        GatewaySwc_McuStatusStatus = GATEWAYSWC_MCU_STATUS_TX_ERROR;
        GatewaySwc_Status.ethLastTransmitOk = 0u;
        GatewaySwc_Status.ethFramesFailed++;
    }
#endif
}

Std_ReturnType GatewaySwc_ReadDid(uint16 did, uint8 *data, Dcm_PduLengthType *dataLen)
{
    if ((data == NULL_PTR) || (dataLen == NULL_PTR))
    {
        return E_NOT_OK;
    }

    if (did != DCM_DID_MCU_DATA_PACKET)
    {
        return E_NOT_OK;
    }

    if (*dataLen < GATEWAYSWC_MCU_STATUS_NVM_IMAGE_SIZE)
    {
        return E_NOT_OK;
    }

    memcpy(data, NvM_McuStatus_Ram, GATEWAYSWC_MCU_STATUS_NVM_IMAGE_SIZE);
    *dataLen = GATEWAYSWC_MCU_STATUS_NVM_IMAGE_SIZE;

    return E_OK;
}

static void GatewaySwc_McuStatusUpdateNextTxDeadline(uint64 nowNs)
{
    GatewaySwc_McuStatusNextTxTimeNs = nowNs + GATEWAYSWC_MCU_STATUS_TX_PERIOD_NS;
}

static uint16 GatewaySwc_McuStatusScaleMilliVolt(float32 voltage)
{
    float32 millivolts = voltage * 1000.0f;

    if (millivolts <= 0.0f)
    {
        return 0u;
    }

    if (millivolts >= 65535.0f)
    {
        return 0xFFFFu;
    }

    return (uint16)(millivolts + 0.5f);
}

static sint16 GatewaySwc_McuStatusScaleCentiDeg(float32 temperature)
{
    float32 centiDeg = temperature * 100.0f;

    if (centiDeg >= 32767.0f)
    {
        return 32767;
    }

    if (centiDeg <= -32768.0f)
    {
        return -32768;
    }

    if (centiDeg >= 0.0f)
    {
        return (sint16)(centiDeg + 0.5f);
    }

    return (sint16)(centiDeg - 0.5f);
}

static void GatewaySwc_PublishRange(GatewaySwc_BusType bus,
        Com_SignalIdType firstSignalId,
        Com_SignalIdType lastSignalId)
{
    Com_SignalIdType signalId;
    uint16 len;
    uint32 value;
    Std_ReturnType receiveResult;

    GatewaySwc_ResetEthFrame(&len, bus);
    GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_DebugPublishBus, (uint8)bus);
    GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_DebugPublishFirstSignalId, firstSignalId);
    GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_DebugPublishLastSignalId, lastSignalId);
    GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_DebugPublishInvalidRange, 0u);

    if (firstSignalId > lastSignalId)
    {
        GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_DebugPublishInvalidRange, 1u);
        return;
    }

    for (signalId = firstSignalId; signalId <= lastSignalId; signalId++)
    {
        GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_DebugPublishSignalId, signalId);
        receiveResult = GatewaySwc_ReceiveU32(signalId, &value);
        GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_DebugPublishReceiveResult, (uint8)receiveResult);

        if (receiveResult != E_OK)
        {
            continue;
        }
        GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_DebugPublishValue, value);
        GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_DebugPublishLen, len);

        if ((uint16)(len + GATEWAYSWC_ENTRY_LEN) > GATEWAYSWC_ETH_MAX_PAYLOAD)
        {
            GatewaySwc_FlushEthFrame(&len);
            GatewaySwc_ResetEthFrame(&len, bus);
            GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_DebugPublishLen, len);
        }

        GatewaySwc_AppendU16(&len, signalId);
        GatewaySwc_AppendU8(&len, (uint8)bus);
        GatewaySwc_AppendU32(&len, value);

        GatewaySwc_Status.ethSignalsPublished++;
        GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_DebugPublishLen, len);
    }

    GatewaySwc_FlushEthFrame(&len);
    GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_DebugPublishLen, len);
}

static void GatewaySwc_SendLinSdat(const GatewaySwc_SdatTimeType *time)
{
    if (time == NULL_PTR)
    {
        return;
    }

    /* The LIN frame preserves the canonical SDAT layout and scaling:
     * year is relative to 2000 and milliseconds use 4 ms per bit. */
    (void)GatewaySwc_SendU32(COM_SIG_TX_LIN_ZGW_SDAT_MINUTE, time->minute);
    (void)GatewaySwc_SendU32(COM_SIG_TX_LIN_ZGW_SDAT_TIMESOURCE, time->timeSource);
    (void)GatewaySwc_SendU32(COM_SIG_TX_LIN_ZGW_SDAT_SECOND, time->second);
    (void)GatewaySwc_SendU32(COM_SIG_TX_LIN_ZGW_SDAT_UTCVALID, time->utcValid);
    (void)GatewaySwc_SendU32(COM_SIG_TX_LIN_ZGW_SDAT_DEFAULTTIME, time->defaultTime);
    (void)GatewaySwc_SendU32(COM_SIG_TX_LIN_ZGW_SDAT_YEAR, time->year);
    (void)GatewaySwc_SendU32(COM_SIG_TX_LIN_ZGW_SDAT_NVMRESTORED, time->nvmRestored);
    (void)GatewaySwc_SendU32(COM_SIG_TX_LIN_ZGW_SDAT_DAY, time->day);
    (void)GatewaySwc_SendU32(COM_SIG_TX_LIN_ZGW_SDAT_HOUR, time->hour);
    (void)GatewaySwc_SendU32(COM_SIG_TX_LIN_ZGW_SDAT_MONTH, time->month);
    (void)GatewaySwc_SendU32(COM_SIG_TX_LIN_ZGW_SDAT_MILLISECOND, time->millisecond);
}

static void GatewaySwc_ResetRxDiagnostics(void)
{
    uint16 i;

    for (i = 0u; i < (uint16)GATEWAYSWC_RX_MESSAGE_DIAG_COUNT; i++)
    {
        GatewaySwc_RxMessageDiagStatus[i] = GATEWAYSWC_RX_DIAG_STATUS_OK;
        GatewaySwc_DemMessageTimeoutState[i] = GATEWAYSWC_DEM_STATE_UNKNOWN;
        GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_RxMessageDiagDebugPduId[i], 0u);
        GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_RxMessageDiagDebugStatus[i], GATEWAYSWC_RX_DIAG_STATUS_OK);
        GatewaySwc_RxMessageTimeoutCounter[i] = 0u;
        GatewaySwc_RxMessageTimeoutActiveSamples[i] = 0u;
    }

    for (i = 0u; i < (uint16)GATEWAYSWC_RX_SIGNAL_DIAG_COUNT; i++)
    {
        GatewaySwc_RxSignalDiagStatus[i] = GATEWAYSWC_RX_DIAG_STATUS_OK;
        GatewaySwc_RxSignalDiagValue[i] = 0u;
        GatewaySwc_RxSignalDiagInvalidValue[i] = 0u;
        GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_RxSignalDiagDebugSignalId[i], 0u);
        GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_RxSignalDiagDebugStatus[i], GATEWAYSWC_RX_DIAG_STATUS_OK);
        GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_RxSignalDiagDebugValue[i], 0u);
        GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_RxSignalDiagDebugInvalidValue[i], 0u);
        GatewaySwc_RxSignalTimeoutCounter[i] = 0u;
        GatewaySwc_RxSignalTimeoutActiveSamples[i] = 0u;
        GatewaySwc_RxSignalInvalidCounter[i] = 0u;
        GatewaySwc_RxSignalInvalidActiveSamples[i] = 0u;
    }
}

static uint8 GatewaySwc_IsNmActiveForBus(GatewaySwc_BusType bus)
{
    Nm_StateType state;
    Nm_ModeType mode;
    uint8 channel;

    switch (bus)
    {
        case GATEWAYSWC_BUS_CAN:
            channel = COMM_CH_CAN;
            break;

        case GATEWAYSWC_BUS_CANFD:
            channel = COMM_CH_CANFD;
            break;

        case GATEWAYSWC_BUS_LIN:
            channel = COMM_CH_LIN;
            break;

        case GATEWAYSWC_BUS_ETH:
            return GatewaySwc_IsEthComActive();

        default:
            return FALSE;
    }

    if (Nm_GetState(channel, &state, &mode) != E_OK)
    {
        return FALSE;
    }

    return ((mode == NM_MODE_NETWORK) &&
            (state != NM_STATE_BUS_SLEEP)) ? TRUE : FALSE;
}

static uint8 GatewaySwc_IsEthComActive(void)
{
    ComM_ModeType mode;

    if (ComM_GetCurrentComMode(COMM_CH_ETH, &mode) != E_OK)
    {
        return FALSE;
    }

    return (mode == COMM_FULL_COMMUNICATION) ? TRUE : FALSE;
}

static void GatewaySwc_UpdateRxDiagnostics(void)
{
    uint16 i;
    uint8 comStatus;
    uint8 status;
    uint8 previousStatus;
    uint16 timeoutCount = 0u;
    uint16 invalidCount = 0u;
    PduIdType pduId;
    Com_SignalIdType signalId;
    GatewaySwc_BusType bus;
    uint32 value;
    uint32 invalidValue;
    uint16 ethRxIndex;

    for (i = 0u; i < (uint16)GATEWAYSWC_RX_MESSAGE_DIAG_COUNT; i++)
    {
        status = GATEWAYSWC_RX_DIAG_STATUS_OK;
        pduId = 0u;
        bus = GATEWAYSWC_BUS_CAN;

        if (GatewaySwc_GetPduDiagConfig(i, &pduId, &bus) == E_OK)
        {
            if (bus == GATEWAYSWC_BUS_ETH)
            {
                ethRxIndex = (uint16)((uint16)pduId -
                        (uint16)GATEWAYSWC_ETH_RX_PDU_COMMAND_SIGNAL);
                if (ethRxIndex < GATEWAYSWC_ETH_RX_MESSAGE_COUNT)
                {
                    if ((CodingApp_IsRxMessageExpected(i) != FALSE) &&
                            (GatewaySwc_IsEthComActive() != FALSE) &&
                            (GatewaySwc_IsRxDiagSuppressedForBus(bus) == FALSE))
                    {
                        if (GatewaySwc_EthRxAgeMs[ethRxIndex] <=
                                (0xFFFFFFFFu - GATEWAYSWC_DIAG_PERIOD_MS))
                        {
                            GatewaySwc_EthRxAgeMs[ethRxIndex] += GATEWAYSWC_DIAG_PERIOD_MS;
                        }

                        if (GatewaySwc_EthRxAgeMs[ethRxIndex] >= GATEWAYSWC_ETH_RX_TIMEOUT_MS)
                        {
                            status |= GATEWAYSWC_RX_DIAG_STATUS_TIMEOUT;
                        }
                    }
                    else
                    {
                        GatewaySwc_EthRxAgeMs[ethRxIndex] = 0u;
                    }
                }
            }
            else if (Com_GetRxPduDiagStatus(pduId, &comStatus) == E_OK)
            {
                if ((comStatus & COM_RX_DIAG_STATUS_TIMEOUT) != 0u)
                {
                    status |= GATEWAYSWC_RX_DIAG_STATUS_TIMEOUT;
                }
            }
        }
        else
        {
            pduId = 0u;
            bus = GATEWAYSWC_BUS_CAN;
        }

        if ((CodingApp_IsRxMessageExpected(i) == FALSE) ||
                (GatewaySwc_IsNmActiveForBus(bus) == FALSE) ||
                (GatewaySwc_IsRxDiagSuppressedForBus(bus) != FALSE))
        {
            status = GATEWAYSWC_RX_DIAG_STATUS_OK;
        }

        previousStatus = GatewaySwc_RxMessageDiagStatus[i];
        GatewaySwc_RxMessageDiagStatus[i] = status;
        GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_RxMessageDiagDebugPduId[i], (uint16)pduId);
        GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_RxMessageDiagDebugStatus[i], status);

        if ((status & GATEWAYSWC_RX_DIAG_STATUS_TIMEOUT) != 0u)
        {
            timeoutCount++;
            GatewaySwc_RxMessageTimeoutActiveSamples[i]++;

            if ((previousStatus & GATEWAYSWC_RX_DIAG_STATUS_TIMEOUT) == 0u)
            {
                GatewaySwc_RxMessageTimeoutCounter[i]++;
                GatewaySwc_Status.rxDiagTimeoutEvents++;
                GatewaySwc_Status.rxDiagLastTimeoutPduId = (uint16)pduId;
            }
        }
        else
        {
            GatewaySwc_RxMessageTimeoutActiveSamples[i] = 0u;
        }
    }

    for (i = 0u; i < (uint16)GATEWAYSWC_RX_SIGNAL_DIAG_COUNT; i++)
    {
        status = GATEWAYSWC_RX_DIAG_STATUS_OK;
        value = 0u;
        invalidValue = 0u;
        signalId = 0u;
        bus = GATEWAYSWC_BUS_CAN;

        if ((GatewaySwc_GetSignalDiagConfig(i, &signalId, &bus) == E_OK) &&
                (Com_GetRxSignalDiagStatus(signalId, &value, &invalidValue, &comStatus) == E_OK))
        {
            if ((comStatus & COM_RX_DIAG_STATUS_TIMEOUT) != 0u)
            {
                status |= GATEWAYSWC_RX_DIAG_STATUS_TIMEOUT;
            }

            if ((comStatus & COM_RX_DIAG_STATUS_INVALID) != 0u)
            {
                status |= GATEWAYSWC_RX_DIAG_STATUS_INVALID;
            }
        }
        else
        {
            signalId = 0u;
            bus = GATEWAYSWC_BUS_CAN;
        }

        if ((CodingApp_IsCoded() == FALSE) ||
                (GatewaySwc_IsNmActiveForBus(bus) == FALSE) ||
                (GatewaySwc_IsRxDiagSuppressedForBus(bus) != FALSE))
        {
            status = GATEWAYSWC_RX_DIAG_STATUS_OK;
        }

        previousStatus = GatewaySwc_RxSignalDiagStatus[i];
        GatewaySwc_RxSignalDiagStatus[i] = status;
        GatewaySwc_RxSignalDiagValue[i] = value;
        GatewaySwc_RxSignalDiagInvalidValue[i] = invalidValue;
        GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_RxSignalDiagDebugSignalId[i], (uint16)signalId);
        GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_RxSignalDiagDebugStatus[i], status);
        GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_RxSignalDiagDebugValue[i], value);
        GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_RxSignalDiagDebugInvalidValue[i], invalidValue);

        if ((status & GATEWAYSWC_RX_DIAG_STATUS_TIMEOUT) != 0u)
        {
            GatewaySwc_RxSignalTimeoutActiveSamples[i]++;

            if ((previousStatus & GATEWAYSWC_RX_DIAG_STATUS_TIMEOUT) == 0u)
            {
                GatewaySwc_RxSignalTimeoutCounter[i]++;
            }
        }
        else
        {
            GatewaySwc_RxSignalTimeoutActiveSamples[i] = 0u;
        }

        if ((status & GATEWAYSWC_RX_DIAG_STATUS_INVALID) != 0u)
        {
            invalidCount++;
            GatewaySwc_RxSignalInvalidActiveSamples[i]++;

            if ((previousStatus & GATEWAYSWC_RX_DIAG_STATUS_INVALID) == 0u)
            {
                GatewaySwc_RxSignalInvalidCounter[i]++;
                GatewaySwc_Status.rxDiagInvalidEvents++;
                GatewaySwc_Status.rxDiagLastInvalidSignalId = (uint16)signalId;
                GatewaySwc_Status.rxDiagLastInvalidValue = value;
            }
        }
        else
        {
            GatewaySwc_RxSignalInvalidActiveSamples[i] = 0u;
        }
    }

    GatewaySwc_Status.rxDiagTimedOutMessages = timeoutCount;
    GatewaySwc_Status.rxDiagInvalidSignals = invalidCount;

    for (i = 0u; i < (uint16)GATEWAYSWC_RX_MESSAGE_DIAG_COUNT; i++)
    {
        GatewaySwc_ReportRxMessageTimeoutToDem(i, GatewaySwc_RxMessageDiagStatus[i]);
    }

}

static void GatewaySwc_UpdateComModeFromBusActivity(void)
{
    /* AI model and CPU telemetry remain scheduled when the vehicle buses are
     * silent. Keep their Ethernet channel available without waking those buses.
     * A separate user also survives ComM's cyclic gateway bus-activity update.
     */
    (void)ComM_RequestComMode(COMM_USER_GATEWAY_ETH,
            (SysMgr_BusActivityCounter > 0u) ?
                    COMM_FULL_COMMUNICATION : COMM_NO_COMMUNICATION);

    if ((SysMgr_BusActivityCounter > 0u) ||
        (Dcm_HasActiveEthernetDiagnosticConnection() != FALSE))
    {
        GatewaySwc_RequestFullCom();
    }
    else
    {
        GatewaySwc_RequestNoCom();
    }
}

static void GatewaySwc_RequestFullCom(void)
{
    if (GatewaySwc_ComModeRequestState == GATEWAYSWC_COMM_FULL)
    {
        return;
    }

    if (ComM_RequestComMode(COMM_USER_GATEWAY,
            COMM_FULL_COMMUNICATION) == E_OK)
    {
        GatewaySwc_ComModeRequestState = GATEWAYSWC_COMM_FULL;
        GatewaySwc_ComFullRequested = 1u;
    }
}

static void GatewaySwc_RequestNoCom(void)
{
    if (GatewaySwc_ComModeRequestState == GATEWAYSWC_COMM_NO)
    {
        return;
    }

    if (ComM_RequestComMode(COMM_USER_GATEWAY,
            COMM_NO_COMMUNICATION) == E_OK)
    {
        GatewaySwc_ComModeRequestState = GATEWAYSWC_COMM_NO;
        GatewaySwc_ComFullRequested = 0u;
    }
}

static boolean GatewaySwc_IsBusDiagnosticFailed(GatewaySwc_BusType bus)
{
    boolean failed;

    switch (bus)
    {
        case GATEWAYSWC_BUS_LIN:
            if ((Dem_GetEventFailed(DEM_EVENT_ID_LIN1_HVDCDC_NO_COMMUNICATION, &failed) == E_OK) &&
                    (failed != FALSE))
            {
                return TRUE;
            }
            if ((Dem_GetEventFailed(DEM_EVENT_ID_LIN1_PROTOCOL_ERROR, &failed) == E_OK) &&
                    (failed != FALSE))
            {
                return TRUE;
            }
            if ((Dem_GetEventFailed(DEM_EVENT_ID_LIN1_CONTROLLER_FAULT, &failed) == E_OK) &&
                    (failed != FALSE))
            {
                return TRUE;
            }
            return FALSE;

        case GATEWAYSWC_BUS_CAN:
            if ((Dem_GetEventFailed(DEM_EVENT_ID_CAN_CLASSIC_BUS_OFF, &failed) == E_OK) &&
                    (failed != FALSE))
            {
                return TRUE;
            }
            if ((Dem_GetEventFailed(DEM_EVENT_ID_CAN_CLASSIC_ERROR_PASSIVE, &failed) == E_OK) &&
                    (failed != FALSE))
            {
                return TRUE;
            }
            if ((Dem_GetEventFailed(DEM_EVENT_ID_CAN_CLASSIC_CONTROLLER_FAULT, &failed) == E_OK) &&
                    (failed != FALSE))
            {
                return TRUE;
            }
            if ((Dem_GetEventFailed(DEM_EVENT_ID_CAN_CLASSIC_PROTOCOL_ERROR, &failed) == E_OK) &&
                    (failed != FALSE))
            {
                return TRUE;
            }
            return FALSE;

        case GATEWAYSWC_BUS_CANFD:
            if ((Dem_GetEventFailed(DEM_EVENT_ID_CANFD_BUS_OFF, &failed) == E_OK) &&
                    (failed != FALSE))
            {
                return TRUE;
            }
            if ((Dem_GetEventFailed(DEM_EVENT_ID_CANFD_ERROR_PASSIVE, &failed) == E_OK) &&
                    (failed != FALSE))
            {
                return TRUE;
            }
            if ((Dem_GetEventFailed(DEM_EVENT_ID_CANFD_CONTROLLER_FAULT, &failed) == E_OK) &&
                    (failed != FALSE))
            {
                return TRUE;
            }
            if ((Dem_GetEventFailed(DEM_EVENT_ID_CANFD_PROTOCOL_ERROR, &failed) == E_OK) &&
                    (failed != FALSE))
            {
                return TRUE;
            }
            return FALSE;

        default:
            return FALSE;
    }
}

static boolean GatewaySwc_IsRxDiagSuppressedForBus(GatewaySwc_BusType bus)
{
    if (GatewaySwc_IsBusDiagnosticFailed(bus) != FALSE)
    {
        return TRUE;
    }

    switch (bus)
    {
        case GATEWAYSWC_BUS_LIN:
            return (LinDiag_IsChannelUnavailable(LIN_CHANNEL_0) != FALSE) ? TRUE : FALSE;

        case GATEWAYSWC_BUS_CAN:
            return (CanDiag_IsChannelUnavailable(CAN_CONTROLLER_CLASSIC) != FALSE) ? TRUE : FALSE;

        case GATEWAYSWC_BUS_CANFD:
            return (CanDiag_IsChannelUnavailable(CAN_CONTROLLER_FD) != FALSE) ? TRUE : FALSE;

        default:
            return FALSE;
    }
}

static void GatewaySwc_ReportRxMessageTimeoutToDem(uint16 index, uint8 status)
{
    Dem_EventStatusType desiredStatus;
    Dem_EventIdType eventId;
    boolean eventFailed;

    if (Dem_IsReady() == FALSE)
    {
        return;
    }

    if (index >= (uint16)GATEWAYSWC_RX_MESSAGE_DIAG_COUNT)
    {
        return;
    }

    desiredStatus = ((status & GATEWAYSWC_RX_DIAG_STATUS_TIMEOUT) != 0u) ?
            DEM_EVENT_STATUS_FAILED :
            DEM_EVENT_STATUS_PASSED;

    eventId = (Dem_EventIdType)(DEM_EVENT_ID_GATEWAY_RX_MESSAGE_TIMEOUT_FIRST + index);

    {
        PduIdType pduId;
        GatewaySwc_BusType bus;

        if ((desiredStatus == DEM_EVENT_STATUS_FAILED) &&
            (GatewaySwc_GetPduDiagConfig(index, &pduId, &bus) == E_OK) &&
            (GatewaySwc_IsRxDiagSuppressedForBus(bus) != FALSE))
        {
            desiredStatus = DEM_EVENT_STATUS_PASSED;
        }
    }

    if (GatewaySwc_DemMessageTimeoutState[index] == GATEWAYSWC_DEM_STATE_UNKNOWN)
    {
        if (Dem_GetEventFailed(eventId, &eventFailed) == E_OK)
        {
            GatewaySwc_DemMessageTimeoutState[index] =
                    (eventFailed != FALSE) ?
                            (uint8)DEM_EVENT_STATUS_FAILED :
                            (uint8)DEM_EVENT_STATUS_PASSED;
        }
        else if (desiredStatus == DEM_EVENT_STATUS_PASSED)
        {
            GatewaySwc_DemMessageTimeoutState[index] = (uint8)desiredStatus;
            return;
        }
    }

    if (GatewaySwc_DemMessageTimeoutState[index] != (uint8)desiredStatus)
    {
        if (Dem_ReportErrorStatus(eventId, desiredStatus) == E_OK)
        {
            GatewaySwc_DemMessageTimeoutState[index] = (uint8)desiredStatus;
        }
    }
}

static Std_ReturnType GatewaySwc_GetPduDiagConfig(uint16 index, PduIdType *pduId, GatewaySwc_BusType *bus)
{
    uint16 i;
    uint16 rangeSize;
    uint16 offset = index;

    if ((pduId == NULL_PTR) || (bus == NULL_PTR))
    {
        return E_NOT_OK;
    }

    for (i = 0u; i < (uint16)(sizeof(GatewaySwc_RxMessageDiagRanges) / sizeof(GatewaySwc_RxMessageDiagRanges[0])); i++)
    {
        rangeSize = GATEWAYSWC_RANGE_SIZE(GatewaySwc_RxMessageDiagRanges[i].firstPduId,
                GatewaySwc_RxMessageDiagRanges[i].lastPduId);

        if (offset < rangeSize)
        {
            *pduId = (PduIdType)((uint16)GatewaySwc_RxMessageDiagRanges[i].firstPduId + offset);
            *bus = GatewaySwc_RxMessageDiagRanges[i].bus;
            return E_OK;
        }

        offset = (uint16)(offset - rangeSize);
    }

    return E_NOT_OK;
}

static Std_ReturnType GatewaySwc_GetSignalDiagConfig(uint16 index, Com_SignalIdType *signalId, GatewaySwc_BusType *bus)
{
    uint16 i;
    uint16 rangeSize;
    uint16 offset = index;

    if ((signalId == NULL_PTR) || (bus == NULL_PTR))
    {
        return E_NOT_OK;
    }

    for (i = 0u; i < (uint16)(sizeof(GatewaySwc_EthSignalRanges) / sizeof(GatewaySwc_EthSignalRanges[0])); i++)
    {
        rangeSize = GATEWAYSWC_RANGE_SIZE(GatewaySwc_EthSignalRanges[i].firstSignalId,
                GatewaySwc_EthSignalRanges[i].lastSignalId);

        if (offset < rangeSize)
        {
            *signalId = (Com_SignalIdType)((uint16)GatewaySwc_EthSignalRanges[i].firstSignalId + offset);
            *bus = GatewaySwc_EthSignalRanges[i].bus;
            return E_OK;
        }

        offset = (uint16)(offset - rangeSize);
    }

    return E_NOT_OK;
}

static void GatewaySwc_ResetEthFrame(uint16 *len, GatewaySwc_BusType bus)
{
    *len = 0u;

    GatewaySwc_AppendU8(len, GATEWAYSWC_MAGIC0);
    GatewaySwc_AppendU8(len, GATEWAYSWC_MAGIC1);
    GatewaySwc_AppendU8(len, GATEWAYSWC_MAGIC2);
    GatewaySwc_AppendU8(len, GATEWAYSWC_FRAME_SUMMARY);

    GatewaySwc_AppendU32(len, GatewaySwc_Status.mainCycles);
    GatewaySwc_AppendU8(len, (uint8)bus);
    GatewaySwc_AppendU8(len, 0u);
    GatewaySwc_AppendU8(len, 0u);
    GatewaySwc_AppendU8(len, 0u);
}

static void GatewaySwc_FlushEthFrame(uint16 *len)
{
    if (*len <= GATEWAYSWC_HEADER_LEN)
    {
        *len = 0u;
        return;
    }

    GatewaySwc_Status.ethLastPayloadLength = *len;
    if (GatewaySwc_QueueEthTx(GATEWAYSWC_ETH_TX_KIND_SUMMARY,
            (SoAd_SoConIdType)GATEWAYSWC_ETH_SOCON_ID,
            NULL_PTR,
            GatewaySwc_EthBuffer,
            *len) == FALSE)
    {
        GatewaySwc_Status.ethLastOpenResult = 0u;
        GatewaySwc_Status.ethLastSoAdResult = SOAD_NOT_OK;
        GatewaySwc_Status.ethLastTransmitOk = 0u;
        GatewaySwc_Status.ethFramesFailed++;
    }

    *len = 0u;
}

void GatewaySwc_ReportDtcTransition(Dem_DTCType dtc, Dem_UdsStatusByteType status)
{
    uint8 nextHead;

    if (GatewaySwc_EnterDtcQueueCritical() == FALSE)
    {
        GATEWAYSWC_DEBUG_INC(GatewaySwc_DebugDtcDropped);
        return;
    }

    nextHead = (uint8)((GatewaySwc_DtcTransitionHead + 1u) % GATEWAYSWC_DTC_TRANSITION_QUEUE_SIZE);
    if (nextHead == GatewaySwc_DtcTransitionTail)
    {
        GatewaySwc_Status.ethFramesFailed++;
        GATEWAYSWC_DEBUG_INC(GatewaySwc_DebugDtcDropped);
        GatewaySwc_UpdateDtcDebugQueueState();
        GatewaySwc_ExitDtcQueueCritical();
        return;
    }

    GatewaySwc_DtcTransitionQueue[GatewaySwc_DtcTransitionHead].dtc = dtc & 0x00FFFFFFu;
    GatewaySwc_DtcTransitionQueue[GatewaySwc_DtcTransitionHead].status = status;
    __dsync();
    GatewaySwc_DtcTransitionHead = nextHead;
    GatewaySwc_UpdateDtcDebugQueueState();
    GatewaySwc_ExitDtcQueueCritical();
}

void GatewaySwc_OnDemEventCleared(Dem_EventIdType eventId)
{
    if ((eventId >= DEM_EVENT_ID_GATEWAY_RX_MESSAGE_TIMEOUT_FIRST) &&
        (eventId <= DEM_EVENT_ID_GATEWAY_RX_MESSAGE_TIMEOUT_LAST))
    {
        uint16 index = (uint16)(eventId - DEM_EVENT_ID_GATEWAY_RX_MESSAGE_TIMEOUT_FIRST);

        if (index < (uint16)GATEWAYSWC_RX_MESSAGE_DIAG_COUNT)
        {
            GatewaySwc_DemMessageTimeoutState[index] = GATEWAYSWC_DEM_STATE_UNKNOWN;
        }
    }
}

static void GatewaySwc_ProcessCore0Async(void)
{
    GatewaySwc_ProcessEthTxResults();
    GatewaySwc_ProcessEthRxQueue();
}

static void GatewaySwc_ProcessEthTxResults(void)
{
    GatewaySwc_EthTxResultType result;

    while (GatewaySwc_PopEthTxResult(&result) != FALSE)
    {
        GatewaySwc_ApplyEthTxResult(&result);
    }
}

static void GatewaySwc_ProcessEthRxQueue(void)
{
    GatewaySwc_EthRxJobType job;

    while (GatewaySwc_PopEthRx(&job) != FALSE)
    {
        GatewaySwc_HandleEthRxMessage(job.soConId,
                (job.hasRemoteAddr != 0u) ? &job.remoteAddr : NULL_PTR,
                job.data,
                job.len);
    }
}

static void GatewaySwc_ProcessEthTxQueueCore2(void)
{
    GatewaySwc_EthTxJobType job;
    uint8 openResult;
    uint8 budget = GATEWAYSWC_ETH_TX_DRAIN_BUDGET;
    sint32 result;

    while ((budget > 0u) && (GatewaySwc_PopEthTx(&job) != FALSE))
    {
        openResult = 0u;

        if (job.kind == GATEWAYSWC_ETH_TX_KIND_MCU_STATUS)
        {
            result = GatewaySwc_Core2TransmitMcuStatus(&job);
        }
        else
        {
            result = (sint32)GatewaySwc_Core2TransmitSoAd(&job, &openResult);
        }

        (void)GatewaySwc_QueueEthTxResult(job.kind, openResult, job.len, result);
        budget--;
    }
}

static boolean GatewaySwc_GetEthTxCodingPduId(uint8 kind, PduIdType *pduId)
{
    if (pduId == NULL_PTR)
    {
        return FALSE;
    }

    switch (kind)
    {
        case GATEWAYSWC_ETH_TX_KIND_SUMMARY:
            *pduId = CODINGAPP_TX_PDU_ETH_SUMMARY;
            break;
        case GATEWAYSWC_ETH_TX_KIND_DTC_TRANSITION:
            *pduId = CODINGAPP_TX_PDU_ETH_DTC_TRANSITION;
            break;
        case GATEWAYSWC_ETH_TX_KIND_MCU_STATUS:
            *pduId = CODINGAPP_TX_PDU_ETH_MCU_STATUS;
            break;
        case GATEWAYSWC_ETH_TX_KIND_AI_MODEL:
            *pduId = CODINGAPP_TX_PDU_ETH_AI_MODEL;
            break;
        case GATEWAYSWC_ETH_TX_KIND_CPU_PERF:
            *pduId = CODINGAPP_TX_PDU_ETH_CPU_PERF;
            break;
        case GATEWAYSWC_ETH_TX_KIND_VEHICLESTATE:
            *pduId = CODINGAPP_TX_PDU_ETH_VEHICLESTATE;
            break;
        default:
            return FALSE;
    }

    return TRUE;
}

static boolean GatewaySwc_IsEthTxKindEnabled(uint8 kind)
{
    PduIdType codingPduId;

    if (GatewaySwc_GetEthTxCodingPduId(kind, &codingPduId) == FALSE)
    {
        return TRUE;
    }

    return CodingApp_IsTxPduEnabled(codingPduId);
}

static uint8 GatewaySwc_QueueEthTx(uint8 kind,
        SoAd_SoConIdType soConId,
        const TcpIp_SockAddrType *remoteAddr,
        const uint8 *data,
        uint16 len)
{
    GatewaySwc_EthTxJobType *job;
    uint8 nextHead;
    uint16 i;

    if ((data == NULL_PTR) || (len == 0u) || (len > GATEWAYSWC_ETH_MAX_PAYLOAD))
    {
        GATEWAYSWC_DEBUG_INC(GatewaySwc_DebugEthTxQueueDropped);
        return FALSE;
    }

    if (GatewaySwc_IsEthTxKindEnabled(kind) == FALSE)
    {
        /* Coding-disabled frames are intentionally suppressed, not failed. */
        return TRUE;
    }

    if (GatewaySwc_EnterCrossCoreCritical() == FALSE)
    {
        GATEWAYSWC_DEBUG_INC(GatewaySwc_DebugEthTxQueueDropped);
        return FALSE;
    }

    nextHead = (uint8)((GatewaySwc_EthTxHead + 1u) % GATEWAYSWC_ETH_TX_QUEUE_SIZE);
    if (nextHead == GatewaySwc_EthTxTail)
    {
        GATEWAYSWC_DEBUG_INC(GatewaySwc_DebugEthTxQueueDropped);
        GatewaySwc_ExitCrossCoreCritical();
        return FALSE;
    }

    job = &GatewaySwc_EthTxQueue[GatewaySwc_EthTxHead];
    job->kind = kind;
    job->soConId = soConId;
    job->hasRemoteAddr = (remoteAddr != NULL_PTR) ? 1u : 0u;
    if (remoteAddr != NULL_PTR)
    {
        job->remoteAddr = *remoteAddr;
    }
    else
    {
        job->remoteAddr.addr = 0u;
        job->remoteAddr.port = 0u;
    }
    job->len = len;
    for (i = 0u; i < len; i++)
    {
        job->data[i] = data[i];
    }

    __dsync();
    GatewaySwc_EthTxHead = nextHead;
    GatewaySwc_ExitCrossCoreCritical();

    return TRUE;
}

static uint8 GatewaySwc_PopEthTx(GatewaySwc_EthTxJobType *job)
{
    uint8 popped = FALSE;

    if (job == NULL_PTR)
    {
        return FALSE;
    }

    if (GatewaySwc_EnterCrossCoreCritical() == FALSE)
    {
        return FALSE;
    }

    if (GatewaySwc_EthTxTail != GatewaySwc_EthTxHead)
    {
        *job = GatewaySwc_EthTxQueue[GatewaySwc_EthTxTail];
        GatewaySwc_EthTxTail =
            (uint8)((GatewaySwc_EthTxTail + 1u) % GATEWAYSWC_ETH_TX_QUEUE_SIZE);
        popped = TRUE;
    }

    GatewaySwc_ExitCrossCoreCritical();

    return popped;
}

static uint8 GatewaySwc_QueueEthTxResult(uint8 kind,
        uint8 openResult,
        uint16 len,
        sint32 result)
{
    GatewaySwc_EthTxResultType *entry;
    uint8 nextHead;

    if (GatewaySwc_EnterCrossCoreCritical() == FALSE)
    {
        GATEWAYSWC_DEBUG_INC(GatewaySwc_DebugEthTxResultQueueDropped);
        return FALSE;
    }

    nextHead = (uint8)((GatewaySwc_EthTxResultHead + 1u) % GATEWAYSWC_ETH_TX_RESULT_QUEUE_SIZE);
    if (nextHead == GatewaySwc_EthTxResultTail)
    {
        GATEWAYSWC_DEBUG_INC(GatewaySwc_DebugEthTxResultQueueDropped);
        GatewaySwc_ExitCrossCoreCritical();
        return FALSE;
    }

    entry = &GatewaySwc_EthTxResultQueue[GatewaySwc_EthTxResultHead];
    entry->kind = kind;
    entry->openResult = openResult;
    entry->len = len;
    entry->result = result;

    __dsync();
    GatewaySwc_EthTxResultHead = nextHead;
    GatewaySwc_ExitCrossCoreCritical();

    return TRUE;
}

static uint8 GatewaySwc_PopEthTxResult(GatewaySwc_EthTxResultType *result)
{
    uint8 popped = FALSE;

    if (result == NULL_PTR)
    {
        return FALSE;
    }

    if (GatewaySwc_EnterCrossCoreCritical() == FALSE)
    {
        return FALSE;
    }

    if (GatewaySwc_EthTxResultTail != GatewaySwc_EthTxResultHead)
    {
        *result = GatewaySwc_EthTxResultQueue[GatewaySwc_EthTxResultTail];
        GatewaySwc_EthTxResultTail =
            (uint8)((GatewaySwc_EthTxResultTail + 1u) % GATEWAYSWC_ETH_TX_RESULT_QUEUE_SIZE);
        popped = TRUE;
    }

    GatewaySwc_ExitCrossCoreCritical();

    return popped;
}

static uint8 GatewaySwc_QueueEthRx(uint8 soConId,
        const TcpIp_SockAddrType *remoteAddr,
        const uint8 *data,
        uint16 len)
{
    GatewaySwc_EthRxJobType *job;
    uint8 nextHead;
    uint16 copyLen;
    uint16 i;

    if ((data == NULL_PTR) || (len == 0u))
    {
        GATEWAYSWC_DEBUG_INC(GatewaySwc_DebugEthRxQueueDropped);
        return FALSE;
    }

    copyLen = len;
    if (copyLen > GATEWAYSWC_ETH_RX_QUEUE_MAX_PAYLOAD)
    {
        copyLen = GATEWAYSWC_ETH_RX_QUEUE_MAX_PAYLOAD;
        GATEWAYSWC_DEBUG_INC(GatewaySwc_EthRxCaptureTruncatedCounter);
    }

    if (GatewaySwc_EnterCrossCoreCritical() == FALSE)
    {
        GATEWAYSWC_DEBUG_INC(GatewaySwc_DebugEthRxQueueDropped);
        return FALSE;
    }

    nextHead = (uint8)((GatewaySwc_EthRxHead + 1u) % GATEWAYSWC_ETH_RX_QUEUE_SIZE);
    if (nextHead == GatewaySwc_EthRxTail)
    {
        GATEWAYSWC_DEBUG_INC(GatewaySwc_DebugEthRxQueueDropped);
        GatewaySwc_ExitCrossCoreCritical();
        return FALSE;
    }

    job = &GatewaySwc_EthRxQueue[GatewaySwc_EthRxHead];
    job->soConId = soConId;
    job->hasRemoteAddr = (remoteAddr != NULL_PTR) ? 1u : 0u;
    if (remoteAddr != NULL_PTR)
    {
        job->remoteAddr = *remoteAddr;
    }
    else
    {
        job->remoteAddr.addr = 0u;
        job->remoteAddr.port = 0u;
    }
    job->len = copyLen;
    for (i = 0u; i < copyLen; i++)
    {
        job->data[i] = data[i];
    }

    __dsync();
    GatewaySwc_EthRxHead = nextHead;
    GatewaySwc_ExitCrossCoreCritical();

    return TRUE;
}

static uint8 GatewaySwc_PopEthRx(GatewaySwc_EthRxJobType *job)
{
    uint8 popped = FALSE;

    if (job == NULL_PTR)
    {
        return FALSE;
    }

    if (GatewaySwc_EnterCrossCoreCritical() == FALSE)
    {
        return FALSE;
    }

    if (GatewaySwc_EthRxTail != GatewaySwc_EthRxHead)
    {
        *job = GatewaySwc_EthRxQueue[GatewaySwc_EthRxTail];
        GatewaySwc_EthRxTail =
            (uint8)((GatewaySwc_EthRxTail + 1u) % GATEWAYSWC_ETH_RX_QUEUE_SIZE);
        popped = TRUE;
    }

    GatewaySwc_ExitCrossCoreCritical();

    return popped;
}

static void GatewaySwc_ApplyEthTxResult(const GatewaySwc_EthTxResultType *result)
{
    if (result == NULL_PTR)
    {
        return;
    }

    GatewaySwc_Status.ethLastPayloadLength = result->len;

    if (result->kind == GATEWAYSWC_ETH_TX_KIND_MCU_STATUS)
    {
        GatewaySwc_McuStatusTxPending = 0u;
        if (result->result == (sint32)result->len)
        {
            GatewaySwc_McuStatusSequenceCounter++;
            GatewaySwc_McuStatusTxCounter++;
            GatewaySwc_McuStatusStatus = GATEWAYSWC_MCU_STATUS_SOCKET_READY;
            GatewaySwc_Status.ethLastTransmitOk = 1u;
            GatewaySwc_Status.ethFramesSent++;
        }
        else
        {
            GatewaySwc_McuStatusStatus = GATEWAYSWC_MCU_STATUS_TX_ERROR;
            GatewaySwc_Status.ethLastTransmitOk = 0u;
            GatewaySwc_Status.ethFramesFailed++;
        }
        return;
    }

    GatewaySwc_Status.ethLastOpenResult = result->openResult;
    GatewaySwc_Status.ethLastSoAdResult = (uint8)result->result;

    if (result->kind == GATEWAYSWC_ETH_TX_KIND_DTC_TRANSITION)
    {
        GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_DebugDtcLastOpenResult, result->openResult);
        GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_DebugDtcLastTxResult, (uint8)result->result);
    }

    if ((SoAd_ReturnType)result->result == SOAD_OK)
    {
        GatewaySwc_Status.ethLastTransmitOk = 1u;
        GatewaySwc_Status.ethFramesSent++;
    }
    else
    {
        GatewaySwc_Status.ethLastTransmitOk = 0u;
        GatewaySwc_Status.ethFramesFailed++;
    }
}

static SoAd_ReturnType GatewaySwc_Core2TransmitSoAd(const GatewaySwc_EthTxJobType *job,
        uint8 *openResult)
{
    const TcpIp_SockAddrType *remoteAddr;

    if ((job == NULL_PTR) || (openResult == NULL_PTR))
    {
        return SOAD_NOT_OK;
    }

    *openResult = 0u;

    if (GatewaySwc_IsEthComActive() == FALSE)
    {
        return SOAD_NOT_OK;
    }

    *openResult = SoAd_OpenSoCon(job->soConId);
    remoteAddr = (job->hasRemoteAddr != 0u) ? &job->remoteAddr : NULL_PTR;

    return GatewaySwc_RequestSoAdIfTransmit(job->soConId,
            remoteAddr,
            job->data,
            job->len);
}

static sint32 GatewaySwc_Core2TransmitMcuStatus(const GatewaySwc_EthTxJobType *job)
{
#if (GATEWAYSWC_MCU_STATUS_UDP_ENABLE == STD_ON)
    TcpIp_SockAddrType remoteAddr;

    if (job == NULL_PTR)
    {
        return -1;
    }

    if (TcpIp_IsLinkAvailable() == 0u)
    {
        GatewaySwc_McuStatusCloseSocket();
        return -1;
    }

    if ((GatewaySwc_McuStatusSocket == TCPIP_INVALID_SOCKET) ||
            (TcpIp_IsSocketOpen(GatewaySwc_McuStatusSocket) == 0u))
    {
        GatewaySwc_McuStatusSocket = TCPIP_INVALID_SOCKET;
        GatewaySwc_McuStatusOpenSocket();
    }

    if ((GatewaySwc_McuStatusSocket == TCPIP_INVALID_SOCKET) ||
            (TcpIp_IsSocketOpen(GatewaySwc_McuStatusSocket) == 0u))
    {
        return -1;
    }

    if (job->hasRemoteAddr != 0u)
    {
        remoteAddr = job->remoteAddr;
    }
    else
    {
        remoteAddr.addr = GATEWAYSWC_MCU_STATUS_UDP_BROADCAST_ADDR;
        remoteAddr.port = GATEWAYSWC_MCU_STATUS_UDP_PORT;
    }

    return GatewaySwc_RequestTcpIpSendTo(GatewaySwc_McuStatusSocket,
            &remoteAddr,
            job->data,
            job->len);
#else
    (void)job;
    return -1;
#endif
}

static uint8 GatewaySwc_EnterCrossCoreCritical(void)
{
    uint32 coreIndex;

    coreIndex = (uint32)IfxCpu_getCoreIndex();

    if (coreIndex >= GATEWAYSWC_CPU_CORE_COUNT)
    {
        coreIndex = 0u;
    }

    GatewaySwc_CrossCoreIrqState[coreIndex] = IfxCpu_disableInterrupts();

    if (IfxCpu_setSpinLock(&GatewaySwc_CrossCoreLock, GATEWAYSWC_CROSS_CORE_LOCK_TIMEOUT) != FALSE)
    {
        GatewaySwc_CrossCoreLockOwned[coreIndex] = TRUE;
        __dsync();
    }
    else
    {
        GATEWAYSWC_DEBUG_INC(GatewaySwc_DebugCrossCoreLockTimeout);
        IfxCpu_restoreInterrupts(GatewaySwc_CrossCoreIrqState[coreIndex]);
        return FALSE;
    }

    return TRUE;
}

static void GatewaySwc_ExitCrossCoreCritical(void)
{
    uint32 coreIndex;

    coreIndex = (uint32)IfxCpu_getCoreIndex();

    if (coreIndex >= GATEWAYSWC_CPU_CORE_COUNT)
    {
        coreIndex = 0u;
    }

    __dsync();

    if (GatewaySwc_CrossCoreLockOwned[coreIndex] != FALSE)
    {
        GatewaySwc_CrossCoreLockOwned[coreIndex] = FALSE;
        IfxCpu_resetSpinLock(&GatewaySwc_CrossCoreLock);
    }

    IfxCpu_restoreInterrupts(GatewaySwc_CrossCoreIrqState[coreIndex]);
}

static uint8 GatewaySwc_EnterDtcQueueCritical(void)
{
    uint32 coreIndex;

    coreIndex = (uint32)IfxCpu_getCoreIndex();

    if (coreIndex >= GATEWAYSWC_CPU_CORE_COUNT)
    {
        coreIndex = 0u;
    }

    GatewaySwc_DtcQueueIrqState[coreIndex] = IfxCpu_disableInterrupts();

    if (IfxCpu_setSpinLock(&GatewaySwc_DtcQueueLock, GATEWAYSWC_DTC_QUEUE_LOCK_TIMEOUT) != FALSE)
    {
        GatewaySwc_DtcQueueLockOwned[coreIndex] = TRUE;
        __dsync();
    }
    else
    {
        GATEWAYSWC_DEBUG_INC(GatewaySwc_DebugDtcQueueLockTimeout);
        IfxCpu_restoreInterrupts(GatewaySwc_DtcQueueIrqState[coreIndex]);
        return FALSE;
    }

    return TRUE;
}

static void GatewaySwc_ExitDtcQueueCritical(void)
{
    uint32 coreIndex;

    coreIndex = (uint32)IfxCpu_getCoreIndex();

    if (coreIndex >= GATEWAYSWC_CPU_CORE_COUNT)
    {
        coreIndex = 0u;
    }

    __dsync();

    if (GatewaySwc_DtcQueueLockOwned[coreIndex] != FALSE)
    {
        GatewaySwc_DtcQueueLockOwned[coreIndex] = FALSE;
        IfxCpu_resetSpinLock(&GatewaySwc_DtcQueueLock);
    }

    IfxCpu_restoreInterrupts(GatewaySwc_DtcQueueIrqState[coreIndex]);
}

#if GATEWAYSWC_DEBUG_INSTRUMENTATION
static void GatewaySwc_UpdateDtcDebugQueueState(void)
{
    GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_DebugDtcQueueHead, GatewaySwc_DtcTransitionHead);
    GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_DebugDtcQueueTail, GatewaySwc_DtcTransitionTail);

    if (GatewaySwc_DtcTransitionHead >= GatewaySwc_DtcTransitionTail)
    {
        GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_DebugDtcQueueCount,
            (uint8)(GatewaySwc_DtcTransitionHead - GatewaySwc_DtcTransitionTail));
    }
    else
    {
        GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_DebugDtcQueueCount,
            (uint8)(GATEWAYSWC_DTC_TRANSITION_QUEUE_SIZE -
                    GatewaySwc_DtcTransitionTail +
                    GatewaySwc_DtcTransitionHead));
    }
}
#endif

static void GatewaySwc_FlushDtcTransitionQueue(void)
{
    GatewaySwc_DtcTransitionType transition;

    while (GatewaySwc_PopDtcTransition(&transition) != FALSE)
    {
        GatewaySwc_PublishDtcTransition(transition.dtc, transition.status);
        GATEWAYSWC_DEBUG_INC(GatewaySwc_DebugDtcFlushed);
    }
}

static uint8 GatewaySwc_PopDtcTransition(GatewaySwc_DtcTransitionType *transition)
{
    uint8 popped;

    if (transition == NULL_PTR)
    {
        return FALSE;
    }

    popped = FALSE;
    if (GatewaySwc_EnterDtcQueueCritical() == FALSE)
    {
        return FALSE;
    }

    if (GatewaySwc_DtcTransitionTail != GatewaySwc_DtcTransitionHead)
    {
        *transition = GatewaySwc_DtcTransitionQueue[GatewaySwc_DtcTransitionTail];
        GatewaySwc_DtcTransitionTail =
            (uint8)((GatewaySwc_DtcTransitionTail + 1u) % GATEWAYSWC_DTC_TRANSITION_QUEUE_SIZE);
        GatewaySwc_UpdateDtcDebugQueueState();
        popped = TRUE;
    }

    GatewaySwc_ExitDtcQueueCritical();

    return popped;
}

static void GatewaySwc_PublishDtcTransition(Dem_DTCType dtc, Dem_UdsStatusByteType status)
{
    uint8 *payload;

    payload = GatewaySwc_DtcTransitionPayload;
    GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_DebugDtcLastDtc, dtc & 0x00FFFFFFu);
    GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_DebugDtcLastStatus, status);

    payload[0] = GATEWAYSWC_MAGIC0;
    payload[1] = GATEWAYSWC_MAGIC1;
    payload[2] = GATEWAYSWC_MAGIC2;
    payload[3] = GATEWAYSWC_FRAME_DTC_TRANSITION;
    GatewaySwc_StoreU32(payload, 4u, GatewaySwc_Status.mainCycles);
    payload[8] = 0u;
    payload[9] = 0u;
    payload[10] = 0u;
    payload[11] = 0u;
    GatewaySwc_StoreU32(payload, 12u, dtc & 0x00FFFFFFu);
    payload[16] = status;

    GatewaySwc_Status.ethLastPayloadLength = GATEWAYSWC_DTC_TRANSITION_LEN;
    if (GatewaySwc_QueueEthTx(GATEWAYSWC_ETH_TX_KIND_DTC_TRANSITION,
            (SoAd_SoConIdType)GATEWAYSWC_ETH_SOCON_ID,
            NULL_PTR,
            payload,
            GATEWAYSWC_DTC_TRANSITION_LEN) == FALSE)
    {
        GatewaySwc_Status.ethLastOpenResult = 0u;
        GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_DebugDtcLastOpenResult, 0u);
        GATEWAYSWC_DEBUG_ASSIGN(GatewaySwc_DebugDtcLastTxResult, SOAD_NOT_OK);
        GatewaySwc_Status.ethLastSoAdResult = SOAD_NOT_OK;
        GatewaySwc_Status.ethLastTransmitOk = 0u;
        GatewaySwc_Status.ethFramesFailed++;
    }
}

static void GatewaySwc_AppendU8(uint16 *len, uint8 value)
{
    if (*len < GATEWAYSWC_ETH_MAX_PAYLOAD)
    {
        GatewaySwc_EthBuffer[*len] = value;
        (*len)++;
    }
}

static void GatewaySwc_AppendU16(uint16 *len, uint16 value)
{
    GatewaySwc_AppendU8(len, (uint8)((value >> 8u) & 0xFFu));
    GatewaySwc_AppendU8(len, (uint8)(value & 0xFFu));
}

static void GatewaySwc_AppendU32(uint16 *len, uint32 value)
{
    GatewaySwc_AppendU8(len, (uint8)((value >> 24u) & 0xFFu));
    GatewaySwc_AppendU8(len, (uint8)((value >> 16u) & 0xFFu));
    GatewaySwc_AppendU8(len, (uint8)((value >> 8u) & 0xFFu));
    GatewaySwc_AppendU8(len, (uint8)(value & 0xFFu));
}

static void GatewaySwc_AppendF32(uint16 *len, float32 value)
{
    union
    {
        float32 f;
        uint32 u;
    } converted;

    converted.f = value;
    GatewaySwc_AppendU32(len, converted.u);
}

static void GatewaySwc_StoreU16(uint8 *buffer, uint16 offset, uint16 value)
{
    buffer[offset] = (uint8)((value >> 8u) & 0xFFu);
    buffer[(uint16)(offset + 1u)] = (uint8)(value & 0xFFu);
}

static void GatewaySwc_StoreS16(uint8 *buffer, uint16 offset, sint16 value)
{
    GatewaySwc_StoreU16(buffer, offset, (uint16)value);
}

static void GatewaySwc_StoreU32(uint8 *buffer, uint16 offset, uint32 value)
{
    buffer[offset] = (uint8)((value >> 24u) & 0xFFu);
    buffer[(uint16)(offset + 1u)] = (uint8)((value >> 16u) & 0xFFu);
    buffer[(uint16)(offset + 2u)] = (uint8)((value >> 8u) & 0xFFu);
    buffer[(uint16)(offset + 3u)] = (uint8)(value & 0xFFu);
}

static void GatewaySwc_StoreU64(uint8 *buffer, uint16 offset, uint64 value)
{
    buffer[offset] = (uint8)((value >> 56u) & 0xFFu);
    buffer[(uint16)(offset + 1u)] = (uint8)((value >> 48u) & 0xFFu);
    buffer[(uint16)(offset + 2u)] = (uint8)((value >> 40u) & 0xFFu);
    buffer[(uint16)(offset + 3u)] = (uint8)((value >> 32u) & 0xFFu);
    buffer[(uint16)(offset + 4u)] = (uint8)((value >> 24u) & 0xFFu);
    buffer[(uint16)(offset + 5u)] = (uint8)((value >> 16u) & 0xFFu);
    buffer[(uint16)(offset + 6u)] = (uint8)((value >> 8u) & 0xFFu);
    buffer[(uint16)(offset + 7u)] = (uint8)(value & 0xFFu);
}

static Std_ReturnType GatewaySwc_SendU32(Com_SignalIdType signalId, uint32 value)
{
    Std_ReturnType ret;

    ret = GatewaySwc_RequestComSendSignal(signalId, &value);

    if (ret == E_OK)
    {
        GatewaySwc_Status.sendSignalOk++;
        GatewaySwc_Status.generatedSignals++;
    }
    else
    {
        GatewaySwc_Status.sendSignalFailed++;
    }

    return ret;
}

static Std_ReturnType GatewaySwc_ReceiveU32(Com_SignalIdType signalId, uint32 *value)
{
    Std_ReturnType ret;

    if (value == NULL_PTR)
    {
        return E_NOT_OK;
    }

    ret = Com_ReceiveSignal(signalId, value);

    if (ret != E_OK)
    {
        GatewaySwc_Status.receiveSignalFailed++;
    }

    return ret;
}
