#include "CanSM.h"
#include "CanIf.h"

#define CANSM_BOR_L1_TICKS              200u
#define CANSM_BOR_L2_TICKS              1000u
#define CANSM_BOR_CHECK_TICKS           20u
#define CANSM_BOR_L1_TO_L2_THRESHOLD    3u
#define CANSM_BOR_MAX_TOTAL_COUNTER     10u

typedef struct
{
    CanSM_StateType state;
    CanSM_ComModeType requestedMode;
    CanSM_ComModeType currentMode;
    uint16 timer;
    uint8 busOffCounter;
    uint8 initialized;
} CanSM_ChannelType;

static CanSM_ChannelType CanSM_Channel[CAN_NUM_CONTROLLERS];

static Std_ReturnType CanSM_ApplyMode(uint8 ControllerId, CanSM_ComModeType Mode)
{
    Std_ReturnType ret;

    if (ControllerId >= CAN_NUM_CONTROLLERS)
    {
        return E_NOT_OK;
    }

    switch (Mode)
    {
        case CANSM_COMM_NO_COMMUNICATION:
            (void)CanIf_SetPduMode(ControllerId, CANIF_PDU_MODE_OFFLINE);
            ret = Can_SetControllerMode(ControllerId, CAN_SLEEP);

            if ((ret == E_OK) &&
                ((Can_GetControllerMode(ControllerId) == CAN_SLEEP) ||
                 (Can_GetControllerMode(ControllerId) == CAN_UNINIT)))
            {
                CanSM_Channel[ControllerId].state = CANSM_BSM_NO_COMMUNICATION;
                CanSM_Channel[ControllerId].currentMode = CANSM_COMM_NO_COMMUNICATION;
                CanSM_ModeChangeNotification(ControllerId, CANSM_COMM_NO_COMMUNICATION);
                return E_OK;
            }

            break;

        case CANSM_COMM_SILENT_COMMUNICATION:
            ret = Can_SetControllerMode(ControllerId, CAN_READY);

            if ((ret == E_OK) && (Can_GetControllerMode(ControllerId) == CAN_READY))
            {
                (void)CanIf_SetPduMode(ControllerId, CANIF_PDU_MODE_RX_ONLINE);
                CanSM_Channel[ControllerId].state = CANSM_BSM_SILENT_COMMUNICATION;
                CanSM_Channel[ControllerId].currentMode = CANSM_COMM_SILENT_COMMUNICATION;
                CanSM_ModeChangeNotification(ControllerId, CANSM_COMM_SILENT_COMMUNICATION);
                return E_OK;
            }

            break;

        case CANSM_COMM_FULL_COMMUNICATION:
            ret = Can_SetControllerMode(ControllerId, CAN_READY);

            if ((ret == E_OK) && (Can_GetControllerMode(ControllerId) == CAN_READY))
            {
                (void)CanIf_SetPduMode(ControllerId, CANIF_PDU_MODE_ONLINE);
                CanSM_Channel[ControllerId].state = CANSM_BSM_FULL_COMMUNICATION;
                CanSM_Channel[ControllerId].currentMode = CANSM_COMM_FULL_COMMUNICATION;
                CanSM_ModeChangeNotification(ControllerId, CANSM_COMM_FULL_COMMUNICATION);
                return E_OK;
            }

            break;

        default:
            break;
    }

    CanSM_Channel[ControllerId].state = CANSM_BSM_FAILED;
    CanSM_FailedNotification(ControllerId);
    return E_NOT_OK;
}

void CanSM_Init(void)
{
    uint8 i;

    for (i = 0u; i < CAN_NUM_CONTROLLERS; i++)
    {
        CanSM_Channel[i].state = CANSM_BSM_NO_COMMUNICATION;
        CanSM_Channel[i].requestedMode = CANSM_COMM_NO_COMMUNICATION;
        CanSM_Channel[i].currentMode = CANSM_COMM_NO_COMMUNICATION;
        CanSM_Channel[i].timer = 0u;
        CanSM_Channel[i].busOffCounter = 0u;
        CanSM_Channel[i].initialized = TRUE;

        (void)CanIf_SetPduMode(i, CANIF_PDU_MODE_OFFLINE);
    }
}

Std_ReturnType CanSM_RequestComMode(uint8 ControllerId, CanSM_ComModeType ComMode)
{
    if ((ControllerId >= CAN_NUM_CONTROLLERS) ||
        (CanSM_Channel[ControllerId].initialized == FALSE))
    {
        return E_NOT_OK;
    }

    if (ComMode > CANSM_COMM_FULL_COMMUNICATION)
    {
        return E_NOT_OK;
    }

    CanSM_Channel[ControllerId].requestedMode = ComMode;

    if ((CanSM_Channel[ControllerId].state == CANSM_BSM_BUS_OFF_CHECK) ||
        (CanSM_Channel[ControllerId].state == CANSM_BSM_BUS_OFF_RECOVERY_L1) ||
        (CanSM_Channel[ControllerId].state == CANSM_BSM_BUS_OFF_RECOVERY_L2))
    {
        return E_OK;
    }

    return CanSM_ApplyMode(ControllerId, ComMode);
}

Std_ReturnType CanSM_GetCurrentComMode(uint8 ControllerId, CanSM_ComModeType* ComMode)
{
    if ((ControllerId >= CAN_NUM_CONTROLLERS) ||
        (ComMode == NULL_PTR) ||
        (CanSM_Channel[ControllerId].initialized == FALSE))
    {
        return E_NOT_OK;
    }

    *ComMode = CanSM_Channel[ControllerId].currentMode;
    return E_OK;
}

CanSM_StateType CanSM_GetState(uint8 ControllerId)
{
    if ((ControllerId >= CAN_NUM_CONTROLLERS) ||
        (CanSM_Channel[ControllerId].initialized == FALSE))
    {
        return CANSM_BSM_UNINIT;
    }

    return CanSM_Channel[ControllerId].state;
}

void CanSM_ControllerBusOff(uint8 ControllerId)
{
    if ((ControllerId >= CAN_NUM_CONTROLLERS) ||
        (CanSM_Channel[ControllerId].initialized == FALSE))
    {
        return;
    }

    CanSM_Channel[ControllerId].busOffCounter++;
    CanSM_Channel[ControllerId].currentMode = CANSM_COMM_NO_COMMUNICATION;
    CanSM_Channel[ControllerId].state = CANSM_BSM_BUS_OFF_CHECK;
    CanSM_Channel[ControllerId].timer = CANSM_BOR_CHECK_TICKS;

    (void)CanIf_SetPduMode(ControllerId, CANIF_PDU_MODE_OFFLINE);
    (void)Can_SetControllerMode(ControllerId, CAN_BUS_OFF);

    CanSM_BusOffBeginNotification(ControllerId);
}

static void CanSM_HandleBusOff(uint8 ControllerId)
{
    if (CanSM_Channel[ControllerId].timer > 0u)
    {
        CanSM_Channel[ControllerId].timer--;
        return;
    }

    if (CanSM_Channel[ControllerId].busOffCounter >= CANSM_BOR_MAX_TOTAL_COUNTER)
    {
        CanSM_Channel[ControllerId].state = CANSM_BSM_FAILED;
        CanSM_FailedNotification(ControllerId);
        return;
    }

    if (CanSM_Channel[ControllerId].state == CANSM_BSM_BUS_OFF_CHECK)
    {
        if (CanSM_Channel[ControllerId].busOffCounter <= CANSM_BOR_L1_TO_L2_THRESHOLD)
        {
            CanSM_Channel[ControllerId].state = CANSM_BSM_BUS_OFF_RECOVERY_L1;
            CanSM_Channel[ControllerId].timer = CANSM_BOR_L1_TICKS;
        }
        else
        {
            CanSM_Channel[ControllerId].state = CANSM_BSM_BUS_OFF_RECOVERY_L2;
            CanSM_Channel[ControllerId].timer = CANSM_BOR_L2_TICKS;
        }

        return;
    }

    if ((CanSM_Channel[ControllerId].state == CANSM_BSM_BUS_OFF_RECOVERY_L1) ||
        (CanSM_Channel[ControllerId].state == CANSM_BSM_BUS_OFF_RECOVERY_L2))
    {
        if (Can_SetControllerMode(ControllerId, CAN_READY) != E_OK)
        {
            CanSM_Channel[ControllerId].state = CANSM_BSM_FAILED;
            CanSM_FailedNotification(ControllerId);
            return;
        }

        if (Can_GetControllerMode(ControllerId) != CAN_READY)
        {
            CanSM_Channel[ControllerId].state = CANSM_BSM_FAILED;
            CanSM_FailedNotification(ControllerId);
            return;
        }

        CanSM_BusOffEndNotification(ControllerId);

        if (CanSM_Channel[ControllerId].requestedMode == CANSM_COMM_FULL_COMMUNICATION)
        {
            (void)CanIf_SetPduMode(ControllerId, CANIF_PDU_MODE_ONLINE);
            CanSM_Channel[ControllerId].currentMode = CANSM_COMM_FULL_COMMUNICATION;
            CanSM_Channel[ControllerId].state = CANSM_BSM_FULL_COMMUNICATION;
            CanSM_ModeChangeNotification(ControllerId, CANSM_COMM_FULL_COMMUNICATION);
        }
        else if (CanSM_Channel[ControllerId].requestedMode == CANSM_COMM_SILENT_COMMUNICATION)
        {
            (void)CanIf_SetPduMode(ControllerId, CANIF_PDU_MODE_RX_ONLINE);
            CanSM_Channel[ControllerId].currentMode = CANSM_COMM_SILENT_COMMUNICATION;
            CanSM_Channel[ControllerId].state = CANSM_BSM_SILENT_COMMUNICATION;
            CanSM_ModeChangeNotification(ControllerId, CANSM_COMM_SILENT_COMMUNICATION);
        }
        else
        {
            (void)CanIf_SetPduMode(ControllerId, CANIF_PDU_MODE_OFFLINE);
            (void)Can_SetControllerMode(ControllerId, CAN_SLEEP);
            CanSM_Channel[ControllerId].currentMode = CANSM_COMM_NO_COMMUNICATION;
            CanSM_Channel[ControllerId].state = CANSM_BSM_NO_COMMUNICATION;
            CanSM_ModeChangeNotification(ControllerId, CANSM_COMM_NO_COMMUNICATION);
        }
    }
}

void CanSM_MainFunction(void)
{
    uint8 i;

    for (i = 0u; i < CAN_NUM_CONTROLLERS; i++)
    {
        if (CanSM_Channel[i].initialized == FALSE)
        {
            continue;
        }

        if ((CanSM_Channel[i].state == CANSM_BSM_BUS_OFF_CHECK) ||
            (CanSM_Channel[i].state == CANSM_BSM_BUS_OFF_RECOVERY_L1) ||
            (CanSM_Channel[i].state == CANSM_BSM_BUS_OFF_RECOVERY_L2))
        {
            CanSM_HandleBusOff(i);
        }
    }
}

__attribute__((weak)) void CanSM_BusOffBeginNotification(uint8 ControllerId)
{
    (void)ControllerId;
}

__attribute__((weak)) void CanSM_BusOffEndNotification(uint8 ControllerId)
{
    (void)ControllerId;
}

__attribute__((weak)) void CanSM_ModeChangeNotification(uint8 ControllerId, CanSM_ComModeType Mode)
{
    (void)ControllerId;
    (void)Mode;
}

__attribute__((weak)) void CanSM_FailedNotification(uint8 ControllerId)
{
    (void)ControllerId;
}
