#include "Com.h"
#include "PduR.h"
#include <string.h>

#define COM_TRUE  1u
#define COM_FALSE 0u


typedef struct
{
    PduIdType pduId;
    Com_IpduGroupIdType groupId;
    uint8 txMode;
    uint16 periodTicks;
    uint16 mdtTicks;
    uint8 repetitions;
    uint16 repetitionPeriodTicks;
    uint16 deadlineTicks;
    uint8 len;
    uint8 init[COM_MAX_IPDU_LEN];
} Com_TxIpduConfigType;

typedef struct
{
    PduIdType pduId;
    Com_IpduGroupIdType groupId;
    uint16 deadlineTicks;
    uint8 len;
    uint8 init[COM_MAX_IPDU_LEN];
} Com_RxIpduConfigType;

typedef struct
{
    Com_SignalIdType signalId;
    uint8 isTx;
    PduIdType pduId;
    uint16 bitPosition;
    uint8 bitSize;
    uint8 dataSize;
    uint8 hasUpdateBit;
    uint16 updateBitPosition;
    uint32 invalidValue;
    uint32 initValue;
} Com_SignalConfigType;

typedef struct
{
    uint8 buffer[COM_MAX_IPDU_LEN];
    uint8 active;
    uint8 dirty;
    uint8 txInProgress;
    uint16 periodTimer;
    uint16 mdtTimer;
    uint8 repetitionsLeft;
    uint16 repetitionTimer;
    uint16 deadlineTimer;
} Com_TxIpduRuntimeType;

typedef struct
{
    uint8 buffer[COM_MAX_IPDU_LEN];
    uint8 active;
    uint16 deadlineTimer;
    uint8 timeout;
} Com_RxIpduRuntimeType;

static const Com_TxIpduConfigType Com_TxIpduCfg[] =
{
    { COM_TX_PDU_VEHICLESTATE                                , COM_IPDU_GROUP_0, COM_TX_MODE_MIXED, 20u, 2u, 1u, 2u, 100u, 1u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_DISPLAYOUTTEMP                              , COM_IPDU_GROUP_0, COM_TX_MODE_MIXED, 20u, 2u, 1u, 2u, 100u, 4u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_STATUSBODYDATA1                             , COM_IPDU_GROUP_0, COM_TX_MODE_MIXED, 20u, 2u, 1u, 2u, 100u, 4u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_COMMANDDISPLAYSTATUS                        , COM_IPDU_GROUP_0, COM_TX_MODE_MIXED, 20u, 2u, 1u, 2u, 100u, 6u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_XCPREQUEST_7C8                              , COM_IPDU_GROUP_0, COM_TX_MODE_NONE, 0u, 2u, 1u, 2u, 100u, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_XCPREQUEST_7C6                              , COM_IPDU_GROUP_0, COM_TX_MODE_NONE, 0u, 2u, 1u, 2u, 100u, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_XCPREQUEST_7C4                              , COM_IPDU_GROUP_0, COM_TX_MODE_NONE, 0u, 2u, 1u, 2u, 100u, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_XCPREQUEST_7C2                              , COM_IPDU_GROUP_0, COM_TX_MODE_NONE, 0u, 2u, 1u, 2u, 100u, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_XCPREQUEST_7C0                              , COM_IPDU_GROUP_0, COM_TX_MODE_NONE, 0u, 2u, 1u, 2u, 100u, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_SDAT                                        , COM_IPDU_GROUP_0, COM_TX_MODE_MIXED, 20u, 2u, 1u, 2u, 100u, 7u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_NM3                                         , COM_IPDU_GROUP_0, COM_TX_MODE_MIXED, 20u, 2u, 1u, 2u, 100u, 1u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_LOADREQUEST                                 , COM_IPDU_GROUP_0, COM_TX_MODE_MIXED, 20u, 2u, 1u, 2u, 100u, 2u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_DIAGREQUEST_706                             , COM_IPDU_GROUP_0, COM_TX_MODE_NONE, 0u, 2u, 1u, 2u, 100u, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_DIAGREQUEST_704                             , COM_IPDU_GROUP_0, COM_TX_MODE_NONE, 0u, 2u, 1u, 2u, 100u, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_DIAGREQUEST_702                             , COM_IPDU_GROUP_0, COM_TX_MODE_NONE, 0u, 2u, 1u, 2u, 100u, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_DIAGREQUEST_700                             , COM_IPDU_GROUP_0, COM_TX_MODE_NONE, 0u, 2u, 1u, 2u, 100u, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_CANFD_INFOTAINMENTDATA1                                      , COM_IPDU_GROUP_0, COM_TX_MODE_MIXED, 20u, 2u, 1u, 2u, 100u, 12u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA2                                  , COM_IPDU_GROUP_0, COM_TX_MODE_MIXED, 20u, 2u, 1u, 2u, 100u, 6u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA1                                  , COM_IPDU_GROUP_0, COM_TX_MODE_MIXED, 20u, 2u, 1u, 2u, 100u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_CANFD_VEHICLESTATE                                           , COM_IPDU_GROUP_0, COM_TX_MODE_MIXED, 20u, 2u, 1u, 2u, 100u, 1u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_CANFD_NM3                                                    , COM_IPDU_GROUP_0, COM_TX_MODE_MIXED, 20u, 2u, 1u, 2u, 100u, 1u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_CANFD_SDAT                                                   , COM_IPDU_GROUP_0, COM_TX_MODE_MIXED, 20u, 2u, 1u, 2u, 100u, 7u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_CANFD_LIGHTDATA1                                             , COM_IPDU_GROUP_0, COM_TX_MODE_MIXED, 20u, 2u, 1u, 2u, 100u, 3u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_CANFD_POWERTRAINDATA2                                        , COM_IPDU_GROUP_0, COM_TX_MODE_MIXED, 20u, 2u, 1u, 2u, 100u, 16u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_CANFD_POWERTRAINDATA1                                        , COM_IPDU_GROUP_0, COM_TX_MODE_MIXED, 20u, 2u, 1u, 2u, 100u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_CANFD_BODYDATA1                                              , COM_IPDU_GROUP_0, COM_TX_MODE_MIXED, 20u, 2u, 1u, 2u, 100u, 20u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_CANFD_PDM1_DIAGREQUEST                                       , COM_IPDU_GROUP_0, COM_TX_MODE_NONE, 20u, 2u, 1u, 2u, 100u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_CANFD_PDM2_DIAGREQUEST                                       , COM_IPDU_GROUP_0, COM_TX_MODE_NONE, 20u, 2u, 1u, 2u, 100u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_CANFD_PDM3_DIAGREQUEST                                       , COM_IPDU_GROUP_0, COM_TX_MODE_NONE, 20u, 2u, 1u, 2u, 100u, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_CANFD_PDM4_DIAGREQUEST                                       , COM_IPDU_GROUP_0, COM_TX_MODE_NONE, 20u, 2u, 1u, 2u, 100u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_CANFD_COMMANDLOAD_PDM1                                       , COM_IPDU_GROUP_0, COM_TX_MODE_MIXED, 20u, 2u, 1u, 2u, 100u, 12u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_CANFD_COMMANDLOAD_PDM2                                       , COM_IPDU_GROUP_0, COM_TX_MODE_MIXED, 20u, 2u, 1u, 2u, 100u, 12u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_CANFD_COMMANDLOAD_PDM3                                       , COM_IPDU_GROUP_0, COM_TX_MODE_MIXED, 20u, 2u, 1u, 2u, 100u, 12u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_CANFD_COMMANDLOAD_PDM4                                       , COM_IPDU_GROUP_0, COM_TX_MODE_MIXED, 20u, 2u, 1u, 2u, 100u, 12u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA3                                  , COM_IPDU_GROUP_0, COM_TX_MODE_MIXED, 20u, 2u, 1u, 2u, 100u, 20u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_LIN_ZGW_NM3                            , COM_IPDU_GROUP_0, COM_TX_MODE_MIXED, 2u, 1u, 1u, 2u, 20u, 1u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_LIN_ZGW_REQUEST_ALT                    , COM_IPDU_GROUP_0, COM_TX_MODE_MIXED, 2u, 1u, 1u, 2u, 20u, 4u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_LIN_ZGW_REQUEST_HVDCDC                 , COM_IPDU_GROUP_0, COM_TX_MODE_MIXED, 2u, 1u, 1u, 2u, 20u, 2u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_TX_PDU_LIN_ZGW_REQUEST_PCU48                  , COM_IPDU_GROUP_0, COM_TX_MODE_MIXED, 2u, 1u, 1u, 2u, 20u, 1u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} }
};

static const Com_RxIpduConfigType Com_RxIpduCfg[] =
{
    { COM_RX_PDU_CENTRALLOCKDATA                             , COM_IPDU_GROUP_0, 100u, 2u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_LIGHTDATA1                                  , COM_IPDU_GROUP_0, 100u, 3u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_STATUSACTUATOR                              , COM_IPDU_GROUP_0, 100u, 2u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_OUTSIDETEMPERATURESTATUS                    , COM_IPDU_GROUP_0, 100u, 4u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CENTRALCOMMAND1                             , COM_IPDU_GROUP_0, 100u, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_DMUSTATUS                                   , COM_IPDU_GROUP_0, 100u, 1u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_ENGINEDATA7                                 , COM_IPDU_GROUP_0, 100u, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_BATTFULLSTAT                                , COM_IPDU_GROUP_0, 100u, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_ENGINEDATA6                                 , COM_IPDU_GROUP_0, 100u, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_ENGINEDATA5                                 , COM_IPDU_GROUP_0, 100u, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_ENGINEDATA4                                 , COM_IPDU_GROUP_0, 100u, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_ENGINEDATA3                                 , COM_IPDU_GROUP_0, 100u, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_ENGINEDATA2                                 , COM_IPDU_GROUP_0, 100u, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_DSCDATA3                                    , COM_IPDU_GROUP_0, 100u, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_DSCDATA2                                    , COM_IPDU_GROUP_0, 100u, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_DSCDATA1                                    , COM_IPDU_GROUP_0, 100u, 5u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_ENGINEDATA1                                 , COM_IPDU_GROUP_0, 100u, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_ASGDATA1                                    , COM_IPDU_GROUP_0, 100u, 2u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_PDCSTAT                                     , COM_IPDU_GROUP_0, 100u, 3u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_MILEAGE                                     , COM_IPDU_GROUP_0, 100u, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_DMU_ALIVE                                   , COM_IPDU_GROUP_0, 100u, 1u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_XCPRESPONSE_7C7                             , COM_IPDU_GROUP_0, 100u, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_XCPRESPONSE_7C5                             , COM_IPDU_GROUP_0, 100u, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_XCPRESPONSE_7C3                             , COM_IPDU_GROUP_0, 100u, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_XCPRESPONSE_7C1                             , COM_IPDU_GROUP_0, 100u, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_VOLTAGECURRENT                              , COM_IPDU_GROUP_0, 100u, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_TEMPMEAS                                    , COM_IPDU_GROUP_0, 100u, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_LOADSTATUS                                  , COM_IPDU_GROUP_0, 100u, 1u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_L1_I2T_COUNTER                              , COM_IPDU_GROUP_0, 100u, 4u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_ERROR_706                                   , COM_IPDU_GROUP_0, 100u, 4u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_ERROR_704                                   , COM_IPDU_GROUP_0, 100u, 4u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_ERROR_702                                   , COM_IPDU_GROUP_0, 100u, 4u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_ERROR_700                                   , COM_IPDU_GROUP_0, 100u, 4u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_DIAGREQUEST_710                             , COM_IPDU_GROUP_0, 100u, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_DIAGRESPONSE_707                            , COM_IPDU_GROUP_0, 100u, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_DIAGRESPONSE_705                            , COM_IPDU_GROUP_0, 100u, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_DIAGRESPONSE_703                            , COM_IPDU_GROUP_0, 100u, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_DIAGRESPONSE_701                            , COM_IPDU_GROUP_0, 100u, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_BATTSOCSOH                                  , COM_IPDU_GROUP_0, 100u, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_BATTSOC                                     , COM_IPDU_GROUP_0, 100u, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_BATTDIAGNOSIS                               , COM_IPDU_GROUP_0, 100u, 1u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_BATTCURRENT                                 , COM_IPDU_GROUP_0, 100u, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_BATTCAPDISCHARGE                            , COM_IPDU_GROUP_0, 100u, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_BATTCAPRES                                  , COM_IPDU_GROUP_0, 100u, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM4_LOADSTATUS                                        , COM_IPDU_GROUP_0, 100u, 12u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM3_LOADSTATUS                                        , COM_IPDU_GROUP_0, 100u, 12u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM2_LOADSTATUS                                        , COM_IPDU_GROUP_0, 100u, 12u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM1_LOADSTATUS                                        , COM_IPDU_GROUP_0, 100u, 12u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_1                                 , COM_IPDU_GROUP_0, 100u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_2                                 , COM_IPDU_GROUP_0, 100u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_3                                 , COM_IPDU_GROUP_0, 100u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_4                                 , COM_IPDU_GROUP_0, 100u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_5                                 , COM_IPDU_GROUP_0, 100u, 48u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_1                                 , COM_IPDU_GROUP_0, 100u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_2                                 , COM_IPDU_GROUP_0, 100u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_3                                 , COM_IPDU_GROUP_0, 100u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_4                                 , COM_IPDU_GROUP_0, 100u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_5                                 , COM_IPDU_GROUP_0, 100u, 48u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM1_STUCKATONEVENT                                    , COM_IPDU_GROUP_0, 100u, 12u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM1_STUCKATOFFEVENT                                   , COM_IPDU_GROUP_0, 100u, 12u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_1                             , COM_IPDU_GROUP_0, 100u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_2                             , COM_IPDU_GROUP_0, 100u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_3                             , COM_IPDU_GROUP_0, 100u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_4                             , COM_IPDU_GROUP_0, 100u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_5                             , COM_IPDU_GROUP_0, 100u, 48u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_1                                 , COM_IPDU_GROUP_0, 100u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_2                                 , COM_IPDU_GROUP_0, 100u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_3                                 , COM_IPDU_GROUP_0, 100u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_4                                 , COM_IPDU_GROUP_0, 100u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_5                                 , COM_IPDU_GROUP_0, 100u, 48u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_1                                 , COM_IPDU_GROUP_0, 100u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_2                                 , COM_IPDU_GROUP_0, 100u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_3                                 , COM_IPDU_GROUP_0, 100u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_4                                 , COM_IPDU_GROUP_0, 100u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_5                                 , COM_IPDU_GROUP_0, 100u, 48u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM2_STUCKATONEVENT                                    , COM_IPDU_GROUP_0, 100u, 12u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM2_STUCKATOFFEVENT                                   , COM_IPDU_GROUP_0, 100u, 12u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_1                             , COM_IPDU_GROUP_0, 100u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_2                             , COM_IPDU_GROUP_0, 100u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_3                             , COM_IPDU_GROUP_0, 100u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_4                             , COM_IPDU_GROUP_0, 100u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_5                             , COM_IPDU_GROUP_0, 100u, 48u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_1                                 , COM_IPDU_GROUP_0, 100u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_2                                 , COM_IPDU_GROUP_0, 100u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_3                                 , COM_IPDU_GROUP_0, 100u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_4                                 , COM_IPDU_GROUP_0, 100u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_5                                 , COM_IPDU_GROUP_0, 100u, 48u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_1                                 , COM_IPDU_GROUP_0, 100u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_2                                 , COM_IPDU_GROUP_0, 100u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_3                                 , COM_IPDU_GROUP_0, 100u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_4                                 , COM_IPDU_GROUP_0, 100u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_5                                 , COM_IPDU_GROUP_0, 100u, 48u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM3_STUCKATONEVENT                                    , COM_IPDU_GROUP_0, 100u, 12u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM3_STUCKATOFFEVENT                                   , COM_IPDU_GROUP_0, 100u, 12u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_1                             , COM_IPDU_GROUP_0, 100u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_2                             , COM_IPDU_GROUP_0, 100u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_3                             , COM_IPDU_GROUP_0, 100u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_4                             , COM_IPDU_GROUP_0, 100u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_5                             , COM_IPDU_GROUP_0, 100u, 48u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_1                                 , COM_IPDU_GROUP_0, 100u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_2                                 , COM_IPDU_GROUP_0, 100u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_3                                 , COM_IPDU_GROUP_0, 100u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_4                                 , COM_IPDU_GROUP_0, 100u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_5                                 , COM_IPDU_GROUP_0, 100u, 48u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_1                                 , COM_IPDU_GROUP_0, 100u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_2                                 , COM_IPDU_GROUP_0, 100u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_3                                 , COM_IPDU_GROUP_0, 100u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_4                                 , COM_IPDU_GROUP_0, 100u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_5                                 , COM_IPDU_GROUP_0, 100u, 48u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM4_STUCKATONEVENT                                    , COM_IPDU_GROUP_0, 100u, 12u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM4_STUCKATOFFEVENT                                   , COM_IPDU_GROUP_0, 100u, 12u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_1                             , COM_IPDU_GROUP_0, 100u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_2                             , COM_IPDU_GROUP_0, 100u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_3                             , COM_IPDU_GROUP_0, 100u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_4                             , COM_IPDU_GROUP_0, 100u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_5                             , COM_IPDU_GROUP_0, 100u, 48u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM1_DIAGRESPONSE                                      , COM_IPDU_GROUP_0, 100u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM2_DIAGRESPONSE                                      , COM_IPDU_GROUP_0, 100u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM3_DIAGRESPONSE                                      , COM_IPDU_GROUP_0, 100u, 8u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_CANFD_PDM4_DIAGRESPONSE                                      , COM_IPDU_GROUP_0, 100u, 64u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_LIN_ALT_STATUS                         , COM_IPDU_GROUP_0, 20u, 7u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_LIN_HVDCDC_STATUS                      , COM_IPDU_GROUP_0, 20u, 5u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} },
    { COM_RX_PDU_LIN_PCU48_STATUS                       , COM_IPDU_GROUP_0, 20u, 5u, {0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u} }
};

static const Com_SignalConfigType Com_SignalCfg[] =
{
    { COM_SIG_TX_VEHICLESTATE_VEHICLESTATUS                                     , COM_TRUE,  COM_TX_PDU_VEHICLESTATE                                , 0u, 4u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFu        , 0u },
    { COM_SIG_TX_DISPLAYOUTTEMP_COMMANDDISPLAYOUTSIDETEMPERATURE                  , COM_TRUE,  COM_TX_PDU_DISPLAYOUTTEMP                              , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_STATUSBODYDATA1_BD1_CENTRALLOCKCOMMAND                            , COM_TRUE,  COM_TX_PDU_STATUSBODYDATA1                             , 29u, 3u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7u        , 0u },
    { COM_SIG_TX_STATUSBODYDATA1_BD1_TURNSIGNALCOMMAND                             , COM_TRUE,  COM_TX_PDU_STATUSBODYDATA1                             , 12u, 4u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFu        , 0u },
    { COM_SIG_TX_STATUSBODYDATA1_BD1_RLSCOMMAND                                    , COM_TRUE,  COM_TX_PDU_STATUSBODYDATA1                             , 24u, 5u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1Fu       , 0u },
    { COM_SIG_TX_STATUSBODYDATA1_BD1_LIGTHSENSOR                                   , COM_TRUE,  COM_TX_PDU_STATUSBODYDATA1                             , 16u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_STATUSBODYDATA1_BD1_IGNITION                                      , COM_TRUE,  COM_TX_PDU_STATUSBODYDATA1                             , 8u, 4u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFu        , 0u },
    { COM_SIG_TX_STATUSBODYDATA1_BD1_HIGHBEAMCOMMAND                               , COM_TRUE,  COM_TX_PDU_STATUSBODYDATA1                             , 6u, 2u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3u        , 0u },
    { COM_SIG_TX_STATUSBODYDATA1_BD1_GEARBOX                                       , COM_TRUE,  COM_TX_PDU_STATUSBODYDATA1                             , 3u, 3u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7u        , 0u },
    { COM_SIG_TX_STATUSBODYDATA1_BD1_FOGLIGHTSCOMMAND                              , COM_TRUE,  COM_TX_PDU_STATUSBODYDATA1                             , 0u, 3u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7u        , 0u },
    { COM_SIG_TX_COMMANDDISPLAYSTATUS_COMMANDDISPLAYRECIRCULATION                       , COM_TRUE,  COM_TX_PDU_COMMANDDISPLAYSTATUS                        , 29u, 3u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7u        , 0u },
    { COM_SIG_TX_COMMANDDISPLAYSTATUS_COMMANDDISPLAYCLIMATEAUTO                         , COM_TRUE,  COM_TX_PDU_COMMANDDISPLAYSTATUS                        , 6u, 2u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3u        , 0u },
    { COM_SIG_TX_COMMANDDISPLAYSTATUS_COMMANDDISPLAYCLIMATEMP                           , COM_TRUE,  COM_TX_PDU_COMMANDDISPLAYSTATUS                        , 41u, 6u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3Fu       , 0u },
    { COM_SIG_TX_COMMANDDISPLAYSTATUS_COMMANDDISPLAYERRORMESSAGE                        , COM_TRUE,  COM_TX_PDU_COMMANDDISPLAYSTATUS                        , 8u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_COMMANDDISPLAYSTATUS_COMMANDDISPLAYDSCSTATUS                           , COM_TRUE,  COM_TX_PDU_COMMANDDISPLAYSTATUS                        , 47u, 1u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_TX_COMMANDDISPLAYSTATUS_COMMANDDISPLAYVEHICLESPEED                        , COM_TRUE,  COM_TX_PDU_COMMANDDISPLAYSTATUS                        , 32u, 9u, COM_SIGNAL_U16, COM_FALSE, 0u, 0x1FFu      , 0u },
    { COM_SIG_TX_COMMANDDISPLAYSTATUS_COMMANDDISPLAYRPM                                 , COM_TRUE,  COM_TX_PDU_COMMANDDISPLAYSTATUS                        , 16u, 13u, COM_SIGNAL_U16, COM_FALSE, 0u, 0x1FFFu     , 0u },
    { COM_SIG_TX_COMMANDDISPLAYSTATUS_COMMANDDISPLAYMODE                                , COM_TRUE,  COM_TX_PDU_COMMANDDISPLAYSTATUS                        , 4u, 2u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3u        , 0u },
    { COM_SIG_TX_COMMANDDISPLAYSTATUS_COMMANDDISPLAYCLIMAFAN                            , COM_TRUE,  COM_TX_PDU_COMMANDDISPLAYSTATUS                        , 0u, 4u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFu        , 0u },
    { COM_SIG_TX_SDAT_CSB_SDAT_YEAR                                     , COM_TRUE,  COM_TX_PDU_SDAT                                        , 16u, 6u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3Fu       , 0u },
    { COM_SIG_TX_SDAT_CSB_SDAT_SECOND                                   , COM_TRUE,  COM_TX_PDU_SDAT                                        , 8u, 6u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3Fu       , 0u },
    { COM_SIG_TX_SDAT_CSB_SDAT_MONTH                                    , COM_TRUE,  COM_TX_PDU_SDAT                                        , 40u, 4u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFu        , 0u },
    { COM_SIG_TX_SDAT_CSB_SDAT_MINUTE                                   , COM_TRUE,  COM_TX_PDU_SDAT                                        , 0u, 6u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3Fu       , 0u },
    { COM_SIG_TX_SDAT_CSB_SDAT_MILLISECOND                              , COM_TRUE,  COM_TX_PDU_SDAT                                        , 48u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_SDAT_CSB_SDAT_HOUR                                     , COM_TRUE,  COM_TX_PDU_SDAT                                        , 32u, 5u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1Fu       , 0u },
    { COM_SIG_TX_SDAT_CSB_SDAT_DAY                                      , COM_TRUE,  COM_TX_PDU_SDAT                                        , 24u, 5u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1Fu       , 0u },
    { COM_SIG_TX_NM3_NM3_PN1                                           , COM_TRUE,  COM_TX_PDU_NM3                                         , 0u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_LOADREQUEST_LOADREQUESTSTATUS                                 , COM_TRUE,  COM_TX_PDU_LOADREQUEST                                 , 7u, 1u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_TX_LOADREQUEST_LOADREQUESTDATAID                                 , COM_TRUE,  COM_TX_PDU_LOADREQUEST                                 , 4u, 3u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7u        , 0u },
    { COM_SIG_TX_LOADREQUEST_LOADREQUESTCRC                                    , COM_TRUE,  COM_TX_PDU_LOADREQUEST                                 , 8u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_LOADREQUEST_LOADREQUESTALIVECOUNTER                           , COM_TRUE,  COM_TX_PDU_LOADREQUEST                                 , 0u, 4u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFu        , 0u },
    { COM_SIG_RX_CENTRALLOCKDATA_VIBRATIONSENSORSTATUS                             , COM_FALSE, COM_RX_PDU_CENTRALLOCKDATA                             , 8u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_CENTRALLOCKDATA_CENTRALLOCKSTATUS                                 , COM_FALSE, COM_RX_PDU_CENTRALLOCKDATA                             , 0u, 3u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7u        , 0u },
    { COM_SIG_RX_CENTRALLOCKDATA_CENTRALLOCKBUZZER                                 , COM_FALSE, COM_RX_PDU_CENTRALLOCKDATA                             , 3u, 2u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3u        , 0u },
    { COM_SIG_RX_LIGHTDATA1_REVERSELIGTHSTATUS                                , COM_FALSE, COM_RX_PDU_LIGHTDATA1                                  , 16u, 2u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3u        , 0u },
    { COM_SIG_RX_LIGHTDATA1_POSITIONLIGHTSTATUS                               , COM_FALSE, COM_RX_PDU_LIGHTDATA1                                  , 14u, 2u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3u        , 0u },
    { COM_SIG_RX_LIGHTDATA1_LOWBEAMSTATUS                                     , COM_FALSE, COM_RX_PDU_LIGHTDATA1                                  , 12u, 2u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3u        , 0u },
    { COM_SIG_RX_LIGHTDATA1_INTERIORLIGHTSTATUS                               , COM_FALSE, COM_RX_PDU_LIGHTDATA1                                  , 10u, 2u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3u        , 0u },
    { COM_SIG_RX_LIGHTDATA1_HIGHBEAMSTATUS                                    , COM_FALSE, COM_RX_PDU_LIGHTDATA1                                  , 8u, 2u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3u        , 0u },
    { COM_SIG_RX_LIGHTDATA1_FOGLIGHTSSTATUS                                   , COM_FALSE, COM_RX_PDU_LIGHTDATA1                                  , 6u, 2u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3u        , 0u },
    { COM_SIG_RX_LIGHTDATA1_TURNSIGNALSSTATUS                                 , COM_FALSE, COM_RX_PDU_LIGHTDATA1                                  , 3u, 3u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7u        , 0u },
    { COM_SIG_RX_LIGHTDATA1_BRAKELIGHTSTATUS                                  , COM_FALSE, COM_RX_PDU_LIGHTDATA1                                  , 0u, 3u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7u        , 0u },
    { COM_SIG_RX_STATUSACTUATOR_STATUSWIPERS                                      , COM_FALSE, COM_RX_PDU_STATUSACTUATOR                              , 8u, 3u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7u        , 0u },
    { COM_SIG_RX_STATUSACTUATOR_STATUSDOORS                                       , COM_FALSE, COM_RX_PDU_STATUSACTUATOR                              , 0u, 6u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3Fu       , 0u },
    { COM_SIG_RX_OUTSIDETEMPERATURESTATUS_OUTSIDETEMPERATURE                                , COM_FALSE, COM_RX_PDU_OUTSIDETEMPERATURESTATUS                    , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CENTRALCOMMAND1_HIGHBEAMCOMMAND                                   , COM_FALSE, COM_RX_PDU_CENTRALCOMMAND1                             , 37u, 2u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3u        , 0u },
    { COM_SIG_RX_CENTRALCOMMAND1_HC05CONNECTIONSTATUS                              , COM_FALSE, COM_RX_PDU_CENTRALCOMMAND1                             , 35u, 2u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3u        , 0u },
    { COM_SIG_RX_CENTRALCOMMAND1_GEARBOX                                           , COM_FALSE, COM_RX_PDU_CENTRALCOMMAND1                             , 32u, 3u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7u        , 0u },
    { COM_SIG_RX_CENTRALCOMMAND1_RECIRCULATIONCOMMAND                              , COM_FALSE, COM_RX_PDU_CENTRALCOMMAND1                             , 28u, 3u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7u        , 0u },
    { COM_SIG_RX_CENTRALCOMMAND1_TURNSIGNALCOMMAND                                 , COM_FALSE, COM_RX_PDU_CENTRALCOMMAND1                             , 24u, 4u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFu        , 0u },
    { COM_SIG_RX_CENTRALCOMMAND1_IGNITION                                          , COM_FALSE, COM_RX_PDU_CENTRALCOMMAND1                             , 20u, 4u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFu        , 0u },
    { COM_SIG_RX_CENTRALCOMMAND1_CLIMATEFANCOMMAND                                 , COM_FALSE, COM_RX_PDU_CENTRALCOMMAND1                             , 16u, 4u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFu        , 0u },
    { COM_SIG_RX_CENTRALCOMMAND1_FOGLIGHTSCOMMAND                                  , COM_FALSE, COM_RX_PDU_CENTRALCOMMAND1                             , 13u, 3u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7u        , 0u },
    { COM_SIG_RX_CENTRALCOMMAND1_RLSCOMMAND                                        , COM_FALSE, COM_RX_PDU_CENTRALCOMMAND1                             , 8u, 5u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1Fu       , 0u },
    { COM_SIG_RX_CENTRALCOMMAND1_CLIMATEAUTOCOMMAND                                , COM_FALSE, COM_RX_PDU_CENTRALCOMMAND1                             , 6u, 2u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3u        , 0u },
    { COM_SIG_RX_CENTRALCOMMAND1_CLIMATETEMPERATURECOMMAND                         , COM_FALSE, COM_RX_PDU_CENTRALCOMMAND1                             , 0u, 6u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3Fu       , 0u },
    { COM_SIG_RX_CENTRALCOMMAND1_WIPERSTOCKCOMMAND                                 , COM_FALSE, COM_RX_PDU_CENTRALCOMMAND1                             , 56u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_CENTRALCOMMAND1_LIGTHSENSOR                                       , COM_FALSE, COM_RX_PDU_CENTRALCOMMAND1                             , 48u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_CENTRALCOMMAND1_CENTRALLOCKCOMMAND                                , COM_FALSE, COM_RX_PDU_CENTRALCOMMAND1                             , 40u, 3u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7u        , 0u },
    { COM_SIG_RX_DMUSTATUS_DISPLAYCAMERASTATUS                               , COM_FALSE, COM_RX_PDU_DMUSTATUS                                   , 0u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_ENGINEDATA7_INTAKETEMPERATURE                                 , COM_FALSE, COM_RX_PDU_ENGINEDATA7                                 , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_ENGINEDATA7_COOLANTTEMPERATURE                                , COM_FALSE, COM_RX_PDU_ENGINEDATA7                                 , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_BATTFULLSTAT_RUNTIMEREMAINING                                  , COM_FALSE, COM_RX_PDU_BATTFULLSTAT                                , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_BATTFULLSTAT_TIMETOFULL                                        , COM_FALSE, COM_RX_PDU_BATTFULLSTAT                                , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_ENGINEDATA6_LONGTERMFUELTRIMBANK1                             , COM_FALSE, COM_RX_PDU_ENGINEDATA6                                 , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_ENGINEDATA6_LONGTERMFUELTRIMBANK2                             , COM_FALSE, COM_RX_PDU_ENGINEDATA6                                 , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_ENGINEDATA5_O2SENSORBANK1_SHORTTERMFUELTRIM                   , COM_FALSE, COM_RX_PDU_ENGINEDATA5                                 , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_ENGINEDATA5_O2SENSORBANK2_SHORTTERMFUELTRIM                   , COM_FALSE, COM_RX_PDU_ENGINEDATA5                                 , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_ENGINEDATA4_O2SENSORVOLTAGE1BANK1                             , COM_FALSE, COM_RX_PDU_ENGINEDATA4                                 , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_ENGINEDATA4_O2SENSORVOLTAGE1BANK2                             , COM_FALSE, COM_RX_PDU_ENGINEDATA4                                 , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_ENGINEDATA3_O2SENSORVOLTAGE2BANK1                             , COM_FALSE, COM_RX_PDU_ENGINEDATA3                                 , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_ENGINEDATA3_O2SENSORVOLTAGE2BANK2                             , COM_FALSE, COM_RX_PDU_ENGINEDATA3                                 , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_ENGINEDATA2_SHORTTERMFUELTRIMBANK1                            , COM_FALSE, COM_RX_PDU_ENGINEDATA2                                 , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_ENGINEDATA2_SHORTTERMFUELTRIMBANK2                            , COM_FALSE, COM_RX_PDU_ENGINEDATA2                                 , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_DSCDATA3_LATACC                                            , COM_FALSE, COM_RX_PDU_DSCDATA3                                    , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_DSCDATA3_LONGACC                                           , COM_FALSE, COM_RX_PDU_DSCDATA3                                    , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_DSCDATA2_VEHSPEED                                          , COM_FALSE, COM_RX_PDU_DSCDATA2                                    , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_DSCDATA2_YAWRATE                                           , COM_FALSE, COM_RX_PDU_DSCDATA2                                    , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_DSCDATA1_TRACTIONCONTROLSTATUS                             , COM_FALSE, COM_RX_PDU_DSCDATA1                                    , 32u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_DSCDATA1_DSCSTATUS                                         , COM_FALSE, COM_RX_PDU_DSCDATA1                                    , 24u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_DSCDATA1_BRAKEWHEELSTATUS                                  , COM_FALSE, COM_RX_PDU_DSCDATA1                                    , 16u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_DSCDATA1_ABSSTATUS                                         , COM_FALSE, COM_RX_PDU_DSCDATA1                                    , 8u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_DSCDATA1_BRAKEPRESSUREVALUE                                , COM_FALSE, COM_RX_PDU_DSCDATA1                                    , 0u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_ENGINEDATA1_MAFVALUE                                          , COM_FALSE, COM_RX_PDU_ENGINEDATA1                                 , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_ENGINEDATA1_TORQUEVALUE                                       , COM_FALSE, COM_RX_PDU_ENGINEDATA1                                 , 59u, 5u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1Fu       , 0u },
    { COM_SIG_RX_ENGINEDATA1_PEDALSTATUS                                       , COM_FALSE, COM_RX_PDU_ENGINEDATA1                                 , 52u, 7u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7Fu       , 0u },
    { COM_SIG_RX_ENGINEDATA1_ENGINERPM                                         , COM_FALSE, COM_RX_PDU_ENGINEDATA1                                 , 32u, 13u, COM_SIGNAL_U16, COM_FALSE, 0u, 0x1FFFu     , 0u },
    { COM_SIG_RX_ENGINEDATA1_ACTUALTORQUE                                      , COM_FALSE, COM_RX_PDU_ENGINEDATA1                                 , 45u, 7u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7Fu       , 0u },
    { COM_SIG_RX_ASGDATA1_ASGSTATUS                                         , COM_FALSE, COM_RX_PDU_ASGDATA1                                    , 14u, 2u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3u        , 0u },
    { COM_SIG_RX_ASGDATA1_CLUTCHSTATUS                                      , COM_FALSE, COM_RX_PDU_ASGDATA1                                    , 11u, 3u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7u        , 0u },
    { COM_SIG_RX_ASGDATA1_SHIFTPHASE                                        , COM_FALSE, COM_RX_PDU_ASGDATA1                                    , 8u, 3u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7u        , 0u },
    { COM_SIG_RX_ASGDATA1_CURRENTGEAR                                       , COM_FALSE, COM_RX_PDU_ASGDATA1                                    , 4u, 4u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFu        , 0u },
    { COM_SIG_RX_PDCSTAT_PDCDISTANCEREAR                                   , COM_FALSE, COM_RX_PDU_PDCSTAT                                     , 8u, 7u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7Fu       , 0u },
    { COM_SIG_RX_PDCSTAT_PDCDISTANCEFRONT                                  , COM_FALSE, COM_RX_PDU_PDCSTAT                                     , 0u, 7u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7Fu       , 0u },
    { COM_SIG_RX_PDCSTAT_PDCBUZZERFRONTREAR                                , COM_FALSE, COM_RX_PDU_PDCSTAT                                     , 16u, 3u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7u        , 0u },
    { COM_SIG_RX_MILEAGE_MILEAGETRIP                                       , COM_FALSE, COM_RX_PDU_MILEAGE                                     , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_MILEAGE_MILEAGETOTAL                                      , COM_FALSE, COM_RX_PDU_MILEAGE                                     , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_DMU_ALIVE_ALIVEINDICATION                                   , COM_FALSE, COM_RX_PDU_DMU_ALIVE                                   , 0u, 1u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_RX_VOLTAGECURRENT_L1VOLTAGE                                         , COM_FALSE, COM_RX_PDU_VOLTAGECURRENT                              , 48u, 16u, COM_SIGNAL_U16, COM_FALSE, 0u, 0xFFFFu     , 0u },
    { COM_SIG_RX_VOLTAGECURRENT_T30VOLTAGE                                        , COM_FALSE, COM_RX_PDU_VOLTAGECURRENT                              , 32u, 16u, COM_SIGNAL_U16, COM_FALSE, 0u, 0xFFFFu     , 0u },
    { COM_SIG_RX_VOLTAGECURRENT_L1ISENSE                                          , COM_FALSE, COM_RX_PDU_VOLTAGECURRENT                              , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_TEMPMEAS_L1TEMP                                            , COM_FALSE, COM_RX_PDU_TEMPMEAS                                    , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_TEMPMEAS_MCUTEMP                                           , COM_FALSE, COM_RX_PDU_TEMPMEAS                                    , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_LOADSTATUS_LOADSTATUS                                        , COM_FALSE, COM_RX_PDU_LOADSTATUS                                  , 0u, 1u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_RX_L1_I2T_COUNTER_I2TCOUNTER                                        , COM_FALSE, COM_RX_PDU_L1_I2T_COUNTER                              , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_ERROR_706_DTCID_706                                         , COM_FALSE, COM_RX_PDU_ERROR_706                                   , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_ERROR_704_DTCID_704                                         , COM_FALSE, COM_RX_PDU_ERROR_704                                   , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_ERROR_702_DTCID_702                                         , COM_FALSE, COM_RX_PDU_ERROR_702                                   , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_ERROR_700_DTCID_700                                         , COM_FALSE, COM_RX_PDU_ERROR_700                                   , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_BATTSOCSOH_SOH                                               , COM_FALSE, COM_RX_PDU_BATTSOCSOH                                  , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_BATTSOCSOH_SOCHYBRID                                         , COM_FALSE, COM_RX_PDU_BATTSOCSOH                                  , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_BATTSOC_SOCOCV                                            , COM_FALSE, COM_RX_PDU_BATTSOC                                     , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_BATTSOC_SOCCOULOMB                                        , COM_FALSE, COM_RX_PDU_BATTSOC                                     , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_BATTDIAGNOSIS_WEAKBATTERY                                       , COM_FALSE, COM_RX_PDU_BATTDIAGNOSIS                               , 7u, 1u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_RX_BATTDIAGNOSIS_VALIDOCVCALIBRATION                               , COM_FALSE, COM_RX_PDU_BATTDIAGNOSIS                               , 6u, 1u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_RX_BATTDIAGNOSIS_DISCHARGING                                       , COM_FALSE, COM_RX_PDU_BATTDIAGNOSIS                               , 5u, 1u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_RX_BATTDIAGNOSIS_DEEPDISCHARGE                                     , COM_FALSE, COM_RX_PDU_BATTDIAGNOSIS                               , 4u, 1u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_RX_BATTDIAGNOSIS_CRANKINGEVENT                                     , COM_FALSE, COM_RX_PDU_BATTDIAGNOSIS                               , 3u, 1u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_RX_BATTDIAGNOSIS_CONFINDENCE                                       , COM_FALSE, COM_RX_PDU_BATTDIAGNOSIS                               , 2u, 1u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_RX_BATTDIAGNOSIS_CHARGING                                          , COM_FALSE, COM_RX_PDU_BATTDIAGNOSIS                               , 1u, 1u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_RX_BATTDIAGNOSIS_BATTREST                                          , COM_FALSE, COM_RX_PDU_BATTDIAGNOSIS                               , 0u, 1u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_RX_BATTCURRENT_AVGDISCHARGECURRENT                               , COM_FALSE, COM_RX_PDU_BATTCURRENT                                 , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_BATTCURRENT_AVGCHARGECURRENT                                  , COM_FALSE, COM_RX_PDU_BATTCURRENT                                 , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_BATTCAPDISCHARGE_DISCHARGEAH                                       , COM_FALSE, COM_RX_PDU_BATTCAPDISCHARGE                            , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_BATTCAPDISCHARGE_CHARGEAH                                          , COM_FALSE, COM_RX_PDU_BATTCAPDISCHARGE                            , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_BATTCAPRES_INTRESISTANCE                                     , COM_FALSE, COM_RX_PDU_BATTCAPRES                                  , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_BATTCAPRES_CAPACITYAH                                        , COM_FALSE, COM_RX_PDU_BATTCAPRES                                  , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_INFOTAINMENTDATA1_IT1_MILEAGETRIP                                                  , COM_TRUE,  COM_TX_PDU_CANFD_INFOTAINMENTDATA1                                      , 56u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_INFOTAINMENTDATA1_IT1_MILEAGETOTAL                                                 , COM_TRUE,  COM_TX_PDU_CANFD_INFOTAINMENTDATA1                                      , 24u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_INFOTAINMENTDATA1_IT1_DISPLAYCAMERASTATUS                                          , COM_TRUE,  COM_TX_PDU_CANFD_INFOTAINMENTDATA1                                      , 16u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_INFOTAINMENTDATA1_IT1_COMMANDDISPLAYERRORMESSAGE                                   , COM_TRUE,  COM_TX_PDU_CANFD_INFOTAINMENTDATA1                                      , 8u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_INFOTAINMENTDATA1_IT1_ALIVEINDICATION                                              , COM_TRUE,  COM_TX_PDU_CANFD_INFOTAINMENTDATA1                                      , 0u, 1u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA2_EM1_WEAKBATTERY                                                  , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA2                                  , 8u, 1u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA2_EM1_VALIDOCVCALIBRATION                                          , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA2                                  , 7u, 1u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA2_EM1_LOADSTATUS                                                   , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA2                                  , 6u, 1u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA2_EM1_DISCHARGING                                                  , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA2                                  , 5u, 1u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA2_EM1_DEEPDISCHARGE                                                , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA2                                  , 4u, 1u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA2_EM1_CRANKINGEVENT                                                , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA2                                  , 3u, 1u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA2_EM1_CONFINDENCE                                                  , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA2                                  , 2u, 1u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA2_EM1_CHARGING                                                     , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA2                                  , 1u, 1u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA2_EM1_CAPACITYAH                                                   , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA2                                  , 16u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA2_EM1_BATTREST                                                     , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA2                                  , 0u, 1u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA1_EM1_TIMETOFULL                                                   , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA1                                  , 480u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA1_EM1_T30VOLTAGE                                                   , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA1                                  , 80u, 16u, COM_SIGNAL_U16, COM_FALSE, 0u, 0xFFFFu     , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA1_EM1_SOH                                                          , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA1                                  , 448u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA1_EM1_SOCOCV                                                       , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA1                                  , 416u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA1_EM1_SOCHYBRID                                                    , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA1                                  , 384u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA1_EM1_SOCCOULOMB                                                   , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA1                                  , 352u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA1_EM1_RUNTIMEREMAINING                                             , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA1                                  , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA1_EM1_MCUTEMP                                                      , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA1                                  , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA1_EM1_L1VOLTAGE                                                    , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA1                                  , 64u, 16u, COM_SIGNAL_U16, COM_FALSE, 0u, 0xFFFFu     , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA1_EM1_L1TEMP                                                       , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA1                                  , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA1_EM1_L1ISENSE                                                     , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA1                                  , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA1_EM1_INTRESISTANCE                                                , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA1                                  , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA1_EM1_I2TCOUNTER                                                   , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA1                                  , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA1_EM1_DISCHARGEAH                                                  , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA1                                  , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA1_EM1_CHARGEAH                                                     , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA1                                  , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA1_EM1_AVGDISCHARGECURRENT                                          , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA1                                  , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA1_EM1_AVGCHARGECURRENT                                             , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA1                                  , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_VEHICLESTATE_VEHICLESTATUS                                                    , COM_TRUE,  COM_TX_PDU_CANFD_VEHICLESTATE                                           , 0u, 4u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFu        , 0u },
    { COM_SIG_TX_CANFD_NM3_NM3_PN1                                                          , COM_TRUE,  COM_TX_PDU_CANFD_NM3                                                    , 0u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_SDAT_CANFD_SDAT_YEAR                                                  , COM_TRUE,  COM_TX_PDU_CANFD_SDAT                                                   , 48u, 6u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3Fu       , 0u },
    { COM_SIG_TX_CANFD_SDAT_CANFD_SDAT_SECOND                                                , COM_TRUE,  COM_TX_PDU_CANFD_SDAT                                                   , 40u, 6u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3Fu       , 0u },
    { COM_SIG_TX_CANFD_SDAT_CANFD_SDAT_MONTH                                                 , COM_TRUE,  COM_TX_PDU_CANFD_SDAT                                                   , 32u, 4u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFu        , 0u },
    { COM_SIG_TX_CANFD_SDAT_CANFD_SDAT_MINUTE                                                , COM_TRUE,  COM_TX_PDU_CANFD_SDAT                                                   , 24u, 6u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3Fu       , 0u },
    { COM_SIG_TX_CANFD_SDAT_CANFD_SDAT_MILLISECOND                                           , COM_TRUE,  COM_TX_PDU_CANFD_SDAT                                                   , 16u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_SDAT_CANFD_SDAT_HOUR                                                  , COM_TRUE,  COM_TX_PDU_CANFD_SDAT                                                   , 8u, 5u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1Fu       , 0u },
    { COM_SIG_TX_CANFD_SDAT_CANFD_SDAT_DAY                                                   , COM_TRUE,  COM_TX_PDU_CANFD_SDAT                                                   , 0u, 5u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1Fu       , 0u },
    { COM_SIG_TX_CANFD_LIGHTDATA1_LD1_TURNSIGNALSSTATUS                                            , COM_TRUE,  COM_TX_PDU_CANFD_LIGHTDATA1                                             , 16u, 3u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7u        , 0u },
    { COM_SIG_TX_CANFD_LIGHTDATA1_LD1_TURNSIGNALCOMMAND                                            , COM_TRUE,  COM_TX_PDU_CANFD_LIGHTDATA1                                             , 12u, 4u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFu        , 0u },
    { COM_SIG_TX_CANFD_LIGHTDATA1_LD1_REVERSELIGTHSTATUS                                           , COM_TRUE,  COM_TX_PDU_CANFD_LIGHTDATA1                                             , 10u, 2u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3u        , 0u },
    { COM_SIG_TX_CANFD_LIGHTDATA1_LD1_POSITIONLIGHTSTATUS                                          , COM_TRUE,  COM_TX_PDU_CANFD_LIGHTDATA1                                             , 8u, 2u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3u        , 0u },
    { COM_SIG_TX_CANFD_LIGHTDATA1_LD1_LOWBEAMSTATUS                                                , COM_TRUE,  COM_TX_PDU_CANFD_LIGHTDATA1                                             , 6u, 2u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3u        , 0u },
    { COM_SIG_TX_CANFD_LIGHTDATA1_LD1_INTERIORLIGHTSTATUS                                          , COM_TRUE,  COM_TX_PDU_CANFD_LIGHTDATA1                                             , 4u, 2u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3u        , 0u },
    { COM_SIG_TX_CANFD_LIGHTDATA1_LD1_HIGHBEAMSTATUS                                               , COM_TRUE,  COM_TX_PDU_CANFD_LIGHTDATA1                                             , 2u, 2u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3u        , 0u },
    { COM_SIG_TX_CANFD_LIGHTDATA1_LD1_FOGLIGHTSSTATUS                                              , COM_TRUE,  COM_TX_PDU_CANFD_LIGHTDATA1                                             , 0u, 2u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3u        , 0u },
    { COM_SIG_TX_CANFD_POWERTRAINDATA2_PT2_VEHSPEED                                                     , COM_TRUE,  COM_TX_PDU_CANFD_POWERTRAINDATA2                                        , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_POWERTRAINDATA2_PT2_TRACTIONCONTROLSTATUS                                        , COM_TRUE,  COM_TX_PDU_CANFD_POWERTRAINDATA2                                        , 88u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_POWERTRAINDATA2_PT2_TORQUEVALUE                                                  , COM_TRUE,  COM_TX_PDU_CANFD_POWERTRAINDATA2                                        , 80u, 5u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1Fu       , 0u },
    { COM_SIG_TX_CANFD_POWERTRAINDATA2_PT2_SHIFTPHASE                                                   , COM_TRUE,  COM_TX_PDU_CANFD_POWERTRAINDATA2                                        , 29u, 3u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7u        , 0u },
    { COM_SIG_TX_CANFD_POWERTRAINDATA2_PT2_PEDALSTATUS                                                  , COM_TRUE,  COM_TX_PDU_CANFD_POWERTRAINDATA2                                        , 56u, 7u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7Fu       , 0u },
    { COM_SIG_TX_CANFD_POWERTRAINDATA2_PT2_ENGINERPM                                                    , COM_TRUE,  COM_TX_PDU_CANFD_POWERTRAINDATA2                                        , 64u, 13u, COM_SIGNAL_U16, COM_FALSE, 0u, 0x1FFFu     , 0u },
    { COM_SIG_TX_CANFD_POWERTRAINDATA2_PT2_DSCSTATUS                                                    , COM_TRUE,  COM_TX_PDU_CANFD_POWERTRAINDATA2                                        , 40u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_POWERTRAINDATA2_PT2_CURRENTGEAR                                                  , COM_TRUE,  COM_TX_PDU_CANFD_POWERTRAINDATA2                                        , 48u, 4u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFu        , 0u },
    { COM_SIG_TX_CANFD_POWERTRAINDATA2_PT2_CLUTCHSTATUS                                                 , COM_TRUE,  COM_TX_PDU_CANFD_POWERTRAINDATA2                                        , 26u, 3u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7u        , 0u },
    { COM_SIG_TX_CANFD_POWERTRAINDATA2_PT2_BRAKEWHEELSTATUS                                             , COM_TRUE,  COM_TX_PDU_CANFD_POWERTRAINDATA2                                        , 32u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_POWERTRAINDATA2_PT2_ASGSTATUS                                                    , COM_TRUE,  COM_TX_PDU_CANFD_POWERTRAINDATA2                                        , 24u, 2u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3u        , 0u },
    { COM_SIG_TX_CANFD_POWERTRAINDATA2_PT2_ACTUALTORQUE                                                 , COM_TRUE,  COM_TX_PDU_CANFD_POWERTRAINDATA2                                        , 16u, 7u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7Fu       , 0u },
    { COM_SIG_TX_CANFD_POWERTRAINDATA2_PT2_ABSSTATUS                                                    , COM_TRUE,  COM_TX_PDU_CANFD_POWERTRAINDATA2                                        , 8u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_POWERTRAINDATA2_PT2_BRAKEPRESSUREVALUE                                           , COM_TRUE,  COM_TX_PDU_CANFD_POWERTRAINDATA2                                        , 0u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_POWERTRAINDATA1_PT1_LATACC                                                       , COM_TRUE,  COM_TX_PDU_CANFD_POWERTRAINDATA1                                        , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_POWERTRAINDATA1_PT1_INTAKETEMPERATURE                                            , COM_TRUE,  COM_TX_PDU_CANFD_POWERTRAINDATA1                                        , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_POWERTRAINDATA1_PT1_COOLANTTEMPERATURE                                           , COM_TRUE,  COM_TX_PDU_CANFD_POWERTRAINDATA1                                        , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_POWERTRAINDATA1_PT1_YAWRATE                                                      , COM_TRUE,  COM_TX_PDU_CANFD_POWERTRAINDATA1                                        , 480u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_POWERTRAINDATA1_PT1_SHORTTERMFUELTRIMBANK2                                       , COM_TRUE,  COM_TX_PDU_CANFD_POWERTRAINDATA1                                        , 448u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_POWERTRAINDATA1_PT1_SHORTTERMFUELTRIMBANK1                                       , COM_TRUE,  COM_TX_PDU_CANFD_POWERTRAINDATA1                                        , 416u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_POWERTRAINDATA1_PT1_O2SENSORVOLTAGE2BANK2                                        , COM_TRUE,  COM_TX_PDU_CANFD_POWERTRAINDATA1                                        , 384u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_POWERTRAINDATA1_PT1_O2SENSORVOLTAGE2BANK1                                        , COM_TRUE,  COM_TX_PDU_CANFD_POWERTRAINDATA1                                        , 352u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_POWERTRAINDATA1_PT1_O2SENSORVOLTAGE1BANK2                                        , COM_TRUE,  COM_TX_PDU_CANFD_POWERTRAINDATA1                                        , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_POWERTRAINDATA1_PT1_O2SENSORVOLTAGE1BANK1                                        , COM_TRUE,  COM_TX_PDU_CANFD_POWERTRAINDATA1                                        , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_POWERTRAINDATA1_PT1_O2SENSB1_SHORTTERMFUELTRIM                                   , COM_TRUE,  COM_TX_PDU_CANFD_POWERTRAINDATA1                                        , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_POWERTRAINDATA1_PT1_O2SENB2_SHORTTERMFUELTRIM                                    , COM_TRUE,  COM_TX_PDU_CANFD_POWERTRAINDATA1                                        , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_POWERTRAINDATA1_PT1_MAFVALUE                                                     , COM_TRUE,  COM_TX_PDU_CANFD_POWERTRAINDATA1                                        , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_POWERTRAINDATA1_PT1_LONGTERMFUELTRIMBANK2                                        , COM_TRUE,  COM_TX_PDU_CANFD_POWERTRAINDATA1                                        , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_POWERTRAINDATA1_PT1_LONGTERMFUELTRIMBANK1                                        , COM_TRUE,  COM_TX_PDU_CANFD_POWERTRAINDATA1                                        , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_POWERTRAINDATA1_PT1_LONGACC                                                      , COM_TRUE,  COM_TX_PDU_CANFD_POWERTRAINDATA1                                        , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_BODYDATA1_BD1_WIPERSTOCKCOMMAND                                            , COM_TRUE,  COM_TX_PDU_CANFD_BODYDATA1                                              , 128u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_BODYDATA1_BD1_VIBRATIONSENSORSTATUS                                        , COM_TRUE,  COM_TX_PDU_CANFD_BODYDATA1                                              , 120u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_BODYDATA1_BD1_STATUSWIPERS                                                 , COM_TRUE,  COM_TX_PDU_CANFD_BODYDATA1                                              , 109u, 3u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7u        , 0u },
    { COM_SIG_TX_CANFD_BODYDATA1_BD1_STATUSDOORS                                                  , COM_TRUE,  COM_TX_PDU_CANFD_BODYDATA1                                              , 112u, 6u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3Fu       , 0u },
    { COM_SIG_TX_CANFD_BODYDATA1_BD1_RLSCOMMAND                                                   , COM_TRUE,  COM_TX_PDU_CANFD_BODYDATA1                                              , 104u, 5u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1Fu       , 0u },
    { COM_SIG_TX_CANFD_BODYDATA1_BD1_RECIRCULATIONCOMMAND                                         , COM_TRUE,  COM_TX_PDU_CANFD_BODYDATA1                                              , 83u, 3u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7u        , 0u },
    { COM_SIG_TX_CANFD_BODYDATA1_BD1_PDCDISTANCEREAR                                              , COM_TRUE,  COM_TX_PDU_CANFD_BODYDATA1                                              , 96u, 7u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7Fu       , 0u },
    { COM_SIG_TX_CANFD_BODYDATA1_BD1_PDCDISTANCEFRONT                                             , COM_TRUE,  COM_TX_PDU_CANFD_BODYDATA1                                              , 88u, 7u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7Fu       , 0u },
    { COM_SIG_TX_CANFD_BODYDATA1_BD1_PDCBUZZERFRONTREAR                                           , COM_TRUE,  COM_TX_PDU_CANFD_BODYDATA1                                              , 80u, 3u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7u        , 0u },
    { COM_SIG_TX_CANFD_BODYDATA1_BD1_OUTSIDETEMPERATURE                                           , COM_TRUE,  COM_TX_PDU_CANFD_BODYDATA1                                              , 48u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_BODYDATA1_BD1_LIGTHSENSOR                                                  , COM_TRUE,  COM_TX_PDU_CANFD_BODYDATA1                                              , 40u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_BODYDATA1_BD1_IGNITION                                                     , COM_TRUE,  COM_TX_PDU_CANFD_BODYDATA1                                              , 34u, 4u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFu        , 0u },
    { COM_SIG_TX_CANFD_BODYDATA1_BD1_HIGHBEAMCOMMAND                                              , COM_TRUE,  COM_TX_PDU_CANFD_BODYDATA1                                              , 32u, 2u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3u        , 0u },
    { COM_SIG_TX_CANFD_BODYDATA1_BD1_HC05CONNECTIONSTATUS                                         , COM_TRUE,  COM_TX_PDU_CANFD_BODYDATA1                                              , 30u, 2u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3u        , 0u },
    { COM_SIG_TX_CANFD_BODYDATA1_BD1_GEARBOX                                                      , COM_TRUE,  COM_TX_PDU_CANFD_BODYDATA1                                              , 20u, 3u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7u        , 0u },
    { COM_SIG_TX_CANFD_BODYDATA1_BD1_FOGLIGHTSCOMMAND                                             , COM_TRUE,  COM_TX_PDU_CANFD_BODYDATA1                                              , 13u, 3u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7u        , 0u },
    { COM_SIG_TX_CANFD_BODYDATA1_BD1_CLIMATETEMPERATURECOMMAND                                    , COM_TRUE,  COM_TX_PDU_CANFD_BODYDATA1                                              , 24u, 6u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3Fu       , 0u },
    { COM_SIG_TX_CANFD_BODYDATA1_BD1_CLIMATEFANCOMMAND                                            , COM_TRUE,  COM_TX_PDU_CANFD_BODYDATA1                                              , 16u, 4u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFu        , 0u },
    { COM_SIG_TX_CANFD_BODYDATA1_BD1_CLIMATEAUTOCOMMAND                                           , COM_TRUE,  COM_TX_PDU_CANFD_BODYDATA1                                              , 11u, 2u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3u        , 0u },
    { COM_SIG_TX_CANFD_BODYDATA1_BD1_CENTRALLOCKSTATUS                                            , COM_TRUE,  COM_TX_PDU_CANFD_BODYDATA1                                              , 8u, 3u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7u        , 0u },
    { COM_SIG_TX_CANFD_BODYDATA1_BD1_CENTRALLOCKCOMMAND                                           , COM_TRUE,  COM_TX_PDU_CANFD_BODYDATA1                                              , 5u, 3u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7u        , 0u },
    { COM_SIG_TX_CANFD_BODYDATA1_BD1_CENTRALLOCKBUZZER                                            , COM_TRUE,  COM_TX_PDU_CANFD_BODYDATA1                                              , 3u, 2u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x3u        , 0u },
    { COM_SIG_TX_CANFD_BODYDATA1_BD1_BRAKELIGHTSTATUS                                             , COM_TRUE,  COM_TX_PDU_CANFD_BODYDATA1                                              , 0u, 3u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x7u        , 0u },
    { COM_SIG_TX_CANFD_PDM1_DIAGREQUEST_PDM1_DIAGREQ_BYTE00                                              , COM_TRUE,  COM_TX_PDU_CANFD_PDM1_DIAGREQUEST                                       , 0u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_PDM1_DIAGREQUEST_PDM1_DIAGREQ_BYTE01                                              , COM_TRUE,  COM_TX_PDU_CANFD_PDM1_DIAGREQUEST                                       , 8u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_PDM1_DIAGREQUEST_PDM1_DIAGREQ_BYTE02                                              , COM_TRUE,  COM_TX_PDU_CANFD_PDM1_DIAGREQUEST                                       , 16u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_PDM1_DIAGREQUEST_PDM1_DIAGREQ_BYTE03                                              , COM_TRUE,  COM_TX_PDU_CANFD_PDM1_DIAGREQUEST                                       , 24u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_PDM1_DIAGREQUEST_PDM1_DIAGREQ_BYTE04                                              , COM_TRUE,  COM_TX_PDU_CANFD_PDM1_DIAGREQUEST                                       , 32u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_PDM1_DIAGREQUEST_PDM1_DIAGREQ_BYTE05                                              , COM_TRUE,  COM_TX_PDU_CANFD_PDM1_DIAGREQUEST                                       , 40u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_PDM1_DIAGREQUEST_PDM1_DIAGREQ_BYTE06                                              , COM_TRUE,  COM_TX_PDU_CANFD_PDM1_DIAGREQUEST                                       , 48u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_PDM1_DIAGREQUEST_PDM1_DIAGREQ_BYTE07                                              , COM_TRUE,  COM_TX_PDU_CANFD_PDM1_DIAGREQUEST                                       , 56u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_PDM2_DIAGREQUEST_PDM2_DIAGREQ_BYTE00                                              , COM_TRUE,  COM_TX_PDU_CANFD_PDM2_DIAGREQUEST                                       , 0u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_PDM2_DIAGREQUEST_PDM2_DIAGREQ_BYTE01                                              , COM_TRUE,  COM_TX_PDU_CANFD_PDM2_DIAGREQUEST                                       , 8u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_PDM2_DIAGREQUEST_PDM2_DIAGREQ_BYTE02                                              , COM_TRUE,  COM_TX_PDU_CANFD_PDM2_DIAGREQUEST                                       , 16u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_PDM2_DIAGREQUEST_PDM2_DIAGREQ_BYTE03                                              , COM_TRUE,  COM_TX_PDU_CANFD_PDM2_DIAGREQUEST                                       , 24u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_PDM2_DIAGREQUEST_PDM2_DIAGREQ_BYTE04                                              , COM_TRUE,  COM_TX_PDU_CANFD_PDM2_DIAGREQUEST                                       , 32u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_PDM2_DIAGREQUEST_PDM2_DIAGREQ_BYTE05                                              , COM_TRUE,  COM_TX_PDU_CANFD_PDM2_DIAGREQUEST                                       , 40u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_PDM2_DIAGREQUEST_PDM2_DIAGREQ_BYTE06                                              , COM_TRUE,  COM_TX_PDU_CANFD_PDM2_DIAGREQUEST                                       , 48u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_PDM2_DIAGREQUEST_PDM2_DIAGREQ_BYTE07                                              , COM_TRUE,  COM_TX_PDU_CANFD_PDM2_DIAGREQUEST                                       , 56u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_PDM3_DIAGREQUEST_PDM3_DIAGREQ_BYTE00                                              , COM_TRUE,  COM_TX_PDU_CANFD_PDM3_DIAGREQUEST                                       , 0u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_PDM3_DIAGREQUEST_PDM3_DIAGREQ_BYTE01                                              , COM_TRUE,  COM_TX_PDU_CANFD_PDM3_DIAGREQUEST                                       , 8u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_PDM3_DIAGREQUEST_PDM3_DIAGREQ_BYTE02                                              , COM_TRUE,  COM_TX_PDU_CANFD_PDM3_DIAGREQUEST                                       , 16u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_PDM3_DIAGREQUEST_PDM3_DIAGREQ_BYTE03                                              , COM_TRUE,  COM_TX_PDU_CANFD_PDM3_DIAGREQUEST                                       , 24u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_PDM3_DIAGREQUEST_PDM3_DIAGREQ_BYTE04                                              , COM_TRUE,  COM_TX_PDU_CANFD_PDM3_DIAGREQUEST                                       , 32u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_PDM3_DIAGREQUEST_PDM3_DIAGREQ_BYTE05                                              , COM_TRUE,  COM_TX_PDU_CANFD_PDM3_DIAGREQUEST                                       , 40u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_PDM3_DIAGREQUEST_PDM3_DIAGREQ_BYTE06                                              , COM_TRUE,  COM_TX_PDU_CANFD_PDM3_DIAGREQUEST                                       , 48u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_PDM3_DIAGREQUEST_PDM3_DIAGREQ_BYTE07                                              , COM_TRUE,  COM_TX_PDU_CANFD_PDM3_DIAGREQUEST                                       , 56u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_PDM4_DIAGREQUEST_PDM4_DIAGREQ_BYTE00                                              , COM_TRUE,  COM_TX_PDU_CANFD_PDM4_DIAGREQUEST                                       , 0u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_PDM4_DIAGREQUEST_PDM4_DIAGREQ_BYTE01                                              , COM_TRUE,  COM_TX_PDU_CANFD_PDM4_DIAGREQUEST                                       , 8u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_PDM4_DIAGREQUEST_PDM4_DIAGREQ_BYTE02                                              , COM_TRUE,  COM_TX_PDU_CANFD_PDM4_DIAGREQUEST                                       , 16u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_PDM4_DIAGREQUEST_PDM4_DIAGREQ_BYTE03                                              , COM_TRUE,  COM_TX_PDU_CANFD_PDM4_DIAGREQUEST                                       , 24u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_PDM4_DIAGREQUEST_PDM4_DIAGREQ_BYTE04                                              , COM_TRUE,  COM_TX_PDU_CANFD_PDM4_DIAGREQUEST                                       , 32u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_PDM4_DIAGREQUEST_PDM4_DIAGREQ_BYTE05                                              , COM_TRUE,  COM_TX_PDU_CANFD_PDM4_DIAGREQUEST                                       , 40u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_PDM4_DIAGREQUEST_PDM4_DIAGREQ_BYTE06                                              , COM_TRUE,  COM_TX_PDU_CANFD_PDM4_DIAGREQUEST                                       , 48u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_PDM4_DIAGREQUEST_PDM4_DIAGREQ_BYTE07                                              , COM_TRUE,  COM_TX_PDU_CANFD_PDM4_DIAGREQUEST                                       , 56u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_COMMANDLOAD_PDM1_PDM1_COMMANDLOAD_01                                              , COM_TRUE,  COM_TX_PDU_CANFD_COMMANDLOAD_PDM1                                       , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_COMMANDLOAD_PDM1_PDM1_COMMANDLOAD_02                                              , COM_TRUE,  COM_TX_PDU_CANFD_COMMANDLOAD_PDM1                                       , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_COMMANDLOAD_PDM1_PDM1_COMMANDLOAD_03                                              , COM_TRUE,  COM_TX_PDU_CANFD_COMMANDLOAD_PDM1                                       , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_COMMANDLOAD_PDM2_PDM2_COMMANDLOAD_01                                              , COM_TRUE,  COM_TX_PDU_CANFD_COMMANDLOAD_PDM2                                       , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_COMMANDLOAD_PDM2_PDM2_COMMANDLOAD_02                                              , COM_TRUE,  COM_TX_PDU_CANFD_COMMANDLOAD_PDM2                                       , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_COMMANDLOAD_PDM2_PDM2_COMMANDLOAD_03                                              , COM_TRUE,  COM_TX_PDU_CANFD_COMMANDLOAD_PDM2                                       , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_COMMANDLOAD_PDM3_PDM3_COMMANDLOAD_01                                              , COM_TRUE,  COM_TX_PDU_CANFD_COMMANDLOAD_PDM3                                       , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_COMMANDLOAD_PDM3_PDM3_COMMANDLOAD_02                                              , COM_TRUE,  COM_TX_PDU_CANFD_COMMANDLOAD_PDM3                                       , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_COMMANDLOAD_PDM3_PDM3_COMMANDLOAD_03                                              , COM_TRUE,  COM_TX_PDU_CANFD_COMMANDLOAD_PDM3                                       , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_COMMANDLOAD_PDM4_PDM4_COMMANDLOAD_01                                              , COM_TRUE,  COM_TX_PDU_CANFD_COMMANDLOAD_PDM4                                       , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_COMMANDLOAD_PDM4_PDM4_COMMANDLOAD_02                                              , COM_TRUE,  COM_TX_PDU_CANFD_COMMANDLOAD_PDM4                                       , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_COMMANDLOAD_PDM4_PDM4_COMMANDLOAD_03                                              , COM_TRUE,  COM_TX_PDU_CANFD_COMMANDLOAD_PDM4                                       , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA3_ALT_RESPONSEERROR                                                , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA3                                  , 0u, 1u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA3_ALT_CHARGINGACTIVE                                               , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA3                                  , 8u, 1u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA3_ALT_OUTPUTCURRENT                                                , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA3                                  , 16u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA3_ALT_OUTPUTVOLTAGE                                                , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA3                                  , 24u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA3_ALT_FIELDDUTYACTUAL                                              , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA3                                  , 32u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA3_ALT_POWER                                                        , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA3                                  , 40u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA3_ALT_TEMPERATURE                                                  , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA3                                  , 48u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA3_HVDCDC_RESPONSEERROR                                             , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA3                                  , 56u, 1u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA3_HVDCDC_LV_VOLTAGE                                                , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA3                                  , 64u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA3_HVDCDC_LV_CURRENT                                                , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA3                                  , 72u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA3_HVDCDC_HV_VOLTAGE                                                , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA3                                  , 80u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA3_HVDCDC_HV_CURRENT                                                , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA3                                  , 88u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA3_PCU48_RESPONSEERROR                                              , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA3                                  , 96u, 1u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA3_PCU48_SOH                                                        , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA3                                  , 104u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA3_PCU48_SOC                                                        , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA3                                  , 112u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA3_PCU48_VOLTAGE                                                    , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA3                                  , 120u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_CANFD_ENERGYMANAGEMENTDATA3_PCU48_CHARGESTATE                                                , COM_TRUE,  COM_TX_PDU_CANFD_ENERGYMANAGEMENTDATA3                                  , 128u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_CANFD_PDM4_LOADSTATUS_PDM4_LOADSTATUS_01                                               , COM_FALSE, COM_RX_PDU_CANFD_PDM4_LOADSTATUS                                        , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_LOADSTATUS_PDM4_LOADSTATUS_02                                               , COM_FALSE, COM_RX_PDU_CANFD_PDM4_LOADSTATUS                                        , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_LOADSTATUS_PDM4_LOADSTATUS_03                                               , COM_FALSE, COM_RX_PDU_CANFD_PDM4_LOADSTATUS                                        , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_LOADSTATUS_PDM3_LOADSTATUS_01                                               , COM_FALSE, COM_RX_PDU_CANFD_PDM3_LOADSTATUS                                        , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_LOADSTATUS_PDM3_LOADSTATUS_02                                               , COM_FALSE, COM_RX_PDU_CANFD_PDM3_LOADSTATUS                                        , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_LOADSTATUS_PDM3_LOADSTATUS_03                                               , COM_FALSE, COM_RX_PDU_CANFD_PDM3_LOADSTATUS                                        , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_LOADSTATUS_PDM2_LOADSTATUS_01                                               , COM_FALSE, COM_RX_PDU_CANFD_PDM2_LOADSTATUS                                        , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_LOADSTATUS_PDM2_LOADSTATUS_02                                               , COM_FALSE, COM_RX_PDU_CANFD_PDM2_LOADSTATUS                                        , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_LOADSTATUS_PDM2_LOADSTATUS_03                                               , COM_FALSE, COM_RX_PDU_CANFD_PDM2_LOADSTATUS                                        , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_LOADSTATUS_PDM1_LOADSTATUS_01                                               , COM_FALSE, COM_RX_PDU_CANFD_PDM1_LOADSTATUS                                        , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_LOADSTATUS_PDM1_LOADSTATUS_02                                               , COM_FALSE, COM_RX_PDU_CANFD_PDM1_LOADSTATUS                                        , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_LOADSTATUS_PDM1_LOADSTATUS_03                                               , COM_FALSE, COM_RX_PDU_CANFD_PDM1_LOADSTATUS                                        , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_1_PDM1_VOLTFB_001                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_1                                 , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_1_PDM1_VOLTFB_002                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_1                                 , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_1_PDM1_VOLTFB_003                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_1                                 , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_1_PDM1_VOLTFB_004                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_1                                 , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_1_PDM1_VOLTFB_005                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_1                                 , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_1_PDM1_VOLTFB_006                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_1                                 , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_1_PDM1_VOLTFB_007                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_1                                 , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_1_PDM1_VOLTFB_008                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_1                                 , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_1_PDM1_VOLTFB_009                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_1                                 , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_1_PDM1_VOLTFB_010                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_1                                 , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_1_PDM1_VOLTFB_011                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_1                                 , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_1_PDM1_VOLTFB_012                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_1                                 , 352u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_1_PDM1_VOLTFB_013                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_1                                 , 384u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_1_PDM1_VOLTFB_014                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_1                                 , 416u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_1_PDM1_VOLTFB_015                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_1                                 , 448u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_1_PDM1_VOLTFB_016                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_1                                 , 480u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_2_PDM1_VOLTFB_017                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_2                                 , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_2_PDM1_VOLTFB_018                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_2                                 , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_2_PDM1_VOLTFB_019                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_2                                 , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_2_PDM1_VOLTFB_020                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_2                                 , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_2_PDM1_VOLTFB_021                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_2                                 , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_2_PDM1_VOLTFB_022                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_2                                 , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_2_PDM1_VOLTFB_023                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_2                                 , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_2_PDM1_VOLTFB_024                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_2                                 , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_2_PDM1_VOLTFB_025                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_2                                 , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_2_PDM1_VOLTFB_026                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_2                                 , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_2_PDM1_VOLTFB_027                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_2                                 , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_2_PDM1_VOLTFB_028                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_2                                 , 352u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_2_PDM1_VOLTFB_029                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_2                                 , 384u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_2_PDM1_VOLTFB_030                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_2                                 , 416u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_2_PDM1_VOLTFB_031                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_2                                 , 448u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_2_PDM1_VOLTFB_032                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_2                                 , 480u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_3_PDM1_VOLTFB_033                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_3                                 , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_3_PDM1_VOLTFB_034                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_3                                 , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_3_PDM1_VOLTFB_035                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_3                                 , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_3_PDM1_VOLTFB_036                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_3                                 , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_3_PDM1_VOLTFB_037                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_3                                 , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_3_PDM1_VOLTFB_038                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_3                                 , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_3_PDM1_VOLTFB_039                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_3                                 , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_3_PDM1_VOLTFB_040                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_3                                 , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_3_PDM1_VOLTFB_041                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_3                                 , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_3_PDM1_VOLTFB_042                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_3                                 , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_3_PDM1_VOLTFB_043                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_3                                 , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_3_PDM1_VOLTFB_044                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_3                                 , 352u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_3_PDM1_VOLTFB_045                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_3                                 , 384u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_3_PDM1_VOLTFB_046                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_3                                 , 416u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_3_PDM1_VOLTFB_047                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_3                                 , 448u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_3_PDM1_VOLTFB_048                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_3                                 , 480u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_4_PDM1_VOLTFB_049                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_4                                 , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_4_PDM1_VOLTFB_050                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_4                                 , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_4_PDM1_VOLTFB_051                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_4                                 , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_4_PDM1_VOLTFB_052                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_4                                 , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_4_PDM1_VOLTFB_053                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_4                                 , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_4_PDM1_VOLTFB_054                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_4                                 , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_4_PDM1_VOLTFB_055                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_4                                 , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_4_PDM1_VOLTFB_056                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_4                                 , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_4_PDM1_VOLTFB_057                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_4                                 , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_4_PDM1_VOLTFB_058                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_4                                 , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_4_PDM1_VOLTFB_059                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_4                                 , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_4_PDM1_VOLTFB_060                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_4                                 , 352u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_4_PDM1_VOLTFB_061                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_4                                 , 384u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_4_PDM1_VOLTFB_062                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_4                                 , 416u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_4_PDM1_VOLTFB_063                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_4                                 , 448u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_4_PDM1_VOLTFB_064                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_4                                 , 480u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_5_PDM1_VOLTFB_065                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_5                                 , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_5_PDM1_VOLTFB_066                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_5                                 , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_5_PDM1_VOLTFB_067                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_5                                 , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_5_PDM1_VOLTFB_068                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_5                                 , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_5_PDM1_VOLTFB_069                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_5                                 , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_5_PDM1_VOLTFB_070                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_5                                 , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_5_PDM1_VOLTFB_071                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_5                                 , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_5_PDM1_VOLTFB_072                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_5                                 , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_5_PDM1_VOLTFB_073                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_5                                 , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_5_PDM1_VOLTFB_074                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_5                                 , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_VOLTAGEFEEDBACK_5_PDM1_VOLTFB_075                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_VOLTAGEFEEDBACK_5                                 , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_1_PDM1_CURRFB_001                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_1                                 , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_1_PDM1_CURRFB_002                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_1                                 , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_1_PDM1_CURRFB_003                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_1                                 , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_1_PDM1_CURRFB_004                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_1                                 , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_1_PDM1_CURRFB_005                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_1                                 , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_1_PDM1_CURRFB_006                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_1                                 , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_1_PDM1_CURRFB_007                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_1                                 , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_1_PDM1_CURRFB_008                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_1                                 , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_1_PDM1_CURRFB_009                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_1                                 , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_1_PDM1_CURRFB_010                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_1                                 , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_1_PDM1_CURRFB_011                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_1                                 , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_1_PDM1_CURRFB_012                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_1                                 , 352u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_1_PDM1_CURRFB_013                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_1                                 , 384u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_1_PDM1_CURRFB_014                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_1                                 , 416u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_1_PDM1_CURRFB_015                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_1                                 , 448u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_1_PDM1_CURRFB_016                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_1                                 , 480u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_2_PDM1_CURRFB_017                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_2                                 , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_2_PDM1_CURRFB_018                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_2                                 , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_2_PDM1_CURRFB_019                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_2                                 , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_2_PDM1_CURRFB_020                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_2                                 , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_2_PDM1_CURRFB_021                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_2                                 , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_2_PDM1_CURRFB_022                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_2                                 , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_2_PDM1_CURRFB_023                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_2                                 , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_2_PDM1_CURRFB_024                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_2                                 , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_2_PDM1_CURRFB_025                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_2                                 , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_2_PDM1_CURRFB_026                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_2                                 , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_2_PDM1_CURRFB_027                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_2                                 , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_2_PDM1_CURRFB_028                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_2                                 , 352u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_2_PDM1_CURRFB_029                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_2                                 , 384u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_2_PDM1_CURRFB_030                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_2                                 , 416u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_2_PDM1_CURRFB_031                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_2                                 , 448u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_2_PDM1_CURRFB_032                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_2                                 , 480u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_3_PDM1_CURRFB_033                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_3                                 , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_3_PDM1_CURRFB_034                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_3                                 , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_3_PDM1_CURRFB_035                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_3                                 , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_3_PDM1_CURRFB_036                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_3                                 , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_3_PDM1_CURRFB_037                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_3                                 , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_3_PDM1_CURRFB_038                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_3                                 , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_3_PDM1_CURRFB_039                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_3                                 , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_3_PDM1_CURRFB_040                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_3                                 , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_3_PDM1_CURRFB_041                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_3                                 , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_3_PDM1_CURRFB_042                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_3                                 , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_3_PDM1_CURRFB_043                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_3                                 , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_3_PDM1_CURRFB_044                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_3                                 , 352u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_3_PDM1_CURRFB_045                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_3                                 , 384u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_3_PDM1_CURRFB_046                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_3                                 , 416u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_3_PDM1_CURRFB_047                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_3                                 , 448u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_3_PDM1_CURRFB_048                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_3                                 , 480u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_4_PDM1_CURRFB_049                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_4                                 , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_4_PDM1_CURRFB_050                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_4                                 , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_4_PDM1_CURRFB_051                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_4                                 , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_4_PDM1_CURRFB_052                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_4                                 , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_4_PDM1_CURRFB_053                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_4                                 , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_4_PDM1_CURRFB_054                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_4                                 , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_4_PDM1_CURRFB_055                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_4                                 , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_4_PDM1_CURRFB_056                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_4                                 , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_4_PDM1_CURRFB_057                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_4                                 , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_4_PDM1_CURRFB_058                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_4                                 , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_4_PDM1_CURRFB_059                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_4                                 , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_4_PDM1_CURRFB_060                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_4                                 , 352u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_4_PDM1_CURRFB_061                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_4                                 , 384u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_4_PDM1_CURRFB_062                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_4                                 , 416u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_4_PDM1_CURRFB_063                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_4                                 , 448u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_4_PDM1_CURRFB_064                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_4                                 , 480u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_5_PDM1_CURRFB_065                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_5                                 , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_5_PDM1_CURRFB_066                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_5                                 , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_5_PDM1_CURRFB_067                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_5                                 , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_5_PDM1_CURRFB_068                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_5                                 , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_5_PDM1_CURRFB_069                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_5                                 , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_5_PDM1_CURRFB_070                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_5                                 , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_5_PDM1_CURRFB_071                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_5                                 , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_5_PDM1_CURRFB_072                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_5                                 , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_5_PDM1_CURRFB_073                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_5                                 , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_5_PDM1_CURRFB_074                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_5                                 , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_CURRENTFEEDBACK_5_PDM1_CURRFB_075                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_CURRENTFEEDBACK_5                                 , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_STUCKATONEVENT_PDM1_STUCKATON_01                                                , COM_FALSE, COM_RX_PDU_CANFD_PDM1_STUCKATONEVENT                                    , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_STUCKATONEVENT_PDM1_STUCKATON_02                                                , COM_FALSE, COM_RX_PDU_CANFD_PDM1_STUCKATONEVENT                                    , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_STUCKATONEVENT_PDM1_STUCKATON_03                                                , COM_FALSE, COM_RX_PDU_CANFD_PDM1_STUCKATONEVENT                                    , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_STUCKATOFFEVENT_PDM1_STUCKATOFF_01                                               , COM_FALSE, COM_RX_PDU_CANFD_PDM1_STUCKATOFFEVENT                                   , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_STUCKATOFFEVENT_PDM1_STUCKATOFF_02                                               , COM_FALSE, COM_RX_PDU_CANFD_PDM1_STUCKATOFFEVENT                                   , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_STUCKATOFFEVENT_PDM1_STUCKATOFF_03                                               , COM_FALSE, COM_RX_PDU_CANFD_PDM1_STUCKATOFFEVENT                                   , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_1_PDM1_TEMPFB_001                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_1                             , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_1_PDM1_TEMPFB_002                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_1                             , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_1_PDM1_TEMPFB_003                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_1                             , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_1_PDM1_TEMPFB_004                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_1                             , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_1_PDM1_TEMPFB_005                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_1                             , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_1_PDM1_TEMPFB_006                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_1                             , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_1_PDM1_TEMPFB_007                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_1                             , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_1_PDM1_TEMPFB_008                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_1                             , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_1_PDM1_TEMPFB_009                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_1                             , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_1_PDM1_TEMPFB_010                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_1                             , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_1_PDM1_TEMPFB_011                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_1                             , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_1_PDM1_TEMPFB_012                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_1                             , 352u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_1_PDM1_TEMPFB_013                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_1                             , 384u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_1_PDM1_TEMPFB_014                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_1                             , 416u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_1_PDM1_TEMPFB_015                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_1                             , 448u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_1_PDM1_TEMPFB_016                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_1                             , 480u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_2_PDM1_TEMPFB_017                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_2                             , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_2_PDM1_TEMPFB_018                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_2                             , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_2_PDM1_TEMPFB_019                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_2                             , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_2_PDM1_TEMPFB_020                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_2                             , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_2_PDM1_TEMPFB_021                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_2                             , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_2_PDM1_TEMPFB_022                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_2                             , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_2_PDM1_TEMPFB_023                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_2                             , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_2_PDM1_TEMPFB_024                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_2                             , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_2_PDM1_TEMPFB_025                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_2                             , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_2_PDM1_TEMPFB_026                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_2                             , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_2_PDM1_TEMPFB_027                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_2                             , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_2_PDM1_TEMPFB_028                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_2                             , 352u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_2_PDM1_TEMPFB_029                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_2                             , 384u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_2_PDM1_TEMPFB_030                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_2                             , 416u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_2_PDM1_TEMPFB_031                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_2                             , 448u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_2_PDM1_TEMPFB_032                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_2                             , 480u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_3_PDM1_TEMPFB_033                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_3                             , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_3_PDM1_TEMPFB_034                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_3                             , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_3_PDM1_TEMPFB_035                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_3                             , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_3_PDM1_TEMPFB_036                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_3                             , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_3_PDM1_TEMPFB_037                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_3                             , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_3_PDM1_TEMPFB_038                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_3                             , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_3_PDM1_TEMPFB_039                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_3                             , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_3_PDM1_TEMPFB_040                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_3                             , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_3_PDM1_TEMPFB_041                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_3                             , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_3_PDM1_TEMPFB_042                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_3                             , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_3_PDM1_TEMPFB_043                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_3                             , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_3_PDM1_TEMPFB_044                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_3                             , 352u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_3_PDM1_TEMPFB_045                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_3                             , 384u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_3_PDM1_TEMPFB_046                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_3                             , 416u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_3_PDM1_TEMPFB_047                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_3                             , 448u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_3_PDM1_TEMPFB_048                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_3                             , 480u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_4_PDM1_TEMPFB_049                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_4                             , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_4_PDM1_TEMPFB_050                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_4                             , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_4_PDM1_TEMPFB_051                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_4                             , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_4_PDM1_TEMPFB_052                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_4                             , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_4_PDM1_TEMPFB_053                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_4                             , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_4_PDM1_TEMPFB_054                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_4                             , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_4_PDM1_TEMPFB_055                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_4                             , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_4_PDM1_TEMPFB_056                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_4                             , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_4_PDM1_TEMPFB_057                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_4                             , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_4_PDM1_TEMPFB_058                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_4                             , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_4_PDM1_TEMPFB_059                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_4                             , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_4_PDM1_TEMPFB_060                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_4                             , 352u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_4_PDM1_TEMPFB_061                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_4                             , 384u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_4_PDM1_TEMPFB_062                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_4                             , 416u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_4_PDM1_TEMPFB_063                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_4                             , 448u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_4_PDM1_TEMPFB_064                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_4                             , 480u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_5_PDM1_TEMPFB_065                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_5                             , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_5_PDM1_TEMPFB_066                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_5                             , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_5_PDM1_TEMPFB_067                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_5                             , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_5_PDM1_TEMPFB_068                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_5                             , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_5_PDM1_TEMPFB_069                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_5                             , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_5_PDM1_TEMPFB_070                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_5                             , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_5_PDM1_TEMPFB_071                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_5                             , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_5_PDM1_TEMPFB_072                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_5                             , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_5_PDM1_TEMPFB_073                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_5                             , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_5_PDM1_TEMPFB_074                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_5                             , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_TEMPERATUREFEEDBACK_5_PDM1_TEMPFB_075                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM1_TEMPERATUREFEEDBACK_5                             , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_1_PDM2_VOLTFB_001                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_1                                 , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_1_PDM2_VOLTFB_002                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_1                                 , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_1_PDM2_VOLTFB_003                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_1                                 , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_1_PDM2_VOLTFB_004                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_1                                 , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_1_PDM2_VOLTFB_005                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_1                                 , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_1_PDM2_VOLTFB_006                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_1                                 , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_1_PDM2_VOLTFB_007                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_1                                 , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_1_PDM2_VOLTFB_008                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_1                                 , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_1_PDM2_VOLTFB_009                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_1                                 , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_1_PDM2_VOLTFB_010                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_1                                 , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_1_PDM2_VOLTFB_011                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_1                                 , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_1_PDM2_VOLTFB_012                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_1                                 , 352u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_1_PDM2_VOLTFB_013                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_1                                 , 384u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_1_PDM2_VOLTFB_014                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_1                                 , 416u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_1_PDM2_VOLTFB_015                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_1                                 , 448u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_1_PDM2_VOLTFB_016                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_1                                 , 480u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_2_PDM2_VOLTFB_017                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_2                                 , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_2_PDM2_VOLTFB_018                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_2                                 , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_2_PDM2_VOLTFB_019                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_2                                 , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_2_PDM2_VOLTFB_020                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_2                                 , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_2_PDM2_VOLTFB_021                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_2                                 , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_2_PDM2_VOLTFB_022                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_2                                 , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_2_PDM2_VOLTFB_023                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_2                                 , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_2_PDM2_VOLTFB_024                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_2                                 , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_2_PDM2_VOLTFB_025                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_2                                 , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_2_PDM2_VOLTFB_026                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_2                                 , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_2_PDM2_VOLTFB_027                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_2                                 , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_2_PDM2_VOLTFB_028                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_2                                 , 352u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_2_PDM2_VOLTFB_029                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_2                                 , 384u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_2_PDM2_VOLTFB_030                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_2                                 , 416u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_2_PDM2_VOLTFB_031                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_2                                 , 448u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_2_PDM2_VOLTFB_032                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_2                                 , 480u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_3_PDM2_VOLTFB_033                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_3                                 , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_3_PDM2_VOLTFB_034                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_3                                 , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_3_PDM2_VOLTFB_035                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_3                                 , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_3_PDM2_VOLTFB_036                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_3                                 , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_3_PDM2_VOLTFB_037                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_3                                 , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_3_PDM2_VOLTFB_038                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_3                                 , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_3_PDM2_VOLTFB_039                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_3                                 , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_3_PDM2_VOLTFB_040                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_3                                 , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_3_PDM2_VOLTFB_041                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_3                                 , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_3_PDM2_VOLTFB_042                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_3                                 , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_3_PDM2_VOLTFB_043                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_3                                 , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_3_PDM2_VOLTFB_044                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_3                                 , 352u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_3_PDM2_VOLTFB_045                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_3                                 , 384u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_3_PDM2_VOLTFB_046                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_3                                 , 416u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_3_PDM2_VOLTFB_047                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_3                                 , 448u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_3_PDM2_VOLTFB_048                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_3                                 , 480u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_4_PDM2_VOLTFB_049                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_4                                 , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_4_PDM2_VOLTFB_050                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_4                                 , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_4_PDM2_VOLTFB_051                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_4                                 , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_4_PDM2_VOLTFB_052                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_4                                 , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_4_PDM2_VOLTFB_053                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_4                                 , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_4_PDM2_VOLTFB_054                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_4                                 , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_4_PDM2_VOLTFB_055                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_4                                 , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_4_PDM2_VOLTFB_056                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_4                                 , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_4_PDM2_VOLTFB_057                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_4                                 , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_4_PDM2_VOLTFB_058                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_4                                 , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_4_PDM2_VOLTFB_059                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_4                                 , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_4_PDM2_VOLTFB_060                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_4                                 , 352u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_4_PDM2_VOLTFB_061                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_4                                 , 384u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_4_PDM2_VOLTFB_062                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_4                                 , 416u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_4_PDM2_VOLTFB_063                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_4                                 , 448u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_4_PDM2_VOLTFB_064                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_4                                 , 480u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_5_PDM2_VOLTFB_065                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_5                                 , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_5_PDM2_VOLTFB_066                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_5                                 , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_5_PDM2_VOLTFB_067                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_5                                 , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_5_PDM2_VOLTFB_068                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_5                                 , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_5_PDM2_VOLTFB_069                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_5                                 , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_5_PDM2_VOLTFB_070                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_5                                 , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_5_PDM2_VOLTFB_071                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_5                                 , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_5_PDM2_VOLTFB_072                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_5                                 , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_5_PDM2_VOLTFB_073                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_5                                 , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_5_PDM2_VOLTFB_074                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_5                                 , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_VOLTAGEFEEDBACK_5_PDM2_VOLTFB_075                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_VOLTAGEFEEDBACK_5                                 , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_1_PDM2_CURRFB_001                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_1                                 , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_1_PDM2_CURRFB_002                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_1                                 , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_1_PDM2_CURRFB_003                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_1                                 , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_1_PDM2_CURRFB_004                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_1                                 , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_1_PDM2_CURRFB_005                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_1                                 , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_1_PDM2_CURRFB_006                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_1                                 , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_1_PDM2_CURRFB_007                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_1                                 , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_1_PDM2_CURRFB_008                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_1                                 , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_1_PDM2_CURRFB_009                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_1                                 , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_1_PDM2_CURRFB_010                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_1                                 , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_1_PDM2_CURRFB_011                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_1                                 , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_1_PDM2_CURRFB_012                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_1                                 , 352u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_1_PDM2_CURRFB_013                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_1                                 , 384u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_1_PDM2_CURRFB_014                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_1                                 , 416u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_1_PDM2_CURRFB_015                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_1                                 , 448u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_1_PDM2_CURRFB_016                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_1                                 , 480u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_2_PDM2_CURRFB_017                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_2                                 , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_2_PDM2_CURRFB_018                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_2                                 , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_2_PDM2_CURRFB_019                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_2                                 , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_2_PDM2_CURRFB_020                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_2                                 , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_2_PDM2_CURRFB_021                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_2                                 , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_2_PDM2_CURRFB_022                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_2                                 , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_2_PDM2_CURRFB_023                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_2                                 , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_2_PDM2_CURRFB_024                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_2                                 , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_2_PDM2_CURRFB_025                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_2                                 , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_2_PDM2_CURRFB_026                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_2                                 , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_2_PDM2_CURRFB_027                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_2                                 , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_2_PDM2_CURRFB_028                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_2                                 , 352u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_2_PDM2_CURRFB_029                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_2                                 , 384u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_2_PDM2_CURRFB_030                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_2                                 , 416u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_2_PDM2_CURRFB_031                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_2                                 , 448u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_2_PDM2_CURRFB_032                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_2                                 , 480u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_3_PDM2_CURRFB_033                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_3                                 , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_3_PDM2_CURRFB_034                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_3                                 , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_3_PDM2_CURRFB_035                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_3                                 , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_3_PDM2_CURRFB_036                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_3                                 , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_3_PDM2_CURRFB_037                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_3                                 , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_3_PDM2_CURRFB_038                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_3                                 , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_3_PDM2_CURRFB_039                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_3                                 , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_3_PDM2_CURRFB_040                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_3                                 , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_3_PDM2_CURRFB_041                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_3                                 , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_3_PDM2_CURRFB_042                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_3                                 , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_3_PDM2_CURRFB_043                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_3                                 , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_3_PDM2_CURRFB_044                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_3                                 , 352u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_3_PDM2_CURRFB_045                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_3                                 , 384u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_3_PDM2_CURRFB_046                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_3                                 , 416u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_3_PDM2_CURRFB_047                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_3                                 , 448u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_3_PDM2_CURRFB_048                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_3                                 , 480u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_4_PDM2_CURRFB_049                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_4                                 , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_4_PDM2_CURRFB_050                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_4                                 , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_4_PDM2_CURRFB_051                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_4                                 , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_4_PDM2_CURRFB_052                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_4                                 , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_4_PDM2_CURRFB_053                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_4                                 , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_4_PDM2_CURRFB_054                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_4                                 , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_4_PDM2_CURRFB_055                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_4                                 , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_4_PDM2_CURRFB_056                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_4                                 , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_4_PDM2_CURRFB_057                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_4                                 , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_4_PDM2_CURRFB_058                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_4                                 , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_4_PDM2_CURRFB_059                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_4                                 , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_4_PDM2_CURRFB_060                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_4                                 , 352u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_4_PDM2_CURRFB_061                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_4                                 , 384u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_4_PDM2_CURRFB_062                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_4                                 , 416u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_4_PDM2_CURRFB_063                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_4                                 , 448u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_4_PDM2_CURRFB_064                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_4                                 , 480u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_5_PDM2_CURRFB_065                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_5                                 , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_5_PDM2_CURRFB_066                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_5                                 , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_5_PDM2_CURRFB_067                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_5                                 , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_5_PDM2_CURRFB_068                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_5                                 , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_5_PDM2_CURRFB_069                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_5                                 , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_5_PDM2_CURRFB_070                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_5                                 , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_5_PDM2_CURRFB_071                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_5                                 , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_5_PDM2_CURRFB_072                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_5                                 , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_5_PDM2_CURRFB_073                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_5                                 , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_5_PDM2_CURRFB_074                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_5                                 , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_CURRENTFEEDBACK_5_PDM2_CURRFB_075                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_CURRENTFEEDBACK_5                                 , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_STUCKATONEVENT_PDM2_STUCKATON_01                                                , COM_FALSE, COM_RX_PDU_CANFD_PDM2_STUCKATONEVENT                                    , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_STUCKATONEVENT_PDM2_STUCKATON_02                                                , COM_FALSE, COM_RX_PDU_CANFD_PDM2_STUCKATONEVENT                                    , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_STUCKATONEVENT_PDM2_STUCKATON_03                                                , COM_FALSE, COM_RX_PDU_CANFD_PDM2_STUCKATONEVENT                                    , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_STUCKATOFFEVENT_PDM2_STUCKATOFF_01                                               , COM_FALSE, COM_RX_PDU_CANFD_PDM2_STUCKATOFFEVENT                                   , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_STUCKATOFFEVENT_PDM2_STUCKATOFF_02                                               , COM_FALSE, COM_RX_PDU_CANFD_PDM2_STUCKATOFFEVENT                                   , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_STUCKATOFFEVENT_PDM2_STUCKATOFF_03                                               , COM_FALSE, COM_RX_PDU_CANFD_PDM2_STUCKATOFFEVENT                                   , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_1_PDM2_TEMPFB_001                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_1                             , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_1_PDM2_TEMPFB_002                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_1                             , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_1_PDM2_TEMPFB_003                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_1                             , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_1_PDM2_TEMPFB_004                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_1                             , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_1_PDM2_TEMPFB_005                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_1                             , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_1_PDM2_TEMPFB_006                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_1                             , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_1_PDM2_TEMPFB_007                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_1                             , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_1_PDM2_TEMPFB_008                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_1                             , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_1_PDM2_TEMPFB_009                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_1                             , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_1_PDM2_TEMPFB_010                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_1                             , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_1_PDM2_TEMPFB_011                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_1                             , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_1_PDM2_TEMPFB_012                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_1                             , 352u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_1_PDM2_TEMPFB_013                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_1                             , 384u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_1_PDM2_TEMPFB_014                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_1                             , 416u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_1_PDM2_TEMPFB_015                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_1                             , 448u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_1_PDM2_TEMPFB_016                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_1                             , 480u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_2_PDM2_TEMPFB_017                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_2                             , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_2_PDM2_TEMPFB_018                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_2                             , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_2_PDM2_TEMPFB_019                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_2                             , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_2_PDM2_TEMPFB_020                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_2                             , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_2_PDM2_TEMPFB_021                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_2                             , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_2_PDM2_TEMPFB_022                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_2                             , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_2_PDM2_TEMPFB_023                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_2                             , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_2_PDM2_TEMPFB_024                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_2                             , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_2_PDM2_TEMPFB_025                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_2                             , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_2_PDM2_TEMPFB_026                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_2                             , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_2_PDM2_TEMPFB_027                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_2                             , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_2_PDM2_TEMPFB_028                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_2                             , 352u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_2_PDM2_TEMPFB_029                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_2                             , 384u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_2_PDM2_TEMPFB_030                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_2                             , 416u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_2_PDM2_TEMPFB_031                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_2                             , 448u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_2_PDM2_TEMPFB_032                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_2                             , 480u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_3_PDM2_TEMPFB_033                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_3                             , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_3_PDM2_TEMPFB_034                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_3                             , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_3_PDM2_TEMPFB_035                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_3                             , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_3_PDM2_TEMPFB_036                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_3                             , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_3_PDM2_TEMPFB_037                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_3                             , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_3_PDM2_TEMPFB_038                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_3                             , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_3_PDM2_TEMPFB_039                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_3                             , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_3_PDM2_TEMPFB_040                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_3                             , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_3_PDM2_TEMPFB_041                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_3                             , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_3_PDM2_TEMPFB_042                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_3                             , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_3_PDM2_TEMPFB_043                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_3                             , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_3_PDM2_TEMPFB_044                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_3                             , 352u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_3_PDM2_TEMPFB_045                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_3                             , 384u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_3_PDM2_TEMPFB_046                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_3                             , 416u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_3_PDM2_TEMPFB_047                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_3                             , 448u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_3_PDM2_TEMPFB_048                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_3                             , 480u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_4_PDM2_TEMPFB_049                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_4                             , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_4_PDM2_TEMPFB_050                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_4                             , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_4_PDM2_TEMPFB_051                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_4                             , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_4_PDM2_TEMPFB_052                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_4                             , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_4_PDM2_TEMPFB_053                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_4                             , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_4_PDM2_TEMPFB_054                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_4                             , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_4_PDM2_TEMPFB_055                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_4                             , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_4_PDM2_TEMPFB_056                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_4                             , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_4_PDM2_TEMPFB_057                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_4                             , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_4_PDM2_TEMPFB_058                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_4                             , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_4_PDM2_TEMPFB_059                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_4                             , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_4_PDM2_TEMPFB_060                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_4                             , 352u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_4_PDM2_TEMPFB_061                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_4                             , 384u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_4_PDM2_TEMPFB_062                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_4                             , 416u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_4_PDM2_TEMPFB_063                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_4                             , 448u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_4_PDM2_TEMPFB_064                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_4                             , 480u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_5_PDM2_TEMPFB_065                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_5                             , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_5_PDM2_TEMPFB_066                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_5                             , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_5_PDM2_TEMPFB_067                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_5                             , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_5_PDM2_TEMPFB_068                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_5                             , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_5_PDM2_TEMPFB_069                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_5                             , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_5_PDM2_TEMPFB_070                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_5                             , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_5_PDM2_TEMPFB_071                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_5                             , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_5_PDM2_TEMPFB_072                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_5                             , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_5_PDM2_TEMPFB_073                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_5                             , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_5_PDM2_TEMPFB_074                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_5                             , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM2_TEMPERATUREFEEDBACK_5_PDM2_TEMPFB_075                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM2_TEMPERATUREFEEDBACK_5                             , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_1_PDM3_VOLTFB_001                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_1                                 , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_1_PDM3_VOLTFB_002                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_1                                 , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_1_PDM3_VOLTFB_003                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_1                                 , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_1_PDM3_VOLTFB_004                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_1                                 , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_1_PDM3_VOLTFB_005                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_1                                 , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_1_PDM3_VOLTFB_006                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_1                                 , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_1_PDM3_VOLTFB_007                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_1                                 , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_1_PDM3_VOLTFB_008                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_1                                 , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_1_PDM3_VOLTFB_009                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_1                                 , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_1_PDM3_VOLTFB_010                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_1                                 , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_1_PDM3_VOLTFB_011                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_1                                 , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_1_PDM3_VOLTFB_012                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_1                                 , 352u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_1_PDM3_VOLTFB_013                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_1                                 , 384u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_1_PDM3_VOLTFB_014                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_1                                 , 416u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_1_PDM3_VOLTFB_015                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_1                                 , 448u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_1_PDM3_VOLTFB_016                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_1                                 , 480u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_2_PDM3_VOLTFB_017                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_2                                 , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_2_PDM3_VOLTFB_018                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_2                                 , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_2_PDM3_VOLTFB_019                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_2                                 , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_2_PDM3_VOLTFB_020                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_2                                 , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_2_PDM3_VOLTFB_021                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_2                                 , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_2_PDM3_VOLTFB_022                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_2                                 , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_2_PDM3_VOLTFB_023                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_2                                 , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_2_PDM3_VOLTFB_024                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_2                                 , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_2_PDM3_VOLTFB_025                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_2                                 , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_2_PDM3_VOLTFB_026                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_2                                 , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_2_PDM3_VOLTFB_027                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_2                                 , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_2_PDM3_VOLTFB_028                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_2                                 , 352u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_2_PDM3_VOLTFB_029                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_2                                 , 384u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_2_PDM3_VOLTFB_030                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_2                                 , 416u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_2_PDM3_VOLTFB_031                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_2                                 , 448u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_2_PDM3_VOLTFB_032                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_2                                 , 480u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_3_PDM3_VOLTFB_033                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_3                                 , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_3_PDM3_VOLTFB_034                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_3                                 , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_3_PDM3_VOLTFB_035                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_3                                 , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_3_PDM3_VOLTFB_036                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_3                                 , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_3_PDM3_VOLTFB_037                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_3                                 , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_3_PDM3_VOLTFB_038                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_3                                 , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_3_PDM3_VOLTFB_039                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_3                                 , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_3_PDM3_VOLTFB_040                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_3                                 , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_3_PDM3_VOLTFB_041                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_3                                 , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_3_PDM3_VOLTFB_042                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_3                                 , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_3_PDM3_VOLTFB_043                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_3                                 , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_3_PDM3_VOLTFB_044                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_3                                 , 352u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_3_PDM3_VOLTFB_045                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_3                                 , 384u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_3_PDM3_VOLTFB_046                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_3                                 , 416u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_3_PDM3_VOLTFB_047                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_3                                 , 448u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_3_PDM3_VOLTFB_048                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_3                                 , 480u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_4_PDM3_VOLTFB_049                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_4                                 , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_4_PDM3_VOLTFB_050                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_4                                 , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_4_PDM3_VOLTFB_051                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_4                                 , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_4_PDM3_VOLTFB_052                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_4                                 , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_4_PDM3_VOLTFB_053                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_4                                 , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_4_PDM3_VOLTFB_054                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_4                                 , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_4_PDM3_VOLTFB_055                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_4                                 , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_4_PDM3_VOLTFB_056                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_4                                 , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_4_PDM3_VOLTFB_057                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_4                                 , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_4_PDM3_VOLTFB_058                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_4                                 , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_4_PDM3_VOLTFB_059                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_4                                 , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_4_PDM3_VOLTFB_060                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_4                                 , 352u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_4_PDM3_VOLTFB_061                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_4                                 , 384u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_4_PDM3_VOLTFB_062                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_4                                 , 416u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_4_PDM3_VOLTFB_063                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_4                                 , 448u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_4_PDM3_VOLTFB_064                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_4                                 , 480u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_5_PDM3_VOLTFB_065                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_5                                 , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_5_PDM3_VOLTFB_066                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_5                                 , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_5_PDM3_VOLTFB_067                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_5                                 , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_5_PDM3_VOLTFB_068                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_5                                 , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_5_PDM3_VOLTFB_069                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_5                                 , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_5_PDM3_VOLTFB_070                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_5                                 , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_5_PDM3_VOLTFB_071                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_5                                 , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_5_PDM3_VOLTFB_072                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_5                                 , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_5_PDM3_VOLTFB_073                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_5                                 , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_5_PDM3_VOLTFB_074                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_5                                 , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_VOLTAGEFEEDBACK_5_PDM3_VOLTFB_075                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_VOLTAGEFEEDBACK_5                                 , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_1_PDM3_CURRFB_001                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_1                                 , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_1_PDM3_CURRFB_002                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_1                                 , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_1_PDM3_CURRFB_003                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_1                                 , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_1_PDM3_CURRFB_004                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_1                                 , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_1_PDM3_CURRFB_005                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_1                                 , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_1_PDM3_CURRFB_006                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_1                                 , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_1_PDM3_CURRFB_007                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_1                                 , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_1_PDM3_CURRFB_008                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_1                                 , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_1_PDM3_CURRFB_009                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_1                                 , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_1_PDM3_CURRFB_010                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_1                                 , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_1_PDM3_CURRFB_011                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_1                                 , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_1_PDM3_CURRFB_012                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_1                                 , 352u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_1_PDM3_CURRFB_013                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_1                                 , 384u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_1_PDM3_CURRFB_014                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_1                                 , 416u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_1_PDM3_CURRFB_015                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_1                                 , 448u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_1_PDM3_CURRFB_016                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_1                                 , 480u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_2_PDM3_CURRFB_017                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_2                                 , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_2_PDM3_CURRFB_018                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_2                                 , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_2_PDM3_CURRFB_019                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_2                                 , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_2_PDM3_CURRFB_020                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_2                                 , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_2_PDM3_CURRFB_021                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_2                                 , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_2_PDM3_CURRFB_022                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_2                                 , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_2_PDM3_CURRFB_023                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_2                                 , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_2_PDM3_CURRFB_024                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_2                                 , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_2_PDM3_CURRFB_025                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_2                                 , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_2_PDM3_CURRFB_026                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_2                                 , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_2_PDM3_CURRFB_027                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_2                                 , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_2_PDM3_CURRFB_028                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_2                                 , 352u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_2_PDM3_CURRFB_029                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_2                                 , 384u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_2_PDM3_CURRFB_030                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_2                                 , 416u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_2_PDM3_CURRFB_031                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_2                                 , 448u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_2_PDM3_CURRFB_032                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_2                                 , 480u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_3_PDM3_CURRFB_033                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_3                                 , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_3_PDM3_CURRFB_034                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_3                                 , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_3_PDM3_CURRFB_035                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_3                                 , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_3_PDM3_CURRFB_036                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_3                                 , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_3_PDM3_CURRFB_037                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_3                                 , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_3_PDM3_CURRFB_038                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_3                                 , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_3_PDM3_CURRFB_039                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_3                                 , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_3_PDM3_CURRFB_040                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_3                                 , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_3_PDM3_CURRFB_041                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_3                                 , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_3_PDM3_CURRFB_042                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_3                                 , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_3_PDM3_CURRFB_043                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_3                                 , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_3_PDM3_CURRFB_044                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_3                                 , 352u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_3_PDM3_CURRFB_045                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_3                                 , 384u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_3_PDM3_CURRFB_046                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_3                                 , 416u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_3_PDM3_CURRFB_047                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_3                                 , 448u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_3_PDM3_CURRFB_048                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_3                                 , 480u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_4_PDM3_CURRFB_049                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_4                                 , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_4_PDM3_CURRFB_050                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_4                                 , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_4_PDM3_CURRFB_051                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_4                                 , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_4_PDM3_CURRFB_052                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_4                                 , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_4_PDM3_CURRFB_053                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_4                                 , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_4_PDM3_CURRFB_054                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_4                                 , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_4_PDM3_CURRFB_055                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_4                                 , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_4_PDM3_CURRFB_056                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_4                                 , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_4_PDM3_CURRFB_057                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_4                                 , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_4_PDM3_CURRFB_058                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_4                                 , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_4_PDM3_CURRFB_059                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_4                                 , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_4_PDM3_CURRFB_060                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_4                                 , 352u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_4_PDM3_CURRFB_061                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_4                                 , 384u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_4_PDM3_CURRFB_062                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_4                                 , 416u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_4_PDM3_CURRFB_063                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_4                                 , 448u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_4_PDM3_CURRFB_064                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_4                                 , 480u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_5_PDM3_CURRFB_065                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_5                                 , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_5_PDM3_CURRFB_066                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_5                                 , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_5_PDM3_CURRFB_067                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_5                                 , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_5_PDM3_CURRFB_068                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_5                                 , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_5_PDM3_CURRFB_069                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_5                                 , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_5_PDM3_CURRFB_070                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_5                                 , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_5_PDM3_CURRFB_071                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_5                                 , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_5_PDM3_CURRFB_072                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_5                                 , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_5_PDM3_CURRFB_073                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_5                                 , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_5_PDM3_CURRFB_074                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_5                                 , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_CURRENTFEEDBACK_5_PDM3_CURRFB_075                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_CURRENTFEEDBACK_5                                 , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_STUCKATONEVENT_PDM3_STUCKATON_01                                                , COM_FALSE, COM_RX_PDU_CANFD_PDM3_STUCKATONEVENT                                    , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_STUCKATONEVENT_PDM3_STUCKATON_02                                                , COM_FALSE, COM_RX_PDU_CANFD_PDM3_STUCKATONEVENT                                    , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_STUCKATONEVENT_PDM3_STUCKATON_03                                                , COM_FALSE, COM_RX_PDU_CANFD_PDM3_STUCKATONEVENT                                    , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_STUCKATOFFEVENT_PDM3_STUCKATOFF_01                                               , COM_FALSE, COM_RX_PDU_CANFD_PDM3_STUCKATOFFEVENT                                   , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_STUCKATOFFEVENT_PDM3_STUCKATOFF_02                                               , COM_FALSE, COM_RX_PDU_CANFD_PDM3_STUCKATOFFEVENT                                   , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_STUCKATOFFEVENT_PDM3_STUCKATOFF_03                                               , COM_FALSE, COM_RX_PDU_CANFD_PDM3_STUCKATOFFEVENT                                   , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_1_PDM3_TEMPFB_001                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_1                             , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_1_PDM3_TEMPFB_002                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_1                             , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_1_PDM3_TEMPFB_003                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_1                             , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_1_PDM3_TEMPFB_004                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_1                             , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_1_PDM3_TEMPFB_005                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_1                             , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_1_PDM3_TEMPFB_006                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_1                             , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_1_PDM3_TEMPFB_007                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_1                             , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_1_PDM3_TEMPFB_008                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_1                             , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_1_PDM3_TEMPFB_009                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_1                             , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_1_PDM3_TEMPFB_010                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_1                             , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_1_PDM3_TEMPFB_011                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_1                             , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_1_PDM3_TEMPFB_012                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_1                             , 352u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_1_PDM3_TEMPFB_013                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_1                             , 384u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_1_PDM3_TEMPFB_014                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_1                             , 416u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_1_PDM3_TEMPFB_015                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_1                             , 448u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_1_PDM3_TEMPFB_016                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_1                             , 480u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_2_PDM3_TEMPFB_017                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_2                             , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_2_PDM3_TEMPFB_018                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_2                             , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_2_PDM3_TEMPFB_019                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_2                             , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_2_PDM3_TEMPFB_020                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_2                             , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_2_PDM3_TEMPFB_021                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_2                             , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_2_PDM3_TEMPFB_022                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_2                             , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_2_PDM3_TEMPFB_023                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_2                             , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_2_PDM3_TEMPFB_024                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_2                             , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_2_PDM3_TEMPFB_025                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_2                             , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_2_PDM3_TEMPFB_026                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_2                             , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_2_PDM3_TEMPFB_027                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_2                             , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_2_PDM3_TEMPFB_028                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_2                             , 352u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_2_PDM3_TEMPFB_029                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_2                             , 384u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_2_PDM3_TEMPFB_030                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_2                             , 416u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_2_PDM3_TEMPFB_031                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_2                             , 448u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_2_PDM3_TEMPFB_032                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_2                             , 480u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_3_PDM3_TEMPFB_033                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_3                             , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_3_PDM3_TEMPFB_034                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_3                             , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_3_PDM3_TEMPFB_035                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_3                             , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_3_PDM3_TEMPFB_036                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_3                             , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_3_PDM3_TEMPFB_037                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_3                             , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_3_PDM3_TEMPFB_038                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_3                             , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_3_PDM3_TEMPFB_039                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_3                             , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_3_PDM3_TEMPFB_040                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_3                             , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_3_PDM3_TEMPFB_041                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_3                             , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_3_PDM3_TEMPFB_042                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_3                             , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_3_PDM3_TEMPFB_043                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_3                             , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_3_PDM3_TEMPFB_044                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_3                             , 352u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_3_PDM3_TEMPFB_045                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_3                             , 384u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_3_PDM3_TEMPFB_046                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_3                             , 416u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_3_PDM3_TEMPFB_047                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_3                             , 448u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_3_PDM3_TEMPFB_048                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_3                             , 480u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_4_PDM3_TEMPFB_049                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_4                             , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_4_PDM3_TEMPFB_050                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_4                             , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_4_PDM3_TEMPFB_051                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_4                             , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_4_PDM3_TEMPFB_052                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_4                             , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_4_PDM3_TEMPFB_053                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_4                             , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_4_PDM3_TEMPFB_054                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_4                             , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_4_PDM3_TEMPFB_055                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_4                             , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_4_PDM3_TEMPFB_056                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_4                             , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_4_PDM3_TEMPFB_057                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_4                             , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_4_PDM3_TEMPFB_058                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_4                             , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_4_PDM3_TEMPFB_059                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_4                             , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_4_PDM3_TEMPFB_060                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_4                             , 352u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_4_PDM3_TEMPFB_061                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_4                             , 384u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_4_PDM3_TEMPFB_062                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_4                             , 416u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_4_PDM3_TEMPFB_063                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_4                             , 448u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_4_PDM3_TEMPFB_064                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_4                             , 480u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_5_PDM3_TEMPFB_065                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_5                             , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_5_PDM3_TEMPFB_066                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_5                             , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_5_PDM3_TEMPFB_067                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_5                             , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_5_PDM3_TEMPFB_068                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_5                             , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_5_PDM3_TEMPFB_069                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_5                             , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_5_PDM3_TEMPFB_070                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_5                             , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_5_PDM3_TEMPFB_071                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_5                             , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_5_PDM3_TEMPFB_072                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_5                             , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_5_PDM3_TEMPFB_073                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_5                             , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_5_PDM3_TEMPFB_074                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_5                             , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM3_TEMPERATUREFEEDBACK_5_PDM3_TEMPFB_075                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM3_TEMPERATUREFEEDBACK_5                             , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_1_PDM4_VOLTFB_001                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_1                                 , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_1_PDM4_VOLTFB_002                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_1                                 , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_1_PDM4_VOLTFB_003                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_1                                 , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_1_PDM4_VOLTFB_004                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_1                                 , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_1_PDM4_VOLTFB_005                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_1                                 , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_1_PDM4_VOLTFB_006                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_1                                 , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_1_PDM4_VOLTFB_007                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_1                                 , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_1_PDM4_VOLTFB_008                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_1                                 , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_1_PDM4_VOLTFB_009                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_1                                 , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_1_PDM4_VOLTFB_010                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_1                                 , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_1_PDM4_VOLTFB_011                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_1                                 , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_1_PDM4_VOLTFB_012                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_1                                 , 352u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_1_PDM4_VOLTFB_013                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_1                                 , 384u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_1_PDM4_VOLTFB_014                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_1                                 , 416u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_1_PDM4_VOLTFB_015                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_1                                 , 448u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_1_PDM4_VOLTFB_016                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_1                                 , 480u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_2_PDM4_VOLTFB_017                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_2                                 , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_2_PDM4_VOLTFB_018                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_2                                 , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_2_PDM4_VOLTFB_019                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_2                                 , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_2_PDM4_VOLTFB_020                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_2                                 , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_2_PDM4_VOLTFB_021                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_2                                 , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_2_PDM4_VOLTFB_022                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_2                                 , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_2_PDM4_VOLTFB_023                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_2                                 , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_2_PDM4_VOLTFB_024                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_2                                 , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_2_PDM4_VOLTFB_025                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_2                                 , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_2_PDM4_VOLTFB_026                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_2                                 , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_2_PDM4_VOLTFB_027                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_2                                 , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_2_PDM4_VOLTFB_028                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_2                                 , 352u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_2_PDM4_VOLTFB_029                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_2                                 , 384u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_2_PDM4_VOLTFB_030                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_2                                 , 416u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_2_PDM4_VOLTFB_031                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_2                                 , 448u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_2_PDM4_VOLTFB_032                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_2                                 , 480u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_3_PDM4_VOLTFB_033                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_3                                 , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_3_PDM4_VOLTFB_034                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_3                                 , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_3_PDM4_VOLTFB_035                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_3                                 , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_3_PDM4_VOLTFB_036                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_3                                 , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_3_PDM4_VOLTFB_037                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_3                                 , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_3_PDM4_VOLTFB_038                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_3                                 , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_3_PDM4_VOLTFB_039                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_3                                 , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_3_PDM4_VOLTFB_040                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_3                                 , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_3_PDM4_VOLTFB_041                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_3                                 , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_3_PDM4_VOLTFB_042                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_3                                 , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_3_PDM4_VOLTFB_043                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_3                                 , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_3_PDM4_VOLTFB_044                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_3                                 , 352u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_3_PDM4_VOLTFB_045                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_3                                 , 384u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_3_PDM4_VOLTFB_046                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_3                                 , 416u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_3_PDM4_VOLTFB_047                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_3                                 , 448u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_3_PDM4_VOLTFB_048                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_3                                 , 480u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_4_PDM4_VOLTFB_049                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_4                                 , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_4_PDM4_VOLTFB_050                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_4                                 , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_4_PDM4_VOLTFB_051                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_4                                 , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_4_PDM4_VOLTFB_052                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_4                                 , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_4_PDM4_VOLTFB_053                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_4                                 , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_4_PDM4_VOLTFB_054                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_4                                 , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_4_PDM4_VOLTFB_055                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_4                                 , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_4_PDM4_VOLTFB_056                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_4                                 , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_4_PDM4_VOLTFB_057                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_4                                 , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_4_PDM4_VOLTFB_058                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_4                                 , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_4_PDM4_VOLTFB_059                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_4                                 , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_4_PDM4_VOLTFB_060                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_4                                 , 352u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_4_PDM4_VOLTFB_061                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_4                                 , 384u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_4_PDM4_VOLTFB_062                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_4                                 , 416u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_4_PDM4_VOLTFB_063                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_4                                 , 448u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_4_PDM4_VOLTFB_064                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_4                                 , 480u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_5_PDM4_VOLTFB_065                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_5                                 , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_5_PDM4_VOLTFB_066                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_5                                 , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_5_PDM4_VOLTFB_067                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_5                                 , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_5_PDM4_VOLTFB_068                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_5                                 , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_5_PDM4_VOLTFB_069                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_5                                 , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_5_PDM4_VOLTFB_070                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_5                                 , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_5_PDM4_VOLTFB_071                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_5                                 , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_5_PDM4_VOLTFB_072                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_5                                 , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_5_PDM4_VOLTFB_073                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_5                                 , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_5_PDM4_VOLTFB_074                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_5                                 , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_VOLTAGEFEEDBACK_5_PDM4_VOLTFB_075                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_VOLTAGEFEEDBACK_5                                 , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_1_PDM4_CURRFB_001                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_1                                 , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_1_PDM4_CURRFB_002                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_1                                 , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_1_PDM4_CURRFB_003                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_1                                 , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_1_PDM4_CURRFB_004                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_1                                 , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_1_PDM4_CURRFB_005                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_1                                 , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_1_PDM4_CURRFB_006                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_1                                 , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_1_PDM4_CURRFB_007                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_1                                 , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_1_PDM4_CURRFB_008                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_1                                 , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_1_PDM4_CURRFB_009                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_1                                 , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_1_PDM4_CURRFB_010                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_1                                 , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_1_PDM4_CURRFB_011                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_1                                 , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_1_PDM4_CURRFB_012                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_1                                 , 352u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_1_PDM4_CURRFB_013                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_1                                 , 384u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_1_PDM4_CURRFB_014                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_1                                 , 416u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_1_PDM4_CURRFB_015                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_1                                 , 448u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_1_PDM4_CURRFB_016                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_1                                 , 480u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_2_PDM4_CURRFB_017                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_2                                 , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_2_PDM4_CURRFB_018                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_2                                 , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_2_PDM4_CURRFB_019                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_2                                 , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_2_PDM4_CURRFB_020                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_2                                 , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_2_PDM4_CURRFB_021                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_2                                 , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_2_PDM4_CURRFB_022                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_2                                 , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_2_PDM4_CURRFB_023                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_2                                 , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_2_PDM4_CURRFB_024                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_2                                 , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_2_PDM4_CURRFB_025                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_2                                 , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_2_PDM4_CURRFB_026                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_2                                 , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_2_PDM4_CURRFB_027                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_2                                 , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_2_PDM4_CURRFB_028                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_2                                 , 352u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_2_PDM4_CURRFB_029                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_2                                 , 384u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_2_PDM4_CURRFB_030                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_2                                 , 416u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_2_PDM4_CURRFB_031                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_2                                 , 448u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_2_PDM4_CURRFB_032                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_2                                 , 480u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_3_PDM4_CURRFB_033                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_3                                 , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_3_PDM4_CURRFB_034                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_3                                 , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_3_PDM4_CURRFB_035                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_3                                 , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_3_PDM4_CURRFB_036                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_3                                 , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_3_PDM4_CURRFB_037                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_3                                 , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_3_PDM4_CURRFB_038                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_3                                 , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_3_PDM4_CURRFB_039                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_3                                 , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_3_PDM4_CURRFB_040                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_3                                 , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_3_PDM4_CURRFB_041                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_3                                 , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_3_PDM4_CURRFB_042                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_3                                 , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_3_PDM4_CURRFB_043                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_3                                 , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_3_PDM4_CURRFB_044                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_3                                 , 352u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_3_PDM4_CURRFB_045                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_3                                 , 384u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_3_PDM4_CURRFB_046                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_3                                 , 416u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_3_PDM4_CURRFB_047                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_3                                 , 448u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_3_PDM4_CURRFB_048                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_3                                 , 480u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_4_PDM4_CURRFB_049                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_4                                 , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_4_PDM4_CURRFB_050                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_4                                 , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_4_PDM4_CURRFB_051                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_4                                 , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_4_PDM4_CURRFB_052                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_4                                 , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_4_PDM4_CURRFB_053                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_4                                 , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_4_PDM4_CURRFB_054                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_4                                 , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_4_PDM4_CURRFB_055                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_4                                 , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_4_PDM4_CURRFB_056                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_4                                 , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_4_PDM4_CURRFB_057                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_4                                 , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_4_PDM4_CURRFB_058                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_4                                 , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_4_PDM4_CURRFB_059                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_4                                 , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_4_PDM4_CURRFB_060                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_4                                 , 352u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_4_PDM4_CURRFB_061                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_4                                 , 384u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_4_PDM4_CURRFB_062                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_4                                 , 416u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_4_PDM4_CURRFB_063                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_4                                 , 448u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_4_PDM4_CURRFB_064                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_4                                 , 480u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_5_PDM4_CURRFB_065                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_5                                 , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_5_PDM4_CURRFB_066                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_5                                 , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_5_PDM4_CURRFB_067                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_5                                 , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_5_PDM4_CURRFB_068                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_5                                 , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_5_PDM4_CURRFB_069                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_5                                 , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_5_PDM4_CURRFB_070                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_5                                 , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_5_PDM4_CURRFB_071                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_5                                 , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_5_PDM4_CURRFB_072                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_5                                 , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_5_PDM4_CURRFB_073                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_5                                 , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_5_PDM4_CURRFB_074                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_5                                 , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_CURRENTFEEDBACK_5_PDM4_CURRFB_075                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_CURRENTFEEDBACK_5                                 , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_STUCKATONEVENT_PDM4_STUCKATON_01                                                , COM_FALSE, COM_RX_PDU_CANFD_PDM4_STUCKATONEVENT                                    , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_STUCKATONEVENT_PDM4_STUCKATON_02                                                , COM_FALSE, COM_RX_PDU_CANFD_PDM4_STUCKATONEVENT                                    , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_STUCKATONEVENT_PDM4_STUCKATON_03                                                , COM_FALSE, COM_RX_PDU_CANFD_PDM4_STUCKATONEVENT                                    , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_STUCKATOFFEVENT_PDM4_STUCKATOFF_01                                               , COM_FALSE, COM_RX_PDU_CANFD_PDM4_STUCKATOFFEVENT                                   , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_STUCKATOFFEVENT_PDM4_STUCKATOFF_02                                               , COM_FALSE, COM_RX_PDU_CANFD_PDM4_STUCKATOFFEVENT                                   , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_STUCKATOFFEVENT_PDM4_STUCKATOFF_03                                               , COM_FALSE, COM_RX_PDU_CANFD_PDM4_STUCKATOFFEVENT                                   , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_1_PDM4_TEMPFB_001                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_1                             , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_1_PDM4_TEMPFB_002                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_1                             , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_1_PDM4_TEMPFB_003                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_1                             , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_1_PDM4_TEMPFB_004                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_1                             , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_1_PDM4_TEMPFB_005                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_1                             , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_1_PDM4_TEMPFB_006                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_1                             , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_1_PDM4_TEMPFB_007                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_1                             , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_1_PDM4_TEMPFB_008                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_1                             , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_1_PDM4_TEMPFB_009                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_1                             , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_1_PDM4_TEMPFB_010                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_1                             , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_1_PDM4_TEMPFB_011                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_1                             , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_1_PDM4_TEMPFB_012                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_1                             , 352u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_1_PDM4_TEMPFB_013                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_1                             , 384u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_1_PDM4_TEMPFB_014                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_1                             , 416u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_1_PDM4_TEMPFB_015                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_1                             , 448u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_1_PDM4_TEMPFB_016                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_1                             , 480u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_2_PDM4_TEMPFB_017                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_2                             , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_2_PDM4_TEMPFB_018                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_2                             , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_2_PDM4_TEMPFB_019                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_2                             , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_2_PDM4_TEMPFB_020                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_2                             , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_2_PDM4_TEMPFB_021                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_2                             , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_2_PDM4_TEMPFB_022                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_2                             , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_2_PDM4_TEMPFB_023                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_2                             , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_2_PDM4_TEMPFB_024                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_2                             , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_2_PDM4_TEMPFB_025                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_2                             , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_2_PDM4_TEMPFB_026                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_2                             , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_2_PDM4_TEMPFB_027                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_2                             , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_2_PDM4_TEMPFB_028                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_2                             , 352u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_2_PDM4_TEMPFB_029                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_2                             , 384u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_2_PDM4_TEMPFB_030                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_2                             , 416u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_2_PDM4_TEMPFB_031                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_2                             , 448u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_2_PDM4_TEMPFB_032                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_2                             , 480u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_3_PDM4_TEMPFB_033                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_3                             , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_3_PDM4_TEMPFB_034                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_3                             , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_3_PDM4_TEMPFB_035                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_3                             , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_3_PDM4_TEMPFB_036                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_3                             , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_3_PDM4_TEMPFB_037                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_3                             , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_3_PDM4_TEMPFB_038                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_3                             , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_3_PDM4_TEMPFB_039                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_3                             , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_3_PDM4_TEMPFB_040                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_3                             , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_3_PDM4_TEMPFB_041                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_3                             , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_3_PDM4_TEMPFB_042                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_3                             , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_3_PDM4_TEMPFB_043                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_3                             , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_3_PDM4_TEMPFB_044                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_3                             , 352u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_3_PDM4_TEMPFB_045                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_3                             , 384u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_3_PDM4_TEMPFB_046                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_3                             , 416u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_3_PDM4_TEMPFB_047                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_3                             , 448u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_3_PDM4_TEMPFB_048                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_3                             , 480u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_4_PDM4_TEMPFB_049                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_4                             , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_4_PDM4_TEMPFB_050                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_4                             , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_4_PDM4_TEMPFB_051                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_4                             , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_4_PDM4_TEMPFB_052                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_4                             , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_4_PDM4_TEMPFB_053                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_4                             , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_4_PDM4_TEMPFB_054                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_4                             , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_4_PDM4_TEMPFB_055                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_4                             , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_4_PDM4_TEMPFB_056                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_4                             , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_4_PDM4_TEMPFB_057                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_4                             , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_4_PDM4_TEMPFB_058                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_4                             , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_4_PDM4_TEMPFB_059                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_4                             , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_4_PDM4_TEMPFB_060                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_4                             , 352u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_4_PDM4_TEMPFB_061                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_4                             , 384u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_4_PDM4_TEMPFB_062                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_4                             , 416u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_4_PDM4_TEMPFB_063                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_4                             , 448u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_4_PDM4_TEMPFB_064                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_4                             , 480u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_5_PDM4_TEMPFB_065                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_5                             , 0u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_5_PDM4_TEMPFB_066                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_5                             , 32u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_5_PDM4_TEMPFB_067                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_5                             , 64u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_5_PDM4_TEMPFB_068                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_5                             , 96u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_5_PDM4_TEMPFB_069                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_5                             , 128u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_5_PDM4_TEMPFB_070                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_5                             , 160u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_5_PDM4_TEMPFB_071                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_5                             , 192u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_5_PDM4_TEMPFB_072                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_5                             , 224u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_5_PDM4_TEMPFB_073                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_5                             , 256u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_5_PDM4_TEMPFB_074                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_5                             , 288u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM4_TEMPERATUREFEEDBACK_5_PDM4_TEMPFB_075                                                  , COM_FALSE, COM_RX_PDU_CANFD_PDM4_TEMPERATUREFEEDBACK_5                             , 320u, 32u, COM_SIGNAL_U32, COM_FALSE, 0u, 0xFFFFFFFFu , 0u },
    { COM_SIG_RX_CANFD_PDM1_DIAGRESPONSE_PDM1_DIAGRESP_BYTE00                                             , COM_FALSE, COM_RX_PDU_CANFD_PDM1_DIAGRESPONSE                                      , 0u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_CANFD_PDM1_DIAGRESPONSE_PDM1_DIAGRESP_BYTE01                                             , COM_FALSE, COM_RX_PDU_CANFD_PDM1_DIAGRESPONSE                                      , 8u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_CANFD_PDM1_DIAGRESPONSE_PDM1_DIAGRESP_BYTE02                                             , COM_FALSE, COM_RX_PDU_CANFD_PDM1_DIAGRESPONSE                                      , 16u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_CANFD_PDM1_DIAGRESPONSE_PDM1_DIAGRESP_BYTE03                                             , COM_FALSE, COM_RX_PDU_CANFD_PDM1_DIAGRESPONSE                                      , 24u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_CANFD_PDM1_DIAGRESPONSE_PDM1_DIAGRESP_BYTE04                                             , COM_FALSE, COM_RX_PDU_CANFD_PDM1_DIAGRESPONSE                                      , 32u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_CANFD_PDM1_DIAGRESPONSE_PDM1_DIAGRESP_BYTE05                                             , COM_FALSE, COM_RX_PDU_CANFD_PDM1_DIAGRESPONSE                                      , 40u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_CANFD_PDM1_DIAGRESPONSE_PDM1_DIAGRESP_BYTE06                                             , COM_FALSE, COM_RX_PDU_CANFD_PDM1_DIAGRESPONSE                                      , 48u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_CANFD_PDM1_DIAGRESPONSE_PDM1_DIAGRESP_BYTE07                                             , COM_FALSE, COM_RX_PDU_CANFD_PDM1_DIAGRESPONSE                                      , 56u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_CANFD_PDM2_DIAGRESPONSE_PDM2_DIAGRESP_BYTE00                                             , COM_FALSE, COM_RX_PDU_CANFD_PDM2_DIAGRESPONSE                                      , 0u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_CANFD_PDM2_DIAGRESPONSE_PDM2_DIAGRESP_BYTE01                                             , COM_FALSE, COM_RX_PDU_CANFD_PDM2_DIAGRESPONSE                                      , 8u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_CANFD_PDM2_DIAGRESPONSE_PDM2_DIAGRESP_BYTE02                                             , COM_FALSE, COM_RX_PDU_CANFD_PDM2_DIAGRESPONSE                                      , 16u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_CANFD_PDM2_DIAGRESPONSE_PDM2_DIAGRESP_BYTE03                                             , COM_FALSE, COM_RX_PDU_CANFD_PDM2_DIAGRESPONSE                                      , 24u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_CANFD_PDM2_DIAGRESPONSE_PDM2_DIAGRESP_BYTE04                                             , COM_FALSE, COM_RX_PDU_CANFD_PDM2_DIAGRESPONSE                                      , 32u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_CANFD_PDM2_DIAGRESPONSE_PDM2_DIAGRESP_BYTE05                                             , COM_FALSE, COM_RX_PDU_CANFD_PDM2_DIAGRESPONSE                                      , 40u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_CANFD_PDM2_DIAGRESPONSE_PDM2_DIAGRESP_BYTE06                                             , COM_FALSE, COM_RX_PDU_CANFD_PDM2_DIAGRESPONSE                                      , 48u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_CANFD_PDM2_DIAGRESPONSE_PDM2_DIAGRESP_BYTE07                                             , COM_FALSE, COM_RX_PDU_CANFD_PDM2_DIAGRESPONSE                                      , 56u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_CANFD_PDM3_DIAGRESPONSE_PDM3_DIAGRESP_BYTE00                                             , COM_FALSE, COM_RX_PDU_CANFD_PDM3_DIAGRESPONSE                                      , 0u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_CANFD_PDM3_DIAGRESPONSE_PDM3_DIAGRESP_BYTE01                                             , COM_FALSE, COM_RX_PDU_CANFD_PDM3_DIAGRESPONSE                                      , 8u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_CANFD_PDM3_DIAGRESPONSE_PDM3_DIAGRESP_BYTE02                                             , COM_FALSE, COM_RX_PDU_CANFD_PDM3_DIAGRESPONSE                                      , 16u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_CANFD_PDM3_DIAGRESPONSE_PDM3_DIAGRESP_BYTE03                                             , COM_FALSE, COM_RX_PDU_CANFD_PDM3_DIAGRESPONSE                                      , 24u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_CANFD_PDM3_DIAGRESPONSE_PDM3_DIAGRESP_BYTE04                                             , COM_FALSE, COM_RX_PDU_CANFD_PDM3_DIAGRESPONSE                                      , 32u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_CANFD_PDM3_DIAGRESPONSE_PDM3_DIAGRESP_BYTE05                                             , COM_FALSE, COM_RX_PDU_CANFD_PDM3_DIAGRESPONSE                                      , 40u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_CANFD_PDM3_DIAGRESPONSE_PDM3_DIAGRESP_BYTE06                                             , COM_FALSE, COM_RX_PDU_CANFD_PDM3_DIAGRESPONSE                                      , 48u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_CANFD_PDM3_DIAGRESPONSE_PDM3_DIAGRESP_BYTE07                                             , COM_FALSE, COM_RX_PDU_CANFD_PDM3_DIAGRESPONSE                                      , 56u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_CANFD_PDM4_DIAGRESPONSE_PDM4_DIAGRESP_BYTE00                                             , COM_FALSE, COM_RX_PDU_CANFD_PDM4_DIAGRESPONSE                                      , 0u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_CANFD_PDM4_DIAGRESPONSE_PDM4_DIAGRESP_BYTE01                                             , COM_FALSE, COM_RX_PDU_CANFD_PDM4_DIAGRESPONSE                                      , 8u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_CANFD_PDM4_DIAGRESPONSE_PDM4_DIAGRESP_BYTE02                                             , COM_FALSE, COM_RX_PDU_CANFD_PDM4_DIAGRESPONSE                                      , 16u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_CANFD_PDM4_DIAGRESPONSE_PDM4_DIAGRESP_BYTE03                                             , COM_FALSE, COM_RX_PDU_CANFD_PDM4_DIAGRESPONSE                                      , 24u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_CANFD_PDM4_DIAGRESPONSE_PDM4_DIAGRESP_BYTE04                                             , COM_FALSE, COM_RX_PDU_CANFD_PDM4_DIAGRESPONSE                                      , 32u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_CANFD_PDM4_DIAGRESPONSE_PDM4_DIAGRESP_BYTE05                                             , COM_FALSE, COM_RX_PDU_CANFD_PDM4_DIAGRESPONSE                                      , 40u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_CANFD_PDM4_DIAGRESPONSE_PDM4_DIAGRESP_BYTE06                                             , COM_FALSE, COM_RX_PDU_CANFD_PDM4_DIAGRESPONSE                                      , 48u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_CANFD_PDM4_DIAGRESPONSE_PDM4_DIAGRESP_BYTE07                                             , COM_FALSE, COM_RX_PDU_CANFD_PDM4_DIAGRESPONSE                                      , 56u, 8u, COM_SIGNAL_U8 , COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_LIN_ZGW_NM3_ZGW_NM3_PN1                                       , COM_TRUE,  COM_TX_PDU_LIN_ZGW_NM3                            , 0u, 8u, COM_SIGNAL_U8, COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_LIN_ZGW_REQUEST_ALT_ZGW_TARGETCURRENT_ALT                             , COM_TRUE,  COM_TX_PDU_LIN_ZGW_REQUEST_ALT                    , 0u, 8u, COM_SIGNAL_U8, COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_LIN_ZGW_REQUEST_ALT_ZGW_TARGETVOLTAGE_ALT                             , COM_TRUE,  COM_TX_PDU_LIN_ZGW_REQUEST_ALT                    , 8u, 8u, COM_SIGNAL_U8, COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_LIN_ZGW_REQUEST_ALT_ZGW_ENABLE_ALT                                    , COM_TRUE,  COM_TX_PDU_LIN_ZGW_REQUEST_ALT                    , 16u, 1u, COM_SIGNAL_U8, COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_TX_LIN_ZGW_REQUEST_ALT_ZGW_FIELDDUTYCOMMAND_ALT                          , COM_TRUE,  COM_TX_PDU_LIN_ZGW_REQUEST_ALT                    , 24u, 8u, COM_SIGNAL_U8, COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_LIN_ZGW_REQUEST_HVDCDC_ZGW_ENABLE_HVDCDC                                 , COM_TRUE,  COM_TX_PDU_LIN_ZGW_REQUEST_HVDCDC                 , 0u, 1u, COM_SIGNAL_U8, COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_TX_LIN_ZGW_REQUEST_HVDCDC_ZGW_TARGETVOLTAGE_HVDCDC                          , COM_TRUE,  COM_TX_PDU_LIN_ZGW_REQUEST_HVDCDC                 , 8u, 8u, COM_SIGNAL_U8, COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_TX_LIN_ZGW_REQUEST_PCU48_ZGW_REQUESTAVAILABILITY_PCU48                     , COM_TRUE,  COM_TX_PDU_LIN_ZGW_REQUEST_PCU48                  , 0u, 1u, COM_SIGNAL_U8, COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_RX_LIN_ALT_STATUS_ALT_RESPONSEERROR                                 , COM_FALSE, COM_RX_PDU_LIN_ALT_STATUS                         , 0u, 1u, COM_SIGNAL_U8, COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_RX_LIN_ALT_STATUS_ALT_CHARGINGACTIVE                                , COM_FALSE, COM_RX_PDU_LIN_ALT_STATUS                         , 8u, 1u, COM_SIGNAL_U8, COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_RX_LIN_ALT_STATUS_ALT_OUTPUTCURRENT                                 , COM_FALSE, COM_RX_PDU_LIN_ALT_STATUS                         , 16u, 8u, COM_SIGNAL_U8, COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_LIN_ALT_STATUS_ALT_OUTPUTVOLTAGE                                 , COM_FALSE, COM_RX_PDU_LIN_ALT_STATUS                         , 24u, 8u, COM_SIGNAL_U8, COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_LIN_ALT_STATUS_ALT_FIELDDUTYACTUAL                               , COM_FALSE, COM_RX_PDU_LIN_ALT_STATUS                         , 32u, 8u, COM_SIGNAL_U8, COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_LIN_ALT_STATUS_ALT_POWER                                         , COM_FALSE, COM_RX_PDU_LIN_ALT_STATUS                         , 40u, 8u, COM_SIGNAL_U8, COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_LIN_ALT_STATUS_ALT_TEMPERATURE                                   , COM_FALSE, COM_RX_PDU_LIN_ALT_STATUS                         , 48u, 8u, COM_SIGNAL_U8, COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_LIN_HVDCDC_STATUS_HVDCDC_RESPONSEERROR                              , COM_FALSE, COM_RX_PDU_LIN_HVDCDC_STATUS                      , 0u, 1u, COM_SIGNAL_U8, COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_RX_LIN_HVDCDC_STATUS_HVDCDC_LV_VOLTAGE                                 , COM_FALSE, COM_RX_PDU_LIN_HVDCDC_STATUS                      , 8u, 8u, COM_SIGNAL_U8, COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_LIN_HVDCDC_STATUS_HVDCDC_LV_CURRENT                                 , COM_FALSE, COM_RX_PDU_LIN_HVDCDC_STATUS                      , 16u, 8u, COM_SIGNAL_U8, COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_LIN_HVDCDC_STATUS_HVDCDC_HV_VOLTAGE                                 , COM_FALSE, COM_RX_PDU_LIN_HVDCDC_STATUS                      , 24u, 8u, COM_SIGNAL_U8, COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_LIN_HVDCDC_STATUS_HVDCDC_HV_CURRENT                                 , COM_FALSE, COM_RX_PDU_LIN_HVDCDC_STATUS                      , 32u, 8u, COM_SIGNAL_U8, COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_LIN_PCU48_STATUS_PCU48_RESPONSEERROR                               , COM_FALSE, COM_RX_PDU_LIN_PCU48_STATUS                       , 0u, 1u, COM_SIGNAL_U8, COM_FALSE, 0u, 0x1u        , 0u },
    { COM_SIG_RX_LIN_PCU48_STATUS_PCU48_SOH                                         , COM_FALSE, COM_RX_PDU_LIN_PCU48_STATUS                       , 8u, 8u, COM_SIGNAL_U8, COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_LIN_PCU48_STATUS_PCU48_SOC                                         , COM_FALSE, COM_RX_PDU_LIN_PCU48_STATUS                       , 16u, 8u, COM_SIGNAL_U8, COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_LIN_PCU48_STATUS_PCU48_VOLTAGE                                     , COM_FALSE, COM_RX_PDU_LIN_PCU48_STATUS                       , 24u, 8u, COM_SIGNAL_U8, COM_FALSE, 0u, 0xFFu       , 0u },
    { COM_SIG_RX_LIN_PCU48_STATUS_PCU48_CHARGESTATE                                 , COM_FALSE, COM_RX_PDU_LIN_PCU48_STATUS                       , 32u, 8u, COM_SIGNAL_U8, COM_FALSE, 0u, 0xFFu       , 0u }
};

static Com_TxIpduRuntimeType Com_TxRt[sizeof(Com_TxIpduCfg) / sizeof(Com_TxIpduCfg[0])];
static Com_RxIpduRuntimeType Com_RxRt[sizeof(Com_RxIpduCfg) / sizeof(Com_RxIpduCfg[0])];

static uint8 Com_FindTxIpdu(PduIdType pduId)
{
    uint8 i;

    for (i = 0u; i < (uint8)(sizeof(Com_TxIpduCfg) / sizeof(Com_TxIpduCfg[0])); i++)
    {
        if (Com_TxIpduCfg[i].pduId == pduId)
        {
            return i;
        }
    }

    return 0xFFu;
}

static uint8 Com_FindRxIpdu(PduIdType pduId)
{
    uint8 i;

    for (i = 0u; i < (uint8)(sizeof(Com_RxIpduCfg) / sizeof(Com_RxIpduCfg[0])); i++)
    {
        if (Com_RxIpduCfg[i].pduId == pduId)
        {
            return i;
        }
    }

    return 0xFFu;
}

static const Com_SignalConfigType* Com_FindSignal(Com_SignalIdType signalId)
{
    uint16 i;

    for (i = 0u; i < (uint16)(sizeof(Com_SignalCfg) / sizeof(Com_SignalCfg[0])); i++)
    {
        if (Com_SignalCfg[i].signalId == signalId)
        {
            return &Com_SignalCfg[i];
        }
    }

    return NULL_PTR;
}

static void Com_WriteBits(uint8* buffer, uint16 bitPos, uint8 bitSize, uint32 value)
{
    uint8 i;
    uint16 bitIndex;
    uint8 byteIndex;
    uint8 bitInByte;

    for (i = 0u; i < bitSize; i++)
    {
        bitIndex = (uint16)(bitPos + i);
        byteIndex = (uint8)(bitIndex / 8u);
        bitInByte = (uint8)(bitIndex % 8u);

        if (((value >> i) & 1u) != 0u)
        {
            buffer[byteIndex] |= (uint8)(1u << bitInByte);
        }
        else
        {
            buffer[byteIndex] &= (uint8)~(uint8)(1u << bitInByte);
        }
    }
}

static uint32 Com_ReadBits(const uint8* buffer, uint16 bitPos, uint8 bitSize)
{
    uint8 i;
    uint32 value = 0u;
    uint16 bitIndex;
    uint8 byteIndex;
    uint8 bitInByte;

    for (i = 0u; i < bitSize; i++)
    {
        bitIndex = (uint16)(bitPos + i);
        byteIndex = (uint8)(bitIndex / 8u);
        bitInByte = (uint8)(bitIndex % 8u);

        if ((buffer[byteIndex] & (uint8)(1u << bitInByte)) != 0u)
        {
            value |= (uint32)(1UL << i);
        }
    }

    return value;
}

static uint32 Com_LoadValue(const void* ptr, uint8 size)
{
    uint32 value = 0u;

    if (size == COM_SIGNAL_U8)
    {
        value = *((const uint8*)ptr);
    }
    else if (size == COM_SIGNAL_U16)
    {
        value = *((const uint16*)ptr);
    }
    else if (size == COM_SIGNAL_U32)
    {
        value = *((const uint32*)ptr);
    }

    return value;
}

static void Com_StoreValue(void* ptr, uint8 size, uint32 value)
{
    if (size == COM_SIGNAL_U8)
    {
        *((uint8*)ptr) = (uint8)value;
    }
    else if (size == COM_SIGNAL_U16)
    {
        *((uint16*)ptr) = (uint16)value;
    }
    else if (size == COM_SIGNAL_U32)
    {
        *((uint32*)ptr) = value;
    }
}

static Std_ReturnType Com_TriggerTransmit(uint8 txIdx)
{
    const Com_TxIpduConfigType* cfg;

    if (txIdx >= (uint8)(sizeof(Com_TxIpduCfg) / sizeof(Com_TxIpduCfg[0])))
    {
        return E_NOT_OK;
    }

    cfg = &Com_TxIpduCfg[txIdx];

    if (Com_TxRt[txIdx].active == COM_FALSE)
    {
        return E_NOT_OK;
    }

    if (Com_TxRt[txIdx].txInProgress != COM_FALSE)
    {
        return E_NOT_OK;
    }

    if (Com_TxRt[txIdx].mdtTimer > 0u)
    {
        return E_NOT_OK;
    }

    if (PduR_ComTransmit(cfg->pduId, Com_TxRt[txIdx].buffer, cfg->len) == E_OK)
    {
        Com_TxRt[txIdx].txInProgress = COM_TRUE;
        Com_TxRt[txIdx].mdtTimer = cfg->mdtTicks;
        Com_TxRt[txIdx].deadlineTimer = cfg->deadlineTicks;
        return E_OK;
    }

    return E_NOT_OK;
}

void Com_Init(void)
{
    uint8 i;

    memset(Com_TxRt, 0, sizeof(Com_TxRt));
    memset(Com_RxRt, 0, sizeof(Com_RxRt));

    for (i = 0u; i < (uint8)(sizeof(Com_TxIpduCfg) / sizeof(Com_TxIpduCfg[0])); i++)
    {
        memcpy(Com_TxRt[i].buffer, Com_TxIpduCfg[i].init, Com_TxIpduCfg[i].len);
        Com_TxRt[i].periodTimer = Com_TxIpduCfg[i].periodTicks;
        Com_TxRt[i].deadlineTimer = Com_TxIpduCfg[i].deadlineTicks;
        Com_TxRt[i].active = COM_TRUE;
    }

    for (i = 0u; i < (uint8)(sizeof(Com_RxIpduCfg) / sizeof(Com_RxIpduCfg[0])); i++)
    {
        memcpy(Com_RxRt[i].buffer, Com_RxIpduCfg[i].init, Com_RxIpduCfg[i].len);
        Com_RxRt[i].deadlineTimer = Com_RxIpduCfg[i].deadlineTicks;
        Com_RxRt[i].active = COM_TRUE;
    }
}

Std_ReturnType Com_IpduGroupStart(Com_IpduGroupIdType groupId)
{
    uint8 i;

    for (i = 0u; i < (uint8)(sizeof(Com_TxIpduCfg) / sizeof(Com_TxIpduCfg[0])); i++)
    {
        if (Com_TxIpduCfg[i].groupId == groupId)
        {
            Com_TxRt[i].active = COM_TRUE;
        }
    }

    for (i = 0u; i < (uint8)(sizeof(Com_RxIpduCfg) / sizeof(Com_RxIpduCfg[0])); i++)
    {
        if (Com_RxIpduCfg[i].groupId == groupId)
        {
            Com_RxRt[i].active = COM_TRUE;
        }
    }

    return E_OK;
}

Std_ReturnType Com_IpduGroupStop(Com_IpduGroupIdType groupId)
{
    uint8 i;

    for (i = 0u; i < (uint8)(sizeof(Com_TxIpduCfg) / sizeof(Com_TxIpduCfg[0])); i++)
    {
        if (Com_TxIpduCfg[i].groupId == groupId)
        {
            Com_TxRt[i].active = COM_FALSE;
        }
    }

    for (i = 0u; i < (uint8)(sizeof(Com_RxIpduCfg) / sizeof(Com_RxIpduCfg[0])); i++)
    {
        if (Com_RxIpduCfg[i].groupId == groupId)
        {
            Com_RxRt[i].active = COM_FALSE;
        }
    }

    return E_OK;
}

Std_ReturnType Com_SendSignal(Com_SignalIdType SignalId, const void* SignalDataPtr)
{
    const Com_SignalConfigType* sig;
    uint8 txIdx;
    uint32 value;

    if (SignalDataPtr == NULL_PTR)
    {
        return E_NOT_OK;
    }

    sig = Com_FindSignal(SignalId);

    if ((sig == NULL_PTR) || (sig->isTx == COM_FALSE))
    {
        return E_NOT_OK;
    }

    txIdx = Com_FindTxIpdu(sig->pduId);

    if ((txIdx == 0xFFu) || (Com_TxRt[txIdx].active == COM_FALSE))
    {
        return E_NOT_OK;
    }

    value = Com_LoadValue(SignalDataPtr, sig->dataSize);
    Com_WriteBits(Com_TxRt[txIdx].buffer, sig->bitPosition, sig->bitSize, value);

    if (sig->hasUpdateBit != COM_FALSE)
    {
        Com_WriteBits(Com_TxRt[txIdx].buffer, sig->updateBitPosition, 1u, 1u);
    }

    Com_TxRt[txIdx].dirty = COM_TRUE;

    if ((Com_TxIpduCfg[txIdx].txMode == COM_TX_MODE_DIRECT) ||
        (Com_TxIpduCfg[txIdx].txMode == COM_TX_MODE_MIXED))
    {
        Com_TxRt[txIdx].repetitionsLeft = Com_TxIpduCfg[txIdx].repetitions;
        Com_TxRt[txIdx].repetitionTimer = 0u;
        (void)Com_TriggerTransmit(txIdx);
    }

    return E_OK;
}

Std_ReturnType Com_ReceiveSignal(Com_SignalIdType SignalId, void* SignalDataPtr)
{
    const Com_SignalConfigType* sig;
    uint8 rxIdx;
    uint32 value;

    if (SignalDataPtr == NULL_PTR)
    {
        return E_NOT_OK;
    }

    sig = Com_FindSignal(SignalId);

    if ((sig == NULL_PTR) || (sig->isTx != COM_FALSE))
    {
        return E_NOT_OK;
    }

    rxIdx = Com_FindRxIpdu(sig->pduId);

    if ((rxIdx == 0xFFu) || (Com_RxRt[rxIdx].active == COM_FALSE))
    {
        return E_NOT_OK;
    }

    if (Com_RxRt[rxIdx].timeout != COM_FALSE)
    {
        return E_NOT_OK;
    }

    if (sig->hasUpdateBit != COM_FALSE)
    {
        if (Com_ReadBits(Com_RxRt[rxIdx].buffer, sig->updateBitPosition, 1u) == 0u)
        {
            return E_NOT_OK;
        }
    }

    value = Com_ReadBits(Com_RxRt[rxIdx].buffer, sig->bitPosition, sig->bitSize);
    Com_StoreValue(SignalDataPtr, sig->dataSize, value);

    return E_OK;
}

Std_ReturnType Com_InvalidateSignal(Com_SignalIdType SignalId)
{
    const Com_SignalConfigType* sig;
    uint8 txIdx;

    sig = Com_FindSignal(SignalId);

    if ((sig == NULL_PTR) || (sig->isTx == COM_FALSE))
    {
        return E_NOT_OK;
    }

    txIdx = Com_FindTxIpdu(sig->pduId);

    if (txIdx == 0xFFu)
    {
        return E_NOT_OK;
    }

    Com_WriteBits(Com_TxRt[txIdx].buffer, sig->bitPosition, sig->bitSize, sig->invalidValue);
    Com_TxRt[txIdx].dirty = COM_TRUE;

    if (sig->hasUpdateBit != COM_FALSE)
    {
        Com_WriteBits(Com_TxRt[txIdx].buffer, sig->updateBitPosition, 1u, 1u);
    }

    return Com_TriggerTransmit(txIdx);
}

void Com_RxIndication(PduIdType RxPduId, const uint8* data, PduLengthType len)
{
    uint8 rxIdx;

    if ((data == NULL_PTR) || (len == 0u))
    {
        return;
    }

    rxIdx = Com_FindRxIpdu(RxPduId);

    if (rxIdx == 0xFFu)
    {
        return;
    }

    if (Com_RxRt[rxIdx].active == COM_FALSE)
    {
        return;
    }

    if (len > Com_RxIpduCfg[rxIdx].len)
    {
        len = Com_RxIpduCfg[rxIdx].len;
    }

    memcpy(Com_RxRt[rxIdx].buffer, data, len);
    Com_RxRt[rxIdx].deadlineTimer = Com_RxIpduCfg[rxIdx].deadlineTicks;
    Com_RxRt[rxIdx].timeout = COM_FALSE;
}

void Com_TxConfirmation(PduIdType TxPduId)
{
    uint8 txIdx;

    txIdx = Com_FindTxIpdu(TxPduId);

    if (txIdx == 0xFFu)
    {
        return;
    }

    Com_TxRt[txIdx].txInProgress = COM_FALSE;
    Com_TxRt[txIdx].dirty = COM_FALSE;
}

void Com_MainFunctionTx(void)
{
    uint8 i;

    for (i = 0u; i < (uint8)(sizeof(Com_TxIpduCfg) / sizeof(Com_TxIpduCfg[0])); i++)
    {
        if (Com_TxRt[i].active == COM_FALSE)
        {
            continue;
        }

        if (Com_TxRt[i].mdtTimer > 0u)
        {
            Com_TxRt[i].mdtTimer--;
        }

        if (Com_TxRt[i].deadlineTimer > 0u)
        {
            Com_TxRt[i].deadlineTimer--;
        }
        else if (Com_TxRt[i].txInProgress != COM_FALSE)
        {
            Com_TxRt[i].txInProgress = COM_FALSE;
        }

        if (Com_TxRt[i].repetitionTimer > 0u)
        {
            Com_TxRt[i].repetitionTimer--;
        }

        if ((Com_TxRt[i].repetitionsLeft > 0u) &&
            (Com_TxRt[i].repetitionTimer == 0u) &&
            (Com_TxRt[i].txInProgress == COM_FALSE))
        {
            if (Com_TriggerTransmit(i) == E_OK)
            {
                Com_TxRt[i].repetitionsLeft--;
                Com_TxRt[i].repetitionTimer = Com_TxIpduCfg[i].repetitionPeriodTicks;
            }
        }

        if ((Com_TxIpduCfg[i].txMode == COM_TX_MODE_PERIODIC) ||
            (Com_TxIpduCfg[i].txMode == COM_TX_MODE_MIXED))
        {
            if (Com_TxRt[i].periodTimer > 0u)
            {
                Com_TxRt[i].periodTimer--;
            }
            else
            {
                (void)Com_TriggerTransmit(i);
                Com_TxRt[i].periodTimer = Com_TxIpduCfg[i].periodTicks;
            }
        }

        if ((Com_TxRt[i].dirty != COM_FALSE) &&
            (Com_TxRt[i].txInProgress == COM_FALSE) &&
            (Com_TxRt[i].mdtTimer == 0u))
        {
            (void)Com_TriggerTransmit(i);
        }
    }
}

void Com_MainFunctionRx(void)
{
    uint8 i;

    for (i = 0u; i < (uint8)(sizeof(Com_RxIpduCfg) / sizeof(Com_RxIpduCfg[0])); i++)
    {
        if (Com_RxRt[i].active == COM_FALSE)
        {
            continue;
        }

        if (Com_RxIpduCfg[i].deadlineTicks == 0u)
        {
            continue;
        }

        if (Com_RxRt[i].deadlineTimer > 0u)
        {
            Com_RxRt[i].deadlineTimer--;
        }
        else
        {
            Com_RxRt[i].timeout = COM_TRUE;
            memcpy(Com_RxRt[i].buffer, Com_RxIpduCfg[i].init, Com_RxIpduCfg[i].len);
        }
    }
}
