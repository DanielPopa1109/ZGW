#include "CanTp.h"
#include "PduR.h"
#include <string.h>

typedef enum
{
    CANTP_DIR_NONE = 0u,
    CANTP_DIR_RX,
    CANTP_DIR_TX
} CanTp_DirectionType;

typedef enum
{
    CANTP_TXFRAME_NONE = 0u,
    CANTP_TXFRAME_SF,
    CANTP_TXFRAME_FF,
    CANTP_TXFRAME_CF,
    CANTP_TXFRAME_FC
} CanTp_TxFrameType;

typedef struct
{
    CanTp_StateType state;
    CanTp_DirectionType direction;
    CanTp_TimerType timerType;

    PduLengthType rxLen;
    PduLengthType rxExpectedLen;
    uint8 rxNextSn;
    uint8 rxBlockCounter;

    uint8 txBuffer[CANTP_MAX_PAYLOAD_LEN];
    PduLengthType txLen;
    PduLengthType txOffset;
    uint8 txSn;
    uint8 txBlockCounter;
    uint8 txBlockSize;
    uint8 txStMinTicks;
    uint8 txStTimer;
    uint8 txWaitFrameCounter;
    uint8 txBusy;
    CanTp_TxFrameType pendingTxFrame;

    uint16 timer;
} CanTp_ChannelStateType;

static const CanTp_ChannelConfigType CanTp_ChannelConfig[] =
{
    { CANIF_PDU_CLASSIC_PHYS_RX, CANIF_PDU_CLASSIC_PHYS_TX, 0u, 0u, CANTP_ADDR_PHYSICAL,   8u,  8u, 0u, 0xAAu, CANTP_FORMAT_NORMAL, 0u, CANTP_PADDING_ON },
    { CANIF_PDU_CLASSIC_FUNC_RX, CANIF_PDU_CLASSIC_PHYS_TX, 1u, 1u, CANTP_ADDR_FUNCTIONAL, 8u,  8u, 0u, 0xAAu, CANTP_FORMAT_NORMAL, 0u, CANTP_PADDING_ON },
    { CANIF_PDU_FD_PHYS_RX,      CANIF_PDU_FD_PHYS_TX,      2u, 2u, CANTP_ADDR_PHYSICAL,   64u, 8u, 0u, 0xAAu, CANTP_FORMAT_NORMAL, 0u, CANTP_PADDING_ON },
    { CANIF_PDU_FD_FUNC_RX,      CANIF_PDU_FD_PHYS_TX,      3u, 3u, CANTP_ADDR_FUNCTIONAL, 64u, 8u, 0u, 0xAAu, CANTP_FORMAT_NORMAL, 0u, CANTP_PADDING_ON }
};

const CanTp_ConfigType CanTp_Config =
{
    CanTp_ChannelConfig,
    (uint8)(sizeof(CanTp_ChannelConfig) / sizeof(CanTp_ChannelConfig[0]))
};

static const CanTp_ConfigType* CanTp_ConfigPtr;
static CanTp_ChannelStateType CanTp_Channel[CANTP_MAX_CHANNELS];

static uint8 CanTp_GetAddrOffset(const CanTp_ChannelConfigType* cfg)
{
    if (cfg == NULL_PTR)
    {
        return 0u;
    }

    if ((cfg->addressFormat == CANTP_FORMAT_EXTENDED) ||
        (cfg->addressFormat == CANTP_FORMAT_MIXED))
    {
        return 1u;
    }

    return 0u;
}

static uint8 CanTp_GetSfMaxPayload(const CanTp_ChannelConfigType* cfg)
{
    uint8 off;

    off = CanTp_GetAddrOffset(cfg);

    if (cfg->canDl <= 8u)
    {
        return (uint8)(7u - off);
    }

    return (uint8)(62u - off);
}

static uint8 CanTp_GetFfPayload(const CanTp_ChannelConfigType* cfg)
{
    return (uint8)(cfg->canDl - 2u - CanTp_GetAddrOffset(cfg));
}

static uint8 CanTp_GetCfPayload(const CanTp_ChannelConfigType* cfg)
{
    return (uint8)(cfg->canDl - 1u - CanTp_GetAddrOffset(cfg));
}

static void CanTp_ClearFrame(uint8* frame, uint8 len, uint8 padding)
{
    memset(frame, padding, len);
}

static uint8 CanTp_CheckRxAddress(const CanTp_ChannelConfigType* cfg,
                                  const uint8* data,
                                  PduLengthType len)
{
    if ((cfg == NULL_PTR) || (data == NULL_PTR) || (len == 0u))
    {
        return FALSE;
    }

    if ((cfg->addressFormat == CANTP_FORMAT_EXTENDED) ||
        (cfg->addressFormat == CANTP_FORMAT_MIXED))
    {
        if (len < 2u)
        {
            return FALSE;
        }

        if (data[0] != cfg->nTa)
        {
            return FALSE;
        }
    }

    return TRUE;
}

static uint8 CanTp_GetRxPciIndex(const CanTp_ChannelConfigType* cfg)
{
    return CanTp_GetAddrOffset(cfg);
}

static void CanTp_SetTxAddress(const CanTp_ChannelConfigType* cfg, uint8* frame)
{
    if ((cfg->addressFormat == CANTP_FORMAT_EXTENDED) ||
        (cfg->addressFormat == CANTP_FORMAT_MIXED))
    {
        frame[0] = cfg->nTa;
    }
}

static uint16 CanTp_GetTimerTicks(CanTp_TimerType timer)
{
    switch (timer)
    {
        case CANTP_TIMER_N_AS: return (uint16)CANTP_N_AS_TICKS;
        case CANTP_TIMER_N_AR: return (uint16)CANTP_N_AR_TICKS;
        case CANTP_TIMER_N_BS: return (uint16)CANTP_N_BS_TICKS;
        case CANTP_TIMER_N_BR: return (uint16)CANTP_N_BR_TICKS;
        case CANTP_TIMER_N_CS: return (uint16)CANTP_N_CS_TICKS;
        case CANTP_TIMER_N_CR: return (uint16)CANTP_N_CR_TICKS;
        default: return 0u;
    }
}

static void CanTp_StartTimer(uint8 ch, CanTp_TimerType timer)
{
    CanTp_Channel[ch].timerType = timer;
    CanTp_Channel[ch].timer = CanTp_GetTimerTicks(timer);
}

static void CanTp_StopTimer(uint8 ch)
{
    CanTp_Channel[ch].timerType = CANTP_TIMER_NONE;
    CanTp_Channel[ch].timer = 0u;
}

static uint8 CanTp_IsConfigValid(void)
{
    if (CanTp_ConfigPtr == NULL_PTR)
    {
        return FALSE;
    }

    if (CanTp_ConfigPtr->channels == NULL_PTR)
    {
        return FALSE;
    }

    if ((CanTp_ConfigPtr->numChannels == 0u) ||
        (CanTp_ConfigPtr->numChannels > CANTP_MAX_CHANNELS))
    {
        return FALSE;
    }

    return TRUE;
}

static uint8 CanTp_FindRxChannel(PduIdType rxPduId)
{
    uint8 i;

    if (CanTp_IsConfigValid() == FALSE)
    {
        return 0xFFu;
    }

    for (i = 0u; i < CanTp_ConfigPtr->numChannels; i++)
    {
        if (CanTp_ConfigPtr->channels[i].rxPduId == rxPduId)
        {
            return i;
        }
    }

    return 0xFFu;
}

static uint8 CanTp_FindTxChannelByUpper(PduIdType upperTxPduId)
{
    uint8 i;

    if (CanTp_IsConfigValid() == FALSE)
    {
        return 0xFFu;
    }

    for (i = 0u; i < CanTp_ConfigPtr->numChannels; i++)
    {
        if (CanTp_ConfigPtr->channels[i].upperTxPduId == upperTxPduId)
        {
            return i;
        }
    }

    return 0xFFu;
}

static uint8 CanTp_FindChannelByCanIfTx(PduIdType txPduId)
{
    uint8 i;

    if (CanTp_IsConfigValid() == FALSE)
    {
        return 0xFFu;
    }

    for (i = 0u; i < CanTp_ConfigPtr->numChannels; i++)
    {
        if ((CanTp_ConfigPtr->channels[i].txPduId == txPduId) &&
            (CanTp_Channel[i].txBusy == TRUE))
        {
            return i;
        }
    }

    return 0xFFu;
}

static uint8 CanTp_StMinToTicks(uint8 stMin)
{
    if (stMin <= 0x7Fu)
    {
        return (uint8)((stMin + CANTP_MAIN_PERIOD_MS - 1u) / CANTP_MAIN_PERIOD_MS);
    }

    if ((stMin >= 0xF1u) && (stMin <= 0xF9u))
    {
        return 1u;
    }

    return 0xFFu;
}

static Std_ReturnType CanTp_ValidateFlowControl(const uint8* data, PduLengthType len)
{
    uint8 fs;
    uint8 stMin;

    if ((data == NULL_PTR) || (len < 3u))
    {
        return E_NOT_OK;
    }

    if ((data[0] & 0xF0u) != CANTP_NPCI_FC)
    {
        return E_NOT_OK;
    }

    fs = data[0] & 0x0Fu;
    stMin = data[2];

    if (fs > CANTP_FS_OVFLW)
    {
        return E_NOT_OK;
    }

    if ((stMin >= 0x80u) && (stMin <= 0xF0u))
    {
        return E_NOT_OK;
    }

    if (stMin > 0xF9u)
    {
        return E_NOT_OK;
    }

    return E_OK;
}

static void CanTp_ResetChannel(uint8 ch)
{
    if (ch < CANTP_MAX_CHANNELS)
    {
        memset(&CanTp_Channel[ch], 0, sizeof(CanTp_Channel[ch]));
        CanTp_Channel[ch].state = CANTP_IDLE;
        CanTp_Channel[ch].direction = CANTP_DIR_NONE;
        CanTp_Channel[ch].timerType = CANTP_TIMER_NONE;
        CanTp_Channel[ch].pendingTxFrame = CANTP_TXFRAME_NONE;
    }
}

void CanTp_Init(const CanTp_ConfigType* ConfigPtr)
{
    uint8 i;

    CanTp_ConfigPtr = (ConfigPtr == NULL_PTR) ? &CanTp_Config : ConfigPtr;

    for (i = 0u; i < CANTP_MAX_CHANNELS; i++)
    {
        CanTp_ResetChannel(i);
    }

    if (CanTp_IsConfigValid() == FALSE)
    {
        CanTp_ConfigPtr = NULL_PTR;
    }
}

static Std_ReturnType CanTp_SendFc(uint8 ch, uint8 fs)
{
    uint8 frame[64u];
    uint8 pci;
    const CanTp_ChannelConfigType* cfg;

    if ((CanTp_IsConfigValid() == FALSE) || (ch >= CanTp_ConfigPtr->numChannels))
    {
        return E_NOT_OK;
    }

    cfg = &CanTp_ConfigPtr->channels[ch];
    pci = CanTp_GetAddrOffset(cfg);

    CanTp_ClearFrame(frame, cfg->canDl, cfg->padding);
    CanTp_SetTxAddress(cfg, frame);

    frame[pci + 0u] = (uint8)(CANTP_NPCI_FC | fs);
    frame[pci + 1u] = cfg->blockSize;
    frame[pci + 2u] = cfg->stMinMs;

    CanTp_Channel[ch].txBusy = TRUE;
    CanTp_Channel[ch].pendingTxFrame = CANTP_TXFRAME_FC;
    CanTp_Channel[ch].state = CANTP_RX_WAIT_FC_TX_CONFIRM;
    CanTp_Channel[ch].direction = CANTP_DIR_RX;
    CanTp_StartTimer(ch, CANTP_TIMER_N_AR);

    if (CanIf_Transmit(cfg->txPduId, frame, cfg->canDl) != E_OK)
    {
        CanTp_ResetChannel(ch);
        return E_NOT_OK;
    }

    return E_OK;
}

static Std_ReturnType CanTp_SendSingleFrame(uint8 ch)
{
    uint8 frame[64u];
    uint8 len;
    uint8 pci;
    const CanTp_ChannelConfigType* cfg;

    cfg = &CanTp_ConfigPtr->channels[ch];
    len = (uint8)CanTp_Channel[ch].txLen;
    pci = CanTp_GetAddrOffset(cfg);

    CanTp_ClearFrame(frame, cfg->canDl, cfg->padding);
    CanTp_SetTxAddress(cfg, frame);

    if (len > CanTp_GetSfMaxPayload(cfg))
    {
        return E_NOT_OK;
    }

    if (cfg->canDl <= 8u)
    {
        frame[pci] = len & 0x0Fu;
        memcpy(&frame[pci + 1u], CanTp_Channel[ch].txBuffer, len);
    }
    else
    {
        if (len <= 15u)
        {
            frame[pci] = len & 0x0Fu;
            memcpy(&frame[pci + 1u], CanTp_Channel[ch].txBuffer, len);
        }
        else
        {
            frame[pci] = 0x00u;
            frame[pci + 1u] = len;
            memcpy(&frame[pci + 2u], CanTp_Channel[ch].txBuffer, len);
        }
    }

    CanTp_Channel[ch].state = CANTP_TX_WAIT_CONFIRM;
    CanTp_Channel[ch].direction = CANTP_DIR_TX;
    CanTp_Channel[ch].txBusy = TRUE;
    CanTp_Channel[ch].pendingTxFrame = CANTP_TXFRAME_SF;
    CanTp_StartTimer(ch, CANTP_TIMER_N_AS);

    if (CanIf_Transmit(cfg->txPduId, frame, cfg->canDl) != E_OK)
    {
        CanTp_ResetChannel(ch);
        return E_NOT_OK;
    }

    return E_OK;
}

static Std_ReturnType CanTp_SendFirstFrame(uint8 ch)
{
    uint8 frame[64u];
    uint8 payloadInFf;
    uint8 pci;
    const CanTp_ChannelConfigType* cfg;

    cfg = &CanTp_ConfigPtr->channels[ch];
    pci = CanTp_GetAddrOffset(cfg);

    if ((CanTp_Channel[ch].txLen <= CanTp_GetSfMaxPayload(cfg)) ||
        (CanTp_Channel[ch].txLen > CANTP_MAX_PAYLOAD_LEN))
    {
        return E_NOT_OK;
    }

    CanTp_ClearFrame(frame, cfg->canDl, cfg->padding);
    CanTp_SetTxAddress(cfg, frame);

    frame[pci + 0u] = (uint8)(CANTP_NPCI_FF | ((CanTp_Channel[ch].txLen >> 8u) & 0x0Fu));
    frame[pci + 1u] = (uint8)(CanTp_Channel[ch].txLen & 0xFFu);

    payloadInFf = CanTp_GetFfPayload(cfg);

    memcpy(&frame[pci + 2u], CanTp_Channel[ch].txBuffer, payloadInFf);

    CanTp_Channel[ch].txOffset = payloadInFf;
    CanTp_Channel[ch].txSn = 1u;
    CanTp_Channel[ch].state = CANTP_TX_WAIT_CONFIRM;
    CanTp_Channel[ch].direction = CANTP_DIR_TX;
    CanTp_Channel[ch].txBusy = TRUE;
    CanTp_Channel[ch].pendingTxFrame = CANTP_TXFRAME_FF;
    CanTp_StartTimer(ch, CANTP_TIMER_N_AS);

    if (CanIf_Transmit(cfg->txPduId, frame, cfg->canDl) != E_OK)
    {
        CanTp_ResetChannel(ch);
        return E_NOT_OK;
    }

    return E_OK;
}

static Std_ReturnType CanTp_SendConsecutiveFrame(uint8 ch)
{
    uint8 frame[64u];
    PduLengthType remaining;
    uint8 payload;
    uint8 copy;
    uint8 pci;
    const CanTp_ChannelConfigType* cfg;

    if ((CanTp_Channel[ch].txBusy == TRUE) || (CanTp_Channel[ch].txStTimer > 0u))
    {
        return E_NOT_OK;
    }

    cfg = &CanTp_ConfigPtr->channels[ch];
    pci = CanTp_GetAddrOffset(cfg);

    CanTp_ClearFrame(frame, cfg->canDl, cfg->padding);
    CanTp_SetTxAddress(cfg, frame);

    frame[pci] = (uint8)(CANTP_NPCI_CF | (CanTp_Channel[ch].txSn & 0x0Fu));

    remaining = (PduLengthType)(CanTp_Channel[ch].txLen - CanTp_Channel[ch].txOffset);
    payload = CanTp_GetCfPayload(cfg);
    copy = (remaining > payload) ? payload : (uint8)remaining;

    if (copy == 0u)
    {
        return E_NOT_OK;
    }

    memcpy(&frame[pci + 1u], &CanTp_Channel[ch].txBuffer[CanTp_Channel[ch].txOffset], copy);

    CanTp_Channel[ch].txBusy = TRUE;
    CanTp_Channel[ch].pendingTxFrame = CANTP_TXFRAME_CF;
    CanTp_Channel[ch].state = CANTP_TX_WAIT_CONFIRM;
    CanTp_Channel[ch].direction = CANTP_DIR_TX;
    CanTp_StartTimer(ch, CANTP_TIMER_N_AS);

    if (CanIf_Transmit(cfg->txPduId, frame, cfg->canDl) != E_OK)
    {
        CanTp_Channel[ch].txBusy = FALSE;
        CanTp_Channel[ch].pendingTxFrame = CANTP_TXFRAME_NONE;
        CanTp_Channel[ch].state = CANTP_TX_CF;
        CanTp_StartTimer(ch, CANTP_TIMER_N_CS);
        return E_NOT_OK;
    }

    CanTp_Channel[ch].txOffset = (PduLengthType)(CanTp_Channel[ch].txOffset + copy);
    CanTp_Channel[ch].txSn = (uint8)((CanTp_Channel[ch].txSn + 1u) & 0x0Fu);
    CanTp_Channel[ch].txBlockCounter++;

    return E_OK;
}

Std_ReturnType CanTp_Transmit(PduIdType CanTpTxSduId, const uint8* data, PduLengthType len)
{
    uint8 ch;
    uint8 sfMax;

    if ((CanTp_IsConfigValid() == FALSE) ||
        (data == NULL_PTR) ||
        (len == 0u) ||
        (len > CANTP_MAX_PAYLOAD_LEN))
    {
        return E_NOT_OK;
    }

    ch = CanTp_FindTxChannelByUpper(CanTpTxSduId);

    if ((ch >= CanTp_ConfigPtr->numChannels) || (CanTp_Channel[ch].state != CANTP_IDLE))
    {
        return E_NOT_OK;
    }

    memcpy(CanTp_Channel[ch].txBuffer, data, len);

    CanTp_Channel[ch].txLen = len;
    CanTp_Channel[ch].txOffset = 0u;
    CanTp_Channel[ch].txBlockCounter = 0u;
    CanTp_Channel[ch].txBlockSize = 0u;
    CanTp_Channel[ch].txStMinTicks = 0u;
    CanTp_Channel[ch].txStTimer = 0u;
    CanTp_Channel[ch].txWaitFrameCounter = 0u;
    CanTp_Channel[ch].txBusy = FALSE;
    CanTp_Channel[ch].pendingTxFrame = CANTP_TXFRAME_NONE;
    CanTp_Channel[ch].direction = CANTP_DIR_TX;

    sfMax = CanTp_GetSfMaxPayload(&CanTp_ConfigPtr->channels[ch]);

    if (len <= sfMax)
    {
        return CanTp_SendSingleFrame(ch);
    }

    return CanTp_SendFirstFrame(ch);
}

static void CanTp_HandleSingleFrame(uint8 ch, const uint8* data, PduLengthType len)
{
    uint8 sfLen;
    uint8 offset;
    const CanTp_ChannelConfigType* cfg;

    cfg = &CanTp_ConfigPtr->channels[ch];

    uint8 pciBase;
    pciBase = CanTp_GetRxPciIndex(cfg);
    data = &data[pciBase];
    len = (PduLengthType)(len - pciBase);

    if (cfg->canDl <= 8u)
    {
        sfLen = data[0] & 0x0Fu;
        offset = 1u;

        if ((sfLen == 0u) || (sfLen > 7u) || ((PduLengthType)(sfLen + offset) > len))
        {
            return;
        }
    }
    else
    {
        if ((data[0] & 0x0Fu) != 0u)
        {
            sfLen = data[0] & 0x0Fu;
            offset = 1u;

            if ((sfLen > 15u) || ((PduLengthType)(sfLen + offset) > len))
            {
                return;
            }
        }
        else
        {
            if (len < 2u)
            {
                return;
            }

            sfLen = data[1];
            offset = 2u;

            if ((sfLen == 0u) || (sfLen > 62u) || ((PduLengthType)(sfLen + offset) > len))
            {
                return;
            }
        }
    }

    if (PduR_CanTpStartOfReception(cfg->upperRxPduId, sfLen) != E_OK)
    {
        return;
    }

    if (PduR_CanTpCopyRxData(cfg->upperRxPduId, &data[offset], sfLen) != E_OK)
    {
        PduR_CanTpRxIndication(cfg->upperRxPduId, E_NOT_OK);
        return;
    }

    PduR_CanTpRxIndication(cfg->upperRxPduId, E_OK);
}

static void CanTp_HandleFirstFrame(uint8 ch, const uint8* data, PduLengthType len)
{
    PduLengthType totalLen;
    uint8 payload;
    uint8 copy;
    const CanTp_ChannelConfigType* cfg;

    cfg = &CanTp_ConfigPtr->channels[ch];

    uint8 pciBase;
    pciBase = CanTp_GetRxPciIndex(cfg);
    data = &data[pciBase];
    len = (PduLengthType)(len - pciBase);

    if ((len < 3u) || (cfg->addressingType == CANTP_ADDR_FUNCTIONAL))
    {
        return;
    }

    totalLen = (PduLengthType)((((PduLengthType)data[0] & 0x0Fu) << 8u) | data[1]);

    if ((totalLen <= CanTp_GetSfMaxPayload(cfg)) || (totalLen > CANTP_MAX_PAYLOAD_LEN))
    {
        (void)CanTp_SendFc(ch, CANTP_FS_OVFLW);
        return;
    }

    payload = (uint8)(len - 2u);
    copy = (totalLen > payload) ? payload : (uint8)totalLen;

    if (PduR_CanTpStartOfReception(cfg->upperRxPduId, totalLen) != E_OK)
    {
        (void)CanTp_SendFc(ch, CANTP_FS_OVFLW);
        return;
    }

    if (PduR_CanTpCopyRxData(cfg->upperRxPduId, &data[2], copy) != E_OK)
    {
        PduR_CanTpRxIndication(cfg->upperRxPduId, E_NOT_OK);
        CanTp_ResetChannel(ch);
        return;
    }

    CanTp_Channel[ch].rxExpectedLen = totalLen;
    CanTp_Channel[ch].rxLen = copy;
    CanTp_Channel[ch].rxNextSn = 1u;
    CanTp_Channel[ch].rxBlockCounter = 0u;
    CanTp_Channel[ch].direction = CANTP_DIR_RX;
    CanTp_StartTimer(ch, CANTP_TIMER_N_BR);

    (void)CanTp_SendFc(ch, CANTP_FS_CTS);
}

static void CanTp_HandleConsecutiveFrame(uint8 ch, const uint8* data, PduLengthType len)
{
    uint8 sn;
    uint8 payload;
    uint8 copy;
    PduLengthType remaining;
    const CanTp_ChannelConfigType* cfg;

    cfg = &CanTp_ConfigPtr->channels[ch];

    uint8 pciBase;
    pciBase = CanTp_GetRxPciIndex(cfg);
    data = &data[pciBase];
    len = (PduLengthType)(len - pciBase);

    if ((CanTp_Channel[ch].state != CANTP_RX_IN_PROGRESS) || (len < 2u))
    {
        return;
    }

    sn = data[0] & 0x0Fu;

    if (sn != CanTp_Channel[ch].rxNextSn)
    {
        PduR_CanTpRxIndication(cfg->upperRxPduId, E_NOT_OK);
        CanTp_ResetChannel(ch);
        return;
    }

    payload = (uint8)(len - 1u);
    remaining = (PduLengthType)(CanTp_Channel[ch].rxExpectedLen - CanTp_Channel[ch].rxLen);
    copy = (remaining > payload) ? payload : (uint8)remaining;

    if (copy == 0u)
    {
        PduR_CanTpRxIndication(cfg->upperRxPduId, E_NOT_OK);
        CanTp_ResetChannel(ch);
        return;
    }

    if (PduR_CanTpCopyRxData(cfg->upperRxPduId, &data[1], copy) != E_OK)
    {
        PduR_CanTpRxIndication(cfg->upperRxPduId, E_NOT_OK);
        CanTp_ResetChannel(ch);
        return;
    }

    CanTp_Channel[ch].rxLen = (PduLengthType)(CanTp_Channel[ch].rxLen + copy);
    CanTp_Channel[ch].rxNextSn = (uint8)((CanTp_Channel[ch].rxNextSn + 1u) & 0x0Fu);
    CanTp_Channel[ch].rxBlockCounter++;

    if (CanTp_Channel[ch].rxLen >= CanTp_Channel[ch].rxExpectedLen)
    {
        PduR_CanTpRxIndication(cfg->upperRxPduId, E_OK);
        CanTp_ResetChannel(ch);
    }
    else if ((cfg->blockSize != 0u) && (CanTp_Channel[ch].rxBlockCounter >= cfg->blockSize))
    {
        CanTp_Channel[ch].rxBlockCounter = 0u;
        CanTp_StartTimer(ch, CANTP_TIMER_N_BR);
        (void)CanTp_SendFc(ch, CANTP_FS_CTS);
    }
    else
    {
        CanTp_StartTimer(ch, CANTP_TIMER_N_CR);
    }
}

static void CanTp_HandleFlowControl(uint8 ch, const uint8* data, PduLengthType len)
{
    uint8 fs;
    uint8 ticks;
    const CanTp_ChannelConfigType* cfg;

    cfg = &CanTp_ConfigPtr->channels[ch];

    uint8 pciBase;
    pciBase = CanTp_GetRxPciIndex(cfg);
    data = &data[pciBase];
    len = (PduLengthType)(len - pciBase);

    if (CanTp_Channel[ch].state != CANTP_TX_WAIT_FC)
    {
        return;
    }

    if (CanTp_ValidateFlowControl(data, len) != E_OK)
    {
        PduR_CanTpTxConfirmation(cfg->upperTxPduId, E_NOT_OK);
        CanTp_ResetChannel(ch);
        return;
    }

    fs = data[0] & 0x0Fu;

    if (fs == CANTP_FS_CTS)
    {
        ticks = CanTp_StMinToTicks(data[2]);

        if (ticks == 0xFFu)
        {
            PduR_CanTpTxConfirmation(cfg->upperTxPduId, E_NOT_OK);
            CanTp_ResetChannel(ch);
            return;
        }

        CanTp_Channel[ch].txBlockSize = data[1];
        CanTp_Channel[ch].txStMinTicks = ticks;
        CanTp_Channel[ch].txBlockCounter = 0u;
        CanTp_Channel[ch].txWaitFrameCounter = 0u;
        CanTp_Channel[ch].state = CANTP_TX_CF;
        CanTp_Channel[ch].direction = CANTP_DIR_TX;
        CanTp_Channel[ch].txStTimer = ticks;
        CanTp_StartTimer(ch, CANTP_TIMER_N_CS);
    }
    else if (fs == CANTP_FS_WAIT)
    {
        CanTp_Channel[ch].txWaitFrameCounter++;

        if (CanTp_Channel[ch].txWaitFrameCounter > CANTP_WFT_MAX)
        {
            PduR_CanTpTxConfirmation(cfg->upperTxPduId, E_NOT_OK);
            CanTp_ResetChannel(ch);
        }
        else
        {
            CanTp_StartTimer(ch, CANTP_TIMER_N_BS);
        }
    }
    else
    {
        PduR_CanTpTxConfirmation(cfg->upperTxPduId, E_NOT_OK);
        CanTp_ResetChannel(ch);
    }
}

void CanTp_RxIndication(PduIdType CanIfRxPduId, const uint8* data, PduLengthType len)
{
    uint8 ch;
    uint8 pci;
    const CanTp_ChannelConfigType* cfg;

    if ((CanTp_IsConfigValid() == FALSE) || (data == NULL_PTR) || (len == 0u))
    {
        return;
    }

    ch = CanTp_FindRxChannel(CanIfRxPduId);

    if (ch >= CanTp_ConfigPtr->numChannels)
    {
        return;
    }

    cfg = &CanTp_ConfigPtr->channels[ch];

    if (CanTp_CheckRxAddress(cfg, data, len) == FALSE)
    {
        return;
    }

    pci = data[CanTp_GetRxPciIndex(cfg)] & 0xF0u;

    if ((cfg->addressingType == CANTP_ADDR_FUNCTIONAL) && (pci != CANTP_NPCI_SF))
    {
        return;
    }

    if (pci == CANTP_NPCI_SF)
    {
        CanTp_HandleSingleFrame(ch, data, len);
    }
    else if (pci == CANTP_NPCI_FF)
    {
        CanTp_HandleFirstFrame(ch, data, len);
    }
    else if (pci == CANTP_NPCI_CF)
    {
        CanTp_HandleConsecutiveFrame(ch, data, len);
    }
    else if (pci == CANTP_NPCI_FC)
    {
        CanTp_HandleFlowControl(ch, data, len);
    }
}

void CanTp_TxConfirmation(PduIdType CanIfTxPduId)
{
    uint8 ch;
    const CanTp_ChannelConfigType* cfg;
    CanTp_TxFrameType confirmedFrame;

    if (CanTp_IsConfigValid() == FALSE)
    {
        return;
    }

    ch = CanTp_FindChannelByCanIfTx(CanIfTxPduId);

    if (ch >= CanTp_ConfigPtr->numChannels)
    {
        return;
    }

    cfg = &CanTp_ConfigPtr->channels[ch];

    confirmedFrame = CanTp_Channel[ch].pendingTxFrame;
    CanTp_Channel[ch].txBusy = FALSE;
    CanTp_Channel[ch].pendingTxFrame = CANTP_TXFRAME_NONE;

    if (confirmedFrame == CANTP_TXFRAME_FC)
    {
        CanTp_Channel[ch].state = CANTP_RX_IN_PROGRESS;
        CanTp_Channel[ch].direction = CANTP_DIR_RX;
        CanTp_StartTimer(ch, CANTP_TIMER_N_CR);
    }
    else if (confirmedFrame == CANTP_TXFRAME_SF)
    {
        PduR_CanTpTxConfirmation(cfg->upperTxPduId, E_OK);
        CanTp_ResetChannel(ch);
    }
    else if (confirmedFrame == CANTP_TXFRAME_FF)
    {
        CanTp_Channel[ch].state = CANTP_TX_WAIT_FC;
        CanTp_Channel[ch].direction = CANTP_DIR_TX;
        CanTp_StartTimer(ch, CANTP_TIMER_N_BS);
    }
    else if (confirmedFrame == CANTP_TXFRAME_CF)
    {
        if (CanTp_Channel[ch].txOffset >= CanTp_Channel[ch].txLen)
        {
            PduR_CanTpTxConfirmation(cfg->upperTxPduId, E_OK);
            CanTp_ResetChannel(ch);
        }
        else if ((CanTp_Channel[ch].txBlockSize != 0u) &&
                 (CanTp_Channel[ch].txBlockCounter >= CanTp_Channel[ch].txBlockSize))
        {
            CanTp_Channel[ch].state = CANTP_TX_WAIT_FC;
            CanTp_StartTimer(ch, CANTP_TIMER_N_BS);
        }
        else
        {
            CanTp_Channel[ch].state = CANTP_TX_CF;
            CanTp_Channel[ch].txStTimer = CanTp_Channel[ch].txStMinTicks;
            CanTp_StartTimer(ch, CANTP_TIMER_N_CS);
        }
    }
}

void CanTp_MainFunction(void)
{
    uint8 ch;
    const CanTp_ChannelConfigType* cfg;

    if (CanTp_IsConfigValid() == FALSE)
    {
        return;
    }

    for (ch = 0u; ch < CanTp_ConfigPtr->numChannels; ch++)
    {
        cfg = &CanTp_ConfigPtr->channels[ch];

        if (CanTp_Channel[ch].state == CANTP_IDLE)
        {
            continue;
        }

        if (CanTp_Channel[ch].txStTimer > 0u)
        {
            CanTp_Channel[ch].txStTimer--;
        }

        if (CanTp_Channel[ch].timer > 0u)
        {
            CanTp_Channel[ch].timer--;
        }
        else
        {
            if (CanTp_Channel[ch].direction == CANTP_DIR_TX)
            {
                PduR_CanTpTxConfirmation(cfg->upperTxPduId, E_NOT_OK);
            }
            else if (CanTp_Channel[ch].direction == CANTP_DIR_RX)
            {
                PduR_CanTpRxIndication(cfg->upperRxPduId, E_NOT_OK);
            }

            CanTp_ResetChannel(ch);
            continue;
        }

        if (CanTp_Channel[ch].state == CANTP_TX_CF)
        {
            (void)CanTp_SendConsecutiveFrame(ch);
        }
    }
}
