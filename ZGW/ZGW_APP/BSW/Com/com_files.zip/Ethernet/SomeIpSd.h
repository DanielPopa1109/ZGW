#ifndef SOMEIPSD_H_
#define SOMEIPSD_H_

#include "Ifx_Types.h"
#include "SoAd.h"

#define SOMEIPSD_SERVICE_ID                 0xFFFFu
#define SOMEIPSD_METHOD_ID                  0x8100u
#define SOMEIPSD_PORT                       30490u
#define SOMEIPSD_MAX_SERVICES               8u
#define SOMEIPSD_MAX_SUBSCRIPTIONS          8u
#define SOMEIPSD_MAX_PACKET_LEN             512u

#define SOMEIPSD_ENTRY_FIND_SERVICE         0x00u
#define SOMEIPSD_ENTRY_OFFER_SERVICE        0x01u
#define SOMEIPSD_ENTRY_SUBSCRIBE_EVENTGROUP 0x06u
#define SOMEIPSD_ENTRY_SUBSCRIBE_ACK        0x07u

typedef struct
{
    uint16 serviceId;
    uint16 instanceId;
    uint8 majorVersion;
    uint32 ttl;
    uint16 udpPort;
    uint16 tcpPort;
} SomeIpSd_OfferedServiceType;

typedef struct
{
    SoAd_SoConIdType sdUdpSoConId;
    TcpIp_SockAddrType multicastAddr;
    const SomeIpSd_OfferedServiceType *services;
    uint8 serviceCount;
    uint32 offerPeriodMs;
} SomeIpSd_ConfigType;

typedef struct
{
    uint8 active;
    TcpIp_SockAddrType remoteAddr;
    uint16 serviceId;
    uint16 instanceId;
    uint16 eventgroupId;
    uint32 ttlMs;
} SomeIpSd_SubscriptionType;

void SomeIpSd_Init(const SomeIpSd_ConfigType *config);
void SomeIpSd_MainFunction(uint32 elapsedMs);

void SomeIpSd_SoAdRxIndication(SoAd_SoConIdType soConId,
                               const TcpIp_SockAddrType *remoteAddr,
                               const uint8 *data,
                               uint16 len);

const SomeIpSd_SubscriptionType *SomeIpSd_GetSubscriptions(void);

#endif
