#include "TcpIpH.h"
#include "lwip_geth_private_phy_dp83825i.h"
#include "lwip/sockets.h"
#include "lwip/inet.h"
#include "lwip/errno.h"

#define TCPIP_MAX_SOCKETS 16u

typedef struct
{
    TcpIp_SocketIdType sock;
    uint8 used;
    uint8 tcp;
} TcpIp_SocketType;

static TcpIp_SocketType TcpIp_Sockets[TCPIP_MAX_SOCKETS];

static uint8 TcpIp_IsLinkUp(void)
{
#if (PHY_DEVICE_NAME == PHY_DP83825I)
    return (uint8)lwip_geth_private_Phy_Dp83825i_is_link_up();
#else
    return 1u;
#endif
}

void TcpIp_Init(void)
{
    uint32 i;

    for (i = 0u; i < TCPIP_MAX_SOCKETS; i++)
    {
        TcpIp_Sockets[i].sock = TCPIP_INVALID_SOCKET;
        TcpIp_Sockets[i].used = 0u;
        TcpIp_Sockets[i].tcp = 0u;
    }
}

void TcpIp_MainFunction(void)
{
    uint32 i;

    if (TcpIp_IsLinkUp() == 0u)
    {
        for (i = 0u; i < TCPIP_MAX_SOCKETS; i++)
        {
            if (TcpIp_Sockets[i].used != 0u)
            {
                lwip_close(TcpIp_Sockets[i].sock);
                TcpIp_Sockets[i].sock = TCPIP_INVALID_SOCKET;
                TcpIp_Sockets[i].used = 0u;
            }
        }
    }
}

static TcpIp_SocketType *TcpIp_Alloc(void)
{
    uint32 i;

    for (i = 0u; i < TCPIP_MAX_SOCKETS; i++)
    {
        if (TcpIp_Sockets[i].used == 0u)
        {
            TcpIp_Sockets[i].used = 1u;
            return &TcpIp_Sockets[i];
        }
    }

    return 0;
}

TcpIp_SocketIdType TcpIp_Create(uint8 tcp)
{
    TcpIp_SocketType *s;
    sint32 type;

    s = TcpIp_Alloc();

    if (s == 0)
    {
        return TCPIP_INVALID_SOCKET;
    }

    type = (tcp != 0u) ? SOCK_STREAM : SOCK_DGRAM;

    s->sock = (TcpIp_SocketIdType)lwip_socket(AF_INET, type, 0);

    if (s->sock < 0)
    {
        s->used = 0u;
        s->sock = TCPIP_INVALID_SOCKET;
        return TCPIP_INVALID_SOCKET;
    }

    s->tcp = tcp;
    (void)lwip_fcntl(s->sock, F_SETFL, O_NONBLOCK);

    return s->sock;
}

sint32 TcpIp_Bind(TcpIp_SocketIdType sock, uint16 port)
{
    struct sockaddr_in addr;

    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    addr.sin_addr.s_addr = INADDR_ANY;

    return (sint32)lwip_bind(sock, (struct sockaddr *)&addr, sizeof(addr));
}

sint32 TcpIp_Listen(TcpIp_SocketIdType sock)
{
    return (sint32)lwip_listen(sock, 4);
}

TcpIp_SocketIdType TcpIp_Accept(TcpIp_SocketIdType sock, TcpIp_SockAddrType *remoteAddr)
{
    struct sockaddr_in addr;
    socklen_t len;
    sint32 newSock;

    len = sizeof(addr);
    newSock = lwip_accept(sock, (struct sockaddr *)&addr, &len);

    if (newSock >= 0)
    {
        (void)lwip_fcntl(newSock, F_SETFL, O_NONBLOCK);

        if (remoteAddr != 0)
        {
            remoteAddr->addr = addr.sin_addr.s_addr;
            remoteAddr->port = ntohs(addr.sin_port);
        }
    }

    return (TcpIp_SocketIdType)newSock;
}

sint32 TcpIp_Connect(TcpIp_SocketIdType sock, uint32 ip, uint16 port)
{
    struct sockaddr_in addr;

    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    addr.sin_addr.s_addr = ip;

    return (sint32)lwip_connect(sock, (struct sockaddr *)&addr, sizeof(addr));
}

sint32 TcpIp_Send(TcpIp_SocketIdType sock, const uint8 *data, uint16 len)
{
    if ((data == 0) || (len == 0u) || (TcpIp_IsLinkUp() == 0u))
    {
        return -1;
    }

    return (sint32)lwip_send(sock, data, len, 0);
}

sint32 TcpIp_SendTo(TcpIp_SocketIdType sock,
                    const TcpIp_SockAddrType *remoteAddr,
                    const uint8 *data,
                    uint16 len)
{
    struct sockaddr_in addr;

    if ((remoteAddr == 0) || (data == 0) || (len == 0u) || (TcpIp_IsLinkUp() == 0u))
    {
        return -1;
    }

    addr.sin_family = AF_INET;
    addr.sin_port = htons(remoteAddr->port);
    addr.sin_addr.s_addr = remoteAddr->addr;

    return (sint32)lwip_sendto(sock, data, len, 0, (struct sockaddr *)&addr, sizeof(addr));
}

sint32 TcpIp_Recv(TcpIp_SocketIdType sock, uint8 *data, uint16 len)
{
    if ((data == 0) || (len == 0u))
    {
        return -1;
    }

    return (sint32)lwip_recv(sock, data, len, 0);
}

sint32 TcpIp_RecvFrom(TcpIp_SocketIdType sock,
                      TcpIp_SockAddrType *remoteAddr,
                      uint8 *data,
                      uint16 len)
{
    struct sockaddr_in addr;
    socklen_t addrLen;
    sint32 ret;

    if ((data == 0) || (len == 0u))
    {
        return -1;
    }

    addrLen = sizeof(addr);

    ret = (sint32)lwip_recvfrom(sock, data, len, 0, (struct sockaddr *)&addr, &addrLen);

    if ((ret > 0) && (remoteAddr != 0))
    {
        remoteAddr->addr = addr.sin_addr.s_addr;
        remoteAddr->port = ntohs(addr.sin_port);
    }

    return ret;
}

void TcpIp_Close(TcpIp_SocketIdType sock)
{
    if (sock != TCPIP_INVALID_SOCKET)
    {
        (void)lwip_close(sock);
    }
}
