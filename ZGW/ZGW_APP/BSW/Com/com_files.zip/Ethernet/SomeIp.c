#include "SomeIp.h"
#include <string.h>

typedef struct
{
    uint8_t stream[SOMEIP_TCP_STREAM_BUF_LEN];
    uint16_t streamLen;
    uint32_t rxCnt;
    uint32_t txCnt;
    uint32_t parseErrCnt;
    uint32_t unknownSvcCnt;
    uint32_t unknownMethodCnt;
} SomeIp_RuntimeType;

static const SomeIp_ConfigType *SomeIp_Cfg;
static SomeIp_RuntimeType SomeIp_Rt;

static uint16_t rd16(const uint8_t *p)
{
    return (uint16_t)(((uint16_t)p[0] << 8u) | p[1]);
}

static uint32_t rd32(const uint8_t *p)
{
    return ((uint32_t)p[0] << 24u) |
           ((uint32_t)p[1] << 16u) |
           ((uint32_t)p[2] << 8u) |
           p[3];
}

static void wr16(uint8_t *p, uint16_t v)
{
    p[0] = (uint8_t)(v >> 8u);
    p[1] = (uint8_t)v;
}

static void wr32(uint8_t *p, uint32_t v)
{
    p[0] = (uint8_t)(v >> 24u);
    p[1] = (uint8_t)(v >> 16u);
    p[2] = (uint8_t)(v >> 8u);
    p[3] = (uint8_t)v;
}

static uint8_t SomeIp_ParseOne(const uint8_t *data,
                               uint32_t len,
                               SomeIp_MessageType *msg,
                               uint32_t *consumedLen)
{
    uint32_t lengthField;
    uint32_t totalLen;

    if ((data == 0) || (msg == 0) || (consumedLen == 0) || (len < SOMEIP_HEADER_LEN))
    {
        return 0u;
    }

    lengthField = rd32(&data[4]);

    if ((lengthField < 8u) || (lengthField > (SOMEIP_MAX_PAYLOAD_LEN + 8u)))
    {
        return 0u;
    }

    totalLen = lengthField + 8u;

    if (len < totalLen)
    {
        return 2u;
    }

    msg->serviceId = rd16(&data[0]);
    msg->methodId = rd16(&data[2]);
    msg->clientId = rd16(&data[8]);
    msg->sessionId = rd16(&data[10]);
    msg->protocolVersion = data[12];
    msg->interfaceVersion = data[13];
    msg->messageType = data[14];
    msg->returnCode = data[15];
    msg->payload = &data[16];
    msg->payloadLen = lengthField - 8u;

    *consumedLen = totalLen;

    return 1u;
}

static uint16_t SomeIp_Build(uint8_t *buf,
                             uint16_t serviceId,
                             uint16_t methodId,
                             uint16_t clientId,
                             uint16_t sessionId,
                             uint8_t interfaceVersion,
                             uint8_t messageType,
                             uint8_t returnCode,
                             const uint8_t *payload,
                             uint32_t payloadLen)
{
    wr16(&buf[0], serviceId);
    wr16(&buf[2], methodId);
    wr32(&buf[4], payloadLen + 8u);
    wr16(&buf[8], clientId);
    wr16(&buf[10], sessionId);

    buf[12] = SOMEIP_PROTOCOL_VERSION;
    buf[13] = interfaceVersion;
    buf[14] = messageType;
    buf[15] = returnCode;

    if ((payload != 0) && (payloadLen > 0u))
    {
        memcpy(&buf[16], payload, payloadLen);
    }

    return (uint16_t)(SOMEIP_HEADER_LEN + payloadLen);
}

static void SomeIp_SendError(SoAd_SoConIdType soConId,
                             const TcpIp_SockAddrType *remoteAddr,
                             const SomeIp_MessageType *request,
                             uint8_t errorCode)
{
    uint8_t tx[SOMEIP_HEADER_LEN];
    uint16_t len;

    if (request == 0)
    {
        return;
    }

    len = SomeIp_Build(tx,
                       request->serviceId,
                       request->methodId,
                       request->clientId,
                       request->sessionId,
                       request->interfaceVersion,
                       SOMEIP_MSG_ERROR,
                       errorCode,
                       0,
                       0u);

    (void)SoAd_IfTransmit(soConId, remoteAddr, tx, len);
}

static void SomeIp_Dispatch(SoAd_SoConIdType soConId,
                            const TcpIp_SockAddrType *remoteAddr,
                            const SomeIp_MessageType *msg)
{
    uint16_t i;
    uint8_t serviceSeen = 0u;

    if ((SomeIp_Cfg == 0) || (msg == 0))
    {
        return;
    }

    if (msg->protocolVersion != SOMEIP_PROTOCOL_VERSION)
    {
        SomeIp_SendError(soConId, remoteAddr, msg, SOMEIP_RET_WRONG_PROTOCOL_VERSION);
        return;
    }

    if ((msg->messageType != SOMEIP_MSG_REQUEST) &&
        (msg->messageType != SOMEIP_MSG_REQUEST_NO_RET) &&
        (msg->messageType != SOMEIP_MSG_NOTIFICATION))
    {
        SomeIp_SendError(soConId, remoteAddr, msg, SOMEIP_RET_MALFORMED_MESSAGE);
        return;
    }

    for (i = 0u; i < SomeIp_Cfg->methodCount; i++)
    {
        const SomeIp_MethodConfigType *m = &SomeIp_Cfg->methods[i];

        if (m->serviceId == msg->serviceId)
        {
            serviceSeen = 1u;
        }

        if ((m->serviceId == msg->serviceId) &&
            (m->methodId == msg->methodId) &&
            (m->interfaceVersion == msg->interfaceVersion))
        {
            if (m->handler != 0)
            {
                SomeIp_Rt.rxCnt++;
                m->handler(soConId, remoteAddr, msg);
                return;
            }

            SomeIp_SendError(soConId, remoteAddr, msg, SOMEIP_RET_NOT_READY);
            return;
        }
    }

    if (serviceSeen == 0u)
    {
        SomeIp_Rt.unknownSvcCnt++;
        SomeIp_SendError(soConId, remoteAddr, msg, SOMEIP_RET_UNKNOWN_SERVICE);
    }
    else
    {
        SomeIp_Rt.unknownMethodCnt++;
        SomeIp_SendError(soConId, remoteAddr, msg, SOMEIP_RET_UNKNOWN_METHOD);
    }
}

static void SomeIp_ProcessTcpStream(SoAd_SoConIdType soConId,
                                    const TcpIp_SockAddrType *remoteAddr)
{
    SomeIp_MessageType msg;
    uint32_t consumed;
    uint8_t ret;

    while (SomeIp_Rt.streamLen >= SOMEIP_HEADER_LEN)
    {
        ret = SomeIp_ParseOne(SomeIp_Rt.stream,
                              SomeIp_Rt.streamLen,
                              &msg,
                              &consumed);

        if (ret == 2u)
        {
            return;
        }

        if (ret == 0u)
        {
            SomeIp_Rt.streamLen = 0u;
            SomeIp_Rt.parseErrCnt++;
            return;
        }

        SomeIp_Dispatch(soConId, remoteAddr, &msg);

        if (SomeIp_Rt.streamLen > consumed)
        {
            memmove(&SomeIp_Rt.stream[0],
                    &SomeIp_Rt.stream[consumed],
                    SomeIp_Rt.streamLen - consumed);
        }

        SomeIp_Rt.streamLen = (uint16_t)(SomeIp_Rt.streamLen - consumed);
    }
}

void SomeIp_Init(const SomeIp_ConfigType *config)
{
    SomeIp_Cfg = config;
    memset(&SomeIp_Rt, 0, sizeof(SomeIp_Rt));
}

void SomeIp_MainFunction(uint32 elapsedMs)
{
    (void)elapsedMs;
}

void SomeIp_SoAdTcpConnected(SoAd_SoConIdType soConId)
{
    (void)soConId;
    SomeIp_Rt.streamLen = 0u;
}

void SomeIp_SoAdTcpDisconnected(SoAd_SoConIdType soConId)
{
    (void)soConId;
    SomeIp_Rt.streamLen = 0u;
}

void SomeIp_SoAdRxIndication(SoAd_SoConIdType soConId,
                             const TcpIp_SockAddrType *remoteAddr,
                             const uint8_t *data,
                             uint16_t len)
{
    SomeIp_MessageType msg;
    uint32_t consumed;
    uint8_t ret;

    if ((SomeIp_Cfg == 0) || (data == 0) || (len == 0u))
    {
        return;
    }

    if (soConId == SomeIp_Cfg->tcpSoConId)
    {
        if ((uint32_t)SomeIp_Rt.streamLen + len > SOMEIP_TCP_STREAM_BUF_LEN)
        {
            SomeIp_Rt.streamLen = 0u;
            SomeIp_Rt.parseErrCnt++;
            return;
        }

        memcpy(&SomeIp_Rt.stream[SomeIp_Rt.streamLen], data, len);
        SomeIp_Rt.streamLen = (uint16_t)(SomeIp_Rt.streamLen + len);

        SomeIp_ProcessTcpStream(soConId, remoteAddr);
        return;
    }

    ret = SomeIp_ParseOne(data, len, &msg, &consumed);

    if ((ret != 1u) || (consumed != len))
    {
        SomeIp_Rt.parseErrCnt++;
        return;
    }

    SomeIp_Dispatch(soConId, remoteAddr, &msg);
}

uint8_t SomeIp_SendResponse(SoAd_SoConIdType soConId,
                            const TcpIp_SockAddrType *remoteAddr,
                            const SomeIp_MessageType *request,
                            const uint8 *payload,
                            uint32 payloadLen,
                            uint8 returnCode)
{
    uint8_t tx[SOMEIP_HEADER_LEN + SOMEIP_MAX_PAYLOAD_LEN];
    uint16_t len;

    if ((request == 0) || (payloadLen > SOMEIP_MAX_PAYLOAD_LEN))
    {
        return 0u;
    }

    len = SomeIp_Build(tx,
                       request->serviceId,
                       request->methodId,
                       request->clientId,
                       request->sessionId,
                       request->interfaceVersion,
                       SOMEIP_MSG_RESPONSE,
                       returnCode,
                       payload,
                       payloadLen);

    if (SoAd_IfTransmit(soConId, remoteAddr, tx, len) == SOAD_OK)
    {
        SomeIp_Rt.txCnt++;
        return 1u;
    }

    return 0u;
}

uint8_t SomeIp_SendNotification(SoAd_SoConIdType soConId,
                                const TcpIp_SockAddrType *remoteAddr,
                                uint16 serviceId,
                                uint16 eventId,
                                uint16 clientId,
                                uint16 sessionId,
                                uint8 interfaceVersion,
                                const uint8 *payload,
                                uint32 payloadLen)
{
    uint8_t tx[SOMEIP_HEADER_LEN + SOMEIP_MAX_PAYLOAD_LEN];
    uint16_t len;

    if (payloadLen > SOMEIP_MAX_PAYLOAD_LEN)
    {
        return 0u;
    }

    len = SomeIp_Build(tx,
                       serviceId,
                       eventId,
                       clientId,
                       sessionId,
                       interfaceVersion,
                       SOMEIP_MSG_NOTIFICATION,
                       SOMEIP_RET_OK,
                       payload,
                       payloadLen);

    if (SoAd_IfTransmit(soConId, remoteAddr, tx, len) == SOAD_OK)
    {
        SomeIp_Rt.txCnt++;
        return 1u;
    }

    return 0u;
}
