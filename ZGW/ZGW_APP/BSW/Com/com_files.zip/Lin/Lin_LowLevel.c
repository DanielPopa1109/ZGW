#include "Lin_LowLevel.h"
#include "Lin.h"
#include "Lin_Cfg.h"

#include "IfxPort.h"
#include <string.h>

static IfxAsclin_Lin Lin_Ild;
static uint8 Lin_LastPid;
static uint8 Lin_ResponseLen;
static uint8 Lin_RxEnabled;

#define LIN_PIN_OUTPUT_IDX   IfxPort_OutputIdx_general

void Lin_LowLevel_Init(void)
{
    IfxAsclin_Lin_Config cfg;

    IfxAsclin_Lin_initModuleConfig(&cfg, &LIN_ASCLIN_MODULE);

    cfg.linMode = IfxAsclin_LinMode_master;
    cfg.brg.baudrate = LIN_DEFAULT_BAUDRATE;
    cfg.lin.breakLength = 13u;
    cfg.data.checksum = IfxAsclin_Checksum_enhanced;
    cfg.data.responseTimeout = 255u;
    cfg.isInterruptMode = FALSE;
    cfg.pins = &LIN_PINS;

    IfxAsclin_Lin_initModule(&Lin_Ild, &cfg);

    Lin_RxEnabled = FALSE;
    Lin_LastPid = 0u;
    Lin_ResponseLen = 0u;
}

void Lin_LowLevel_SendBreak(uint8 Channel)
{
    uint8 id;

    (void)Channel;

    /*
     * iLLD LIN API sends break+sync+PID through sendHeader().
     * Upper Lin state machine still models BREAK/SYNC/PID logically.
     */
    id = 0u;
    (void)id;

    Lin_IsrTxDone(LIN_CHANNEL_0);
}

void Lin_LowLevel_SendByte(uint8 Channel, uint8 byte)
{
    static uint8 headerPhase = 0u;
    static uint8 txData[8u];
    static uint8 txLen = 0u;

    (void)Channel;

    if (byte == 0x55u)
    {
        headerPhase = 1u;
        return;
    }

    if (headerPhase == 1u)
    {
        Lin_LastPid = byte;
        headerPhase = 0u;

        {
            uint8 id = (uint8)(Lin_LastPid & 0x3Fu);
            IfxAsclin_Lin_sendHeader(&Lin_Ild, &id);
        }

        Lin_IsrTxDone(LIN_CHANNEL_0);
        return;
    }

    if (txLen >= sizeof(txData))
    {
        txLen = 0u;
        Lin_IsrError(LIN_CHANNEL_0, LIN_RES_NOT_OK);
        return;
    }

    txData[txLen] = byte;
    txLen++;

    if (txLen >= Lin_ResponseLen)
    {
        IfxAsclin_Lin_sendResponse(&Lin_Ild, txData, txLen);
        txLen = 0u;
        Lin_IsrTxDone(LIN_CHANNEL_0);
    }
}

void Lin_LowLevel_EnableRx(uint8 Channel)
{
    uint8 rx[LIN_MAX_DATA_LEN + 1u];
    uint32 i;

    (void)Channel;

    Lin_RxEnabled = TRUE;

    if (Lin_ResponseLen == 0u)
    {
        return;
    }

    IfxAsclin_Lin_receiveResponse(&Lin_Ild, rx, Lin_ResponseLen);

    if (Lin_RxEnabled != FALSE)
    {
        for (i = 0u; i < Lin_ResponseLen; i++)
        {
            Lin_IsrRxByte(LIN_CHANNEL_0, rx[i]);
        }
    }
}

void Lin_LowLevel_DisableRx(uint8 Channel)
{
    (void)Channel;
    Lin_RxEnabled = FALSE;
}

void Lin_LowLevel_WakeupPulse(uint8 Channel)
{
    volatile uint32 delay;

    (void)Channel;

    IfxPort_setPinModeOutput(LIN_TX_PORT,
            LIN_TX_PIN_INDEX,
            IfxPort_OutputMode_pushPull,
            LIN_PIN_OUTPUT_IDX);

    IfxPort_setPinLow(LIN_TX_PORT, LIN_TX_PIN_INDEX);

    for (delay = 0u; delay < LIN_WAKEUP_DELAY_TICKS; delay++)
    {
        __asm("nop");
    }

    IfxPort_setPinHigh(LIN_TX_PORT, LIN_TX_PIN_INDEX);
}

void Lin_LowLevel_SetResponseLength(uint8 len)
{
    Lin_ResponseLen = len;
}
