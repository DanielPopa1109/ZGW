#include "Lin_Protocol.h"

uint8 Lin_MakePid(uint8 id)
{
    uint8 p0;
    uint8 p1;

    id &= 0x3Fu;

    p0 = (uint8)(((id >> 0u) ^ (id >> 1u) ^ (id >> 2u) ^ (id >> 4u)) & 1u);
    p1 = (uint8)(~(((id >> 1u) ^ (id >> 3u) ^ (id >> 4u) ^ (id >> 5u)) & 1u) & 1u);

    return (uint8)(id | (p0 << 6u) | (p1 << 7u));
}

Std_ReturnType Lin_CheckPid(uint8 pid, uint8* idOut)
{
    uint8 id;

    if (idOut == NULL_PTR)
    {
        return E_NOT_OK;
    }

    id = (uint8)(pid & 0x3Fu);

    if (Lin_MakePid(id) != pid)
    {
        return E_NOT_OK;
    }

    *idOut = id;
    return E_OK;
}

uint8 Lin_CalcChecksum(uint8 pid, const uint8* data, uint8 len, Lin_ChecksumType type)
{
    uint16 sum;
    uint8 i;

    if ((data == NULL_PTR) || (len > 8u))
    {
        return 0x00u;
    }

    sum = 0u;

    if ((type == LIN_CS_ENHANCED) &&
        ((pid & 0x3Fu) != 0x3Cu) &&
        ((pid & 0x3Fu) != 0x3Du))
    {
        sum += pid;
    }

    for (i = 0u; i < len; i++)
    {
        sum += data[i];

        while (sum > 0xFFu)
        {
            sum = (uint16)((sum & 0xFFu) + (sum >> 8u));
        }
    }

    return (uint8)(~sum);
}
