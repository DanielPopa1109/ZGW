#include "LinIf.h"
#include "LinTp.h"
#include "PduR.h"
#include <string.h>
#include "SysMgr.h"

static const Lin_FrameConfigType LinIf_Frame_MRF =
{
    0x3Cu, LIN_PID_MASTER_REQUEST, 8u, LIN_CS_CLASSIC, LIN_FRM_DIAGNOSTIC_MRF, 20u
};

static const Lin_FrameConfigType LinIf_Frame_SRF =
{
    0x3Du, LIN_PID_SLAVE_RESPONSE, 8u, LIN_CS_CLASSIC, LIN_FRM_DIAGNOSTIC_SRF, 20u
};

static const Lin_FrameConfigType LinIf_Frame_ZGW_NM3 =
{
    0x01u, 0u, 1u, LIN_CS_ENHANCED, LIN_FRM_UNCONDITIONAL, 20u
};

static const Lin_FrameConfigType LinIf_Frame_ZGW_REQUEST_ALT =
{
    0x02u, 0u, 4u, LIN_CS_ENHANCED, LIN_FRM_UNCONDITIONAL, 20u
};

static const Lin_FrameConfigType LinIf_Frame_ZGW_REQUEST_HVDCDC =
{
    0x03u, 0u, 2u, LIN_CS_ENHANCED, LIN_FRM_UNCONDITIONAL, 20u
};

static const Lin_FrameConfigType LinIf_Frame_ZGW_REQUEST_PCU48 =
{
    0x04u, 0u, 1u, LIN_CS_ENHANCED, LIN_FRM_UNCONDITIONAL, 20u
};

static const Lin_FrameConfigType LinIf_Frame_ALT_STATUS =
{
    0x0Au, 0u, 7u, LIN_CS_ENHANCED, LIN_FRM_UNCONDITIONAL, 20u
};

static const Lin_FrameConfigType LinIf_Frame_HVDCDC_STATUS =
{
    0x0Bu, 0u, 5u, LIN_CS_ENHANCED, LIN_FRM_UNCONDITIONAL, 20u
};

static const Lin_FrameConfigType LinIf_Frame_PCU48_STATUS =
{
    0x0Cu, 0u, 5u, LIN_CS_ENHANCED, LIN_FRM_UNCONDITIONAL, 20u
};
static const LinIf_ScheduleEntryType LinIf_NormalEntries[] =
{
    { &LinIf_Frame_ZGW_NM3, 10u, LIN_MASTER_RESPONSE },
    { &LinIf_Frame_ZGW_REQUEST_PCU48, 10u, LIN_MASTER_RESPONSE },
    { &LinIf_Frame_ZGW_REQUEST_HVDCDC, 10u, LIN_MASTER_RESPONSE },
    { &LinIf_Frame_ZGW_REQUEST_ALT, 10u, LIN_MASTER_RESPONSE },
    { &LinIf_Frame_PCU48_STATUS, 10u, LIN_SLAVE_RESPONSE },
    { &LinIf_Frame_HVDCDC_STATUS, 10u, LIN_SLAVE_RESPONSE },
    { &LinIf_Frame_ALT_STATUS, 10u, LIN_SLAVE_RESPONSE }
};


static const LinIf_ScheduleEntryType LinIf_DiagReqEntries[] =
{
    { &LinIf_Frame_MRF, 10u, LIN_MASTER_RESPONSE }
};

static const LinIf_ScheduleEntryType LinIf_DiagRespEntries[] =
{
    { &LinIf_Frame_SRF, 10u, LIN_SLAVE_RESPONSE }
};

static const LinIf_ScheduleTableType LinIf_Schedules[] =
{
    { LinIf_NormalEntries,   (uint8)(sizeof(LinIf_NormalEntries) / sizeof(LinIf_NormalEntries[0])),   FALSE },
    { LinIf_DiagReqEntries,  (uint8)(sizeof(LinIf_DiagReqEntries) / sizeof(LinIf_DiagReqEntries[0])),  TRUE  },
    { LinIf_DiagRespEntries, (uint8)(sizeof(LinIf_DiagRespEntries) / sizeof(LinIf_DiagRespEntries[0])), TRUE  }
};

typedef struct
{
    PduIdType pduId;
    uint8 frameId;
    uint8 dlc;
} LinIf_AppPduConfigType;

typedef struct
{
    uint8 data[LIN_MAX_DATA_LEN];
    uint8 valid;
} LinIf_AppTxRuntimeType;

typedef struct
{
    uint8 activeSchedule;
    uint8 index;
    uint16 timer;
    uint8 busy;

    uint8 diagReq[8];
    uint8 diagResp[8];
    uint8 diagRespValid;
    LinIf_DiagStateType diagState;

    uint16 diagTimer;
    LinIf_ChannelStateType channelState;
    uint32 scheduleErrorCounter;
    uint32 diagTimeoutCounter;
} LinIf_StateType;

static const LinIf_AppPduConfigType LinIf_AppTxPduCfg[] =
{
    { LINIF_TX_PDU_ZGW_NM3, 0x01u, 1u },
    { LINIF_TX_PDU_ZGW_REQUEST_ALT, 0x02u, 4u },
    { LINIF_TX_PDU_ZGW_REQUEST_HVDCDC, 0x03u, 2u },
    { LINIF_TX_PDU_ZGW_REQUEST_PCU48, 0x04u, 1u }
};

static const LinIf_AppPduConfigType LinIf_AppRxPduCfg[] =
{
    { LINIF_RX_PDU_ALT_STATUS, 0x0Au, 7u },
    { LINIF_RX_PDU_HVDCDC_STATUS, 0x0Bu, 5u },
    { LINIF_RX_PDU_PCU48_STATUS, 0x0Cu, 5u }
};

static LinIf_StateType LinIf_State;
static LinIf_AppTxRuntimeType LinIf_AppTxRt[sizeof(LinIf_AppTxPduCfg) / sizeof(LinIf_AppTxPduCfg[0])];

static uint8 LinIf_FindTxPdu(PduIdType pduId)
{
    uint8 i;

    for (i = 0u; i < (uint8)(sizeof(LinIf_AppTxPduCfg) / sizeof(LinIf_AppTxPduCfg[0])); i++)
    {
        if (LinIf_AppTxPduCfg[i].pduId == pduId)
        {
            return i;
        }
    }

    return 0xFFu;
}

static uint8 LinIf_FindTxPduByFrameId(uint8 frameId)
{
    uint8 i;

    for (i = 0u; i < (uint8)(sizeof(LinIf_AppTxPduCfg) / sizeof(LinIf_AppTxPduCfg[0])); i++)
    {
        if (LinIf_AppTxPduCfg[i].frameId == frameId)
        {
            return i;
        }
    }

    return 0xFFu;
}

static uint8 LinIf_FindRxPduByFrameId(uint8 frameId)
{
    uint8 i;

    for (i = 0u; i < (uint8)(sizeof(LinIf_AppRxPduCfg) / sizeof(LinIf_AppRxPduCfg[0])); i++)
    {
        if (LinIf_AppRxPduCfg[i].frameId == frameId)
        {
            return i;
        }
    }

    return 0xFFu;
}

void LinIf_Init(void)
{
    memset(&LinIf_State, 0, sizeof(LinIf_State));
    memset(LinIf_AppTxRt, 0, sizeof(LinIf_AppTxRt));

    LinIf_State.activeSchedule = LINIF_SCHED_NORMAL;
    LinIf_State.diagState = LINIF_DIAG_IDLE;
    LinIf_State.channelState = LINIF_CHANNEL_IDLE;

    Lin_Init();
}

Std_ReturnType LinIf_SwitchSchedule(uint8 scheduleId)
{
    if (scheduleId >= (uint8)(sizeof(LinIf_Schedules) / sizeof(LinIf_Schedules[0])))
    {
        return E_NOT_OK;
    }

    LinIf_State.activeSchedule = scheduleId;
    LinIf_State.index = 0u;
    LinIf_State.timer = 0u;
    LinIf_State.busy = FALSE;

    return E_OK;
}

Std_ReturnType LinIf_Transmit(PduIdType LinIfTxPduId,
                              const uint8* data,
                              PduLengthType len)
{
    uint8 txIdx;

    if ((data == NULL_PTR) || (len == 0u) || (len > LIN_MAX_DATA_LEN))
    {
        return E_NOT_OK;
    }

    txIdx = LinIf_FindTxPdu(LinIfTxPduId);

    if (txIdx == 0xFFu)
    {
        return E_NOT_OK;
    }

    if (len != LinIf_AppTxPduCfg[txIdx].dlc)
    {
        return E_NOT_OK;
    }

    memcpy(LinIf_AppTxRt[txIdx].data, data, len);
    LinIf_AppTxRt[txIdx].valid = TRUE;

    return E_OK;
}

Std_ReturnType LinIf_SetDiagRequest(const uint8 data[8])
{
    if (data == NULL_PTR)
    {
        return E_NOT_OK;
    }

    if ((LinIf_State.diagState != LINIF_DIAG_IDLE) &&
        (LinIf_State.diagState != LINIF_DIAG_DONE) &&
        (LinIf_State.diagState != LINIF_DIAG_ERROR))
    {
        return E_NOT_OK;
    }

    memcpy(LinIf_State.diagReq, data, 8u);
    LinIf_State.diagRespValid = FALSE;
    LinIf_State.diagState = LINIF_DIAG_MRF_PENDING;
    LinIf_State.diagTimer = LINIF_DIAG_TIMEOUT_TICKS;

    return LinIf_SwitchSchedule(LINIF_SCHED_DIAG_REQ);
}

Std_ReturnType LinIf_GetDiagResponse(uint8 data[8])
{
    if ((data == NULL_PTR) || (LinIf_State.diagRespValid == FALSE))
    {
        return E_NOT_OK;
    }

    memcpy(data, LinIf_State.diagResp, 8u);
    LinIf_State.diagRespValid = FALSE;

    return E_OK;
}

LinIf_DiagStateType LinIf_GetDiagState(void)
{
    return LinIf_State.diagState;
}

void LinIf_DiagFrameDone(uint8 success)
{
    if (success == FALSE)
    {
        LinIf_State.diagState = LINIF_DIAG_ERROR;
        LinIf_State.channelState = LINIF_CHANNEL_ERROR;
        LinIf_State.scheduleErrorCounter++;
        (void)LinIf_SwitchSchedule(LINIF_SCHED_NORMAL);
        return;
    }

    if (LinIf_State.diagState == LINIF_DIAG_MRF_ACTIVE)
    {
        LinIf_State.diagState = LINIF_DIAG_SRF_PENDING;
        (void)LinIf_SwitchSchedule(LINIF_SCHED_DIAG_RESP);
    }
    else if (LinIf_State.diagState == LINIF_DIAG_SRF_ACTIVE)
    {
        LinIf_State.diagState = LINIF_DIAG_DONE;
        (void)LinIf_SwitchSchedule(LINIF_SCHED_NORMAL);
    }
}

static Std_ReturnType LinIf_TransmitFrame(const LinIf_ScheduleEntryType* entry)
{
    Lin_PduType pdu;
    uint8 txIdx;

    if ((entry == NULL_PTR) || (entry->frame == NULL_PTR))
    {
        return E_NOT_OK;
    }

    memset(&pdu, 0, sizeof(pdu));

    pdu.pid = entry->frame->pid;
    pdu.dlc = entry->frame->dlc;
    pdu.checksumType = entry->frame->checksumType;

    if ((pdu.pid == 0u) && (entry->frame->id <= 0x3Fu))
    {
        pdu.pid = Lin_MakePid(entry->frame->id);
    }

    if (entry->frame->frameClass == LIN_FRM_DIAGNOSTIC_MRF)
    {
        pdu.direction = LIN_MASTER_RESPONSE;
        memcpy(pdu.data, LinIf_State.diagReq, 8u);
        LinIf_State.diagState = LINIF_DIAG_MRF_ACTIVE;
    }
    else if (entry->frame->frameClass == LIN_FRM_DIAGNOSTIC_SRF)
    {
        pdu.direction = LIN_SLAVE_RESPONSE;
        LinIf_State.diagState = LINIF_DIAG_SRF_ACTIVE;
    }
    else
    {
        pdu.direction = entry->direction;

        if (entry->direction == LIN_MASTER_RESPONSE)
        {
            txIdx = LinIf_FindTxPduByFrameId(entry->frame->id);

            if (txIdx != 0xFFu)
            {
                if (LinIf_AppTxRt[txIdx].valid != FALSE)
                {
                    memcpy(pdu.data, LinIf_AppTxRt[txIdx].data, entry->frame->dlc);
                }
                else
                {
                    memset(pdu.data, 0u, entry->frame->dlc);
                }
            }
        }
    }

    return Lin_SendFrame(LIN_CHANNEL_0, &pdu);
}

void LinIf_MainFunction(void)
{
    const LinIf_ScheduleTableType* sched;
    const LinIf_ScheduleEntryType* entry;
    uint8 rx[8];
    uint8 len;
    uint8 rxIdx;
    uint8 txIdx;
    Lin_ResultType res;

    Lin_MainFunction();

    if ((LinIf_State.diagState != LINIF_DIAG_IDLE) &&
        (LinIf_State.diagState != LINIF_DIAG_DONE) &&
        (LinIf_State.diagState != LINIF_DIAG_ERROR))
    {
        if (LinIf_State.diagTimer > 0u)
        {
            LinIf_State.diagTimer--;
        }
        else
        {
            LinIf_State.diagTimeoutCounter++;
            LinIf_State.diagState = LINIF_DIAG_ERROR;
            LinIf_State.busy = FALSE;
            LinIf_State.channelState = LINIF_CHANNEL_ERROR;
            (void)LinIf_SwitchSchedule(LINIF_SCHED_NORMAL);
            return;
        }
    }

    if (LinIf_State.busy == TRUE)
    {
        if (Lin_GetState(LIN_CHANNEL_0) == LIN_IDLE)
        {
            entry = &LinIf_Schedules[LinIf_State.activeSchedule].entries[LinIf_State.index];
            res = Lin_GetStatus(LIN_CHANNEL_0, rx, &len);

            if (res == LIN_RES_OK)
            {
                SysMgr_BusActivityCounter = 400u;
                SysMgr_NoBusActivity = 1u;

                if (entry->frame->frameClass == LIN_FRM_DIAGNOSTIC_MRF)
                {
                    LinTp_TxFrameConfirmation(TRUE);
                    LinIf_DiagFrameDone(TRUE);
                }
                else if (entry->frame->frameClass == LIN_FRM_DIAGNOSTIC_SRF)
                {
                    memcpy(LinIf_State.diagResp, rx, 8u);
                    LinIf_State.diagRespValid = TRUE;

                    LinTp_RxSlaveResponse(rx);
                    LinIf_DiagFrameDone(TRUE);
                }
                else if (entry->frame->frameClass == LIN_FRM_UNCONDITIONAL)
                {
                    if (entry->direction == LIN_SLAVE_RESPONSE)
                    {
                        rxIdx = LinIf_FindRxPduByFrameId(entry->frame->id);

                        if (rxIdx != 0xFFu)
                        {
                            PduR_LinIfRxIndication(LinIf_AppRxPduCfg[rxIdx].pduId, rx, (PduLengthType)len);
                        }
                    }
                    else if (entry->direction == LIN_MASTER_RESPONSE)
                    {
                        txIdx = LinIf_FindTxPduByFrameId(entry->frame->id);

                        if (txIdx != 0xFFu)
                        {
                            PduR_LinIfTxConfirmation(LinIf_AppTxPduCfg[txIdx].pduId);
                        }
                    }
                }
            }
            else
            {
                if (entry->frame->frameClass == LIN_FRM_DIAGNOSTIC_MRF)
                {
                    LinTp_TxFrameConfirmation(FALSE);
                    LinIf_DiagFrameDone(FALSE);
                }
                else if (entry->frame->frameClass == LIN_FRM_DIAGNOSTIC_SRF)
                {
                    LinIf_DiagFrameDone(FALSE);
                }
                else if ((entry->frame->frameClass == LIN_FRM_UNCONDITIONAL) &&
                         (entry->direction == LIN_MASTER_RESPONSE))
                {
                    txIdx = LinIf_FindTxPduByFrameId(entry->frame->id);

                    if (txIdx != 0xFFu)
                    {
                        PduR_LinIfTxConfirmation(LinIf_AppTxPduCfg[txIdx].pduId);
                    }
                }
            }

            LinIf_State.busy = FALSE;
            LinIf_State.channelState = LINIF_CHANNEL_IDLE;
            LinIf_State.index++;

            sched = &LinIf_Schedules[LinIf_State.activeSchedule];

            if (LinIf_State.index >= sched->numEntries)
            {
                if (sched->runOnce != FALSE)
                {
                    if ((LinIf_State.diagState != LINIF_DIAG_SRF_PENDING) &&
                        (LinIf_State.diagState != LINIF_DIAG_MRF_ACTIVE))
                    {
                        (void)LinIf_SwitchSchedule(LINIF_SCHED_NORMAL);
                    }
                }
                else
                {
                    LinIf_State.index = 0u;
                }
            }
        }

        return;
    }

    if (LinIf_State.timer > 0u)
    {
        LinIf_State.timer--;
        return;
    }

    sched = &LinIf_Schedules[LinIf_State.activeSchedule];
    entry = &sched->entries[LinIf_State.index];

    if (LinIf_TransmitFrame(entry) == E_OK)
    {
        LinIf_State.timer = entry->delayTicks;
        LinIf_State.busy = TRUE;
        LinIf_State.channelState = LINIF_CHANNEL_BUSY;
        Lin_SetResponseTimeout(entry->frame->responseTimeoutTicks);
    }
}

LinIf_ChannelStateType LinIf_GetChannelState(void)
{
    return LinIf_State.channelState;
}

void LinIf_ResetDiagnostic(void)
{
    LinIf_State.diagRespValid = FALSE;
    LinIf_State.diagState = LINIF_DIAG_IDLE;
    LinIf_State.diagTimer = 0u;
}
